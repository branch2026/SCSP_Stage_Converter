"""Local, per-run batch receipts for the Windows GUI."""
import json
import os
import time
import uuid
from html import escape
from pathlib import Path


def atomic_text(path, text):
    temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(text, encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def effective_mode(task, default):
    override = task.get("include_inactive")
    return override if isinstance(override, bool) else default


class BatchReport:
    def __init__(self, parent, tasks, settings):
        name = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
        self.folder = Path(parent).resolve() / "BatchReports" / name
        self.folder.mkdir(parents=True)
        self.rows = [
            dict(scene=t["scene"], root=t["root"], project=t.get("project") or settings.get("project", ""),
                 include_inactive=effective_mode(t, settings["include_inactive"]), status="未执行")
            for t in tasks
        ]
        for task,row in zip(tasks,self.rows):
            if task.get("root_selection"):
                row["root_selection"] = task["root_selection"]
        self.message = "运行中"
        self.save()

    def record(self, index, output, stem, error=None):
        row = self.rows[index]
        row["status"] = "失败" if error else "成功"
        if error:
            log = self.folder / f"failure-{index + 1}.txt"
            atomic_text(log, error)
            row.update(error=error.strip().splitlines()[-1], failure_log=str(log))
        if output:
            folder = Path(output)
            row["output"] = str(folder)
            if not error:
                row["pmx"] = str(folder / (stem + ".pmx"))
            quality = folder / (stem + "_quality_report.json")
            try:
                summary = json.loads(quality.read_text(encoding="utf-8-sig"))["summary"]
                row.update(quality=str(quality), quality_status=summary["status"],
                           warnings=summary["warnings"], failures=summary["failures"])
            except (OSError, ValueError, KeyError, TypeError):
                row["quality_status"] = "报告不可用"
            auto = folder / "AutoStage" / "AutoStage_Report.json"
            if auto.is_file():
                row["auto_stage_report"] = str(auto)
                try:
                    restoration = json.loads(auto.read_text(encoding="utf-8-sig"))
                    preview = restoration.get("mme_preview",{})
                    if preview.get("folder") and preview.get("pmx"):
                        effect_pmx = auto.parent / preview["folder"] / preview["pmx"]
                        if effect_pmx.is_file():
                            row["mme_pmx"] = str(effect_pmx)
                    row["effect_modes"] = restoration.get("effect_coverage",{}).get("mme_material_modes",{})
                    row["mme_status"] = preview.get("status","未生成")
                except (OSError,ValueError,AttributeError,TypeError):
                    row["mme_status"] = "报告不可用"
        self.save()

    def save(self):
        data = dict(version="5.3", status=self.message, tasks=self.rows)
        atomic_text(self.folder / "batch.json", json.dumps(data, ensure_ascii=False, indent=2))
        rows = []
        for task in self.rows:
            links = []
            for key, label in (("output", "目录"), ("pmx", "基础 PMX"), ("mme_pmx", "效果 PMX"),
                               ("auto_stage_report", "效果报告"), ("quality", "质量报告"), ("failure_log", "失败日志")):
                if key in task:
                    url = escape(Path(task[key]).as_uri(), quote=True)
                    links.append(f'<a href="{url}">{label}</a>')
            cells = [task["root"], task["scene"], "包含" if task["include_inactive"] else "排除",
                     task["status"], task.get("quality_status", "—"), str(task.get("warnings", "—")),
                     task.get("mme_status", "—"), task.get("error", "")]
            rows.append("<tr>" + "".join("<td>" + escape(s) + "</td>" for s in cells)
                        + "<td>" + " · ".join(links) + "</td></tr>")
        html = ('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>批量转换报告</title>'
                '<style>body{font:16px system-ui;margin:3vw;color:#192f41}table{border-collapse:collapse}'
                'td,th{padding:.7em;border:1px solid #ccd5db;text-align:left}th{background:#eff5f7}</style>'
                '<h1>V5.3 批量转换报告</h1><p>' + escape(self.message) + '</p><table><tr>'
                '<th>舞台</th><th>场景</th><th>inactive</th><th>转换</th><th>质量</th>'
                '<th>警告数</th><th>舞台效果</th><th>失败原因</th><th>文件</th></tr>' + "".join(rows) + '</table></html>')
        atomic_text(self.folder / "index.html", html)
