#!/usr/bin/env python3
# SCSP Unity Mesh -> Blender scene reconstruction (V1.2-dev)
# Run with Blender: blender --background --python rebuild_stage_blender.py -- --project <scene-project> [--scene Assets/182_superd.unity] [--root 182_SuperD] [--out <output.blend>]
from __future__ import annotations
import argparse, json, math, re, struct, sys, traceback
from pathlib import Path
from collections import defaultdict

DOC_RE = re.compile(r'(?=^--- !u!\d+ &)', re.M)
HEAD_RE = re.compile(r'^--- !u!(\d+) &(\d+)', re.M)
GUID_RE = re.compile(r'^guid: ([0-9a-fA-F]{32})', re.M)

BUILTIN_MESH_GUID = "0000000000000000e000000000000000"
BUILTIN_MESH_FILEIDS = {
    10209: "Plane",
    10210: "Quad",
}


def parse_builtin_mesh(file_id):
    """Recreate supported Unity built-in primitive meshes from their stable fileID.

    Unity's built-in resources are not exported as ordinary Assets/*.meta files.
    The all-zero/e000... GUID therefore must be resolved by the referenced fileID.
    """
    try:
        fid = int(file_id)
    except (TypeError, ValueError):
        raise ValueError(f"Invalid Unity built-in mesh fileID: {file_id!r}")

    if fid == 10209:  # Unity built-in Plane: 10 x 10 units, 10 subdivisions/axis.
        positions = []
        normals = []
        uv = []
        divisions = 10
        for z in range(divisions + 1):
            for x in range(divisions + 1):
                positions.append((-5.0 + x, 0.0, -5.0 + z))
                normals.append((0.0, 1.0, 0.0))
                uv.append((x / divisions, z / divisions))

        indices = []
        stride = divisions + 1
        for z in range(divisions):
            for x in range(divisions):
                a = z * stride + x
                b = a + 1
                c = a + stride
                d = c + 1
                # Unity Plane faces upward (+Y).
                indices.extend((a, c, b, c, d, b))

        return {
            "name": "UnityBuiltin_Plane",
            "positions": positions,
            "normals": normals,
            "uv": uv,
            "indices": indices,
            "submeshes": [{
                "firstByte": 0,
                "indexCount": len(indices),
                "topology": 0,
                "baseVertex": 0,
            }],
            "vertexCount": len(positions),
            "indexFormat": 0,
            "builtin": True,
            "builtinFileID": fid,
        }

    if fid == 10210:  # Unity built-in Quad: 1 x 1, facing local -Z.
        positions = [
            (-0.5, -0.5, 0.0),  # bottom-left
            ( 0.5, -0.5, 0.0),  # bottom-right
            (-0.5,  0.5, 0.0),  # top-left
            ( 0.5,  0.5, 0.0),  # top-right
        ]
        indices = [0, 2, 1, 2, 3, 1]
        return {
            "name": "UnityBuiltin_Quad",
            "positions": positions,
            "normals": [(0.0, 0.0, -1.0)] * 4,
            "uv": [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)],
            "indices": indices,
            "submeshes": [{
                "firstByte": 0,
                "indexCount": len(indices),
                "topology": 0,
                "baseVertex": 0,
            }],
            "vertexCount": len(positions),
            "indexFormat": 0,
            "builtin": True,
            "builtinFileID": fid,
        }

    raise ValueError(
        f"Unsupported Unity built-in mesh fileID {fid}; "
        f"supported: {', '.join(str(x) for x in sorted(BUILTIN_MESH_FILEIDS))}"
    )

def docs(text):
    out=[]
    for d in DOC_RE.split(text):
        h=HEAD_RE.match(d)
        if h: out.append((int(h.group(1)),int(h.group(2)),d))
    return out

def scalar(s,k,default=None):
    m=re.search(r'^\s*'+re.escape(k)+r':\s*(.*?)\s*$',s,re.M)
    return m.group(1).strip(' "') if m else default

def number(s,k,default=0):
    try:return int(scalar(s,k,str(default)))
    except:return default

def vec(s,k,keys,default):
    m=re.search(r'^\s*'+re.escape(k)+r':\s*\{([^}]+)\}',s,re.M)
    if not m:return default
    vals={a:float(b.strip()) for a,b in re.findall(r'([A-Za-z]+):\s*([^,]+)',m.group(1))}
    return tuple(vals.get(a,default[i]) for i,a in enumerate(keys))

def ref(s,key):
    m=re.search(r'^\s*'+re.escape(key)+r':\s*\{([^}]+)\}',s,re.M)
    if not m:return None
    return {k:v.strip(' "') for k,v in re.findall(r'(fileID|guid|type):\s*([^, }]+)',m.group(1))}

def decode_format(fmt, raw, offset, count):
    # Unity VertexAttributeFormat enum
    spec={0:('f',4),1:('e',2),2:('B',1),3:('b',1),4:('H',2),5:('h',2),6:('B',1),7:('b',1),8:('H',2),9:('h',2),10:('I',4),11:('i',4)}
    if fmt not in spec: raise ValueError(f'Unsupported Unity vertex format {fmt}')
    code,size=spec[fmt]
    return struct.unpack_from('<'+code*count,raw,offset)

def parse_mesh(path):
    s=path.read_text(encoding='utf-8-sig',errors='replace')
    if not re.search(r'^Mesh:\s*$',s,re.M): return None
    name=scalar(s,'m_Name',path.stem)
    vc=number(s,'m_VertexCount',0)
    if vc<=0:return None
    im=re.search(r'^\s*m_IndexBuffer:\s*([0-9a-fA-F]+)',s,re.M)
    vm=re.search(r'^\s*_typelessdata:\s*([0-9a-fA-F]+)',s,re.M)
    if not im or not vm: raise ValueError(f'{name}: missing index or vertex buffer')
    ib=bytes.fromhex(im.group(1)); vb=bytes.fromhex(vm.group(1))
    # Read active vertex channels; dimension's low nibble is the actual channel width.
    cm=re.search(r'm_Channels:\s*\n(.*?)(?=\n\s*m_DataSize:)',s,re.S)
    if not cm: raise ValueError(f'{name}: no m_Channels')
    channels=[]
    channel_blocks=re.findall(r'- stream:.*?(?=\n    - stream:|$)',cm.group(1),re.S)
    for channel_index,b in enumerate(channel_blocks):
        st=re.search(r'\bstream:\s*(\d+)',b); off=re.search(r'\boffset:\s*(\d+)',b); fm=re.search(r'\bformat:\s*(\d+)',b); dm=re.search(r'\bdimension:\s*(\d+)',b)
        if not (st and off and fm and dm):continue
        stream,offset,fmt,dim=map(int,(st.group(1),off.group(1),fm.group(1),dm.group(1)))
        dim=dim & 0x0f
        if dim:channels.append((channel_index,stream,offset,fmt,dim))
    # Each Unity vertex stream is stored as a contiguous interleaved block.
    def fmt_size(f): return {0:4,1:2,2:1,3:1,4:2,5:2,6:1,7:1,8:2,9:2,10:4,11:4}[f]
    stream_strides={}
    for _,stream,off,fmt,dim in channels:
        stream_strides[stream]=max(stream_strides.get(stream,0),off+fmt_size(fmt)*dim)
    stream_bases={}; cursor=0
    for stream in sorted(stream_strides):
        stream_bases[stream]=cursor; cursor += stream_strides[stream]*vc
    if cursor>len(vb): raise ValueError(f'{name}: vertex buffer too short ({len(vb)} < {cursor})')
    attrs={}
    for ch,(channel_index,stream,off,fmt,dim) in enumerate(channels):
        values=[]
        for i in range(vc):
            v=decode_format(fmt,vb,stream_bases[stream]+i*stream_strides[stream]+off,dim)
            # normalized integer channel formats
            if fmt in (2,4): v=tuple(x/((1<<(8*fmt_size(fmt)))-1) for x in v)
            elif fmt in (3,5): v=tuple(max(-1.0,x/((1<<(8*fmt_size(fmt)-1))-1)) for x in v)
            values.append(tuple(float(x) for x in v))
        attrs[channel_index]=values
    # Standard Unity channel indices: 0 position, 1 normal, 4 uv0
    positions=attrs.get(0)
    if not positions: raise ValueError(f'{name}: no position channel')
    normals=attrs.get(1); uv=attrs.get(4)
    # Submesh records
    sm=re.search(r'm_SubMeshes:\s*\n(.*?)(?=\n\s*m_Shapes:|\n\s*m_BindPose:|\n\s*m_VertexData:)',s,re.S)
    sub=[]
    if sm:
        blocks=re.findall(r'- serializedVersion: 2\n(.*?)(?=\n  - serializedVersion: 2|$)',sm.group(1),re.S)
        for b in blocks:
            sub.append({'firstByte':int(re.search(r'firstByte:\s*(\d+)',b).group(1)) if re.search(r'firstByte:\s*(\d+)',b) else 0,
                        'indexCount':int(re.search(r'indexCount:\s*(\d+)',b).group(1)) if re.search(r'indexCount:\s*(\d+)',b) else 0,
                        'topology':int(re.search(r'topology:\s*(\d+)',b).group(1)) if re.search(r'topology:\s*(\d+)',b) else 0,
                        'baseVertex':int(re.search(r'baseVertex:\s*(-?\d+)',b).group(1)) if re.search(r'baseVertex:\s*(-?\d+)',b) else 0})
    idxfmt=number(s,'m_IndexFormat',0)
    isize=4 if idxfmt==1 else 2
    if len(ib)%isize: raise ValueError(f'{name}: index buffer length invalid for index format {idxfmt}')
    indices=list(struct.unpack('<'+('I' if isize==4 else 'H')*(len(ib)//isize),ib))
    return {'name':name,'positions':positions,'normals':normals,'uv':uv,'indices':indices,'submeshes':sub,'vertexCount':vc,'indexFormat':idxfmt,'builtin':False}

def parse_scene(scene_path, assets):
    text=scene_path.read_text(encoding='utf-8-sig',errors='replace')
    objects={}; transforms={}; meshfilters={}; renderers={}; component_go={}
    for cls,fid,d in docs(text):
        if cls==1:
            comps=[int(x) for x in re.findall(r'- component: \{fileID: (-?\d+)\}',d)]
            objects[fid]={'id':fid,'name':scalar(d,'m_Name',f'GO_{fid}'),'active':scalar(d,'m_IsActive','1')!='0','components':comps}
            for c in comps:component_go[c]=fid
        elif cls in (4,224):
            go=ref(d,'m_GameObject'); go=int(go['fileID']) if go else 0
            transforms[fid]={'id':fid,'go':go,'pos':vec(d,'m_LocalPosition',('x','y','z'),(0,0,0)),'rot':vec(d,'m_LocalRotation',('x','y','z','w'),(0,0,0,1)),'scale':vec(d,'m_LocalScale',('x','y','z'),(1,1,1)),'father':(int(ref(d,'m_Father')['fileID']) if ref(d,'m_Father') else 0)}
        elif cls==33:
            go=ref(d,'m_GameObject'); mr=ref(d,'m_Mesh')
            meshfilters[fid]={'go':int(go['fileID']) if go else 0,'mesh':mr}
        if cls==23:
            go=ref(d,'m_GameObject'); mats=[]
            mm=re.search(r'm_Materials:\s*\n(.*?)(?=\n\s*m_StaticBatchInfo:)',d,re.S)
            if mm:
                mats=[{k:v.strip(' "') for k,v in re.findall(r'(fileID|guid|type):\s*([^, }]+)',x)} for x in re.findall(r'- \{([^}]+)\}',mm.group(1))]
            renderers[fid]={'go':int(go['fileID']) if go else 0,'materials':mats,'enabled':scalar(d,'m_Enabled','1')!='0'}
    # GUID index
    guid={}
    for mp in assets.rglob('*.meta'):
        try: mt=mp.read_text(encoding='utf-8-sig',errors='replace')
        except OSError:continue
        m=GUID_RE.search(mt)
        if m:guid[m.group(1).lower()]=Path(str(mp)[:-5])
    by_go_mf=defaultdict(list); by_go_mr=defaultdict(list)
    for x in meshfilters.values():by_go_mf[x['go']].append(x)
    for x in renderers.values():by_go_mr[x['go']].append(x)
    t_by_go={t['go']:t for t in transforms.values()}
    children=defaultdict(list)
    for tid,t in transforms.items():children[t['father']].append(tid)
    go_by_tid={tid:t['go'] for tid,t in transforms.items()}
    roots=[tid for tid,t in transforms.items() if t['father']==0]
    return objects,transforms,t_by_go,children,go_by_tid,roots,by_go_mf,by_go_mr,guid

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--project',required=True);ap.add_argument('--scene',default='Assets/182_superd.unity');ap.add_argument('--root',default='182_SuperD');ap.add_argument('--out',default='SCSP_182_superd_rebuilt.blend');ap.add_argument('--include-inactive',dest='include_inactive',action='store_true',help='Include inactive GameObjects (default)');ap.add_argument('--exclude-inactive',dest='include_inactive',action='store_false',help='Exclude inactive GameObjects and their descendants');ap.set_defaults(include_inactive=True);ap.add_argument('--export-fbx',action='store_true');ap.add_argument('--export-regions',action='store_true',help='Export each direct child under the stage root as a separate FBX');ap.add_argument('--region-dir',default='');ap.add_argument('--report',default='')
    args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    project=Path(args.project).resolve();assets=project/'Assets';scene=project/args.scene
    if not assets.is_dir():raise SystemExit(f'Assets directory not found: {assets}')
    (objects,transforms,t_by_go,children,go_by_tid,roots,by_go_mf,by_go_mr,guid)=parse_scene(scene,assets)
    root_go=next((i for i,o in objects.items() if o['name']==args.root),None)
    if root_go is None:raise SystemExit(f'Root GameObject not found: {args.root}')
    root_tid=t_by_go.get(root_go,{}).get('id')
    if not root_tid:raise SystemExit('Root object has no Transform')
    # Locate only referenced mesh assets; cache decoded mesh data by GUID.
    import bpy
    from mathutils import Matrix, Quaternion, Vector
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    stage_collection=bpy.data.collections.new(args.root);bpy.context.scene.collection.children.link(stage_collection)
    bpy.context.scene.unit_settings.system='METRIC'
    # coordinate conversion: Unity Y-up -> Blender Z-up
    C=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
    Cinv=C.inverted()
    decoded={}; material_cache={}; stats={'gameObjects':0,'meshObjects':0,'meshAssetsDecoded':0,'builtinMeshesDecoded':0,'builtinMeshFilterComponents':0,'builtinMeshTypes':{},'meshFiltersEncountered':0,'meshFiltersOnInactiveObjects':0,'inactiveGameObjectsIncluded':0,'inactiveGameObjectsExcluded':0,'materials':0,'texturedMaterials':0,'missingMesh':[],'meshErrors':[],'skippedInactive':[],'submeshes':0,'triangles':0}
    def material_for(g):
        if not g:g='__SCSP_DEFAULT__'
        if g in material_cache:return material_cache[g]
        p=guid.get(g)
        mat=bpy.data.materials.new(p.stem if p else 'Unity_Material_'+g[:8]);mat.diffuse_color=(0.65,0.65,0.65,1)
        mat.use_nodes=True
        if p and p.exists():
            try:
                ms=p.read_text(encoding='utf-8-sig',errors='replace')
                cm=re.search(r'_Color:\s*\{r:\s*([^,]+),\s*g:\s*([^,]+),\s*b:\s*([^,]+),\s*a:\s*([^}]+)\}',ms)
                if cm:
                    rgba=tuple(max(0,min(1,float(x))) for x in cm.groups());mat.diffuse_color=rgba
                    bs=mat.node_tree.nodes.get('Principled BSDF')
                    if bs:bs.inputs['Base Color'].default_value=rgba
                tm=re.search(r'_MainTex:\s*\n(.*?)(?=\n\s*_[A-Za-z0-9]+:|\n\s*\})',ms,re.S)
                if tm:
                    txref=re.search(r'm_Texture:\s*\{[^}]*guid:\s*([0-9a-fA-F]{32})',tm.group(1))
                    if txref:
                        txpath=guid.get(txref.group(1).lower())
                        if txpath and txpath.suffix.lower() in ('.png','.jpg','.jpeg','.tga','.tif','.tiff','.exr') and txpath.exists():
                            image=bpy.data.images.load(str(txpath),check_existing=True)
                            tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=image
                            bs=mat.node_tree.nodes.get('Principled BSDF')
                            if bs:mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
                            scale=re.search(r'm_Scale:\s*\{x:\s*([^,]+),\s*y:\s*([^}]+)\}',tm.group(1))
                            offset=re.search(r'm_Offset:\s*\{x:\s*([^,]+),\s*y:\s*([^}]+)\}',tm.group(1))
                            if scale or offset:
                                mapping=mat.node_tree.nodes.new('ShaderNodeMapping')
                                uvnode=mat.node_tree.nodes.new('ShaderNodeTexCoord')
                                if scale:mapping.inputs['Scale'].default_value=(float(scale.group(1)),float(scale.group(2)),1.0)
                                if offset:mapping.inputs['Location'].default_value=(float(offset.group(1)),float(offset.group(2)),0.0)
                                mat.node_tree.links.new(uvnode.outputs['UV'],mapping.inputs['Vector'])
                                mat.node_tree.links.new(mapping.outputs['Vector'],tex.inputs['Vector'])
                            stats['texturedMaterials']+=1
            except Exception as e:
                stats.setdefault('materialWarnings',[]).append({'material':str(p),'warning':str(e)})
        material_cache[g]=mat;stats['materials']=len(material_cache);return mat
    # Traverse hierarchy under requested root. Use world matrix to avoid parenting matrix ambiguity.
    region_collections={}
    def visit(go_id,parent_world,parent_empty=None,depth=0,target_collection=None):
        if go_id not in objects:return
        target_collection = target_collection or stage_collection
        objdata=objects[go_id]
        if not args.include_inactive and not objdata['active']:
            stats['inactiveGameObjectsExcluded']+=1
            stats['skippedInactive'].append({'name':objdata['name'],'gameObjectFileID':go_id,'meshFilters':len(by_go_mf.get(go_id,[]))})
            return
        if not objdata['active']: stats['inactiveGameObjectsIncluded']+=1
        tid=t_by_go.get(go_id,{}).get('id');t=transforms.get(tid,{})
        pos=t.get('pos',(0,0,0));rot=t.get('rot',(0,0,0,1));sc=t.get('scale',(1,1,1))
        local=Matrix.Translation(Vector(pos)) @ Quaternion((rot[3],rot[0],rot[1],rot[2])).to_matrix().to_4x4() @ Matrix.Diagonal((sc[0],sc[1],sc[2],1))
        world=parent_world @ local
        stats['gameObjects']+=1
        empty=bpy.data.objects.new(objdata['name'],None);target_collection.objects.link(empty)
        empty.empty_display_type='PLAIN_AXES';empty.empty_display_size=0.08
        if parent_empty is not None:empty.parent=parent_empty
        empty.matrix_world=C @ world @ Cinv
        empty['unity_gameObject_fileID']=go_id
        empty['unity_active_self']=bool(objdata['active'])
        # create a mesh object for each MeshFilter; preserve original transform via world matrix
        for mf in by_go_mf.get(go_id,[]):
            stats['meshFiltersEncountered']+=1
            if not objdata['active']: stats['meshFiltersOnInactiveObjects']+=1
            mr=mf['mesh'] or {};g=mr.get('guid','').lower()
            file_id=str(mr.get('fileID',''))
            cache_key=(g,file_id)
            if g == BUILTIN_MESH_GUID:
                builtin_name=BUILTIN_MESH_FILEIDS.get(int(file_id)) if file_id.isdigit() else None
                if builtin_name:
                    stats['builtinMeshFilterComponents']+=1
                    stats['builtinMeshTypes'][builtin_name]=stats['builtinMeshTypes'].get(builtin_name,0)+1
                if cache_key not in decoded:
                    try:
                        decoded[cache_key]=parse_builtin_mesh(file_id)
                        stats['meshAssetsDecoded']+=1
                        stats['builtinMeshesDecoded']+=1
                    except Exception as e:
                        stats['meshErrors'].append({'object':objdata['name'],'guid':g,'fileID':file_id,'error':str(e)})
                        continue
            else:
                if not g or g not in guid:
                    stats['missingMesh'].append({'object':objdata['name'],'guid':g,'fileID':file_id});continue
                if cache_key not in decoded:
                    try:
                        decoded[cache_key]=parse_mesh(guid[g]);stats['meshAssetsDecoded']+=1
                    except Exception as e:
                        stats['meshErrors'].append({'path':str(guid[g]),'error':str(e)});continue
            md=decoded[cache_key]
            if not md:continue
            verts=[(v[0],-v[2],v[1]) for v in md['positions']]
            faces=[]; face_mats=[]
            submeshes=md['submeshes'] or [{'firstByte':0,'indexCount':len(md['indices']),'topology':0,'baseVertex':0}]
            for si,sub in enumerate(submeshes):
                if sub['topology']!=0:continue
                start=sub['firstByte']//(4 if md.get('indexFormat',0)==1 else 2)
                count=sub['indexCount'];chunk=md['indices'][start:start+count];base=sub.get('baseVertex',0)
                mat_index=si
                for j in range(0,len(chunk)-2,3):
                    tri=tuple(int(chunk[j+k])+base for k in range(3))
                    if min(tri)>=0 and max(tri)<len(verts):faces.append(tri);face_mats.append(mat_index);stats['triangles']+=1
                stats['submeshes']+=1
            if not faces:continue
            me=bpy.data.meshes.new(md['name']);me.from_pydata(verts,[],faces);me.update()
            if md['normals'] and len(md['normals'])==len(verts):
                try:
                    me.normals_split_custom_set_from_vertices([Vector((n[0],-n[2],n[1])) for n in md['normals']])
                    # Blender 4.x supports normals via corner_normals only read-only; set split normals removed.
                except Exception:pass
            if md['uv'] and len(md['uv'])==len(verts):
                uv=me.uv_layers.new(name='UVMap')
                for poly in me.polygons:
                    for li in poly.loop_indices:
                        vi=me.loops[li].vertex_index;u=md['uv'][vi];uv.data[li].uv=(u[0],u[1])
            renderers=by_go_mr.get(go_id,[])
            mats=renderers[0]['materials'] if renderers else []
            for mrref in mats:
                gmat=mrref.get('guid','').lower();mat=material_for(gmat);me.materials.append(mat) if mat else None
            if not me.materials:me.materials.append(material_for(None))
            for poly,mi in zip(me.polygons,face_mats):poly.material_index=min(mi,len(me.materials)-1)
            ob=bpy.data.objects.new(objdata['name']+'__'+md['name'],me);target_collection.objects.link(ob)
            ob.parent=empty;ob.matrix_world=C @ world @ Cinv
            ob['unity_gameObject_fileID']=go_id
            ob['unity_source_active_self']=bool(objdata['active'])
            stats['meshObjects']+=1
        for ctid in children.get(tid,[]):
            child=go_by_tid.get(ctid)
            if child is not None:
                child_collection=target_collection
                if go_id==root_go and args.export_regions:
                    child_name=objects[child]['name']
                    safe=re.sub(r'[^0-9A-Za-z_一-龥.-]+','_',child_name).strip('._') or ('region_'+str(child))
                    # Keep deterministic unique collection names even when Unity names repeat.
                    key=safe; suffix=2
                    while key in region_collections: key=f'{safe}_{suffix}'; suffix+=1
                    child_collection=bpy.data.collections.new(key)
                    stage_collection.children.link(child_collection)
                    region_collections[key]=child_collection
                visit(child,world,empty,depth+1,child_collection)
    # Count the complete source subtree independently from the chosen inclusion policy.
    root_subtree=[]; todo=[root_tid]
    while todo:
        _tid=todo.pop(); _go=go_by_tid.get(_tid)
        if _go in objects:
            root_subtree.append(_go); todo.extend(children.get(_tid,[]))
    stats['sourceRootGameObjects']=len(root_subtree)
    stats['sourceRootInactiveGameObjects']=sum(not objects[x]['active'] for x in root_subtree)
    stats['sourceRootMeshFilters']=sum(len(by_go_mf.get(x,[])) for x in root_subtree)
    stats['sourceRootInactiveMeshFilters']=sum(len(by_go_mf.get(x,[])) for x in root_subtree if not objects[x]['active'])
    # Unity activeInHierarchy is false for descendants of an inactive parent.
    excluded_ids=set(); inactive_self_ids=set(); stack=[(root_tid,False)]
    while stack:
        _tid,_blocked=stack.pop(); _go=go_by_tid.get(_tid)
        if _go not in objects: continue
        _self_inactive=not objects[_go]['active']
        if _self_inactive: inactive_self_ids.add(_go)
        _blocked=_blocked or _self_inactive
        if _blocked: excluded_ids.add(_go)
        stack.extend((_child,_blocked) for _child in children.get(_tid,[]))
    stats['sourceRootInactiveInHierarchyGameObjects']=len(excluded_ids)
    stats['sourceRootInactiveInHierarchyMeshFilters']=sum(len(by_go_mf.get(x,[])) for x in excluded_ids)
    visit(root_go,Matrix.Identity(4))
    # ParticleSystem components remain in the reconstructed GameObject hierarchy,
    # but their time-dependent simulation is not baked into a static PMX model.
    selected_component_ids={component_id for go in root_subtree for component_id in objects[go].get('components',[])}
    particle_system_count=0
    particle_renderer_count=0
    scene_text=scene.read_text(encoding='utf-8-sig',errors='replace')
    for class_id,component_id,document in docs(scene_text):
        if component_id not in selected_component_ids:
            continue
        if class_id==198: particle_system_count+=1
        elif class_id==199: particle_renderer_count+=1
    stats['particleSystemComponents']=particle_system_count
    stats['particleSystemRendererComponents']=particle_renderer_count
    if particle_system_count:
        stats.setdefault('warnings',[]).append({
            'warning':'Unity ParticleSystem simulation is dynamic and is not baked into static PMX geometry.',
            'particleSystems':particle_system_count,
            'particleSystemRenderers':particle_renderer_count,
        })
    stats['meshFilterAccounting']=stats['meshFiltersEncountered'] + (stats['sourceRootInactiveInHierarchyMeshFilters'] if not args.include_inactive else 0)
    stats['inactiveGameObjectsExcluded']=len(excluded_ids) if not args.include_inactive else 0
    stats['skippedInactive']=[{'name':objects[x]['name'],'gameObjectFileID':x,'meshFilters':len(by_go_mf.get(x,[]))} for x in sorted(excluded_ids)] if not args.include_inactive else []
    # Set origin/camera-friendly viewport and scene metadata.
    bpy.context.scene['SCSP_source_scene']=str(scene);bpy.context.scene['SCSP_root']=args.root
    bpy.context.scene['SCSP_rebuild_stats']=json.dumps(stats,ensure_ascii=False)
    out=Path(args.out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(out))
    report=Path(args.report).resolve() if args.report else out.with_suffix('.report.json')
    report.write_text(json.dumps({'scene':str(scene),'root':args.root,'inactivePolicy':'include' if args.include_inactive else 'exclude','stats':stats},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2));print('BLEND:',out);print('REPORT:',report)
    export_errors=[]
    if args.export_fbx:
        fbx=out.with_suffix('.fbx')
        try:
            bpy.ops.object.select_all(action='DESELECT')
            for ob in bpy.context.scene.objects: ob.select_set(True)
            bpy.context.view_layer.objects.active=next((o for o in bpy.context.scene.objects if o.type=='MESH'),None)
            bpy.ops.export_scene.fbx(filepath=str(fbx),use_selection=True,object_types={'EMPTY','MESH'},add_leaf_bones=False,apply_unit_scale=True,path_mode='COPY',embed_textures=True)
            if not fbx.is_file() or fbx.stat().st_size==0: raise RuntimeError('FBX operator returned without a non-empty output file')
            print('FBX:',fbx)
        except Exception as exc:
            export_errors.append({'kind':'full_fbx','error':repr(exc)})
            print('ERROR: full FBX export failed:',repr(exc))
    if args.export_regions:
        region_dir=Path(args.region_dir).resolve() if args.region_dir else out.parent/(out.stem+'_regions')
        region_dir.mkdir(parents=True,exist_ok=True)
        for name,collection in region_collections.items():
            try:
                bpy.ops.object.select_all(action='DESELECT')
                region_objects=[]
                def gather(col):
                    region_objects.extend(list(col.objects))
                    for subcol in col.children: gather(subcol)
                gather(collection)
                for ob in region_objects: ob.select_set(True)
                active=next((o for o in region_objects if o.type=='MESH'),None)
                if active: bpy.context.view_layer.objects.active=active
                region_path=region_dir/(name+'.fbx')
                bpy.ops.export_scene.fbx(filepath=str(region_path),use_selection=True,object_types={'EMPTY','MESH'},add_leaf_bones=False,apply_unit_scale=True,path_mode='COPY',embed_textures=True)
                if not region_path.is_file() or region_path.stat().st_size==0: raise RuntimeError('FBX operator returned without a non-empty output file')
                print('REGION_FBX:',region_path)
            except Exception as exc:
                export_errors.append({'kind':'region_fbx','region':name,'error':repr(exc)})
                print('ERROR: region FBX export failed:',name,repr(exc))
        (region_dir/'regions_manifest.json').write_text(json.dumps({'regions':list(region_collections.keys()),'errors':export_errors},ensure_ascii=False,indent=2),encoding='utf-8')
    if export_errors:
        report_data={'scene':str(scene),'root':args.root,'inactivePolicy':'include' if args.include_inactive else 'exclude','stats':stats,'exportErrors':export_errors}
        report.write_text(json.dumps(report_data,ensure_ascii=False,indent=2),encoding='utf-8')
        raise SystemExit('One or more exports failed; see report: '+str(report))

if __name__=='__main__':
    try:main()
    except Exception:
        traceback.print_exc();raise
