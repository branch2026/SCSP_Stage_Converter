# V2.4.4-dev — Mesh Occurrence Trace 精准定位版

## 本次修正
- 将 Unity 全局 `activeInHierarchy` 与转换器从所选舞台根对象开始的 root-relative inclusion 分开计算。
- 读取所选根对象外部的 Transform 祖先链，避免把外部 inactive 祖先误当作转换器内部的排除原因。
- 为每个 GameObject 输出 `activeWithinSelectedRoot`、`conversionDecision`、`hierarchyInactiveCause` 与 `conversionBlockingInactiveObject`。
- 通过只读解析 Unity YAML class 33 文档，为 Mesh 引用关联精确的 MeshFilter component fileID。
- 空 Mesh 引用现在提供 GameObject 路径、GameObject fileID 和 MeshFilter component fileID。
- 同一 GameObject 上多个 MeshFilter 引用相同 Mesh 时，逐个保留各自的组件 fileID。
- JSON / TXT 同步输出新增追踪信息，诊断 schema 升级为 `scsp-mesh-channel-diagnostics-v4`。

## 严格保护
- 不修改 `SceneBuilder/rebuild_stage_blender.py`、PMXExporter、`UnityParser/batch_folder_discovery.py`、`Validator/validate_source.py` 或 `RUN_GUI.bat`。
- 不修改 Unity → Blender → PMX 转换逻辑。
- 不增加自动修复，不重算法线、不生成 UV、不改写材质。
- V2.3.2-dev 仍是批量转换回退基线；V2.4.3-dev 保留为上一版诊断回退基线。

## 验证
- 自动化测试：58/58 通过。
- Python 编译检查通过。
- 新增外部 inactive 祖先、根对象内部 inactive 祖先、MeshFilter component fileID、空 Mesh 引用定位测试。
- 185_SankaF 两组 V2.4.3 实机报告作为固定数量对照；当前环境未重新运行完整 Windows scene-project，仍需实机回归。
