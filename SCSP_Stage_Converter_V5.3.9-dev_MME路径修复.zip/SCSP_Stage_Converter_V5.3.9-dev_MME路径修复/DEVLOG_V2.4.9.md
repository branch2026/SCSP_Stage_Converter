# V2.4.9-dev 开发记录

## 基础版本

- 从 `SCSP_Stage_Converter_V2.4.8-dev_WarningDiagnostics.zip` 继续开发。
- 保留 V2.3.2-dev 作为批量转换回退基线。
- 保留 V2.4.8 的 WARNING 精准定位能力。

## 本次修正

1. 质量报告的 `objects.inactiveInHierarchyObjects` 现在明确写入 `activeInHierarchy`、状态来源和 inferred 标记。
2. 对旧 V2.4.7 / V2.4.8 报告，诊断器从 `inactiveInHierarchyObjects` 列表成员身份推导有效状态为 false，并记录推导来源。
3. 将 inactive GameObject 按所选舞台树中最上层 inactive 节点分组。
4. 每个 inactive 根对象关联其子树的 Mesh Inventory occurrence，并统计 MeshFilter 组件和唯一 Mesh。
5. Mesh 按 GUID + fileID 去重；按 included / excludedOnly / shared 分类。
6. Include 和 Exclude 两种模式均输出根对象摘要；BLD-004 继续输出完整被排除对象清单。

## 185_SankaF 实际报告回归

使用用户此前上传的 Include / Exclude 两份 V2.4.7-dev JSON，无需重新转换：

- 两种模式均识别 311 个 inactive GameObject。
- 两种模式均分组为 16 个最上层 inactive 根对象。
- 两种模式均关联 133 个含 Mesh 的 GameObject、133 个 MeshFilter 组件和 133 个唯一 Mesh。
- Include：133 个 Mesh 均归入 included。
- Exclude：133 个 Mesh 均归入 excludedOnly。
- 根对象分组完整：311 / 311，未分组 0，状态冲突 0。
- `Stage_005Prop_floor_light_mainstage`：217 个 GameObject、96 个 MeshFilter、96 个唯一 Mesh。
- `door`：23 个 GameObject、18 个 MeshFilter、18 个唯一 Mesh。
- 旧报告缺少 activeInHierarchy 的记录均以 false 输出，并标记 inferred=true。
- 原始 WARNING 仍为 Include 1 项、Exclude 2 项；3/3 已完整定位。

## 安全边界

不重新运行 Unity / Blender / PMX 转换，不改写转换输出，不改变 inactive 策略，不自动修复资源。
