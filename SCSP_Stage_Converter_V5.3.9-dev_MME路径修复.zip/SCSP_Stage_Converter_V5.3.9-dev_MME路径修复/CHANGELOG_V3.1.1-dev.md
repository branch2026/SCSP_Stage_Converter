# V3.1.1-dev · Phase Morph + VMD Compatibility Diagnostics

## Added
- `material_state` effect type creates a single PMX type-8 morph with explicit offsets across multiple material slots.
- Supports PMX MaterialMorph multiply (operation 0) and add (operation 1), all 28 material coefficients.
- Missing coefficients use neutral identity values: 1 for multiply, 0 for add.
- VMD 0002 codec validates header, bone/morph/camera/light/self-shadow/model-display sections and exact end-of-file consumption.
- Optional neutral bone-anchor VMD variant (zero translation + identity quaternion) for MMD compatibility A/B testing.
- `vmd_compare.py` compares track names, frames, weights, model identifiers, section counts and SHA-256.
- GUI exposes a Phase-style multi-material alpha state choice and creates both VMD variants when a short CP932 bone name is available.
- Added read-only extraction of the supplied ITTW46 404 Phase1–Phase5, HeliLight, SpotX, SpotY and Rise data.

## Fixed / hardened
- VMD parser now validates complete sections instead of stopping after morph records.
- UV effect descriptions now correctly include selected material information.
- PMX type-8 writer retains legacy diffuse-alpha/tint offsets and adds a validated full 28-float material-state target form.

## Preserved
- V3.0 single-stage conversion function and 15 protected conversion/export files remain unchanged.
- Effects remain opt-in and are written to a separate folder; source PMX and original batch success state are not modified.

## Not claimed
- The neutral bone anchor is a diagnostic A/B variant, not a confirmed MMD fix.
- No Unity original Timeline or shader effect is inferred without source evidence.
- No third-party ITTW46 FX or stage assets are bundled.
