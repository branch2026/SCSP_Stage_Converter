# V2.3.2-dev Development Log

- Re-opened the V2.3.1-dev BuiltinMeshFix archive as the source baseline.
- Replaced the incorrect multi-`.unity` file-selection concept with a common-parent + multi-stage-folder selection workflow.
- Added bounded AssetRipper project discovery and recursive `.unity` enumeration under each project's `Assets` directory.
- Added a project root and source folder to every task; conversion now resolves the source project per task.
- Preserved the existing root-candidate scanner and Hierarchy selector. Unique root candidates are auto-added; ambiguous scenes require explicit selection.
- Preserved the native MMD Tools exporter, Blender rebuild pipeline, texture path repair, and Unity built-in Plane / Quad support.
- Added per-project default output handling for multi-project batches; an explicitly selected shared output directory is respected.
- Added task-list version 2 while keeping compatibility with legacy single-project task lists.
- Validation: 34 automated tests pass; Python syntax compilation passes.
- Pending: run the new GUI folder-selection workflow on the user's Windows 10 setup and complete PMX integration acceptance.
