# V2.4.7-dev — Excluded Mesh 完整资源身份追踪增强版

## 新增（只读诊断）

- 质量报告 Mesh schema 升级至 `scsp-mesh-channel-diagnostics-v6`。
- 新增 `meshInventory`，为每个唯一 Mesh GUID + fileID 保存完整身份、Assets 路径、顶点数、法线/UV0、解码状态、scope 和 GameObject 引用。
- 即使 Mesh 解码失败或 GUID 资源路径无法解析，也保留 Mesh 身份、引用对象和失败状态。
- GameObject 级 Renderer 材质明细新增 material GUID/fileID、材质路径、MainTex GUID/fileID/路径。
- 新增 `meshInventorySummary`，核对完整度、身份覆盖、解码状态及 Included / Excluded-only / Shared 范围计数。
- 双模式比较器支持 v6，优先从 include 全量清单结合 exclude `skippedInactive` 推导排除资源；若两份 v6 报告都可用，则比较 GUID/fileID 集合及 GameObject / MeshFilter component fileID 关联。
- 对比报告新增完整 Excluded-only Mesh 目录、Unity Renderer 材质身份目录和清单覆盖状态；第 14 项检查专门核对完整身份清单。
- v4/v5 旧报告继续兼容；缺少 v6 清单时以 INFO 明确提示，不编造 GUID。

## 兼容性与保护

- 以 V2.4.6-dev 源码 ZIP 为开发基线。
- 15 个受保护转换文件与 V2.4.6-dev 逐字节一致。
- 不修改 `SceneBuilder/rebuild_stage_blender.py`、`PMXExporter/*`、`UnityParser/batch_folder_discovery.py`、`Validator/validate_source.py`、`RUN_GUI.bat`。
- 不修改 Unity 资源、BLEND、PMX、贴图、法线、UV、材质或 inactive 转换决策。
- 不增加自动修复行为；质量报告仍在现有转换流程之后只读运行。

## 测试范围

- 89 项 pytest 自动化测试全部通过。
- 质量诊断测试覆盖完整 Mesh 资源记录、Excluded-only / Shared 范围、材质与 MainTex 身份字段。
- 比较器测试覆盖 v6 完整身份清单、单侧 v6 输入、跨报告 GUID 集合不一致警告和 v4/v5 旧报告兼容。
- 使用用户当前 185_SankaF v5 报告进行回归：原有 13 项比较仍 PASS；第 14 项为 INFO，仍准确显示已知 7 / 133、未知 126。
- 185_SankaF 新 v6 清单仍需用户在 Windows + Unity 项目环境中重新运行质量检查后实机验收。
