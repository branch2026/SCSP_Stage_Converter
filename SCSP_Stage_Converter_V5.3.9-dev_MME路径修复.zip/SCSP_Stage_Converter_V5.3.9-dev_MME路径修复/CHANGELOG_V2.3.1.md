# V2.3.1-dev — Unity Built-in Mesh 修复

## 问题定位

- V2.3 Hierarchy 预览已正确显示 `121_ForbiP > EffectPlayer > 121_Effects`。
- 转换失败发生在 Unity 资源验证阶段，并非根对象识别失败。
- `121_forbip.unity` 中有 71 个 MeshFilter 引用 Unity 内置资源 GUID `0000000000000000e000000000000000`。
- 该 GUID 本身不是 Assets 目录下普通 `.meta` 文件的 GUID；必须结合 fileID 区分具体内置网格。
- 本场景使用 `fileID 10209`（Plane）和 `fileID 10210`（Quad）。V2.3 旧验证器只按 GUID 查找 `.meta`，因此把合法内置资源误判为 unresolved。

## 本版修复

- 新增 `parse_builtin_mesh()`，支持 Unity 内置 Plane / Quad。
- Plane：10 × 10 单位、10 × 10 细分、UV、+Y 法线。
- Quad：1 × 1 单位、Unity 默认 -Z 朝向、UV 和法线。
- Mesh 缓存键改为 `(GUID, fileID)`，避免两个不同内置网格因共用 GUID 而冲突。
- Validator 识别内置网格，并把 null / unknown built-in refs 与正常资产引用区分。
- Rebuilder 为内置 Plane / Quad 创建真实 Blender Mesh 几何。
- Rebuild report 增加内置 Mesh 计数和 ParticleSystem 运行时效果限制说明。
- 保留 V2.3 Hierarchy 预览、任务队列、GUI 操作方式和每舞台完整 PMX 工作流。

## 121_ForbiP 完整场景验证

- GameObjects：747
- MeshFilter：285
- 普通 Mesh GUID：150 个已解析资源
- 内置 MeshFilter：71 个（Plane 26、Quad 45）
- 唯一 Mesh 引用：152（按 GUID + fileID 统计）
- 已解析 Mesh 引用：152
- 主贴图引用：56 / 56
- 验证 errors：0
- ParticleSystem：188
- ParticleSystemRenderer：188

## 明确限制

静态 MeshFilter 网格会进入 Blender / PMX 转换。Unity ParticleSystem 是运行时动态模拟；本版保留其 GameObject 层级和组件统计，但不声称把粒子动画完整烘焙为静态 PMX。

## 回归

- 28 项自动化测试通过。
- 完整 121_ForbiP scene-project 的 `validate_source.py` 退出代码 0。
- PMXExporter、贴图路径修复逻辑和主启动器沿用 V2.2.2-dev / V2.3 版本，不作改动。
- 尚需用户在 Windows 10、Blender 4.4.3、MMD Tools 4.5.14 和 MMD 9.32 环境完成 Blender 重建及最终 PMX 验收。
