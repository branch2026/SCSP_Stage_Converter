# 185_SankaF — V2.4.2 报告对照与 V2.4.3 回归期望

本记录基于用户上传的两组 V2.4.2 JSON/TXT 质量报告：

- `185_SankaF_quality_report(1)`：`inactivePolicy=exclude`
- `185_SankaF_quality_report(2)`：`inactivePolicy=include`

此处是对既有报告的离线核对，不代表在当前开发容器重新运行了 Unity `scene-project`。

## V2.4.2 实测报告原始统计

| 指标 | exclude | include |
|---|---:|---:|
| Source 唯一 Mesh 引用 | 918 | 918 |
| Included 唯一 Mesh 引用 | 785 | 918 |
| Excluded-only 唯一 Mesh 引用 | 133 | 0 |
| Shared Mesh 引用 | 0 | 0 |
| Source 已解码 Mesh | 918 | 918 |
| Included 已解码 Mesh | 785 | 918 |
| Excluded-only 已解码 Mesh | 133 | 0 |

## 通道缺失数量

| 范围 | Mesh 数 | 缺少法线 | 缺少 UV0 | 缺失法线或 UV0 去重并集 |
|---|---:|---:|---:|---:|
| Source | 918 | 217 | 118 | 217 |
| Included（exclude 模式） | 785 | 210 | 118 | 210 |
| Excluded-only（exclude 模式） | 133 | 7 | 0 | 7 |
| Included（include 模式） | 918 | 217 | 118 | 217 |

法线缺失与 UV0 缺失存在重叠；两个列表不能直接相加。既有报告显示两种模式下，118 个缺少 UV0 的唯一 Mesh 都同时属于缺少法线集合。

## UV0 材质风险

两份 V2.4.2 报告的 118 个缺少 UV0 记录均为 `NO_MAIN_TEXTURE_DETECTED`，且没有记录检测到 MainTex 或未知材质用途。

V2.4.3 的预期分类：

- SRC-006 不再因这 118 个 Mesh 单独产生 WARNING，而是显示 INFO。
- 该 INFO 只说明材质未检测到 `_MainTex`，不证明没有其他 Shader 自定义纹理属性。
- SRC-005 仍按 Included 范围报告法线缺失：exclude 为 210，include 为 217。
- exclude 模式仍保留 BLD-004 inactive 几何排除提示；include 模式不应出现该排除提示。

## V2.4.3 期望的检查状态变化

| 模式 | V2.4.2 WARNING 数 | V2.4.3 预期 WARNING 数 | 原因 |
|---|---:|---:|---|
| exclude | 3 | 2 | SRC-006 从 WARNING 降为 INFO；SRC-005 与 BLD-004 保留 |
| include | 2 | 1 | SRC-006 从 WARNING 降为 INFO；SRC-005 保留 |

以上是根据保存报告数据推导的回归期望；必须在 Windows 10 上重新运行 V2.4.3，才能确认新 JSON/TXT 实际输出。
