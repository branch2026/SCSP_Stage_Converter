# 185_SankaF — V2.4.4 回归基准与实机验收要求

## 已有 V2.4.3 Windows 实测数据

以下数字来自用户在 Windows 上实际运行 V2.4.3 的两组报告，作为 V2.4.4 的固定数量基准；不是本开发容器重新转换得到的数据。

| 指标 | inactive 勾选（include） | inactive 不勾选（exclude） |
|---|---:|---:|
| GameObject 参与转换 | 1820 | 1509 |
| GameObject 排除 | 0 | 311 |
| 全部 MeshFilter 组件 | 921 | 921 |
| 参与转换 MeshFilter | 921 | 788 |
| 唯一 Included Mesh | 918 | 785 |
| Excluded-only Mesh | 0 | 133 |
| Shared Mesh | 0 | 0 |
| Blender Mesh 对象 | 921 | 788 |
| 三角面 | 58851 | 54202 |
| Included 缺少法线 | 217 | 210 |
| Included 缺少 UV0 | 118 | 118 |
| WARNING | 1 | 2 |

## V2.4.4 必须保持的结果

- `Source / Included / Excluded-only / Shared` 的统计口径不变。
- 法线缺失数量与 UV0 缺失数量不变。
- 不修改转换核心，因此 Blender Mesh 对象数量和三角面数量应与 V2.4.3 相同。
- inactive 选项默认状态不变；GUI 的原有 include / exclude 行为不变。
- 新增的 MeshFilter component fileID 只补充来源定位，不改变 Mesh 数量和转换结果。
- `activeInHierarchy` 现在反映 Unity 全局状态；`activeWithinSelectedRoot` 与 `conversionIncluded` 分开反映原转换器从所选根对象开始的遍历决策。

## 需要用户在 Windows 10 验收

1. 使用同一个 `185_SankaF` scene-project。
2. 首次打开 GUI，确认 inactive GameObject 默认仍为勾选。
3. 勾选运行一次，保存 JSON 和 TXT。
4. 取消勾选运行一次，保存 JSON 和 TXT。
5. 对比上表中的 Mesh 数量、法线、UV0、三角面和 WARNING 数量。
6. 在 JSON 中确认 `meshFilterComponentIdCoverage.complete=true`，且缺失通道记录中的 `meshFilterComponentFileIDs` 已填充。
7. 在 TXT 中确认每个缺失 Mesh 的 GameObject、MeshFilter component fileID、active 状态和 conversion decision 可读。
8. 如果所选舞台根对象存在外部 inactive 祖先，确认 `activeInHierarchy=false` 不会错误地改变 `conversionIncluded`；此行为应与转换器直接从所选根对象开始遍历的现有逻辑一致。
9. 两个 PMX 文件仍需在 MMD 9.32 中打开检查外观。

当前开发环境完成了 58 项自动化测试与 Python 编译检查，但没有完整的 Windows `scene-project` 和 Blender 实机环境；上述实机回归仍待用户验收。
