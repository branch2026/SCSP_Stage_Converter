# 185_SankaF — V2.4.7 legacy v5 compatibility sample

This sample uses the user's existing V2.4.5-era `scsp-mesh-channel-diagnostics-v5` include/exclude quality reports. It verifies that V2.4.7 still reads the old reports without fabricating Mesh identities.

- Original 13 comparison checks: PASS.
- New 14th full-inventory check: INFO, because neither input contains `meshInventory` v1.
- Excluded-only unique Mesh references: 133.
- Mesh GUID/fileID identities known from old missing-channel records: 7.
- Mesh identities still unavailable in old reports: 126.

This is expected. The sample does **not** represent the final V2.4.7 full-inventory result for the real stage. To obtain the real 133 Mesh identities, regenerate at least one quality report with V2.4.7-dev (recommended: regenerate both include and exclude reports), then run the comparison again.
