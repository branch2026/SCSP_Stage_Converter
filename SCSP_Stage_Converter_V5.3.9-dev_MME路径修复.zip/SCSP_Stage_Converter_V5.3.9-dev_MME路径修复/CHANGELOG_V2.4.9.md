# V2.4.9-dev — inactive 状态一致性增强版

## 新增 / 修复

- `objects.inactiveInHierarchyObjects` 增加 `activeInHierarchy`、`activeInHierarchySource`、`activeInHierarchyInferred`。
- WARNING 诊断兼容旧报告缺失字段的情况：根据 inactive 列表语义推导 false，并显式标记 inferred。
- 新增 `inactiveHierarchySummary`，按最上层 inactive 根对象分组。
- 每个根对象统计受影响 GameObject、含 Mesh GameObject、MeshFilter 组件、唯一 Mesh。
- 按 included / excludedOnly / shared 统计 Mesh 范围，按 GUID + fileID 去重。
- JSON / TXT 同步输出 inactive 根对象影响清单。
- 质量报告版本标记升级为 2.4.9-dev；WARNING 诊断同时兼容 2.4.7-dev 和 2.4.9-dev。

## 不变更

- 不修改 Unity → Blender 重建核心。
- 不修改 Blender → PMX 导出核心。
- 不修改 inactive 纳入 / 排除规则。
- 不自动修复法线、UV、材质或隐藏对象。
