# V2.3.2-dev — Folder Batch Workflow Rebuild

## Baseline and scope

- Rebuilt from the preserved V2.3.1-dev BuiltinMeshFix baseline.
- Does not use the previous V2.3.2-dev multi-`.unity` file picker as its design basis.
- Leaves `SceneBuilder`, `PMXExporter`, Unity validation, built-in Plane / Quad handling, and texture repair unchanged.

## Correct batch workflow

1. Select the common parent directory containing stage folders.
2. Multi-select stage folders in the discovery dialog (Ctrl / Shift).
3. Discover each folder's `scene-project/Assets` (also accepts a folder that is itself a scene-project root).
4. Find `.unity` scenes below each `Assets` directory.
5. Scan each scene's top-level GameObject roots. A unique candidate is added automatically; multiple candidates open the retained Hierarchy selector.
6. Add tasks to one shared queue.

## Task isolation

- Every task stores `project`, `source_folder`, `scene`, and `root`.
- Validation, Blender rebuilding, and PMX export resolve the `project` path from the current task, not from the first selected project.
- Task-list format is version 2; legacy lists with one top-level `project` remain readable.
- When output is still the app's automatically suggested default, each stage writes under its own project. A manually selected shared output directory remains authoritative.

## Tests

- 4 folder-discovery tests pass; 2 additional task-isolation wiring tests pass.
- All 28 baseline tests pass.
- Total: 34 tests pass.
- Windows GUI interaction and full end-to-end PMX conversion remain pending user-side acceptance.
