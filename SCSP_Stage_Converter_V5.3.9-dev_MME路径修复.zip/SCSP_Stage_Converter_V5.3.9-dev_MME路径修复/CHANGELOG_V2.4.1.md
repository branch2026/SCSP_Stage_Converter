# V2.4.1-dev — Mesh 质量诊断增强

## 开发基线

- 从 V2.4.0-dev Quality Inspection 的工作副本继续开发。
- 原始 V2.4.0-dev 压缩包保持不变。
- V2.3.2-dev FolderBatchRebuild 和 V2.3.1-dev BuiltinMeshFix 原始回退压缩包保持不变。

## 新增功能

- 在只读质量检查阶段重新解析每个唯一 Mesh GUID + fileID 引用。
- 精确定位缺失法线和 UV0 的 Mesh。
- 记录 Mesh 名称、GUID、fileID、Assets 相对路径、顶点数和引用数量。
- 同时报告 MeshFilter 总数、有效引用数、空引用数和唯一 Mesh 引用数，便于解释组件数与资源数不相等的情况。
- 将 Mesh 映射到所有引用它的 GameObject，记录完整 Hierarchy 路径、GameObject fileID 和 activeSelf 状态。
- 对缺失 UV0 的 Mesh 记录 Renderer 材质及 MainTex 线索，提供风险提示。
- 统计缺失法线、缺失 UV0 和去重并集；避免将重叠项目重复计数。
- 新增 SRC-009，对对象级 Mesh 诊断与原有 Unity 源验证汇总数量进行交叉核对。
- JSON / TXT 报告输出完整定位信息；GUI 中 SRC-005 / SRC-006 显示前 10 个样例。

## 严格保护

- 不修改 SceneBuilder、PMXExporter、UnityParser/batch_folder_discovery.py、Validator/validate_source.py 或 RUN_GUI.bat。
- 不修改 Unity 资源、BLEND、PMX 或贴图。
- 不自动重算法线、不生成 UV、不改材质。
- 不改变批量添加、任务队列、项目隔离、Blender 重建、MMD Tools 导出或贴图修复逻辑。
- 质量诊断失败不会将已经成功生成的 PMX 改判为转换失败。

## 自动化测试

- V2.4.0 的 46 项回归测试全部保留。
- 新增 2 项 Mesh 通道对象级定位测试（缺失通道映射、共享 Mesh 多对象映射）。
- 当前共 48 项自动化测试通过。

## 实际资源测试

- 在已上传的 121_ForbiP scene-project 上执行对象级诊断。
- 152 个唯一 Mesh 引用全部解码。
- 90 个 Mesh 缺少法线；40 个 Mesh 缺少 UV0；90 个 Mesh 位于缺失通道去重并集。
- 对象级诊断的 Mesh 解码数、法线数和 UV0 数与原有 Unity 源验证报告完全一致。
- 185_SankaF 场景仍需用户在 Windows 端用 V2.4.1 重新运行，确认其 918 个 Mesh 的具体定位清单。

## 尚待用户验收

- Windows 10 GUI 交互与完整批量转换实机测试。
- 185_SankaF 的真实对象级诊断报告。
- MMD 9.32 最终外观验收。
