@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if "%~1"=="" (
  echo 用鼠标将一个 PMX 文件拖到本 BAT 上，可生成材质与贴图检查 JSON。
  pause
  exit /b 2
)
py -3 "StageEffects\stage_effects.py" inspect "%~1" --out "%~dpn1_StageEffects_Inspect.json"
set "ret=%errorlevel%"
if not "%ret%"=="0" pause
exit /b %ret%
