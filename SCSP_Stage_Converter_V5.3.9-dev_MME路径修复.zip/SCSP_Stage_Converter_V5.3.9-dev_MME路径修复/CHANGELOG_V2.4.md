# V2.4.0-dev — Conversion Quality Inspection

## 基线

- 从 `SCSP_Stage_Converter_V2.3.2-dev_FolderBatchRebuild.zip` 解压副本继续开发。
- `SCSP_Stage_Converter_V2.3.2-dev_FolderBatchRebuild.zip` 原始回退压缩包保持不变。
- V2.3.2 的多文件夹批量选择、每任务独立 scene-project、场景根对象扫描、任务队列、顺序转换逻辑保留。

## 新增

- 新增只读 `Validator/quality_check.py`。
- PMX 成功导出后自动执行质量检查。
- 检查 Unity Mesh 解码、MeshFilter 计数、法线/UV、材质和主贴图引用。
- 检查 Hierarchy 结构、MeshFilter / MeshRenderer 关系、空材质槽、重复对象名和空层级节点。
- 检查 Blender 重建的缺失 Mesh、Mesh 错误、几何输出覆盖、inactive 对象排除、材质警告和 ParticleSystem 动态效果。
- 检查 MMD Tools parser 回读、PMX 文件、PMX 二进制贴图表和实际贴图路径。
- 每个舞台输出 JSON + TXT 质量报告；若转换中途失败且已创建输出目录，也会尽可能生成部分质量报告。
- GUI 新增质量检查列和「打开质量报告」按钮。

## 保护措施

- 质量检查只读取数据，不改写 PMX 或贴图。
- 质量检查器异常不会让已成功生成的 PMX 转换任务失败。
- `SceneBuilder`、`PMXExporter`、`UnityParser/batch_folder_discovery.py` 和原有 Unity 源验证脚本不修改。
- `PASS` / `WARNING` / `FAIL` 与转换状态分开显示，质量警告不会触发重复转换。

## 自动化测试

- V2.3.2 原有 34 项测试保留。
- 新增 8 项质量检查测试。
- 新增 4 项 V2.4 GUI / 模块接线测试。
- 总计 46 项自动化测试。
