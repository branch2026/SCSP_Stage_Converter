# V2.4.6-dev 开发记录

开发目标：将现有 V2.4.5 的 Mesh 质量诊断接入一套**可单独运行、只读、可复现**的 inactive 两模式差异比较器，以便 V2.4 收尾后转向 V3.0 批量自动化。

## 实现

1. 复制完整 V2.4.5-dev 源码 ZIP，所有原有转换代码保留。
2. 新建 `Validator/compare_inactive_modes.py`，从报告 `objects`、`rebuild`、`meshDiagnostics`、`pmx` 取结构化数据。
3. 核对 include/exclude 策略、舞台根对象/场景/项目路径与 Unity 源统计，避免拿不同场景误作 A/B。
4. 精确统计排除 GameObject、MeshFilter、Excluded-only 唯一 Mesh；Shared 仍属于 Included 子集。
5. 从 `objects.inactiveInHierarchyObjects` 与 `rebuild.skippedInactive` 联合产生排除对象清单；从 `excludedOnlyMissing*` 尽可能补充 Mesh GUID/fileID。原报告没有完整 Mesh 资源引用表，不推测剩余 GUID。
6. 对比 PMX parser / Blender triangles / textureValidation.normalized_references，输出数量差、贴图差、审计状态及证据边界。
7. 新增独立 BAT 文件选择器；主 GUI 新增独立对比按钮，仅执行读取质量报告、保存对比报告。
8. 对照用户上传的 V2.4.5 include `(7)` / exclude `(8)` 真实报告检查，结果 13/13 PASS；保留 311 个排除对象和 133 个 MeshFilter 对象。
9. 运行自动化测试、Python 编译、转换文件 SHA-256、独立 ZIP 解压验证。

## 已知限制

- 质量报告中不包含完整的所有 Mesh GUID 与材质名称。要列出 133 个被排除 Mesh 的所有 GUID，需要未来另行设计仅扩充诊断清单的功能；这不应阻碍当前版本对比验收，更不应修改转换核心。
- 只读对比检查报告，不代表在 MMD 9.32 中实际测量到对应光照、动画、视频屏幕的视觉效果。
- V2.4.5 的部分 JSON 顶层 `version` 仍是 `2.4.4-dev`（检查器早期硬编码）；其 `meshDiagnostics.schema=v5` 与文件内容才是本轮报告实际能力依据。V2.4.6 不改变已有 `quality_check.py`，避免为展示元信息动转换或检查器逻辑。
