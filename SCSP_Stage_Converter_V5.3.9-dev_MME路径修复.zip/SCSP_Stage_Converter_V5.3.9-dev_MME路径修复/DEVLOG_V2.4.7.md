# V2.4.7-dev 开发记录

## 目标

解决 V2.4.6-dev 双模式报告中 133 个 Excluded-only 唯一 Mesh 仅 7 个有 GUID/fileID 的问题，并补充 Unity Renderer 材质身份线索。不得修改已验证的 Unity → Blender → PMX 转换功能。

## 根因

V2.4.6 的 `quality_check.py` 在 `_inspect_mesh_channel_diagnostics()` 中已经遍历全部唯一 Mesh GUID + fileID，解析 Mesh、GameObject、MeshFilter component fileID 和 Renderer 材质；但只有缺少法线或 UV0 的记录会被写入 JSON 明细数组。正常 Mesh 的身份仅存在于内存循环中，没有序列化到质量报告。因此 126 个有完整几何通道的 Mesh 在旧报告中不可追溯。

## 实现

1. 以 V2.4.6-dev 完整源码为起点，不覆盖历史 ZIP。
2. 将质量诊断 schema 升级为 v6，新增 `meshInventory`，每个唯一 Mesh GUID + fileID 一条记录。
3. 对 decoded / unresolved / decode_error 三种状态均保留身份和对象引用；解码错误不会让资源身份消失。
4. 为每个 GameObject 的 Renderer 材质增加 material GUID/fileID 和 MainTex GUID/fileID/路径信息；明确这是 GameObject 级材质关联，不冒充严格一对一 Mesh 绑定。
5. 增加 `meshInventorySummary`，验证 inventory 行数、GUID/fileID 完整性、解码状态和 scope 计数。
6. 比较器优先使用 include 全量清单和 exclude 的 skippedInactive ID 推导 Excluded-only / Shared；若 include 缺少 v6，则可从 exclude v6 清单恢复；两份 v6 均存在时校验身份集合一致。
7. v4/v5 报告继续兼容，旧报告只显示已有 7 条身份，不生成虚构 GUID，并用 INFO 提醒重新生成 v6 报告。
8. 更新 GUI 版本标签、使用说明、比较指南和质量诊断指南。

## 回归保护

- 15 个受保护转换文件 SHA-256 与 V2.4.6-dev 基线逐字节一致。
- `SceneBuilder`、`PMXExporter`、批量文件夹发现、源验证和 RUN_GUI.bat 未修改。
- 新逻辑只在只读质量报告生成与对比阶段运行。

## 当前验收边界

- 自动化测试：89/89 PASS。
- 用户当前 185_SankaF 旧 v5 JSON：兼容对比 13 项 PASS + 1 项 INFO，7 已知、126 未知；这是预期的旧报告限制。
- 尚未拿到 185_SankaF 的完整 Unity scene-project / Assets 源文件，无法在本构建环境重跑该场景的 Unity 资源扫描。用户需用 V2.4.7 在本机重新生成 v6 include/exclude 质量报告，才能验收真实的 133 条 Mesh 身份。
