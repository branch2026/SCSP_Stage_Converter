# SCSP Stage Converter V2.3.2-dev · Folder Batch Rebuild

## 本版目标

本版从 **V2.3.1-dev** 回退基线重新制作批量入口。保留原有 Unity Hierarchy 识别、Plane / Quad 内置 Mesh 修复、Blender 舞台重建、MMD Tools 原生 PMX 导出和贴图路径修复。

本版批量入口的对象是**多个舞台文件夹**，不是多个 `.unity` 文件。每个队列任务独立保存自己的 `scene-project` 根目录，避免不同舞台错误共用第一个项目路径。

**V2.2 的最终 PMX 输出改为 Blender 中已启用的 MMD Tools 原生 `bpy.ops.mmd_tools.export_pmx`。**

本版继续采用每个 Unity 舞台输出一个完整 PMX 的方案。

## 本版核心流程

### 多文件夹批量添加（本版重点）

1. 点击「批量添加舞台文件夹…」。
2. 选择多个舞台文件夹共同所在的父目录，例如 `G:\STAGE\Stage\新建文件夹`。
3. 程序列出父目录中的子文件夹；按住 Ctrl 多选，或按住 Shift 连选需要转换的舞台文件夹。
4. 自动识别每个舞台文件夹里的 `scene-project\Assets`，也兼容直接选择 `scene-project` 根目录。
5. 自动递归查找各自 `Assets` 下的 `.unity` 文件，并扫描每个场景的顶层 GameObject 根对象。
6. 如果场景只有一个根对象候选，自动加入；如果存在多个候选，打开原有 Hierarchy 预览供确认，不会静默选错。
7. 每个任务独立记录自己的 `scene-project` 路径，统一加入队列。

### 转换流程

1. 验证 Unity 场景和 Mesh 资源。
2. 使用 Blender 后台重建完整舞台 `.blend`。
3. 使用 MMD Tools 原生 PMX 导出器输出一个完整 PMX。
4. 自动读取 PMX 中的贴图引用。
5. 检查输出目录中的贴图文件；若 MMD Tools 将 `name_<8位哈希>.png` 的路径同步为 `name.png`，自动补齐同名文件。
6. 如果存在缺失或歧义贴图引用，本舞台标记失败并保留报告；批量队列继续处理下一项。

## 主要功能

- Unity 场景顶层根对象候选扫描和选择
- 完整 Unity Hierarchy 树状预览、展开/折叠和子对象名称搜索
- 每个 GameObject 的 MeshFilter、Renderer、ParticleSystem 数量显示
- 多舞台任务队列
- 一次选择多个舞台文件夹，自动发现各自的 `scene-project\Assets\*.unity`
- 每个队列任务独立保存项目根路径；不同舞台不会共用错误的 Assets 目录
- 任务清单 JSON 导入 / 导出（保存每个任务的项目路径）
- 单舞台转换 / 顺序批量转换
- 单项失败后继续处理后续舞台
- 停止按钮只在当前舞台完成后停止
- 每个舞台独立输出目录、日志和 JSON 报告
- 自动保存 Blender、项目和输出目录设置
- 默认包含 inactive GameObject
- 每个舞台输出一个完整 PMX
- MMD Tools 环境预检查：在重建舞台之前确认所选 Blender 已注册原生导出操作符
- PMX 文件由 MMD Tools 自身解析回读
- 自动贴图路径修复及完整性校验

## 环境要求

- Windows 10
- Python 3.10 或更高版本（用户环境 Python 3.14.10 可用）
- Python Tkinter
- Blender 4.4.3
- Blender 4.4.3 当前用户配置中已安装并启用 MMD Tools 4.x
- 已实测的 MMD Tools 版本：4.5.14

**重要：** MMD Tools 必须在 GUI 选择的同一个 Blender 安装中启用，并保存 Blender 偏好设置。V2.2 会先用该 Blender 执行后台预检查。如果未启用，程序会在开始重建 Unity 场景前停止，不会白白跑完整个转换。

## 运行方法

1. 解压整个 ZIP 到一个新目录，不要覆盖 V2.3.1-dev 回退基线。
2. 双击 `RUN_GUI.bat`。
3. 选择 Blender 4.4.3 的 `blender.exe`。
4. 点击「批量添加舞台文件夹…」，选择包含多个舞台文件夹的共同父目录。
5. 在文件夹列表中按 Ctrl / Shift 选择多个舞台文件夹，点击「添加选中的文件夹」。
6. 检查队列中的来源文件夹、Unity 场景和舞台根对象。若场景存在多个根对象候选，按原有 Hierarchy 预览确认。
7. 点击「批量转换」。

如果只想添加一个场景，仍可使用「单场景默认 scene-project」和「添加单个场景…」按钮。

## MMD Tools 加载方式

- MMD Tools 预检查和 PMX 导出阶段**不会使用** `--factory-startup`，以便 Blender 读取当前用户保存的扩展/插件启用设置。
- Unity 场景重建阶段仍使用 `--factory-startup`，因为该步骤不依赖 MMD Tools。
- 后台脚本会尝试通过 Blender Preferences 启用已安装的 MMD Tools，再检查 `bpy.ops.mmd_tools.export_pmx` 是否注册。
- 不会把 MMD Tools 插件本体打包进本项目；使用用户已经安装的插件。

## 输出结构

默认情况下，每个舞台输出到各自 `scene-project/PMX_Output_GUI/`。如果手动指定统一 PMX 输出目录，则所有队列任务都写入该统一目录。

批量任务的输出目录名会带上来源舞台文件夹名，避免不同项目中的同名场景发生覆盖。

`<scene文件名>__<根对象名>/`
- `<根对象名>_source_validation.json`
- `<根对象名>_source_validation.log`
- `<根对象名>_rebuilt.blend`
- `<根对象名>_rebuild_report.json`
- `<根对象名>_rebuild.log`
- `<根对象名>.pmx`
- `textures/`（原始导出贴图及为 PMX 引用补齐的准确文件名）
- `<根对象名>_mmd_tools_report.json`
- `<根对象名>_mmd_tools_export.log`
- `<根对象名>_native_export_internal.log`

如果目标目录已存在，程序会自动追加 `_02`、`_03`，不会覆盖旧输出。

## 贴图路径处理说明

V2.2.2 读取 MMD Tools 实际写入 PMX 的贴图字符串表，逐项验证贴图引用。针对 V2.2 实际运行日志中出现的绝对 Windows 路径（例如 `G:\...\textures\Stage_xxx_hash.png`），会先确认目标文件确实位于当前舞台输出包中，再转换为 `textures/Stage_xxx_hash.png` 这样的相对路径。

当 PMX 引用 `textures/Stage_xxx.png`，而导出目录只有 `textures/Stage_xxx_1234abcd.png` 时，程序会根据唯一的八位哈希后缀候选复制一份准确命名的文件，不重新编码图像。

**PMX 二进制改写范围严格限制为贴图字符串表。** 程序不重新序列化顶点、法线、UV、面索引、材质、骨骼、Morph、刚体或关节。改写前后会回读 PMX 字符串表，并再次调用 MMD Tools parser 检查整个 PMX。如果贴图解析、表回读或 MMD Tools parser 检查失败，会恢复改写前的原始 PMX 字节并将舞台标记失败。

如果同一个目标名称对应多个不同的哈希候选，程序会报告歧义并将该舞台标记失败，不会随意挑选错误贴图。

## 旧版自定义 PMX Writer

旧版 `pmx_stage_writer.py` 和 `export_stage_pmx.py` 已移动到：

`PMXExporter/Legacy_CustomWriter/`

它们只作为历史代码保留。**V2.2 GUI 不会调用旧写入器。**

## 验证边界

本次已完成：
- 全部 Python 文件语法检查
- GUI 自动根对象扫描的模拟 Unity YAML 回归测试
- MMD Tools 桥接模块和原生导出命令静态检查
- 绝对路径规范化、相对路径验证、哈希文件名别名、重复引用、缺失引用和越界路径回归测试
- PMX 贴图字符串表改写测试：覆盖 BDEF1、BDEF2、BDEF4、SDEF、QDEF，并验证贴图表前后字节保留
- 使用已上传的 182_SuperD 原生 PMX 样本进行 48 条绝对路径模拟改写；验证 48 条引用全部转为相对路径，贴图表以外字节保持一致
- 21 项自动化测试通过

本次尚未完成：
- 未在用户 Windows 10 / Blender 4.4.3 / MMD Tools 4.5.14 环境实际执行整套 V2.2.2 GUI 批量流程
- 新版改写后的 PMX 尚需在 MMD 9.32 实机验收
- 除 182_SuperD、185_SankaF 已有的 V2.2 运行结果外，其他舞台仍需逐个验收
- 没有加入 Bloom、游戏灯光、发光和粒子效果

## 建议首次测试顺序

1. 先只添加 `182_superd.unity`，确认自动识别出 `182_SuperD`。
2. 转换一个舞台。
3. 检查报告中 `mmd_tools_parser_check.status` 为 `PASSED`。
4. 检查 `texture_validation.status` 为 `PASSED`，且 `unresolved_count` 为 `0`。
5. 用 MMD 9.32 打开输出 PMX。
6. 单舞台通过后，再把其他舞台加入批量队列。

## 失败时需要提供

如果失败，只需要上传对应舞台目录中的：
- `<根对象名>_mmd_tools_report.json`
- `<根对象名>_mmd_tools_export.log`
- `<根对象名>_native_export_internal.log`
- 若失败发生在重建阶段，再提供 `<根对象名>_rebuild.log`

不需要重新上传整个 AssetRipper scene-project。


## V2.2.2-dev 贴图路径修复

根据 V2.2 在 Blender 4.4.3 / MMD Tools 4.5.14 下的实际日志，PMX 文件已由 MMD Tools 成功写出，但 PMX 贴图表中的 48 个引用是绝对 Windows 路径。V2.2 原本的检查器只接受相对路径，因此将这些有效引用全部误判为缺失。

V2.2.2 在不更换原生 PMX Writer 的前提下修复这一点：

1. 读取 MMD Tools 导出的 PMX 贴图字符串表，保留原始顺序和重复项。
2. 检查每条绝对或相对路径，并确认实际贴图文件存在。
3. 将指向当前舞台输出包的绝对路径转换为 `textures/文件名` 相对路径；必要时按唯一哈希候选补齐准确文件名。
4. 只改写 PMX 贴图字符串表，不重新序列化顶点、面、材质、骨骼、Morph、刚体或关节。
5. 再次读取 PMX 字符串表、检查每个贴图文件，并用 MMD Tools parser 回读整个 PMX。
6. 如果后置校验或 parser 回读失败，恢复路径改写前的 PMX 原始字节，不留下半成品改写文件。

**主程序仍然是根目录 `RUN_GUI.bat`。** 本版不包含独立的贴图修复 BAT；请从主 GUI 执行单舞台或批量转换。

## V2.2.2 首次测试建议

1. 解压到全新目录，不覆盖 V2.2。
2. 双击 `RUN_GUI.bat`，确认主 GUI 正常显示。
3. 使用原来的 `scene-project` 和 Blender 4.4.3 路径。
4. 先只转换 `Assets/182_superd.unity`，根对象选择 `182_SuperD`。
5. 检查报告：`texture_validation.status` 应为 `PASSED`，`unresolved_count` 应为 `0`；`mmd_tools_parser_check.status` 应为 `PASSED`。
6. 确认 PMX 贴图引用已经是相对路径，再用 MMD 9.32 打开验收。
7. 单舞台通过后再执行其他舞台的批量转换。


## V2.3 Unity Hierarchy 识别窗口

自动识别窗口分为上下两个区域：

- 上方候选表只显示场景顶层 GameObject。选择这里的对象，才会作为舞台根对象加入任务队列。
- 下方 Hierarchy 树显示所选顶层对象的完整子层级，可以展开/折叠，并按名称搜索子对象。
- 子对象（例如 `EffectPlayer`）不会作为独立舞台候选。
- 树中各行的 MeshFilter、Renderer、ParticleSystem 数字表示该 GameObject 自身的组件数量；上方候选表显示整个子树的汇总数量。
- Renderer 汇总包含 MeshRenderer、SkinnedMeshRenderer、ParticleSystemRenderer、LineRenderer、TrailRenderer、SpriteRenderer 和 CanvasRenderer。

`121_ForbiP` 验收样本：根对象下包含 `EffectPlayer`，其下包含 `121_Effects`。V2.3 会在层级树中显示该关系。


## V2.3.1-dev — Unity Built-in Mesh 修复

V2.3 的 Hierarchy 预览已经能正确显示 `121_ForbiP > EffectPlayer > 121_Effects`，但 `121_forbip.unity` 在资源验证阶段出现：

`Mesh GUID unresolved: 0000000000000000e000000000000000`

这不是缺失的普通 `.asset` 文件。该 GUID 是 Unity 内置资源标识，必须结合 `fileID` 判断具体内置网格。

本版修复：

- `fileID: 10209` → Unity 内置 Plane（10 × 10，10 × 10 网格细分）。
- `fileID: 10210` → Unity 内置 Quad（1 × 1，局部法线朝 -Z）。
- Mesh 缓存键从单独 GUID 改为 `(GUID, fileID)`，避免 Plane 与 Quad 因共用 GUID 而互相覆盖。
- Unity 资源验证器会把受支持的内置网格识别为已解析资源，不再误报 `Mesh GUID unresolved`。
- Blender 重建器会为 Plane / Quad 生成对应几何，并计入重建报告。

### 121_ForbiP 验收数据

本次对上传的完整 `041451774686.zip` / `scene-project/Assets/121_forbip.unity` 执行了资源验证：

| 项目 | 验证结果 |
|---|---:|
| GameObjects | 747 |
| MeshFilter 组件 | 285 |
| 已解析 MeshFilter | 285 / 285 |
| 普通 Mesh 资源 | 150 |
| 内置 MeshFilter | 71 |
| 内置 Plane | 26 |
| 内置 Quad | 45 |
| 主贴图引用 | 56 / 56 |
| 验证错误 | 0 |

### EffectPlayer 与粒子系统的转换边界

`EffectPlayer` 子树中的 71 个静态 MeshFilter（26 个 Plane、45 个 Quad）现在可以进入 Blender 静态几何重建。

场景还包含 188 个 ParticleSystem 和 188 个 ParticleSystemRenderer。它们的 GameObject 层级会保留，但 Unity 粒子系统属于随时间变化的运行时效果，不会被伪装成已完整转换的静态 PMX 网格。本版会在验证和重建报告中明确记录这一限制。

### 本版验证边界

- Python 源码语法检查通过。
- 28 项自动化测试通过。
- 使用完整 121_ForbiP scene-project 实际运行 `validate_source.py`：退出代码 0，285/285 MeshFilter 全部解析，56/56 主贴图解析。
- Plane / Quad 顶点、UV、索引和法线方向单元测试通过。
- 尚未在用户 Windows 10 + Blender 4.4.3 + MMD Tools 4.5.14 环境执行完整 Blender 重建和 MMD 9.32 实机验收；请先单独转换 `121_forbip.unity`。


## V2.3.2-dev — 多文件夹批量入口重做

本版不是在错误的「多选 `.unity` 文件」入口上继续打补丁，而是从 V2.3.1-dev 回退基线重新实现文件夹级批量添加。

- 新增「批量添加舞台文件夹…」按钮。
- 先选择多个舞台文件夹共同所在的父目录，再在列表中使用 Ctrl / Shift 多选。
- 自动识别 `<舞台文件夹>\scene-project\Assets`；也兼容所选文件夹本身就是包含 `Assets` 的 scene-project 根目录，以及少量额外包装目录。
- 自动递归查找 `Assets` 下的 `.unity` 场景。
- 自动扫描顶层舞台根对象；唯一候选自动加入，多候选保留原有 Hierarchy 预览确认。
- 每个任务单独记录 `project` 和 `source_folder`；转换时按当前任务自己的项目路径验证、重建和导出。
- 任务清单升级为版本 2，导入时兼容旧版只记录单个项目根目录的任务清单。
- 当输出目录是程序自动建议的默认目录时，多文件夹批量任务分别输出到各自项目目录；用户手动指定统一输出目录时则遵从用户设置。

### 本版自动化验证

- 批量文件夹发现测试：4 项通过（多舞台目录、直接 scene-project 根目录、额外包装目录、多个嵌套项目歧义检测）。
- V2.3.1-dev 原有测试：28 项通过。
- 当前合计：34 项自动化测试通过。
- Python 源码语法检查通过。
- 尚未在用户 Windows 10 / Blender 4.4.3 / MMD Tools 4.5.14 环境执行实际 GUI 文件夹多选及完整 PMX 转换；需要先用两个测试舞台文件夹验收批量入口。
