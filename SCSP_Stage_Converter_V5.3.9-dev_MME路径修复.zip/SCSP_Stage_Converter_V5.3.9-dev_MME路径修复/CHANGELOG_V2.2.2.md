# SCSP Stage Converter V2.2.2-dev

## 基线
- 从完整的 `SCSP_Stage_Converter_V2.2-dev_MMDToolsNative.zip` 重新建立。
- 保留 V2.2 主 GUI、任务队列、根对象扫描、Unity 验证、Blender 重建和 MMD Tools 原生导出流程。
- 保留 Blender 4.4.3、MMD Tools 4.5.14、PMX 比例 12.5 和每舞台一个 PMX 的输出方式。

## 修复
- 修复 MMD Tools 写入 PMX 绝对 Windows 贴图路径时，V2.2 将所有引用误判为缺失的问题。
- 新增 PMX 贴图表解析和只修改贴图字符串表的安全改写。
- 保留贴图表顺序和重复项。
- 改写后再次用 MMD Tools parser 回读；失败则恢复原始 PMX 字节。
- GUI 日志显示绝对路径规范化数量、文件名别名补齐数量和字符串表改写数量。
- 保留原来的 `RUN_GUI.bat` 作为唯一主 GUI 启动入口，不包含独立的修复 BAT。

## 自动化验证
- 21 项自动化测试通过。
- 已用 182_SuperD 原生 PMX 样本做 48 条绝对路径模拟，全部规范化成功。
- PMX 贴图表前后的非贴图数据字节一致。
- 尚未在用户 Windows / Blender / MMD 9.32 环境实机验收本版。
