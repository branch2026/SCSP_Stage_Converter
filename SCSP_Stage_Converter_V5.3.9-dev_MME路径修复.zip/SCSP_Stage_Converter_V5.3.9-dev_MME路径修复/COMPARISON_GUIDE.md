# SCSP V2.4.7-dev · 双模式质量报告与 Excluded Mesh 完整追踪指南

## 用户操作（最简单）

1. 推荐使用 V2.4.7-dev，分别对**同一个** Unity 舞台生成勾选 `inactive GameObject` 和未勾选的质量报告。若已有 V2.4.7 质量报告，可直接比较，不需要重新转换。
2. 将两次产生的 `*_quality_report.json` 保留在不同目录或用不同文件名备份。**注意**：如果两次输出到相同目录，后一次可能覆盖前一次质量报告；事先备份第一份。
3. 双击 `RUN_COMPARE.bat`，先选择「勾选（include）」的质量报告 JSON，再选择「未勾选（exclude）」的 JSON。
4. 选择输出 JSON 的保存位置。程序同时生成同名 TXT。无需运行 Blender、无需打开 PMX。
5. 也可以打开 `RUN_GUI.bat`，在主 GUI 点击「双模式对比…」运行同一功能。

> 双模式对比**不会**帮你自动生成两组 PMX，也不会修改源报告或模型。它针对**已经完成转换**的两组报告做只读检查。

## 命令行调用

```bat
py -3 "Validator\compare_inactive_modes.py" ^
  --include "D:\Reports\include\185_SankaF_quality_report.json" ^
  --exclude "D:\Reports\exclude\185_SankaF_quality_report.json" ^
  --json-out "D:\Reports\185_SankaF_inactive_mode_comparison.json" ^
  --text-out "D:\Reports\185_SankaF_inactive_mode_comparison.txt"
```

退出码：`0 = 自检通过`、`1 = 存在需要人工核查的数据差异`、`2 = 输入不合法、文件操作错误或不能比较`。

## 输入兼容性

- 必须为结构化 SCSP `scsp-stage-quality-report-v1` 质量报告 JSON，不能使用 TXT 作为输入。
- 兼容 `scsp-mesh-channel-diagnostics-v4`、`v5`、`v6`。v4/v5 可完成旧版 13 项结构对比，但没有完整 Mesh 身份清单；v6 额外提供全量 `meshInventory`。
- include 与 exclude 策略必须各一份，且要对应同一 Unity `project` / `scene` / `root`，源统计相同。
- 一份数据缺失、来源不一致或两份策略相同，将报错拒绝比较；绝不会把不同场景误判为可比较。

## 输出 JSON 字段

- `summary`：对比自检状态、被排除 GameObject / MeshFilter / 唯一 Mesh 数量、GUID 已识别与未知数量。
- `differences`：原有 include 与 exclude 的参与对象、MeshFilter、Mesh、Blender 对象/面、PMX 顶点/面/材质/贴图、缺法线/UV0 的差值。
- `excludedObjects`：全部被排除 GameObject（含无 MeshFilter 的层级对象），包括 fileID、层级路径、inactive 自身/父级原因。
- `excludedMeshFilterObjects`：上面子集：存在 MeshFilter 的对象；v6 可完整关联 Mesh GUID/fileID，旧版 v4/v5 只关联已有缺失通道明细的 Mesh。
- `identifiedExcludedOnlyMeshes`：v6 下完整列出 Excluded-only Mesh 的 GUID/fileID、资源路径、通道状态、层级对象及材质引用；旧版 v4/v5 仍只包含缺失通道清单中已知的 Mesh。
- `meshInventoryCoverage`：全量清单可用性、覆盖数量、身份完整性、范围计数、include/exclude GUID/fileID 集合一致性，以及 GameObject / MeshFilter component fileID 关联一致性。
- `excludedMaterialInventory`：被排除对象 Renderer 使用的 Unity 材质身份及 MainTex 引用；这是 GameObject 级关联证据，不是 PMX 材质槽清单；同一 GUID 下多个 Material 子资产的名称/MainTex 仍需按 fileID 人工复核。
- `pmxTextureDifferences`：两组 PMX 报告中的实际贴图引用差集。
- `checks`：14 项判断；旧版缺少 v6 清单时第 14 项为 INFO，不会伪装成完整追踪。
- `limitations`：原质量报告字段约束和人工视觉验收界限。

## V2.4.7 完整身份清单生成步骤

1. 使用 V2.4.7-dev 完成舞台转换后，质量检查会自动生成 v6 JSON；若不希望重新转换，可按 `QUALITY_CHECK_GUIDE.md` 的命令行方式，使用已有 source validation、Blender rebuild、PMX report、PMX 文件和 Unity scene-project 重新运行只读质量检查。
2. 分别保留 include 与 exclude 两份新的 `*_quality_report.json`。建议两份都用 V2.4.7-dev 生成。
3. 运行 `RUN_COMPARE.bat`，先选 include，再选 exclude。
4. 检查 `meshInventoryCoverage`：`inventoryComplete=true`、`identityComplete=true`、`scopeCountsMatch=true`、`crossReportIdentityMatch=true`、`crossReportOccurrenceMatch=true`、`reportSummaryScopeMatch=true`。
5. 对本次 185_SankaF，预期 Excluded-only 唯一 Mesh 为 133；如果真实新报告统计不同，以新报告的源范围核对结果为准，不强行要求旧数量。

旧 v4/v5 报告不会因为使用新比较器而自动获得缺失 GUID。至少一份输入报告必须包含 v6 `meshInventory` 才能恢复全量身份。

## 185_SankaF 实机样本

使用用户上传的 V2.4.5-dev include `185_SankaF_quality_report(7).json` 和 exclude `185_SankaF_quality_report(8).json`，V2.4.6 对比器 13/13 检查通过（这是旧版报告的基线结果）：

| 指标 | include | exclude | 差值 |
|---|---:|---:|---:|
| 参与转换 GameObject | 1820 | 1509 | 311 |
| 参与转换 MeshFilter | 921 | 788 | 133 |
| 参与转换唯一 Mesh | 918 | 785 | 133 |
| Blender 三角面 / PMX 面 | 58,851 | 54,202 | 4,649 |
| PMX 顶点 | 94,654 | 88,659 | 5,995 |
| PMX 材质 | 56 | 52 | 4 |
| PMX 贴图 | 46 | 43 | 3 |
| 缺少法线的参与转换 Mesh | 217 | 210 | 7 |

额外识别 133 个 MeshFilter 所在对象及其层级路径；所有 133 个对象 fileID 均能定位。只有 7 个 GUID 可以由缺失通道明细确定，余下 126 个 GUID 无法凭旧版质量报告单独重建。V2.4.7-dev 新增全量 meshInventory 后，需要重新生成至少一份 v6 质量报告；推荐 include 和 exclude 两份都重新生成，以便做跨报告身份集合核对。

旧版兼容示例位于 `docs/185_SankaF_V2.4.7_LegacyCompatibility.json/.txt`；历史 V2.4.6 样例也保留。无需将原始两份约 10 MB 的质量报告重新打包到程序里。

## 工程保护原则

- 不修改或重新运行 Unity → Blender → PMX 转换链。
- 不修改法线/UV/材质/贴图或舞台层级。
- 即使对比 `PASS`，原始两组质量报告中的 WARNING 仍保留。
- 不能仅凭数量相等承诺 MMD 9.32 视觉效果与 Unity 原舞台一致。
