# V2.4.10-dev — Mesh 法线与 inactive 关联诊断增强版

## 新增

- 缺法线 Mesh 按 GUID + fileID 比较 Include / Exclude 两种转换模式，分类为 common、include_only、exclude_only。
- 对每个缺法线 Mesh 同时读取两种模式的 MeshInventory 状态：scope、conversionIncluded、hasNormals 和 GameObject 引用。
- 将 `activeInHierarchy=false` 的 Mesh 引用关联到最上层 inactive 根对象，保留完整 Hierarchy 路径、GameObject fileID、inactive cause 和状态来源。
- 验证 Include-only 缺法线 Mesh 是否在 Exclude 的 MeshInventory 中明确标记为 `excludedOnly` 且 `conversionIncluded=false`。
- 新增 UV0、材质贴图状态和 normalEvidence 分类统计。
- 新增 inactive 状态来源核验：区分 MeshInventory 原始字段、inactive 清单成员推导，以及不可用状态。
- 新增 Include / Exclude 相同 GameObject fileID 的原始 activeInHierarchy 跨模式一致性检查。
- JSON 输出 schema 升级为 `scsp-warning-diagnostics-v2`；TXT 同步增加法线与 inactive 关联章节。
- 主 GUI 的 WARNING 诊断入口更新为「WARNING / 法线关联诊断…」。

## 185_SankaF 回归数据

- Include：217 个缺法线唯一 Mesh。
- Exclude：210 个缺法线唯一 Mesh。
- 两模式共有：210。
- Include-only：7；Exclude-only：0。
- Include-only 的 7 个 Mesh 均在 Exclude inventory 中验证为 `excludedOnly` 且未参与转换。
- 7 个 Include-only Mesh 全部关联到 2 个 inactive 根对象：`door`（6 个）与 `bonfire_shadow02`（1 个）。
- 217 个 Include 缺法线 Mesh：118 个 UV0 缺失且材质未检测到 MainTex；99 个 UV0 存在且关联带贴图材质。
- inactive 对象清单共 311 项；其中 133 项可通过 MeshInventory 原始 activeInHierarchy 字段直接核验为 false，另外 178 项没有 MeshInventory 对象引用，仍按 inactive 清单成员身份推导。
- 两种模式 MeshInventory 中 921 个共同 GameObject fileID 的原始 activeInHierarchy 状态一致，0 项冲突。
- 3 条原有 WARNING 全部仍保留并完成原有定位；本版本不修复 WARNING。

## 不变更

- 不修改 Unity → Blender 重建核心。
- 不修改 Blender → PMX 导出核心。
- 不修改 inactive 纳入 / 排除规则。
- 不自动补法线、UV、材质或贴图。
- 不删除、启用或禁用任何 GameObject / Mesh。
