# SCSP Stage Converter V3.0 使用说明

完整批量转换与失败重试步骤见 README.md。

1. 将整个 ZIP 解压到一个新目录，在 Windows 上双击 `RUN_GUI.bat`。启动器使用 `py -3` 调用带 Tk 的 Python 3。
2. 在界面指定已启用 MMD Tools 的 Blender 和导出目录。本次验收使用 Blender 4.4.3。
3. 添加 AssetRipper 的 scene-project，选择 Unity 场景及舞台根对象。按需要勾选「inactive GameObject」以包含隐藏对象。
4. 执行转换，在各舞台输出目录中查看 PMX 和质量报告。移动模型时一并复制 textures 文件夹。比较两种模式时分别保留各自的输出目录。

## 2. 使用 WARNING 精准定位

1. 双击 `RUN_GUI.bat`。
2. 点击主界面「WARNING / 法线关联诊断…」。
3. 选择勾选 inactive GameObject 时生成的 Include JSON。
4. 选择取消勾选 inactive GameObject 时生成的 Exclude JSON。
5. 选择输出位置。程序自动生成同名 JSON 和 TXT。

也可以双击 `RUN_WARNING_DIAGNOSTICS.bat` 独立启动诊断窗口。此过程不重新转换舞台。

## 3. inactive 状态字段

新版本质量报告的 `objects.inactiveInHierarchyObjects` 每条记录新增：

- `activeInHierarchy`：Unity 层级计算得到的有效激活状态。
- `activeInHierarchySource`：状态来源，当前新报告为 `computed_by_unity_hierarchy_walk`。
- `activeInHierarchyInferred`：新报告为 `false`。

旧版 V2.4.7 / V2.4.8 JSON 没有 `activeInHierarchy` 字段时，诊断器依据对象属于 `inactiveInHierarchyObjects` 清单这一事实推导为 `false`，并标记：

- `activeInHierarchySource = inferred_from_inactiveInHierarchyObjects_membership`
- `activeInHierarchyInferred = true`

因此不会把推导值误写成 Unity 原始采样值。

## 4. inactive 根对象汇总

诊断器会在所选舞台层级内寻找最上层的 inactive GameObject，并将其后代 inactive 对象归入对应根对象。每个根对象输出：

- 根对象名称、GameObject fileID、完整 Hierarchy 路径。
- 受影响 GameObject 数量。
- 含 Mesh 的 GameObject 数量。
- MeshFilter 组件数量。
- 唯一 Mesh 数量（按 GUID + fileID 去重）。
- included / excludedOnly / shared Mesh 数量。

根对象分组不是自动修复，也不会自动把隐藏对象加入转换。

## 5. WARNING 诊断内容

- `SRC-005`：缺少法线 Mesh 的资源身份、GameObject、MeshFilter、Hierarchy、材质和 MainTex。
- `BLD-004`：被排除的 inactive GameObject、Excluded-only Mesh，以及每个 inactive 根对象的影响统计。
- 跨模式比较缺法线 Mesh 的共有 / 独有 GUID + fileID。
- 未支持的 WARNING 保留原始 details，不推测归属。

## 6. 兼容性

WARNING 诊断支持读取 V2.4.7-dev 和 V2.4.9-dev 质量报告。V2.4.7 / V2.4.8 旧 JSON 不需要重新转换即可运行；如果重新生成质量报告，新字段会直接写入。

## 7. 安全边界

- 不修改 Unity 场景、BLEND、PMX、贴图、Mesh、法线、UV 或材质。
- 不修改 Unity → Blender → PMX 转换核心。
- 不改变 inactive GameObject 纳入 / 排除策略。
- 不自动修复任何质量问题。


**V3.1-dev** 新增舞台效果后处理。请先看 `README.md` 和 `StageEffects/README_V3.1.md`；原有批量转换操作保持不变。
