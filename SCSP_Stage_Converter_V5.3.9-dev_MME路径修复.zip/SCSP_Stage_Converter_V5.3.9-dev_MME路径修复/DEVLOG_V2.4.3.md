# V2.4.3-dev 开发记录

## 开发目的
修正 V2.4.2 报告中 Source 全场景统计与实际转换范围统计混合展示的问题，并让 UV0 缺失警告更贴近材质证据。

## 统计范围
- `source`：舞台根层级内全部可解析唯一 Mesh 引用。
- `included`：至少被一个本次参与转换的 GameObject 引用的唯一 Mesh；Shared Mesh 在此范围只计一次。
- `excludedOnly`：只被本次排除对象引用的唯一 Mesh。
- `shared`：同时被纳入与排除对象引用的唯一 Mesh；作为 included 的子集单独展示，不与 included 相加。

每个范围分别记录唯一引用数、有效 MeshFilter 组件数、成功解码数、有法线/缺少法线、有 UV0/缺少 UV0、缺失通道去重并集及 UV 风险分布。解码失败引用仍保留在唯一引用统计中，不会悄悄从范围分母消失；通道覆盖率分母使用该范围内成功解码的 Mesh 数。

## SRC-005 法线
- `withNormals` 与 `decodedMeshes` 均取 Included 范围。
- `missingMeshCount` 取 Included 范围缺失法线的唯一 Mesh 数。
- Source / Excluded-only / Shared 数据作为附加 scopeStats 输出，不混入 Included 分母。

## SRC-006 UV0
- `withUV0` 与 `decodedMeshes` 均取 Included 范围。
- `TEXTURED_MATERIAL_ASSIGNED` 和 `MATERIAL_USAGE_UNKNOWN` 仍为 WARNING。
- `NO_MAIN_TEXTURE_DETECTED` 降为 INFO，不再单独触发贴图风险 WARNING。
- 风险判断严格基于 Included 对象自身的材质引用；Excluded 对象的材质不能抬高 Included 范围风险。
- 当前只读检测检查 Unity 材质 `_MainTex`；不会据此断言材质没有其他 Shader 自定义纹理属性。

## JSON / TXT
- JSON 增加 `meshDiagnostics.scopes.source/included/excludedOnly/shared`。
- `SRC-005` / `SRC-006` details 同时提供范围统计和对应范围的分子、分母。
- TXT 增加四个范围的通道覆盖摘要与 UV 风险分类摘要。

## 风险控制
只修改 `Validator/quality_check.py`、GUI 版本标识、测试和文档。没有修改 SceneBuilder、PMXExporter、UnityParser/batch_folder_discovery.py、Validator/validate_source.py 或 RUN_GUI.bat。
不增加自动修复功能，不改变 inactive include/exclude 选项和转换核心。

## 测试结果
- V2.4.2 压缩包内 TEST_RESULTS 记载 51 项；本次在当前环境重新运行原始 pytest 套件，实际收集并通过 54 项。
- V2.4.3 新增 scope 统计与 UV 风险回归断言。
- 当前完整测试套件：55 项通过。
- Python 编译检查通过。

## 185_SankaF 回归资料
已检查用户提供的 V2.4.2 两份 JSON/TXT 报告。排除模式统计：Source 918 / Included 785 / Excluded-only 133 / Shared 0；法线缺失分别为 217 / 210 / 7 / 0；UV0 缺失分别为 118 / 118 / 0 / 0。包含模式：Source 918 / Included 918 / Excluded-only 0 / Shared 0。两份报告中的 118 个 UV0 缺失记录均为 `NO_MAIN_TEXTURE_DETECTED`。

这部分是对已有报告的离线对照，不代表在当前环境重新运行了完整 scene-project。Windows GUI / MMD 9.32 最终回归仍需用户实测。
