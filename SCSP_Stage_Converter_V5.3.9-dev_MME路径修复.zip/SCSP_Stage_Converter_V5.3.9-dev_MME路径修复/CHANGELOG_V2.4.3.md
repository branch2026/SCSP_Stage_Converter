# V2.4.3-dev — Mesh Scope Diagnostics

## 核心变更
- 将 Mesh 通道诊断分为 Source、Included、Excluded-only、Shared 四个统计范围。
- Included 统计包含任何被转换对象引用的唯一 Mesh；跨 Included/Excluded 的 Shared Mesh 在 Included 只计一次，并另行标记。
- Excluded-only 只统计完全没有 Included 引用的 Mesh。
- SRC-005 法线检查详情中的 `withNormals`、`decodedMeshes` 与 `missingMeshCount` 全部来自 Included 范围。
- SRC-006 UV0 检查详情中的 `withUV0`、`decodedMeshes` 与 `missingMeshCount` 全部来自 Included 范围。
- UV0 缺失但材质已知且未检测到 `_MainTex` 时降为 INFO；检测到 MainTex 或材质用途未知时仍为 WARNING。
- Shared Mesh 的 UV 风险按 Included 对象的材质判断，不受 Excluded 对象材质影响。
- JSON / TXT 同步输出各范围数量、法线/UV0 覆盖、缺失并集和 UV 风险计数。
- 新增 `scopeAccounting` 守恒检查，确保 Source 可由 Included + Excluded-only 正确分解，Shared 不重复累加。

## 严格保护
- V2.3.2-dev 继续作为批量转换回退基线。
- V2.4.2-dev 作为本次源码基线保留。
- SceneBuilder、PMXExporter、UnityParser/batch_folder_discovery.py、Validator/validate_source.py、RUN_GUI.bat 不修改。
- 不修改 Unity → Blender → PMX 转换逻辑。
- 不增加法线、UV、材质自动修复。

## 验证
- 自动化测试 55/55 通过。
- Python 编译通过。
- 185_SankaF V2.4.2 include/exclude 报告已做离线统计交叉核对。
- Windows 10 GUI / 完整 scene-project / MMD 9.32 最终回归仍待实机验收。
