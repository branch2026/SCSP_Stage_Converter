# V2.4.1-dev 开发记录

## 设计决策

用户已明确要求保留 V2.3.2-dev 作为批量转换回退基线，并保留 V2.4.0-dev 的质量检查功能。V2.4.1 只增强诊断能力，不改变已经验证成功的转换流程。

## 实现方式

对象级诊断放在 `Validator/quality_check.py` 的只读检查阶段。它复用 `SceneBuilder/rebuild_stage_blender.py` 的 Unity 场景 / Mesh 解析函数，按唯一 Mesh GUID + fileID 解码 Mesh，再将结果映射到 GameObject Hierarchy 和 Renderer 材质。没有修改既有 `Validator/validate_source.py`，避免改变转换前的源验证路径。

## 风险控制

- 新诊断只读取资源。
- 缺失法线和 UV0 只产生定位信息，不自动修复。
- UV MainTex 检测仅作风险线索，不把无 MainTex 直接判为错误。
- `SRC-009` 用于验证新诊断结果是否与原有源验证汇总一致。
- 如果对象级诊断自身失败，质量报告会显示诊断异常 / WARNING；不改变 PMX 已生成的事实。

## 测试

- 48 项自动化测试全部通过。
- 121_ForbiP 实际 Unity 项目对象级诊断：152/152 Mesh 解码；法线 62/152；UV0 112/152；与现有源验证统计一致。
- 未对 Unity 资源、BLEND、PMX 或贴图执行任何写入。
