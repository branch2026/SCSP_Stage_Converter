@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 "Validator\compare_inactive_modes.py" --gui
) else (
    python "Validator\compare_inactive_modes.py" --gui
)
echo.
echo [V2.4.7] 双模式报告工具已退出。若出现错误请查看上方提示。
pause
