# V2.1-dev GUI Preview 1 — 开发记录

- 基线采用用户最近测试的 `SCSP_Stage_Converter_V2.0-dev_RecoveryRebuild2`。
- 保留原有 Unity 验证、Blender 场景重建和 PMX 导出代码。
- 新增 Tkinter GUI：环境配置、舞台任务队列、任务清单导入/导出、单项/批量转换、阶段日志、停止后续任务。
- 批量执行采用顺序调度；单项失败后继续下一项。
- 每个舞台使用独立且不覆盖旧结果的输出目录。
- 任务状态“PMX已生成（待MMD验收）”明确区分文件生成与 MMD 实机兼容。
- 未接入 scsp_mmd_tools v0.2.0 的角色/歌曲动作专用流程。
- 未修改 PMX Writer；MMD 闪退问题仍未解决。

- GUI Preview 2：新增 Unity 场景根对象自动扫描。
- 扫描复用 SceneBuilder 的 Unity YAML docs/ref/scalar 解析规则；仅解析场景层级，不扫描全部 Assets GUID。
- 列出 Transform father=0 的顶层 GameObject，并统计子层级 GameObjects、MeshFilter、Renderer 数量。
- 提供候选选择和手动输入备用路径；不静默把最大 Mesh 数候选当作确定根对象。

- GUI Preview 2 Fix1：修复 `_add_stage()` 自动扫描根对象时将 `scene_path` 误写为未定义的 `scene_abs` 的问题；候选选择窗口也统一传入 `scene_path`。
- 回归检查：确认两个调用点均引用已定义的 `scene_path`；所有 Python 源码通过 AST 语法检查。

- V2.2-dev：基于 V2.1 GUI Preview 2 Fix1 保留任务队列和 Unity 顶层根对象候选扫描。
- 将 GUI 的 PMX 后端切换为 Blender 当前用户配置中的 MMD Tools 原生 `bpy.ops.mmd_tools.export_pmx`。
- 增加 MMD Tools 后台预检查；检查失败时在 Unity 场景重建前停止。
- 原生导出阶段不使用 `--factory-startup`，以便加载 Blender 用户已启用的 MMD Tools 扩展。
- 贴图输出改为先复制到每个舞台输出目录，再把 Blender Image.filepath 指向导出副本。
- 增加 PMX 回读和贴图路径修复：按 PMX 中实际纹理引用补齐哈希文件名别名，并逐项验证引用文件存在。
- 旧版自定义 PMX Writer 移至 `PMXExporter/Legacy_CustomWriter/`，GUI 不再调用。
- 本版暂不加入 Bloom、发光、游戏灯光和粒子特效，优先稳定批量转换。
- 验证：Python AST 语法检查、合成 Unity YAML 根对象扫描、182_SuperD 48 项贴图映射回归测试、ZIP 解压检查通过。
- 限制：未在用户的 Windows / Blender 4.4.3 / MMD Tools 4.5.14 环境实机执行 V2.2 整条批量流水线。


# V2.2.2-dev — 从 V2.2 基线重建

- 重新从 `SCSP_Stage_Converter_V2.2-dev_MMDToolsNative.zip` 解压并建立开发目录；不以 V2.2.1 的独立修复 BAT 为基础。
- 完整保留 V2.2 的 Tkinter GUI、任务队列、场景根对象扫描、Unity 资源验证、Blender 舞台重建、MMD Tools 预检查和原生 PMX 导出调用。
- 继续使用 Blender 4.4.3 + MMD Tools 4.5.14 的 `bpy.ops.mmd_tools.export_pmx`；旧自定义 PMX Writer 仍只放在 Legacy_CustomWriter 中，不参与流水线。
- 修复 V2.2 已确认的后置贴图校验误判：MMD Tools 4.5.14 在本项目实际日志中写入了绝对 Windows 贴图路径，而 V2.2 贴图检查器只接受相对路径。
- 新增 `pmx_texture_table.py`，按 PMX 结构定位贴图字符串表；仅改写贴图引用字符串，保留表外所有 PMX 原始字节。
- 新增 `pmx_texture_pipeline.py`：先逐项解析路径，再进行原子改写、回读和文件存在性验证；失败时恢复原始 PMX 字节。
- 改写后再次用 MMD Tools 自身 PMX parser 回读；如果 parser 不接受改写后的 PMX，自动恢复原始导出字节并标记失败。
- 原始引用顺序和重复项均保留，不改变 PMX 材质纹理索引。
- GUI 仍由根目录 `RUN_GUI.bat` 启动；没有加入单独的 PMX 修复 BAT，避免误把命令行修复工具当作主 GUI。
- 未更改 Unity 场景重建逻辑、PMX 比例 12.5、inactive GameObject 默认包含设置和每舞台独立输出目录策略。
- 测试边界：本次可在开发容器执行语法、单元、合成 PMX 和已有 182_SuperD PMX 文件结构测试；Blender/MMD Tools 运行时回读及 MMD 9.32 最终验收仍需用户 Windows 环境确认。


## V2.3-dev — Unity Hierarchy preview

- Based on the V2.2.2-dev stable package.
- Root candidate list remains top-level-only.
- Added expandable/searchable child hierarchy preview and per-GameObject MeshFilter/Renderer/ParticleSystem counts.
- Verified the uploaded 121_ForbiP scene contains EffectPlayer as a child of 121_ForbiP and 121_Effects beneath EffectPlayer.
- PMX exporter, texture-table repair, SceneBuilder and main launcher are unchanged.


# V2.3.1-dev — Unity Built-in Mesh fix

- Reproduced the user's 121_ForbiP validation failure from the uploaded full scene-project.
- Identified 71 MeshFilter components under EffectPlayer using Unity built-in resource GUID `0000000000000000e000000000000000`.
- Confirmed the scene uses fileID 10209 (Plane) and 10210 (Quad); the old validator incorrectly treated the built-in GUID as a missing `.meta` asset.
- Added deterministic Plane / Quad geometry reconstruction and changed mesh cache identity to `(GUID, fileID)`.
- Updated source validation to count unique mesh references rather than GUIDs alone.
- Added explicit ParticleSystem / ParticleSystemRenderer reporting; runtime particle simulation is not baked into static PMX.
- Full 121_ForbiP validator run: 285/285 MeshFilters resolved, 56/56 main textures resolved, zero errors.
- 28 unit/regression tests pass.
- Full Blender 4.4.3 / MMD Tools / MMD 9.32 runtime verification remains pending on the user's Windows system.
