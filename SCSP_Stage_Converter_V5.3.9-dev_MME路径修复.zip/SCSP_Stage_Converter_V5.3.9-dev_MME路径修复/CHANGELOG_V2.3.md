# V2.3-dev — Unity Hierarchy 层级识别增强

## 本版改动

- 保留 V2.2.2-dev 的批量转换、Blender 舞台重建、MMD Tools 原生 PMX 导出和贴图路径修复流程。
- 自动识别窗口继续只列出场景顶层根对象候选，不把子对象误列为独立舞台。
- 新增所选根对象的完整 Unity Hierarchy 树状预览，支持展开和折叠。
- 新增子对象名称搜索，可定位 EffectPlayer、121_Effects 等对象，并展开其父级路径。
- 每个 GameObject 显示自身 MeshFilter、Renderer、ParticleSystem 组件数量。
- 顶层候选表显示整个子树的 GameObjects、MeshFilter、Renderer、ParticleSystem 汇总数。
- Renderer 汇总包括 MeshRenderer、SkinnedMeshRenderer、ParticleSystemRenderer、LineRenderer、TrailRenderer、SpriteRenderer 和 CanvasRenderer。

## 121_ForbiP 验收样本

原始 `121_forbip.unity` 中，`EffectPlayer` 是 `121_ForbiP` 的直接子对象，`121_Effects` 位于 `EffectPlayer` 下面。扫描到 747 个 GameObject、285 个 MeshFilter、285 个 MeshRenderer、188 个 ParticleSystem 和 188 个 ParticleSystemRenderer。

因此顶层候选表只出现 `121_ForbiP` 是正确行为；V2.3 的层级树会显示 `EffectPlayer` 和 `121_Effects`。

## 不变项目

- 不修改 `SceneBuilder/rebuild_stage_blender.py`。
- 不修改 `PMXExporter` 的原生导出器、PMX 贴图表修复和回滚逻辑。
- 不修改 `RUN_GUI.bat` 主程序入口。
- 不更改每个舞台输出一个完整 PMX 的工作流。
- 不加入 Bloom、灯光或游戏粒子效果模拟。
