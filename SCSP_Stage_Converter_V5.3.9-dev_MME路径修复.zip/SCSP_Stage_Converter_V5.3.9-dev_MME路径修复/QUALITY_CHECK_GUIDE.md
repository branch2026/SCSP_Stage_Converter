# V2.4.4 转换质量检查与 Mesh 分范围诊断说明

V2.4.4 在 V2.3.2-dev 的转换流程成功生成 PMX 后，自动执行一次只读质量检查，并提供 Source / Included / Excluded-only / Shared 四个 Mesh 统计范围。检查器不会重建、改写或修复 BLEND、PMX、Unity 资源或贴图；它只读取已有报告、Unity 场景结构、PMX 二进制贴图表和输出贴图文件。

## 质量等级

- `PASS`：本次自动检查项全部通过。仍需在 MMD 9.32 中人工验收外观。
- `WARNING`：未发现阻断性错误，但有需要人工确认的项目，例如缺少 UV/法线、inactive 几何被排除、ParticleSystem 动态效果未烘焙、空材质槽或资源关系异常。
- `FAIL`：发现可能影响舞台完整性的问题，例如 Mesh 解码错误、MeshFilter 数量对不上、PMX 结构回读失败、PMX 贴图文件缺失或路径越界。

`PASS` 不代表游戏中的实时舞台效果已还原；Bloom、实时灯光、视频屏幕、粒子模拟等仍不属于静态 PMX 质量检查范围。

## 自动检查项目

1. Unity Mesh 引用数量、唯一 Mesh 解码、索引数据、法线和 UV0 覆盖情况。
2. Unity 材质主贴图 GUID、材质资源文件和 MainTex 资源定位。
3. Hierarchy Transform 循环/非有限数值/零缩放、MeshFilter / MeshRenderer 配对、空材质槽、重复对象名、空层级节点。
4. Blender 重建报告中的缺失 Mesh、Mesh 解码错误、MeshFilter 数量核对、未生成几何的 MeshFilter。
5. inactive 对象排除数量、材质重建警告、ParticleSystem 动态效果提示。
6. MMD Tools PMX 导出状态、PMX parser 回读数量、PMX 文件大小。
7. PMX 二进制贴图表、贴图引用与导出报告一致性、实际贴图文件是否存在、路径是否越出舞台输出目录。

## 输出文件

每个转换完成的舞台输出目录增加：

- `<根对象名>_quality_report.json`：完整机器可读检查结果。
- `<根对象名>_quality_report.txt`：可直接阅读的检查报告。

GUI 队列新增「质量检查」列。选择舞台后点击「打开质量报告」即可查看 TXT 报告。

## 重要的兼容原则

- V2.3.2-dev 的批量文件夹发现、任务队列隔离和每舞台独立输出方式保留。
- `SceneBuilder`、`PMXExporter`、`UnityParser/batch_folder_discovery.py` 和原有 `Validator/validate_source.py` 不修改。
- 质量检查在 PMX 导出成功后运行；如果检查器自身发生异常，不会把已成功生成的 PMX 转换任务改判为转换失败，会在队列中显示「检查异常」。
- 转换过程原有的源资源验证、Blender 重建和 MMD Tools 导出门槛仍然生效。

## 手动执行

可在命令行运行：

```bat
py -3 Validator\quality_check.py ^
  --source-validation "舞台输出目录\Root_source_validation.json" ^
  --rebuild-report "舞台输出目录\Root_rebuild_report.json" ^
  --pmx-report "舞台输出目录\Root_mmd_tools_report.json" ^
  --pmx "舞台输出目录\Root.pmx" ^
  --project "AssetRipper scene-project 路径" ^
  --scene "Assets\Stage.unity" ^
  --root "舞台根 GameObject 名称" ^
  --json-out "舞台输出目录\Root_quality_report.json" ^
  --text-out "舞台输出目录\Root_quality_report.txt"
```

命令退出码：`0=PASS`、`1=WARNING`、`2=FAIL`、`3=检查器执行异常`。


## V2.4.2 Mesh 对象级诊断

V2.4.2 在 V2.4.0 的只读检查基础上，额外解析舞台根对象下每个唯一 Mesh 引用的顶点通道，并将缺失法线 / UV0 的 Mesh 映射回场景对象。该步骤只读 Unity 场景和 Mesh 资源，不会写回 Unity 资源，也不会修改 Blender 重建结果、PMX 或贴图。

### 诊断字段

每个异常 Mesh 会记录：

- `meshFilterComponents`、`validMeshFilterComponents`、`nullMeshFilterComponents`、`uniqueMeshReferences`：MeshFilter 组件、有效引用、空引用和唯一 Mesh 引用数量。
- `meshName`、`meshGUID`、`meshFileID`：Mesh 名称及 Unity 引用标识。
- `assetPath`：Mesh 资源在 `Assets` 下的相对路径；内置 Mesh 会标记为 Unity Built-in Mesh。
- `vertexCount`、`hasNormals`、`hasUV0`：顶点数量和通道是否存在。
- `occurrenceCount`、`uniqueGameObjectCount`：被引用的 MeshFilter 组件数和 GameObject 数。
- `gameObjects[]`：引用该 Mesh 的 GameObject 名称、fileID、完整 Hierarchy 路径、activeSelf 状态、Renderer 数量及材质线索。
- UV0 缺失记录额外包含 `uvRisk`、`texturedMaterialOccurrences` 和关联材质的 MainTex 分配/解析状态。

### 统计口径

- 法线 / UV0 缺失数量按唯一 Mesh GUID + fileID 统计，不按 MeshFilter 组件数量统计。
- 同一个 Mesh 被多个 GameObject 共用时，只计一个唯一 Mesh，但会列出所有引用它的 GameObject。
- `missingEitherCount` 是缺失法线或 UV0 的去重并集。法线缺失与 UV0 缺失清单可能重叠，不能直接相加。
- `SRC-009` 将对象级诊断的解码数量、法线数量和 UV0 数量与既有 Unity 源验证报告交叉核对。数量不一致或诊断无法完整解码时显示 WARNING，不会改写 PMX。

### UV 风险提示解释

- `TEXTURED_MATERIAL_ASSIGNED`：关联 GameObject 至少有一个材质检测到 MainTex 贴图引用，缺少 UV0 更值得优先人工检查。
- `NO_MAIN_TEXTURE_DETECTED`：关联材质没有检测到 MainTex 引用；可能是纯色材质，但不能据此断言一定不需要 UV。
- `MATERIAL_USAGE_UNKNOWN`：材质槽或材质资源无法充分判断，需要人工确认。

MainTex 检测是辅助线索，不保证覆盖所有 Shader 自定义贴图属性。V2.4.2 不会自动生成 UV、重算法线、改写材质或执行任何修复。

### 旧版报告兼容

V2.4.2 会使用现有的 Unity 场景和 Mesh 资源重新生成对象级诊断，不要求旧版 `*_source_validation.json` 预先包含新字段。旧版 JSON / TXT 质量报告不会自动回填；需要重新运行 V2.4.4 的质量检查。


## V2.4.2 Active Mesh 转换范围诊断

V2.4.2 保留 V2.4.1 的全场景 Mesh 清单，同时按 Blender 重建报告中的 `inactivePolicy` 计算本次真正参与转换的对象范围。不会改变转换器的 inactive 选项或重建逻辑。

- `activeSelf`：GameObject 自身的启用状态。
- `activeInHierarchy`：自身及所有父级均启用时才为 true；父级 inactive 时，activeSelf=true 的后代仍为 false。
- `conversionIncluded`：是否按本次 `inactivePolicy` 纳入转换。`exclude` 时仅 activeInHierarchy=true 纳入；`include` 时根对象层级内全部纳入。
- `conversionUniqueMeshReferences`：至少有一个纳入转换对象引用的唯一 Mesh 数。
- `excludedOnlyUniqueMeshReferences`：只被排除对象引用的唯一 Mesh 数。
- `sharedMeshReferencesAcrossIncludedAndExcludedObjects`：同时被纳入和排除对象引用的唯一 Mesh 数。此类 Mesh 仍计入转换范围一次，并保留两侧对象引用。
- `conversionMissingNormals` / `conversionMissingUV0`：只包含至少被一个纳入转换对象引用的缺失通道 Mesh。

SRC-005 / SRC-006 仅根据上述转换范围清单产生 WARNING。全场景 `missingNormals` / `missingUV0` 仍保留，SRC-009 仍使用全场景统计与 Unity 源验证进行交叉核对。这样既不会因排除对象误报转换风险，也不会丢失被排除资源的诊断线索。


## V2.4.3 Mesh 通道统计范围

JSON 的 `meshDiagnostics.scopes` 现在分别提供：

- `source`：舞台根层级内全部唯一 Mesh 引用。
- `included`：至少有一个 GameObject 引用参与本次转换的 Mesh；Shared Mesh 只计一次。
- `excludedOnly`：只被本次排除对象引用的 Mesh。
- `shared`：同时被 Included 与 Excluded 对象引用的 Mesh；它是 Included 的子集，不应与 Included 相加。

每个范围的 `decodedMeshes` 是通道覆盖率分母；`withNormals` / `withUV0` 是对应分子；`missingNormalsCount` / `missingUV0Count` 是缺失数量。无法解码的 Mesh 引用保留在 `uniqueMeshReferences`，但不会冒充已解码 Mesh 进入通道覆盖率分母。

`SRC-005` 与 `SRC-006` 的 `withNormals` / `withUV0`、`decodedMeshes` 和 `missingMeshCount` 均来自 Included 范围。Source / Excluded-only / Shared 统计在 `scopeStats` 中单独提供。

### UV0 风险等级

- `TEXTURED_MATERIAL_ASSIGNED`：Included 对象关联材质检测到 `_MainTex`，缺少 UV0 仍为 WARNING。
- `MATERIAL_USAGE_UNKNOWN`：无法充分确认材质用途，缺少 UV0 仍为 WARNING。
- `NO_MAIN_TEXTURE_DETECTED`：材质可读取且没有检测到 `_MainTex`，缺少 UV0 降为 INFO，不单独触发贴图风险 WARNING。

对 Shared Mesh，Included 范围风险只依据 Included 对象的材质引用；Excluded 对象材质只保留在 Source / occurrence 明细，不会污染 Included 的风险等级。MainTex 检测仅检查 `_MainTex`，不保证覆盖 Shader 的其他自定义纹理属性。

范围统计另带 `scopeAccounting` 自检，核对 Source 是否可由 Included 与 Excluded-only 分解、有效 MeshFilter 组件数是否守恒，以及各范围法线/UV0 计数和 UV 风险计数是否一致。Shared 是 Included 的子集，不能再加到 Source 总数中。


## V2.4.4 Mesh Occurrence Trace 字段

- `activeInHierarchy`：Unity 场景全局层级状态，包含所选舞台根对象外部的祖先。
- `activeWithinSelectedRoot`：只从所选舞台根对象开始计算的相对层级状态。
- `conversionIncluded`：按现有转换器从所选根对象开始的遍历规则及 inactive 策略计算，不因根对象外部祖先 inactive 而误排除。
- `conversionDecision`：说明对象因自身 inactive、内部祖先 inactive、include 策略覆盖或正常活动而被纳入 / 排除。
- `hierarchyInactiveCause` / `conversionBlockingInactiveObject`：指出 Unity 全局层级 inactive 原因，以及转换器根对象子树内实际阻止纳入的对象。
- `meshFilterComponentFileIDs`：精确列出该 Mesh 引用对应的 Unity MeshFilter 序列化组件 fileID。
- `nullMeshFilterComponentDetails`：列出空 Mesh 引用对应的 GameObject 与 MeshFilter 组件 fileID。

这些字段只用于诊断；不修改转换器的 inactive 遍历、Mesh 重建或 PMX 导出逻辑。


## V2.4.5 缺失法线证据分类

V2.4.5 在缺少法线 Mesh 条目中增加 `normalEvidence`：`RENDERER_WITH_TEXTURED_MATERIAL`、`RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL`、`RENDERER_MATERIAL_USAGE_UNKNOWN`、`NO_RENDERER_DETECTED`。该分类只依据 Renderer / 材质引用可见性，不等于实际 MMD 阴影效果结论。四个统计范围分别计数，并通过 scopeAccounting 检查分类计数总和。此功能只读，不会自动重算法线或修改资源。


## V2.4.7 Mesh 完整资源身份清单（只读）

V2.4.7 将 `meshDiagnostics.schema` 升级为 `scsp-mesh-channel-diagnostics-v6`，并新增：

- `meshInventorySchema`: `scsp-mesh-resource-inventory-v1`。
- `meshInventory[]`: 每个唯一 Mesh GUID + fileID 一条记录；不再只记录缺少法线/UV0 的 Mesh。
- `meshInventorySummary`: 全量引用数量、已记录数量、GUID/fileID 完整性、解码状态数量、Included / Excluded-only / Shared 范围计数及完整性检查。

每条 Mesh 记录包括 `meshName`、`meshGUID`、`meshFileID`、`assetPath`、`vertexCount`、`hasNormals`、`hasUV0`、`decodeStatus`、`scope`、引用次数，以及 `gameObjects[]`。对象明细包括 GameObject fileID、Hierarchy 路径、MeshFilter component fileID、转换纳入决定、inactive 原因、Renderer 数量和 Unity 材质引用。

Unity Renderer 材质明细包含 `materialGUID`、`materialFileID`、材质名称/Assets 路径，以及 `mainTextureGUID`、`mainTextureFileID`、MainTex 资源路径和解析状态。材质关联以 GameObject 的 Renderer 为依据；一个 GameObject 有多个 MeshFilter / Renderer 时，不把它伪装成严格的一对一 Mesh-材质绑定。同一 GUID 下若有多个 Material 子资产，当前名称/MainTex 读取仍需按 fileID 人工复核。

该清单在 Mesh 解码失败或资源路径无法解析时仍保留 GUID/fileID、层级对象和状态，避免资源错误导致身份记录消失。它只读 Unity 场景和 Assets，不修改任何资源，也不改变 Blender 重建、PMX 导出、inactive 决策、法线或 UV。

## V2.4.6 双模式对比（独立只读模块）

本功能不依赖 `quality_check.py` 重新运行，不访问 Unity 工程、BLEND、PMX 或贴图。请保留 include / exclude 两份 JSON，运行 `RUN_COMPARE.bat` 或在主 GUI 点击「双模式对比…」。详见 `COMPARISON_GUIDE.md`。

自动核对 Source、Included、Excluded-only、Shared 数值守恒，检查 Blender 三角面和 PMX 面数、PMX 贴图列表差异，输出 311 个被排除对象的层级路径和排除原因（以 185_SankaF 样本为例）。原报告中没有记录的 Mesh GUID 或材质名称无法凭空恢复。
