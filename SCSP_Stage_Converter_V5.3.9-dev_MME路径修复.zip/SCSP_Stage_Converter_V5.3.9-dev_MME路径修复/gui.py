# -*- coding: utf-8 -*-
"""SCSP Stage Converter V5.3.9-dev · automatic stage effects."""
from __future__ import annotations

import json
import math
from batch_report import BatchReport, effective_mode, atomic_text
from StageEffects.screen_input import bind_screen_image
from StageEffects.screen_sequence import bind_screen_sequence
from StageEffects.screen_video import bind_screen_video
from StageEffects.auto_restore import restore as restore_stage
from StageEffects.stage_effects import inspect as inspect_effect_pmx, build_effect_package
import os
import importlib.util
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

APP = Path(__file__).resolve().parent
CONFIG_DIR = APP / "Config"
SETTINGS_FILE = CONFIG_DIR / "gui_settings.json"
TASKS_FILE = CONFIG_DIR / "task_queue.json"

VALIDATOR = APP / "Validator" / "validate_source.py"
REBUILDER = APP / "SceneBuilder" / "rebuild_stage_blender.py"
PMX_EXPORTER = APP / "PMXExporter" / "export_with_mmd_tools.py"
MMD_TOOLS_CHECKER = APP / "PMXExporter" / "check_mmd_tools.py"
BATCH_DISCOVERY = APP / "UnityParser" / "batch_folder_discovery.py"
QUALITY_CHECKER = APP / "Validator" / "quality_check.py"
EFFECT_PROFILES_DIR = APP / "StageEffects" / "profiles"

DEFAULT_BLENDER = Path(
    r"C:\Dpan\MMD\Blender\blender-4.4.3-windows-x64\blender.exe"
)
DEFAULT_SCALE = 12.5
STATUS_PENDING = "待处理"
STATUS_RUNNING = "处理中"
STATUS_DONE = "PMX已生成（待MMD验收）"
STATUS_FAILED = "失败"
QUALITY_UNCHECKED = "未检查"


def safe_name(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(value)).strip(" .")
    return value[:80] or "SCSP_Stage"


def stage_output_name(source, scene, root, *, mme_preview):
    stages = [safe_name(scene), safe_name(root)]
    labels = [safe_name(Path(source).name), *stages] if source else stages
    name = "__".join(labels)
    if not mme_preview or name.isascii():
        return name
    if all(label.isascii() for label in stages):
        return "__".join(stages)
    # Material and texture paths are resolved relative to this directory in MME.
    suffix = uuid.uuid5(uuid.NAMESPACE_OID, name).hex[:12]
    return "__".join([*(label for label in stages if label.isascii()), f"stage_{suffix}"])


def root_selection(scene_path, candidates):
    """Select a unique exportable stage root using names and renderable geometry."""
    def normalized(name):
        return ''.join(c for c in unicodedata.normalize("NFKC", name).casefold() if c.isalnum())

    name_counts = {}
    for candidate in candidates:
        key = candidate["name"].casefold()
        name_counts[key] = name_counts.get(key, 0) + 1
    technical = re.compile(r"^(?:effect(?:player|s)?|vfx|particles?|lighting|livecamera|camerarig|ui|timeline)(?:\d.*)?$")
    eligible = [c for c in candidates if c.get("mesh_filters", 1) > 0
                and c.get("active", True) and c.get("exportable_by_name",True)
                and not technical.fullmatch(normalized(c["name"]))]
    matches = [c for c in eligible if c["name"].casefold() == scene_path.stem.casefold()]
    if not matches:
        matches = [c for c in eligible if normalized(c["name"]) == normalized(scene_path.stem)]
    if matches:
        if len(matches)==1 and name_counts[matches[0]["name"].casefold()]==1:
            return matches[0]["name"], "场景名称与几何根对象一致"
        return None, "存在同名几何根对象"
    ranked = sorted(eligible, key=lambda c: c.get("mesh_renderers", 0), reverse=True)
    if (len(ranked)==1 and ranked[0].get("mesh_renderers",0)>0
            and name_counts[ranked[0]["name"].casefold()]==1):
        return ranked[0]["name"], "唯一的舞台几何根对象"
    if len(ranked)>=2:
        first = ranked[0].get("mesh_renderers", 0)
        second = ranked[1].get("mesh_renderers", 0)
        if (first >= 12 and first >= 4*max(1,second)
                and name_counts[ranked[0]["name"].casefold()]==1):
            return ranked[0]["name"], "可渲染网格集中在一个根对象"
    return None, "没有唯一可确认的舞台根对象"


def recommended_root(scene_path, candidates):
    return root_selection(scene_path,candidates)[0]


def unique_dir(parent: Path, name: str) -> Path:
    parent.mkdir(parents=True, exist_ok=True)
    suffix = 1
    while True:
        candidate = parent / (name if suffix == 1 else f"{name}_{suffix:02d}")
        try:
            candidate.mkdir()
            return candidate
        except FileExistsError:
            suffix += 1



def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


class StageConversionError(RuntimeError):
    pass


class StageConverterGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("SCSP Stage Converter V5.3.9-dev — Auto Stage Restoration")
        self.root.geometry("1160x790")
        self.root.minsize(940, 650)

        self.events: queue.Queue = queue.Queue()
        self.last_report = ""
        self.worker: threading.Thread | None = None
        self.is_running = False
        self.stop_after_current = threading.Event()
        self.current_indices: list[str] = []
        self.tasks: list[dict] = []

        self.blender_var = tk.StringVar(value=str(DEFAULT_BLENDER))
        self.project_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.output_auto = False
        self.include_inactive_var = tk.BooleanVar(value=True)
        self.scale_var = tk.StringVar(value=str(DEFAULT_SCALE))
        self.auto_restore_var = tk.BooleanVar(value=True)
        self.floor_cleanup_var = tk.BooleanVar(value=True)
        self.mme_preview_var = tk.BooleanVar(value=True)
        self.enable_effect_var = tk.BooleanVar(value=False)
        self.effect_profile_dir_var = tk.StringVar(value=str(EFFECT_PROFILES_DIR))
        self.status_var = tk.StringVar(value="就绪。可批量选择舞台文件夹，或选择单个 scene-project。")
        self.progress_var = tk.DoubleVar(value=0)

        self._load_settings()
        self._load_saved_tasks()
        self._build_ui()
        self._refresh_tree()
        self.root.after(100, self._poll_events)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _load_settings(self):
        data = read_json(SETTINGS_FILE, {}) or {}
        self.last_report = str(data.get("last_report", ""))
        self.blender_var.set(data.get("blender", str(DEFAULT_BLENDER)))
        self.project_var.set(data.get("project", ""))
        self.output_var.set(data.get("output", ""))
        saved_project = str(data.get("project", "")).strip()
        saved_output = str(data.get("output", "")).strip()
        self.output_auto = bool(data.get("output_auto", False)) or bool(
            saved_project and saved_output
            and Path(saved_output).expanduser() == (Path(saved_project).expanduser() / "PMX_Output_GUI")
        )
        self.include_inactive_var.set(bool(data.get("include_inactive", True)))
        self.scale_var.set(str(data.get("scale", DEFAULT_SCALE)))
        self.auto_restore_var.set(bool(data.get("auto_restore", True)))
        self.floor_cleanup_var.set(bool(data.get("floor_cleanup", True)))
        self.mme_preview_var.set(bool(data.get("mme_preview", True)))
        self.enable_effect_var.set(bool(data.get("enable_stage_effects", False)))
        self.effect_profile_dir_var.set(str(data.get("effect_profile_dir", EFFECT_PROFILES_DIR)))

    def _save_settings(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "blender": self.blender_var.get().strip(),
            "project": self.project_var.get().strip(),
            "output": self.output_var.get().strip(),
            "output_auto": bool(self.output_auto),
            "last_report": self.last_report,
            "include_inactive": bool(self.include_inactive_var.get()),
            "scale": self.scale_var.get().strip(),
            "auto_restore": bool(self.auto_restore_var.get()),
            "floor_cleanup": bool(self.floor_cleanup_var.get()),
            "mme_preview": bool(self.mme_preview_var.get()),
            "enable_stage_effects": bool(self.enable_effect_var.get()),
            "effect_profile_dir": self.effect_profile_dir_var.get().strip(),
        }
        SETTINGS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def _load_saved_tasks(self):
        data = read_json(TASKS_FILE, {}) or {}
        items = data.get("tasks", []) if isinstance(data, dict) else []
        for item in items:
            scene = str(item.get("scene", "")).strip()
            root_name = str(item.get("root", "")).strip()
            if scene and root_name:
                task_project = str(item.get("project") or data.get("project") or self.project_var.get() or "").strip()
                self.tasks.append({
                    "id": uuid.uuid4().hex,
                    "project": task_project,
                    "source_folder": str(item.get("source_folder", "")).strip(),
                    "scene": scene.replace("\\", "/"),
                    "root": root_name,
                    "status": item.get("status") if item.get("status") in (STATUS_DONE, STATUS_FAILED) else STATUS_PENDING,
                    "output": str(item.get("output", "")),
                    "include_inactive": item.get("include_inactive"),
                    "candidate_count": item.get("candidate_count", 0),
                    "quality_status": str(item.get("quality_status", QUALITY_UNCHECKED)),
                    "quality_report": str(item.get("quality_report", "")),
                    "quality_report_text": str(item.get("quality_report_text", "")),
                })

    def _save_tasks(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "version": 3,
            "project": self.project_var.get().strip(),
            "tasks": [
                {
                    "project": t.get("project", self.project_var.get().strip()),
                    "source_folder": t.get("source_folder", ""),
                    "scene": t["scene"],
                    "root": t["root"],
                    "output": t.get("output", ""),
                    "include_inactive": t.get("include_inactive"),
                    "candidate_count": t.get("candidate_count", 0),
                    "status": t.get("status", STATUS_PENDING),
                    "quality_status": t.get("quality_status", QUALITY_UNCHECKED),
                    "quality_report": t.get("quality_report", ""),
                    "quality_report_text": t.get("quality_report_text", ""),
                }
                for t in self.tasks
            ],
        }
        atomic_text(TASKS_FILE, json.dumps(data, ensure_ascii=False, indent=2))

    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass

        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)

        title = ttk.Frame(outer)
        title.pack(fill="x", pady=(0, 8))
        ttk.Label(
            title, text="SCSP Stage Converter",
            font=("Microsoft YaHei UI", 17, "bold")
        ).pack(side="left")
        ttk.Label(
            title, text="V5.3.9-dev · Unity 舞台自动还原",
            foreground="#64748b"
        ).pack(side="left", padx=12, pady=(7, 0))
        ttk.Label(
            title, text="每个舞台输出一个完整 PMX",
            foreground="#2563eb"
        ).pack(side="right", pady=(7, 0))

        config = ttk.LabelFrame(outer, text="转换环境", padding=8)
        config.pack(fill="x", pady=(0, 8))
        config.columnconfigure(1, weight=1)

        ttk.Label(config, text="单场景默认 scene-project：").grid(
            row=0, column=0, sticky="w", padx=(0, 6), pady=4
        )
        ttk.Entry(config, textvariable=self.project_var).grid(
            row=0, column=1, sticky="ew", pady=4
        )
        ttk.Button(config, text="浏览…", command=self._browse_project).grid(
            row=0, column=2, padx=(6, 0), pady=4
        )

        ttk.Label(config, text="Blender 4.4.3：").grid(
            row=1, column=0, sticky="w", padx=(0, 6), pady=4
        )
        ttk.Entry(config, textvariable=self.blender_var).grid(
            row=1, column=1, sticky="ew", pady=4
        )
        ttk.Button(config, text="浏览…", command=self._browse_blender).grid(
            row=1, column=2, padx=(6, 0), pady=4
        )

        ttk.Label(config, text="PMX 输出目录：").grid(
            row=2, column=0, sticky="w", padx=(0, 6), pady=4
        )
        self.output_entry = ttk.Entry(config, textvariable=self.output_var)
        self.output_entry.grid(row=2, column=1, sticky="ew", pady=4)
        self.output_entry.bind("<KeyRelease>", self._mark_output_manual)
        self.output_entry.bind("<<Paste>>", self._mark_output_manual)
        ttk.Button(config, text="浏览…", command=self._browse_output).grid(
            row=2, column=2, padx=(6, 0), pady=4
        )

        options = ttk.Frame(config)
        options.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(5, 0))
        ttk.Checkbutton(
            options, text="包含 inactive GameObject（默认）",
            variable=self.include_inactive_var
        ).pack(side="left")
        ttk.Label(options, text="PMX 比例：").pack(side="left", padx=(18, 4))
        ttk.Entry(options, textvariable=self.scale_var, width=8).pack(side="left")
        ttk.Label(
            options, text="PMX 后端：MMD Tools 原生导出 + 自动贴图路径修复",
            foreground="#15803d"
        ).pack(side="right")

        fxbar = ttk.Frame(config)
        fxbar.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        ttk.Checkbutton(fxbar, text="自动还原舞台效果", variable=self.auto_restore_var).pack(side="left")
        ttk.Checkbutton(fxbar, text="自动去除地板黑影", variable=self.floor_cleanup_var).pack(side="left",padx=8)
        ttk.Checkbutton(fxbar, text="另存 MME 效果试验包", variable=self.mme_preview_var).pack(side="left",padx=8)
        ttk.Checkbutton(fxbar, text="附加旧版效果配置", variable=self.enable_effect_var).pack(side="left")
        ttk.Label(fxbar, text="效果配置文件夹：").pack(side="left", padx=(14, 4))
        ttk.Entry(fxbar, textvariable=self.effect_profile_dir_var, width=34).pack(side="left", fill="x", expand=True)
        ttk.Button(fxbar, text="浏览…", command=self._browse_effect_profiles).pack(side="left", padx=5)
        ttk.Label(fxbar, text="不覆盖原始 PMX", foreground="#15803d").pack(side="left")

        queue_frame = ttk.LabelFrame(outer, text="舞台任务队列", padding=8)
        queue_frame.pack(fill="both", expand=True, pady=(0, 8))
        queue_frame.rowconfigure(0, weight=1)
        queue_frame.columnconfigure(0, weight=1)

        columns = ("source", "scene", "root", "inactive", "status", "quality", "output")
        self.tree = ttk.Treeview(
            queue_frame, columns=columns, show="headings",
            selectmode="extended", height=9
        )
        self.tree.heading("source", text="来源舞台文件夹")
        self.tree.heading("scene", text="Unity 场景相对路径")
        self.tree.heading("root", text="舞台根 GameObject")
        self.tree.heading("inactive", text="inactive")
        self.tree.column("inactive", width=85, minwidth=72)
        self.tree.heading("status", text="转换状态")
        self.tree.heading("quality", text="质量检查")
        self.tree.heading("output", text="输出目录")
        self.tree.column("source", width=145, minwidth=105)
        self.tree.column("scene", width=235, minwidth=155)
        self.tree.column("root", width=135, minwidth=105)
        self.tree.column("status", width=155, minwidth=125)
        self.tree.column("quality", width=95, minwidth=80, anchor="center")
        self.tree.column("output", width=250, minwidth=150)
        self.tree.grid(row=0, column=0, sticky="nsew")

        scroll = ttk.Scrollbar(queue_frame, orient="vertical", command=self.tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.tag_configure("done", foreground="#15803d")
        self.tree.tag_configure("failed", foreground="#b91c1c")
        self.tree.tag_configure("running", foreground="#1d4ed8")
        self.tree.tag_configure("pending", foreground="#475569")

        actions = ttk.Frame(queue_frame)
        actions.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        self.add_button = ttk.Button(actions, text="添加单个场景…", command=self._add_stage)
        self.add_button.pack(side="left")
        self.add_folders_button = ttk.Button(
            actions, text="批量添加舞台文件夹…", command=self._add_stage_folders
        )
        self.add_folders_button.pack(side="left", padx=(5, 0))
        self.remove_button = ttk.Button(actions, text="移除选中", command=self._remove_selected)
        self.remove_button.pack(side="left", padx=5)
        self.clear_button = ttk.Button(actions, text="清空队列", command=self._clear_tasks)
        self.clear_button.pack(side="left")
        ttk.Separator(actions, orient="vertical").pack(side="left", fill="y", padx=10)
        ttk.Button(actions, text="导入任务清单…", command=self._import_tasks).pack(side="left")
        ttk.Button(actions, text="保存任务清单…", command=self._export_tasks).pack(side="left", padx=5)
        ttk.Button(actions, text="打开质量报告", command=self._open_quality_report).pack(side="left", padx=5)
        ttk.Button(actions, text="双模式对比…", command=self._compare_quality_reports).pack(side="left", padx=5)
        ttk.Button(actions, text="WARNING / 法线关联诊断…", command=self._diagnose_warning_reports).pack(side="left", padx=5)
        ttk.Button(actions, text="打开输出目录", command=self._open_output).pack(side="right")

        taskbar = ttk.Frame(queue_frame)
        taskbar.grid(row=2, column=0, sticky="w", pady=(5, 0))
        self.effect_tool_button = ttk.Button(taskbar, text="舞台效果工具…", command=self._stage_effects_tool)
        self.effect_tool_button.pack(side="right", padx=(16,0))
        ttk.Button(taskbar, text="替换屏幕画面…", command=self._bind_screen_image).pack(side="right",padx=5)
        ttk.Button(taskbar, text="屏幕序列动画…", command=self._bind_screen_sequence).pack(side="right",padx=5)
        ttk.Button(taskbar, text="导入屏幕视频…", command=self._bind_screen_video).pack(side="right",padx=5)
        self.edit_button = ttk.Button(taskbar, text="编辑选中任务…", command=self._edit_task)
        self.edit_button.pack(side="left")
        self.retry_button = ttk.Button(taskbar, text="仅重试失败项", command=self._retry_failed)
        self.retry_button.pack(side="left", padx=5)
        ttk.Button(taskbar, text="打开批量报告", command=self._open_batch_report).pack(side="left")
        self.tree.bind("<Double-1>", lambda event: self._edit_task())
        for variable in (self.output_var, self.project_var, self.include_inactive_var):
            variable.trace_add("write", lambda *_: self._refresh_tree())

        runbar = ttk.Frame(outer)
        runbar.pack(fill="x", pady=(0, 8))
        self.run_batch_button = ttk.Button(
            runbar, text="▶ 批量转换", command=self._run_batch
        )
        self.run_batch_button.pack(side="left")
        self.run_selected_button = ttk.Button(
            runbar, text="转换选中舞台", command=self._run_selected
        )
        self.run_selected_button.pack(side="left", padx=6)
        self.stop_button = ttk.Button(
            runbar, text="停止（当前舞台完成后）",
            command=self._request_stop, state="disabled"
        )
        self.stop_button.pack(side="left", padx=6)
        self.progress = ttk.Progressbar(
            runbar, variable=self.progress_var, maximum=100, mode="determinate"
        )
        self.progress.pack(side="left", fill="x", expand=True, padx=(16, 8))
        ttk.Label(runbar, textvariable=self.status_var, width=36).pack(side="right")

        log_frame = ttk.LabelFrame(outer, text="运行日志", padding=6)
        log_frame.pack(fill="both", expand=True)
        log_frame.rowconfigure(0, weight=1)
        log_frame.columnconfigure(0, weight=1)
        self.log_text = tk.Text(
            log_frame, height=10, wrap="word", font=("Consolas", 9),
            background="#111827", foreground="#e5e7eb",
            insertbackground="#ffffff", relief="flat"
        )
        self.log_text.grid(row=0, column=0, sticky="nsew")
        log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        log_scroll.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.tag_configure("error", foreground="#fca5a5")
        self.log_text.tag_configure("success", foreground="#86efac")
        self.log_text.tag_configure("info", foreground="#93c5fd")

        footer = ttk.Label(
            outer,
            text="提示：批量添加时选择共同目录下的多个舞台文件夹；程序自动查找各自 scene-project\\Assets。",
            foreground="#64748b"
        )
        footer.pack(anchor="w", pady=(6, 0))

    def _browse_effect_profiles(self):
        folder = filedialog.askdirectory(title="选择舞台效果 JSON 配置文件夹")
        if folder:
            self.effect_profile_dir_var.set(folder)
            self._save_settings()

    def _bind_screen_video(self):
        report = filedialog.askopenfilename(parent=self.root, title="选择效果包的 AutoStage_Report.json",
                                            filetypes=[("AutoStage 报告", "AutoStage_Report.json")])
        if not report:
            return
        video = filedialog.askopenfilename(parent=self.root, title="选择本地屏幕视频",
                                           filetypes=[("视频", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v")])
        if not video:
            return
        start = simpledialog.askfloat("视频起点", "从视频的第几秒开始取帧",
                                      initialvalue=0,minvalue=0,parent=self.root)
        if start is None:
            return
        duration = simpledialog.askfloat("片段时长", "读取多少秒视频",
                                         initialvalue=4,minvalue=.1,parent=self.root)
        if duration is None:
            return
        step = simpledialog.askinteger("取帧速度", "每张画面持续几个 MMD 帧（每秒 30 帧）",
                                      initialvalue=5,minvalue=1,maxvalue=120,parent=self.root)
        if step is None:
            return
        aspect = simpledialog.askstring("屏幕画面比例", "输入宽:高，例如竖屏 9:16。留空按原贴图比例。",
                                        parent=self.root)
        if aspect is None:
            return
        ffmpeg = shutil.which('ffmpeg') or filedialog.askopenfilename(
            parent=self.root,title="选择 ffmpeg.exe",filetypes=[("FFmpeg", "ffmpeg.exe")])
        if not ffmpeg:
            return
        destination = filedialog.askdirectory(parent=self.root,title="选择屏幕视频效果包的上级目录")
        if not destination:
            return
        folder = Path(report).parent
        output = Path(destination)/(folder.name+"_屏幕视频_"+uuid.uuid4().hex[:6])
        def import_video():
            try:
                result = bind_screen_video(folder,video,output,start=start,duration=duration,step=step,
                                           ffmpeg=ffmpeg,aspect=aspect.strip() or None)
                self.events.put(("screen_video_done",str(output/result["output_pmx"])))
            except (OSError,ValueError) as error:
                self.events.put(("screen_video_error",str(error)))

        self._log("正在提取视频帧并生成屏幕效果包", "info")
        threading.Thread(target=import_video,daemon=True).start()

    def _bind_screen_sequence(self):
        report = filedialog.askopenfilename(parent=self.root, title="选择效果包的 AutoStage_Report.json",
                                            filetypes=[("AutoStage 报告", "AutoStage_Report.json")])
        if not report:
            return
        images = filedialog.askdirectory(parent=self.root, title="选择连续编号 PNG 所在文件夹")
        if not images:
            return
        step = simpledialog.askinteger("屏幕播放速度", "每张画面持续的 MMD 帧数（MMD 每秒 30 帧）",
                                      initialvalue=5,minvalue=1,maxvalue=120,parent=self.root)
        if step is None:
            return
        destination = filedialog.askdirectory(parent=self.root, title="选择屏幕动画包的上级目录")
        if not destination:
            return
        folder = Path(report).parent
        output = Path(destination)/(folder.name+"_屏幕序列_"+uuid.uuid4().hex[:6])
        try:
            result = bind_screen_sequence(folder,images,output,step=step)
        except (OSError,ValueError) as error:
            messagebox.showerror("屏幕序列生成失败",str(error),parent=self.root)
            return
        messagebox.showinfo("屏幕序列已生成",str(output/result["output_pmx"]),parent=self.root)

    def _bind_screen_image(self):
        report = filedialog.askopenfilename(parent=self.root, title="选择效果包的 AutoStage_Report.json",
                                            filetypes=[("AutoStage 报告", "AutoStage_Report.json")])
        if not report:
            return
        image = filedialog.askopenfilename(parent=self.root, title="选择屏幕静态 PNG",
                                           filetypes=[("PNG 画面", "*.png")])
        if not image:
            return
        destination = filedialog.askdirectory(parent=self.root, title="选择屏幕效果包的上级目录")
        if not destination:
            return
        folder = Path(report).parent
        output = Path(destination) / (folder.name + "_自定义屏幕_" + uuid.uuid4().hex[:6])
        try:
            result = bind_screen_image(folder,image,output)
        except (OSError,ValueError) as error:
            messagebox.showerror("屏幕画面替换失败",str(error),parent=self.root)
            return
        messagebox.showinfo("屏幕效果包已生成",str(output / result["output_pmx"]),parent=self.root)

    def _stage_effects_tool(self):
        if self.is_running:
            return
        pmx_path = filedialog.askopenfilename(
            title="选择一个已导出的舞台 PMX（不会修改原文件）",
            filetypes=[("PMX 模型", "*.pmx")]
        )
        if not pmx_path:
            return
        try:
            info=inspect_effect_pmx(pmx_path)
        except (OSError, ValueError) as exc:
            messagebox.showerror("PMX 检查失败", str(exc))
            return
        if info["missing_textures"]:
            messagebox.showerror("贴图不完整", "原始 PMX 的贴图存在缺失或不安全路径：\n"+"\n".join(info["missing_textures"][:8]))
            return
        dialog=tk.Toplevel(self.root)
        dialog.title("V3.1 舞台材质 / UV 控制项生成器")
        dialog.geometry("760x570")
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog,text=f"{info['model']}  ·  {info['vertices']} 顶点  ·  {len(info['materials'])} 材质槽").pack(anchor="w",padx=12,pady=8)
        ttk.Label(dialog,text="选择一个或多个材质槽（Ctrl / Shift 多选）。不会影响原始 PMX。").pack(anchor="w",padx=12)
        area=ttk.Frame(dialog);area.pack(fill="both",expand=True,padx=12,pady=(4,8))
        tree=ttk.Treeview(area,columns=("index","name","alpha","triangles"),show="headings",selectmode="extended")
        for k,label,w in (("index","索引",65),("name","材质名称",405),("alpha","原始透明度",110),("triangles","三角形",90)):
            tree.heading(k,text=label);tree.column(k,width=w,anchor="w" if k=="name" else "center")
        tree.pack(side="left",fill="both",expand=True)
        bar=ttk.Scrollbar(area,command=tree.yview);bar.pack(side="right",fill="y");tree.configure(yscrollcommand=bar.set)
        for m in info['materials']:
            tree.insert("",'end',iid=str(m['index']),values=(m['index'],m['name'],m['alpha'],m['triangles']))
        options=ttk.Frame(dialog);options.pack(fill="x",padx=12,pady=(0,8))
        kind=tk.StringVar(value="透明度（逐渐隐藏）")
        name=tk.StringVar(value="灯面消去")
        target=tk.StringVar(value="0")
        ttk.Label(options,text="控制类型").grid(row=0,column=0,sticky="w",pady=3)
        ttk.Combobox(options,state="readonly",textvariable=kind,values=("透明度（逐渐隐藏）","Phase（多材质状态/透明度）","基础UV横向偏移","基础UV纵向偏移"),width=27).grid(row=0,column=1,padx=7)
        ttk.Label(options,text="形态键名称").grid(row=0,column=2,padx=(14,3))
        ttk.Entry(options,textvariable=name,width=20).grid(row=0,column=3)
        ttk.Label(options,text="目标 Alpha / UV 移动量").grid(row=1,column=0,sticky="w",pady=3)
        ttk.Entry(options,textvariable=target,width=10).grid(row=1,column=1,sticky="w",padx=7)
        ttk.Label(options,text="自动生成 0~120 帧测试 VMD；并记录 provenance=manual-demo",foreground="#64748b").grid(row=2,column=0,columnspan=4,sticky="w",pady=5)
        def create():
            selected=tree.selection()
            if not selected:
                messagebox.showwarning("没有材质","先在列表中选择一个材质槽。",parent=dialog);return
            try:
                value=float(target.get())
                fx={"name":name.get().strip(),"material_indices":[int(i) for i in selected],"provenance":"manual-demo",
                    "keys":[[0,0],[30,0],[60,0.5],[90,1],[120,0]]}
                if kind.get().startswith("透明度"):
                    fx.update(type="material_alpha",target_alpha=value)
                elif kind.get().startswith("Phase"):
                    # One PMX material morph can drive many material slots at once,
                    # mirroring the multi-material Phase pattern observed in ITTW46 404.
                    by_index={int(m['index']):float(m['alpha']) for m in info['materials']}
                    fx.update(type="material_state",material_offsets=[
                        {"material_index":int(i),"operation":"add",
                         "diffuse":[0.0,0.0,0.0,value-by_index[int(i)] ]}
                        for i in selected
                    ])
                else:
                    fx.update(type="uv_offset",uv_channel=0,offset=[value,0] if "横向" in kind.get() else [0,value])
                anchor=None
                for bone_name in info.get('bones',[]):
                    try:
                        if len(bone_name.encode('cp932'))<=15:
                            anchor=bone_name
                            break
                    except UnicodeEncodeError:
                        continue
                spec={"schema_version":1,"model_name":info['model'],
                      "notes":"从 V3.1 GUI 手动创建，仅供控制和测试，不代表 Unity 原版动画", "effects":[fx],
                      "vmd":{"neutral_anchor_bone":anchor} if anchor else {}}
                src=Path(pmx_path)
                base=src.parent/(src.stem+'_V3.1_FX')
                out=base
                seq=2
                while out.exists():
                    out=Path(str(base)+'_'+str(seq));seq+=1
                profile=out.parent/(out.name+'.profile.json')
                profile.write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
                try:
                    result=build_effect_package(src,profile,out)
                except Exception:
                    profile.unlink(missing_ok=True)
                    raise
            except (OSError,ValueError,OverflowError) as exc:
                messagebox.showerror("无法生成效果版",str(exc),parent=dialog);return
            dialog.destroy()
            messagebox.showinfo("效果包已生成",f"新增形态键：{fx['name']}\n输出目录：{out}\n已生成纯形态键 VMD 和中性骨骼锚点 VMD（如模型有可用骨骼）。\n两份 VMD 请分别单独导入测试。\n原始 PMX 没有修改。请在 MMD932 手动验收。")
        ttk.Button(dialog,text="生成独立效果版 PMX + VMD",command=create).pack(side="right",padx=12,pady=(0,12))
        ttk.Button(dialog,text="取消",command=dialog.destroy).pack(side="right",pady=(0,12))

    def _browse_project(self):
        path = filedialog.askdirectory(title="选择 AssetRipper scene-project 根目录")
        if not path:
            return
        project = Path(path)
        if not (project / "Assets").is_dir():
            messagebox.showerror("目录无效", "所选目录内没有 Assets 文件夹。请选择 scene-project 根目录。")
            return
        self.project_var.set(str(project))
        if not self.output_var.get().strip() or self.output_auto:
            self.output_var.set(str(project / "PMX_Output_GUI"))
            self.output_auto = True
        self._save_settings()

    def _browse_blender(self):
        path = filedialog.askopenfilename(
            title="选择 Blender 4.4.3 blender.exe",
            filetypes=[("Blender executable", "blender.exe"), ("Executable", "*.exe")]
        )
        if path:
            self.blender_var.set(path)
            self._save_settings()

    def _mark_output_manual(self, _event=None):
        # If the user edits the output path directly, it is no longer an
        # automatically suggested per-project default.
        self.output_auto = False

    def _browse_output(self):
        path = filedialog.askdirectory(title="选择 PMX 输出目录")
        if path:
            self.output_var.set(path)
            self.output_auto = False
            self._save_settings()

    def _scan_scene_root_candidates(self, scene_path: Path):
        """Scan top-level roots and retain their complete child hierarchy for preview.

        The candidate table intentionally contains top-level GameObjects only.
        Every candidate also carries a nested hierarchy tree so child objects such
        as EffectPlayer remain visible without being mistaken for separate stages.
        """
        spec = importlib.util.spec_from_file_location(
            "scsp_scene_parser_for_gui", REBUILDER
        )
        if spec is None or spec.loader is None:
            raise RuntimeError("无法加载现有 Unity 场景解析模块。")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        text = scene_path.read_text(encoding="utf-8-sig", errors="replace")
        objects = {}
        transforms = {}
        component_counts_by_go = {}

        # Unity class IDs: MeshFilter, renderer-derived components and ParticleSystem.
        # ParticleSystemRenderer is counted as a Renderer as well as being represented
        # by its owning ParticleSystem component in the separate PS column.
        renderer_classes = {23, 96, 120, 137, 199, 212}
        for cls, fid, document in module.docs(text):
            if cls == 1:  # GameObject
                components = [
                    int(x) for x in re.findall(
                        r'- component: \{fileID: (-?\d+)\}', document
                    )
                ]
                objects[fid] = {
                    "id": fid,
                    "name": module.scalar(document, "m_Name", f"GO_{fid}"),
                    "components": components,
                    "active": module.scalar(document,"m_IsActive","1") != "0",
                }
            elif cls in (4, 224):  # Transform / RectTransform
                go_ref = module.ref(document, "m_GameObject")
                father_ref = module.ref(document, "m_Father")
                go_id = int(go_ref["fileID"]) if go_ref else 0
                father_id = int(father_ref["fileID"]) if father_ref else 0
                transforms[fid] = {"id": fid, "go": go_id, "father": father_id}
            elif cls in ({33, 198} | renderer_classes):
                go_ref = module.ref(document, "m_GameObject")
                go_id = int(go_ref["fileID"]) if go_ref else 0
                if not go_id:
                    continue
                counts = component_counts_by_go.setdefault(
                    go_id,
                    {"mesh_filters": 0, "renderers": 0, "particle_systems": 0, "mesh_renderers": 0},
                )
                if cls == 33:  # MeshFilter
                    counts["mesh_filters"] += 1
                if cls in renderer_classes:
                    counts["renderers"] += 1
                if cls == 23 and module.scalar(document,"m_Enabled","1") != "0":
                    counts["mesh_renderers"] += 1
                if cls == 198:  # ParticleSystem
                    counts["particle_systems"] += 1

        children = {}
        transform_by_go = {}
        first_by_name = {}
        for go,obj in objects.items():
            first_by_name.setdefault(obj["name"],go)
        for tid, transform in transforms.items():
            children.setdefault(transform["father"], []).append(tid)
            transform_by_go.setdefault(transform["go"], tid)

        def build_root_tree(root_tid):
            root_node = None
            visited_transforms = set()
            visited_objects = set()
            totals = {
                "game_objects": 0,
                "mesh_filters": 0,
                "renderers": 0,
                "particle_systems": 0,
                "mesh_renderers": 0,
            }
            stack = [(root_tid, None, True)]
            while stack:
                tid, parent_node, active = stack.pop()
                if tid in visited_transforms:
                    continue
                visited_transforms.add(tid)
                transform = transforms.get(tid)
                if not transform:
                    continue
                go_id = transform["go"]
                node = parent_node
                if go_id in objects and go_id not in visited_objects:
                    visited_objects.add(go_id)
                    active = active and objects[go_id]["active"]
                    direct = component_counts_by_go.get(
                        go_id,
                        {"mesh_filters": 0, "renderers": 0, "particle_systems": 0},
                    )
                    node = {
                        "go_id": go_id,
                        "transform_id": tid,
                        "name": objects[go_id]["name"],
                        "mesh_filters": direct["mesh_filters"],
                        "renderers": direct["renderers"],
                        "particle_systems": direct["particle_systems"],
                        "children": [],
                    }
                    if parent_node is None:
                        root_node = node
                    else:
                        parent_node["children"].append(node)
                    totals["game_objects"] += 1
                    totals["mesh_filters"] += direct["mesh_filters"]
                    totals["renderers"] += direct["renderers"]
                    totals["particle_systems"] += direct["particle_systems"]
                    if direct["mesh_filters"] and active:
                        totals["mesh_renderers"] += direct.get("mesh_renderers",0)
                # Push in reverse so the hierarchy preview preserves scene order.
                for child_tid in reversed(children.get(tid, [])):
                    stack.append((child_tid, node, active))
            return root_node, totals

        candidates = []
        for root_tid, transform in transforms.items():
            if transform["father"] != 0:
                continue
            root_go = transform["go"]
            if root_go not in objects:
                continue
            hierarchy, totals = build_root_tree(root_tid)
            if hierarchy is None:
                continue
            candidates.append({
                "name": objects[root_go]["name"],
                "game_objects": totals["game_objects"],
                "mesh_filters": totals["mesh_filters"],
                "renderers": totals["renderers"],
                "particle_systems": totals["particle_systems"],
                "mesh_renderers": totals["mesh_renderers"],
                "active": objects[root_go]["active"],
                "exportable_by_name": first_by_name[objects[root_go]["name"]]==root_go,
                "root_go_id": root_go,
                "root_transform_id": root_tid,
                "hierarchy": hierarchy,
            })

        # Preserve the original root-candidate policy: mesh-bearing top-level roots
        # are listed first, sorted by MeshFilter count. Child objects are preview-only.
        mesh_candidates = [x for x in candidates if x["mesh_filters"] > 0]
        if mesh_candidates:
            candidates = mesh_candidates
        candidates.sort(
            key=lambda x: (
                x["mesh_filters"], x["renderers"], x["game_objects"]
            ),
            reverse=True,
        )
        return candidates

    def _select_root_candidate(self, scene_path: Path, candidates: list[dict]):
        """Pick a top-level stage root and preview its complete Unity hierarchy."""
        dialog = tk.Toplevel(self.root)
        dialog.title("自动识别舞台根对象 — Unity Hierarchy 预览")
        dialog.geometry("1080x740")
        dialog.minsize(900, 620)
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.result = None

        ttk.Label(
            dialog,
            text=f"已扫描：{scene_path.name}\n"
                 "上方只列出场景顶层 GameObject 候选；下方可以展开查看所选根对象的完整子层级。",
            wraplength=1030,
            justify="left",
        ).pack(fill="x", padx=12, pady=(12, 8))

        candidate_frame = ttk.LabelFrame(
            dialog, text="顶层舞台根对象候选（选择完整舞台根对象）", padding=8
        )
        candidate_frame.pack(fill="x", padx=12, pady=(0, 8))
        candidate_frame.columnconfigure(0, weight=1)
        columns = ("name", "game_objects", "mesh_filters", "renderers", "particle_systems")
        candidate_tree = ttk.Treeview(
            candidate_frame, columns=columns, show="headings", selectmode="browse", height=4
        )
        candidate_tree.heading("name", text="顶层 GameObject 名称")
        candidate_tree.heading("game_objects", text="子树 GameObjects")
        candidate_tree.heading("mesh_filters", text="MeshFilter")
        candidate_tree.heading("renderers", text="Renderer（含粒子渲染器）")
        candidate_tree.heading("particle_systems", text="ParticleSystem")
        candidate_tree.column("name", width=300, anchor="w")
        candidate_tree.column("game_objects", width=145, anchor="center")
        candidate_tree.column("mesh_filters", width=105, anchor="center")
        candidate_tree.column("renderers", width=180, anchor="center")
        candidate_tree.column("particle_systems", width=130, anchor="center")
        candidate_tree.grid(row=0, column=0, sticky="ew")
        candidate_scroll = ttk.Scrollbar(
            candidate_frame, orient="vertical", command=candidate_tree.yview
        )
        candidate_scroll.grid(row=0, column=1, sticky="ns")
        candidate_tree.configure(yscrollcommand=candidate_scroll.set)

        hierarchy_frame = ttk.LabelFrame(
            dialog, text="所选根对象的 Unity Hierarchy（只读预览）", padding=8
        )
        hierarchy_frame.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        search_row = ttk.Frame(hierarchy_frame)
        search_row.pack(fill="x", pady=(0, 6))
        ttk.Label(search_row, text="搜索子对象：").pack(side="left")
        search_var = tk.StringVar()
        search_entry = ttk.Entry(search_row, textvariable=search_var, width=36)
        search_entry.pack(side="left", fill="x", expand=True, padx=(4, 6))
        ttk.Button(search_row, text="清除", command=lambda: search_var.set("")).pack(side="left")
        hierarchy_summary = tk.StringVar(value="请选择上方的顶层根对象。")
        ttk.Label(
            hierarchy_frame, textvariable=hierarchy_summary, foreground="#475569"
        ).pack(anchor="w", pady=(0, 5))

        hierarchy_columns = ("mesh_filters", "renderers", "particle_systems")
        hierarchy_tree = ttk.Treeview(
            hierarchy_frame,
            columns=hierarchy_columns,
            show="tree headings",
            selectmode="browse",
            height=16,
        )
        hierarchy_tree.heading("#0", text="GameObject / Unity Hierarchy")
        hierarchy_tree.heading("mesh_filters", text="本对象 MeshFilter")
        hierarchy_tree.heading("renderers", text="本对象 Renderer")
        hierarchy_tree.heading("particle_systems", text="本对象 ParticleSystem")
        hierarchy_tree.column("#0", width=570, minwidth=300, anchor="w")
        hierarchy_tree.column("mesh_filters", width=130, anchor="center")
        hierarchy_tree.column("renderers", width=130, anchor="center")
        hierarchy_tree.column("particle_systems", width=150, anchor="center")
        hierarchy_tree.pack(side="left", fill="both", expand=True)
        hierarchy_scroll = ttk.Scrollbar(
            hierarchy_frame, orient="vertical", command=hierarchy_tree.yview
        )
        hierarchy_scroll.pack(side="right", fill="y")
        hierarchy_tree.configure(yscrollcommand=hierarchy_scroll.set)

        def populate_hierarchy(*_args):
            hierarchy_tree.delete(*hierarchy_tree.get_children(""))
            selection = candidate_tree.selection()
            if not selection:
                hierarchy_summary.set("请选择上方的顶层根对象。")
                return
            candidate = candidates[int(selection[0])]
            query = search_var.get().strip().casefold()
            hierarchy = candidate.get("hierarchy")
            hierarchy_summary.set(
                f"{candidate['name']}：{candidate['game_objects']} 个 GameObject，"
                f"{candidate['mesh_filters']} 个 MeshFilter，"
                f"{candidate['renderers']} 个 Renderer，"
                f"{candidate['particle_systems']} 个 ParticleSystem。"
                "各行数字表示该 GameObject 自身组件数量。"
            )
            if not hierarchy:
                return

            def subtree_matches(node):
                if not query:
                    return True
                if query in node["name"].casefold():
                    return True
                return any(subtree_matches(child) for child in node["children"])

            def insert_node(parent_iid, node, depth=0, force=False):
                self_match = bool(query and query in node["name"].casefold())
                include_all_children = force or self_match
                if query and not include_all_children and not subtree_matches(node):
                    return None
                iid = str(node["go_id"])
                hierarchy_tree.insert(
                    parent_iid,
                    "end",
                    iid=iid,
                    text=node["name"],
                    values=(node["mesh_filters"], node["renderers"], node["particle_systems"]),
                )
                has_matching_descendant = any(
                    subtree_matches(child) for child in node["children"]
                ) if query and not include_all_children else False
                for child in node["children"]:
                    insert_node(iid, child, depth + 1, include_all_children)
                # With no filter, open only the selected root. With a search, open
                # the path to matching nodes and the matching node itself.
                should_open = depth == 0 or (query and (self_match or has_matching_descendant))
                hierarchy_tree.item(iid, open=bool(should_open))
                return iid

            insert_node("", hierarchy)
            if not hierarchy_tree.get_children(""):
                hierarchy_tree.insert(
                    "", "end", iid="__no_match__", text="没有找到匹配的 GameObject。"
                )

        for index, item in enumerate(candidates):
            candidate_tree.insert(
                "", "end", iid=str(index),
                values=(
                    item["name"], item["game_objects"], item["mesh_filters"],
                    item["renderers"], item["particle_systems"],
                ),
            )
        candidate_tree.bind("<<TreeviewSelect>>", populate_hierarchy)
        search_var.trace_add("write", populate_hierarchy)
        if candidates:
            candidate_tree.selection_set("0")
            candidate_tree.focus("0")
            populate_hierarchy()

        note = (
            "说明：上方只显示顶层根对象候选；EffectPlayer 等子对象会显示在下方层级树中，"
            "不会被误当成独立舞台。搜索可定位任意子对象；预览统计包含 inactive 对象，"
            "实际转换范围由主界面的 inactive 选项决定。"
        )
        ttk.Label(
            dialog, text=note, foreground="#9a6700",
            wraplength=1030, justify="left"
        ).pack(fill="x", padx=12, pady=(0, 8))

        buttons = ttk.Frame(dialog, padding=(12, 0, 12, 12))
        buttons.pack(fill="x")

        def use_selected():
            selection = candidate_tree.selection()
            if not selection:
                messagebox.showwarning("尚未选择", "请先选择一个顶层根对象候选。", parent=dialog)
                return
            item = candidates[int(selection[0])]
            dialog.result = item["name"]
            dialog.destroy()

        def manual_entry():
            value = simpledialog.askstring(
                "手动输入根对象",
                "请输入 Unity Hierarchy 中的准确 GameObject 名称：",
                parent=dialog
            )
            if value and value.strip():
                dialog.result = value.strip()
                dialog.destroy()

        ttk.Button(buttons, text="使用选中对象", command=use_selected).pack(side="right")
        ttk.Button(buttons, text="手动输入…", command=manual_entry).pack(side="right", padx=6)
        ttk.Button(buttons, text="取消", command=dialog.destroy).pack(side="right", padx=6)

        self.root.wait_window(dialog)
        return dialog.result

    def _add_stage(self):
        project_text = self.project_var.get().strip()
        if not project_text:
            messagebox.showwarning("需要先选择项目", "请先选择 AssetRipper scene-project 根目录。")
            return
        project = Path(project_text).expanduser().resolve()
        if not (project / "Assets").is_dir():
            messagebox.showerror("目录无效", "项目根目录下找不到 Assets 文件夹。")
            return

        selected = filedialog.askopenfilename(
            title="选择 Unity 场景文件",
            initialdir=str(project / "Assets"),
            filetypes=[("Unity scene", "*.unity")]
        )
        if not selected:
            return
        scene_path = Path(selected).resolve()
        try:
            scene_rel = scene_path.relative_to(project).as_posix()
        except ValueError:
            messagebox.showerror("场景路径无效", "场景文件必须位于所选 scene-project 目录内部。")
            return
        if scene_path.suffix.lower() != ".unity":
            messagebox.showerror("文件类型错误", "请选择 .unity 场景文件。")
            return

        try:
            self._log(f"正在扫描 Unity 场景完整 Hierarchy：{scene_rel}", "info")
            candidates = self._scan_scene_root_candidates(scene_path)
            if not candidates:
                raise RuntimeError("场景中没有找到带 Transform 的顶层 GameObject。")
            self._log(
                "根对象候选：" + "；".join(
                    f"{x['name']}（MeshFilter {x['mesh_filters']}，"
                    f"Renderer {x['renderers']}，ParticleSystem {x['particle_systems']}，"
                    f"GameObjects {x['game_objects']}）"
                    for x in candidates[:12]
                ),
                "info",
            )
            root_name, reason = root_selection(scene_path,candidates)
            if root_name:
                self._log(f"自动识别根对象：{root_name}（{reason}）", "success")
            else:
                root_name = self._select_root_candidate(scene_path, candidates)
        except Exception as exc:
            self._log(f"自动扫描根对象失败：{exc}", "error")
            messagebox.showwarning(
                "自动扫描失败",
                "无法自动扫描该 Unity 场景的根对象。\n\n"
                f"原因：{exc}\n\n"
                "可以选择手动输入，但请确保名称来自 Unity 场景。",
                parent=self.root,
            )
            root_name = simpledialog.askstring(
                "手动输入舞台根对象",
                "请输入准确的 Unity GameObject 名称：",
                parent=self.root,
            )

        if root_name is None:
            return
        root_name = root_name.strip()
        if not root_name:
            messagebox.showerror("根对象名称为空", "舞台根 GameObject 名称不能为空。")
            return

        if any(
            str(t.get("project", "")).casefold() == str(project).casefold()
            and t["scene"].casefold() == scene_rel.casefold()
            and t["root"].casefold() == root_name.casefold()
            for t in self.tasks
        ):
            messagebox.showinfo("任务已存在", "队列中已经有相同项目、场景和根对象的任务。")
            return

        self.tasks.append({
            "id": uuid.uuid4().hex,
            "project": str(project),
            "source_folder": str(project.parent),
            "scene": scene_rel,
            "root": root_name,
            "status": STATUS_PENDING,
            "output": "",
            "quality_status": QUALITY_UNCHECKED,
            "quality_report": "",
            "quality_report_text": "",
        })
        self._refresh_tree()
        self._save_tasks()
        self._log(f"已添加任务：{scene_rel}  |  {root_name}", "info")

    def _add_stage_folders(self):
        """Select several stage folders and discover their scene-projects/scenes."""
        initial_dir = None
        current_project = self.project_var.get().strip()
        if current_project:
            current = Path(current_project).expanduser()
            if current.name.casefold() == "scene-project":
                initial_dir = str(current.parent.parent)
            else:
                initial_dir = str(current.parent)

        common_root_text = filedialog.askdirectory(
            title="选择包含多个舞台文件夹的共同父目录",
            initialdir=initial_dir,
        )
        if not common_root_text:
            return
        common_root = Path(common_root_text).expanduser().resolve()

        try:
            spec = importlib.util.spec_from_file_location(
                "scsp_batch_folder_discovery", BATCH_DISCOVERY
            )
            if spec is None or spec.loader is None:
                raise RuntimeError("无法加载批量文件夹扫描模块。")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            entries = module.discover_stage_folders(common_root)
        except Exception as exc:
            messagebox.showerror("扫描文件夹失败", str(exc), parent=self.root)
            return

        if not entries:
            messagebox.showinfo(
                "没有找到舞台文件夹",
                "所选目录下没有可扫描的子文件夹。请选中多个舞台文件夹共同所在的父目录。",
                parent=self.root,
            )
            return

        dialog = tk.Toplevel(self.root)
        dialog.title("批量选择舞台文件夹")
        dialog.geometry("1080x620")
        dialog.minsize(850, 480)
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.result = []

        ttk.Label(
            dialog,
            text=(
                f"共同父目录：{common_root}\n"
                "点击左侧勾选框选择舞台，也可用 Ctrl / Shift 多选。扫描各文件夹的 "
                "scene-project\\Assets，自动查找其中的 .unity 场景。"
            ),
            justify="left", wraplength=1030,
        ).pack(fill="x", padx=12, pady=(12, 8))

        frame = ttk.Frame(dialog, padding=(12, 0, 12, 8))
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        columns = ("selected", "folder", "project", "scenes", "status")
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="extended")
        tree.heading("selected", text="转换")
        tree.column("selected", width=48, minwidth=44, stretch=False, anchor="center")
        tree.heading("folder", text="舞台文件夹")
        tree.heading("project", text="自动识别的 scene-project")
        tree.heading("scenes", text=".unity 数量")
        tree.heading("status", text="扫描状态")
        tree.column("folder", width=190, minwidth=130)
        tree.column("project", width=510, minwidth=280)
        tree.column("scenes", width=90, minwidth=70, anchor="center")
        tree.column("status", width=220, minwidth=150)
        tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=scroll.set)
        tree.tag_configure("valid", foreground="#166534")
        tree.tag_configure("invalid", foreground="#b91c1c")

        valid_ids = []
        for index, entry in enumerate(entries):
            folder = Path(entry["stage_folder"])
            project_root = entry.get("project_root")
            scenes = entry.get("scenes", [])
            error = entry.get("error", "")
            valid = bool(project_root and scenes and not error)
            values = (
                "☑" if valid else "—", folder.name,
                str(project_root) if project_root else "（未找到）",
                len(scenes),
                "可添加" if valid else (error or "无有效场景"),
            )
            tree.insert("", "end", iid=str(index), values=values,
                        tags=("valid" if valid else "invalid",))
            if valid:
                valid_ids.append(str(index))
        if valid_ids:
            tree.selection_set(valid_ids)
            tree.focus(valid_ids[0])

        def sync_checks(_event=None):
            chosen = set(tree.selection())
            for iid in valid_ids:
                tree.set(iid, "selected", "☑" if iid in chosen else "☐")

        def toggle_check(event):
            iid = tree.identify_row(event.y)
            if tree.identify_column(event.x) == "#1" and iid:
                if iid in valid_ids:
                    tree.selection_toggle(iid)
                return "break"

        tree.bind("<<TreeviewSelect>>", sync_checks)
        tree.bind("<Button-1>", toggle_check)
        selection_hint = ttk.Label(
            dialog,
            text=f"发现 {len(entries)} 个文件夹，其中 {len(valid_ids)} 个包含有效 scene-project 和 Unity 场景。",
            foreground="#475569",
        )
        selection_hint.pack(anchor="w", padx=12, pady=(0, 8))

        buttons = ttk.Frame(dialog, padding=(12, 0, 12, 12))
        buttons.pack(fill="x")

        def select_all_valid():
            tree.selection_set(valid_ids)

        def clear_selection():
            tree.selection_remove(tree.selection())

        def accept():
            selected = tree.selection()
            chosen = [entries[int(i)] for i in selected]
            chosen = [e for e in chosen if e.get("project_root") and e.get("scenes") and not e.get("error")]
            if not chosen:
                messagebox.showwarning(
                    "没有选择有效文件夹",
                    "请至少选择一个包含 scene-project\\Assets\\*.unity 的舞台文件夹。",
                    parent=dialog,
                )
                return
            dialog.result = chosen
            dialog.destroy()

        ttk.Button(buttons, text="全选有效文件夹", command=select_all_valid).pack(side="left")
        ttk.Button(buttons, text="清空选择", command=clear_selection).pack(side="left", padx=5)
        ttk.Button(buttons, text="取消", command=dialog.destroy).pack(side="right")
        ttk.Button(buttons, text="添加选中的文件夹", command=accept).pack(side="right", padx=5)

        self.root.wait_window(dialog)
        selected_entries = dialog.result
        if not selected_entries:
            return

        if self.output_auto:
            self.output_var.set("")
            self.output_auto = False

        added = 0
        skipped = 0
        errors = []
        for folder_index, entry in enumerate(selected_entries, 1):
            stage_folder = Path(entry["stage_folder"])
            project_root = Path(entry["project_root"])
            scenes = entry["scenes"]
            self._log(
                f"[批量扫描 {folder_index}/{len(selected_entries)}] {stage_folder}；"
                f"scene-project：{project_root}；Unity 场景：{len(scenes)} 个",
                "info",
            )
            for scene_path in scenes:
                try:
                    scene_rel = Path(scene_path).resolve().relative_to(project_root).as_posix()
                    self._log(f"正在扫描 Unity 场景完整 Hierarchy：{scene_rel}", "info")
                    candidates = self._scan_scene_root_candidates(Path(scene_path))
                    if not candidates:
                        skipped += 1
                        errors.append(f"{stage_folder.name} / {scene_rel}：没有找到带 Transform 的顶层 GameObject")
                        self._log(f"[跳过] {scene_rel}：没有找到有效舞台根对象。", "error")
                        continue

                    self._log(
                        "根对象候选：" + "；".join(
                            f"{x['name']}（MeshFilter {x['mesh_filters']}，"
                            f"Renderer {x['renderers']}，ParticleSystem {x['particle_systems']}，"
                            f"GameObjects {x['game_objects']}）"
                            for x in candidates[:12]
                        ),
                        "info",
                    )
                    root_name, root_reason = root_selection(Path(scene_path), candidates)
                    if root_name:
                        self._log(f"自动识别根对象：{root_name}（{root_reason}）", "success")
                    else:
                        skipped += 1
                        names = "、".join(x["name"] for x in candidates[:6])
                        errors.append(f"{stage_folder.name} / {scene_rel}：{root_reason}（{names}）")
                        self._log(f"[待确认] {scene_rel}：{root_reason}（{names}）", "error")
                        continue

                    duplicate = any(
                        str(t.get("project", "")).casefold() == str(project_root).casefold()
                        and t["scene"].casefold() == scene_rel.casefold()
                        and t["root"].casefold() == root_name.casefold()
                        for t in self.tasks
                    )
                    if duplicate:
                        skipped += 1
                        self._log(f"[跳过] 队列中已存在：{stage_folder.name} / {scene_rel} / {root_name}", "info")
                        continue

                    self.tasks.append({
                        "id": uuid.uuid4().hex,
                        "project": str(project_root),
                        "candidate_count": len(candidates),
                        "source_folder": str(stage_folder),
                        "scene": scene_rel,
                        "root": root_name,
                        "root_selection": root_reason,
                        "status": STATUS_PENDING,
                        "output": "",
                        "quality_status": QUALITY_UNCHECKED,
                        "quality_report": "",
                        "quality_report_text": "",
                    })
                    added += 1
                    self._log(
                        f"已加入队列：{stage_folder.name} | {scene_rel} | {root_name}",
                        "success",
                    )
                except Exception as exc:
                    skipped += 1
                    errors.append(f"{stage_folder.name} / {Path(scene_path).name}：{exc}")
                    self._log(f"[扫描失败] {stage_folder.name} / {Path(scene_path).name}：{exc}", "error")

        self._refresh_tree()
        self._save_tasks()
        self._save_settings()
        summary = f"批量添加完成。\n\n新增任务：{added}\n跳过/失败：{skipped}\n\n已加入的任务可以在队列中统一批量转换。"
        if errors:
            summary += "\n\n部分问题：\n" + "\n".join(errors[:8])
            if len(errors) > 8:
                summary += f"\n……另有 {len(errors) - 8} 项，详情请查看运行日志。"
        if added:
            self._log(f"批量添加结束：新增 {added} 个，跳过/失败 {skipped} 个。", "success")
        messagebox.showinfo("批量添加结果", summary, parent=self.root)

    def _remove_selected(self):
        if self.is_running:
            return
        ids = set(self.tree.selection())
        if not ids:
            return
        self.tasks = [t for t in self.tasks if t["id"] not in ids]
        self._refresh_tree()
        self._save_tasks()

    def _clear_tasks(self):
        if self.is_running:
            return
        if not self.tasks:
            return
        if not messagebox.askyesno("清空队列", "确定清空全部舞台任务吗？"):
            return
        self.tasks.clear()
        self._refresh_tree()
        self._save_tasks()

    def _export_tasks(self):
        path = filedialog.asksaveasfilename(
            title="保存舞台任务清单",
            defaultextension=".json",
            initialfile="SCSP_Stage_Tasks.json",
            filetypes=[("JSON", "*.json")]
        )
        if not path:
            return
        payload = {
            "version": 3,
            "project": self.project_var.get().strip(),
            "tasks": [
                {
                    "project": t.get("project", self.project_var.get().strip()),
                    "source_folder": t.get("source_folder", ""),
                    "scene": t["scene"],
                    "root": t["root"],
                    "output": t.get("output", ""),
                    "include_inactive": t.get("include_inactive"),
                    "candidate_count": t.get("candidate_count", 0),
                    "status": t.get("status", STATUS_PENDING),
                    "quality_status": t.get("quality_status", QUALITY_UNCHECKED),
                    "quality_report": t.get("quality_report", ""),
                    "quality_report_text": t.get("quality_report_text", ""),
                } for t in self.tasks
            ],
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self._log(f"任务清单已保存：{path}", "success")

    def _import_tasks(self):
        if self.is_running:
            return
        path = filedialog.askopenfilename(
            title="导入舞台任务清单",
            filetypes=[("JSON", "*.json")]
        )
        if not path:
            return
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8-sig"))
            tasks = payload.get("tasks", [])
            if not isinstance(tasks, list):
                raise ValueError("JSON 中的 tasks 必须是数组")
            project = str(payload.get("project", "")).strip()
            if project and not self.project_var.get().strip():
                self.project_var.set(project)
            added = 0
            for item in tasks:
                scene = str(item.get("scene", "")).strip().replace("\\", "/")
                root_name = str(item.get("root", "")).strip()
                if not scene or not root_name:
                    continue
                task_project = str(item.get("project") or project or self.project_var.get() or "").strip()
                source_folder = str(item.get("source_folder", "")).strip()
                duplicate = any(
                    str(t.get("project", self.project_var.get())).casefold() == task_project.casefold()
                    and t["scene"].casefold() == scene.casefold()
                    and t["root"].casefold() == root_name.casefold()
                    for t in self.tasks
                )
                if duplicate:
                    continue
                self.tasks.append({
                    "id": uuid.uuid4().hex, "project": task_project,
                    "source_folder": source_folder, "scene": scene, "root": root_name,
                    "status": STATUS_PENDING, "output": str(item.get("output", "")),
                    "include_inactive": item.get("include_inactive"),
                    "candidate_count": item.get("candidate_count", 0),
                    "quality_status": str(item.get("quality_status", QUALITY_UNCHECKED)),
                    "quality_report": str(item.get("quality_report", "")),
                    "quality_report_text": str(item.get("quality_report_text", "")),
                })
                added += 1
            self._refresh_tree()
            self._save_tasks()
            self._save_settings()
            self._log(f"已导入 {added} 个任务：{path}", "success")
        except Exception as exc:
            messagebox.showerror("导入失败", str(exc))

    def _open_quality_report(self):
        selected = self.tree.selection()
        if len(selected) != 1:
            messagebox.showinfo("选择舞台", "请先在队列中选择一个舞台。")
            return
        task = next((item for item in self.tasks if item["id"] == selected[0]), None)
        if not task:
            return
        report_text = str(task.get("quality_report_text", "")).strip()
        report_json = str(task.get("quality_report", "")).strip()
        report_path = Path(report_text or report_json) if (report_text or report_json) else None
        if report_path is None or not report_path.is_file():
            messagebox.showinfo("质量报告不存在", "该舞台尚未生成质量报告。请先完成一次转换。")
            return
        try:
            os.startfile(str(report_path))
        except Exception as exc:
            messagebox.showerror("无法打开质量报告", str(exc))

    def _compare_quality_reports(self):
        """Read-only comparison. Never alters a queued conversion or its PMX."""
        try:
            from Validator.compare_inactive_modes import compare_report_files
            include = filedialog.askopenfilename(
                title="选择【勾选 inactive】include 的质量报告 JSON",
                filetypes=[("SCSP 质量报告", "*.json")], parent=self.root,
            )
            if not include:
                return
            exclude = filedialog.askopenfilename(
                title="选择【未勾选 inactive】exclude 的质量报告 JSON",
                filetypes=[("SCSP 质量报告", "*.json")], parent=self.root,
            )
            if not exclude:
                return
            root_name = safe_name(read_json(Path(include), {}).get("stage", {}).get("root", "stage"))
            target = filedialog.asksaveasfilename(
                title="保存双模式对比 JSON（会自动生成同名 TXT）",
                initialdir=str(Path(exclude).parent),
                initialfile=f"{root_name}_inactive_mode_comparison.json",
                filetypes=[("JSON", "*.json")], defaultextension=".json", parent=self.root,
            )
            if not target:
                return
            json_path = Path(target)
            text_path = json_path.with_suffix(".txt")
            result = compare_report_files(include, exclude, json_path, text_path)
            status = result["summary"]["status"]
            self._log(
                f"[V2.4.9 对比] {status}：{result['summary']['excludedGameObjects']} 个排除 GameObject；"
                f"{result['summary']['excludedMeshFilterComponents']} 个 MeshFilter。{json_path}",
                "success" if status == "PASS" else "info",
            )
            if messagebox.askyesno(
                "双模式对比已完成",
                f"状态：{status}；自检：{result['summary']['passed']}/{result['summary']['checks']}\n"
                f"JSON：{json_path}\nTXT：{text_path}\n\n是否打开 TXT 报告？",
                parent=self.root,
            ):
                os.startfile(str(text_path))
        except Exception as exc:
            messagebox.showerror("双模式对比失败", str(exc), parent=self.root)

    def _diagnose_warning_reports(self):
        """Read-only WARNING, normal-channel and inactive association diagnostics."""
        try:
            from Validator.diagnose_warnings import diagnose_warning_files
            include = filedialog.askopenfilename(
                title="选择【勾选 inactive】Include 质量报告 JSON",
                filetypes=[("SCSP 质量报告", "*.json")], parent=self.root,
            )
            if not include:
                return
            exclude = filedialog.askopenfilename(
                title="选择【取消勾选 inactive】Exclude 质量报告 JSON",
                filetypes=[("SCSP 质量报告", "*.json")], parent=self.root,
            )
            if not exclude:
                return
            root_name = safe_name(read_json(Path(include), {}).get("stage", {}).get("root", "stage"))
            target = filedialog.asksaveasfilename(
                title="保存 WARNING 诊断 JSON（会自动生成同名 TXT）",
                initialdir=str(Path(exclude).parent),
                initialfile=f"{root_name}_warning_diagnostics.json",
                filetypes=[("JSON", "*.json")], defaultextension=".json", parent=self.root,
            )
            if not target:
                return
            json_path = Path(target)
            text_path = json_path.with_suffix(".txt")
            result = diagnose_warning_files(include, exclude, json_path, text_path)
            summary = result["summary"]
            status = summary["diagnosticStatus"]
            self._log(
                f"[V3.0 WARNING / 法线-inactive 关联诊断] {status}：Include {summary['includeWarningCount']} 项，"
                f"Exclude {summary['excludeWarningCount']} 项；完整定位 {summary['fullyMappedWarningCount']} 项。{json_path}",
                "success" if status == "COMPLETE" else "info",
            )
            if messagebox.askyesno(
                "WARNING / 法线关联诊断完成",
                f"WARNING 定位：{status}\\n"
                f"Include WARNING：{summary['includeWarningCount']}\\n"
                f"Exclude WARNING：{summary['excludeWarningCount']}\\n"
                f"法线 / inactive 关联：{summary.get('normalInactiveAssociationStatus')}\\n"
                f"inactive 状态核验：{summary.get('inactiveStateValidationStatus')}\\n"
                f"完整定位：{summary['fullyMappedWarningCount']}\\n"
                f"未完整定位：{summary['unmappedWarningCount']}\\n\\n"
                f"JSON：{json_path}\\nTXT：{text_path}\\n\\n是否打开 TXT 报告？",
                parent=self.root,
            ):
                os.startfile(str(text_path))
        except Exception as exc:
            messagebox.showerror("WARNING / 法线关联诊断失败", str(exc), parent=self.root)

    def _open_output(self):
        selected = self.tree.selection()
        task = next((t for t in self.tasks if len(selected) == 1 and t["id"] == selected[0]), {})
        value = task.get("output") or self.output_var.get().strip()
        if not value:
            fallback_project = task.get("project", "")
            if not fallback_project and self.tasks:
                fallback_project = str(self.tasks[0].get("project", "")).strip()
            if not fallback_project:
                fallback_project = self.project_var.get().strip()
            if not fallback_project:
                messagebox.showinfo("没有输出目录", "请先添加舞台任务或选择一个 scene-project。")
                return
            value = str(Path(fallback_project) / "PMX_Output_GUI")
        path = Path(value).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(path))
        except Exception as exc:
            messagebox.showerror("无法打开目录", str(exc))

    def _open_batch_report(self):
        if self.last_report and Path(self.last_report).is_file():
            try:
                os.startfile(self.last_report)
            except OSError as exc:
                messagebox.showerror("无法打开批量报告", str(exc))
        else:
            messagebox.showinfo("批量报告", "完成一次批量转换后可在此查看报告。")

    def _edit_task(self):
        if self.is_running:
            return
        selected = self.tree.selection()
        if len(selected) != 1:
            messagebox.showinfo("编辑任务", "请选择一个舞台任务。")
            return
        task = next(t for t in self.tasks if t["id"] == selected[0])
        dialog = tk.Toplevel(self.root)
        dialog.title("编辑舞台任务")
        dialog.transient(self.root)
        dialog.grab_set()
        fields = {}
        for row, (key, label) in enumerate((("project", "scene-project 目录"), ("scene", "场景相对路径"), ("root", "舞台根对象"))):
            fields[key] = tk.StringVar(dialog, value=task.get(key, ""))
            ttk.Label(dialog, text=label).grid(row=row, column=0, padx=8, pady=5)
            ttk.Entry(dialog, textvariable=fields[key], width=65).grid(row=row, column=1, padx=8)
        modes = {"跟随全局": None, "包含": True, "排除": False}
        current = task.get("include_inactive")
        mode = tk.StringVar(dialog, value=next((k for k, v in modes.items() if v is current), "跟随全局"))
        def choose_root():
            scene = Path(fields["project"].get() or self.project_var.get()) / fields["scene"].get()
            try:
                candidates = self._scan_scene_root_candidates(scene)
                name = self._select_root_candidate(scene, candidates)
            except (OSError, ValueError) as exc:
                messagebox.showerror("无法扫描场景", str(exc), parent=dialog)
                return
            finally:
                dialog.grab_set()
            if name:
                fields["root"].set(name)
        ttk.Button(dialog, text="查看根候选…", command=choose_root).grid(row=2, column=2, padx=6)
        ttk.Label(dialog, text="inactive GameObject").grid(row=3, column=0)
        ttk.Combobox(dialog, state="readonly", textvariable=mode, values=list(modes)).grid(row=3, column=1, sticky="w", padx=8)

        def apply():
            values = {key: value.get().strip() for key, value in fields.items()}
            if not values["root"] or not values["scene"]:
                messagebox.showerror("任务不完整", "请填写根对象和场景相对路径。", parent=dialog)
                return
            values["scene"] = values["scene"].replace(chr(92), "/")
            values["include_inactive"] = modes[mode.get()]
            if any(task.get(k) != v for k, v in values.items()):
                if values["project"] and values["project"] != task.get("project"):
                    task["source_folder"] = str(Path(values["project"]).parent)
                task.update(values)
                if task["status"] != STATUS_FAILED:
                    task["status"] = STATUS_PENDING
                task.update(output="", quality_report="", quality_report_text="", quality_status=QUALITY_UNCHECKED)
                self._refresh_tree()
                self.tree.selection_set(task["id"])
                self._save_tasks()
            dialog.destroy()
        ttk.Button(dialog, text="保存", command=apply).grid(row=4, column=1, sticky="e", padx=8, pady=8)

    def _retry_failed(self):
        if self.is_running:
            return
        ids = [t["id"] for t in self.tasks if t.get("status") == STATUS_FAILED]
        if ids:
            self._start_worker(ids)
        else:
            messagebox.showinfo("重试失败项", "当前队列没有失败任务。")

    def _row_values(self, task):
        project = task.get("project") or self.project_var.get()
        source = task.get("source_folder") or str(Path(project).parent)
        mode = "包含" if effective_mode(task, self.include_inactive_var.get()) else "排除"
        if not isinstance(task.get("include_inactive"), bool):
            mode += "（全局）"
        target = self.output_var.get().strip() or str(Path(project) / "PMX_Output_GUI")
        count = task.get("candidate_count", 0)
        root_label = f"{task['root']}（{count} 候选）" if isinstance(count, int) and count > 1 else task["root"]
        return (Path(source).name, task["scene"], root_label, mode, task.get("status", STATUS_PENDING),
                task.get("quality_status", QUALITY_UNCHECKED), task.get("output") or "输出到 " + target)

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for task in self.tasks:
            status = task.get("status", STATUS_PENDING)
            tag = "done" if status == STATUS_DONE else (
                "failed" if status == STATUS_FAILED else (
                    "running" if status == STATUS_RUNNING else "pending"
                )
            )
            self.tree.insert(
                "", "end", iid=task["id"],
                values=self._row_values(task),
                tags=(tag,)
            )

    def _set_task_status(self, task_id: str, status: str, output: str | None = None):
        task = next((t for t in self.tasks if t["id"] == task_id), None)
        if task:
            task["status"] = status
            if output is not None:
                task["output"] = output
            if status == STATUS_RUNNING:
                task.update(output="", quality_report="", quality_report_text="", quality_status=QUALITY_UNCHECKED)
            values = self._row_values(task)
            tag = "done" if status == STATUS_DONE else (
                "failed" if status == STATUS_FAILED else (
                    "running" if status == STATUS_RUNNING else "pending"
                )
            )
            if self.tree.exists(task_id):
                self.tree.item(task_id, values=values, tags=(tag,))
            self._save_tasks()

    def _run_selected(self):
        if self.is_running:
            return
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("选择任务", "请在队列中选择要转换的舞台任务。")
            return
        self._start_worker(list(selected))

    def _run_batch(self):
        if self.is_running:
            return
        indices = [
            t["id"] for t in self.tasks
            if t.get("status") != STATUS_DONE
        ]
        if not indices:
            messagebox.showinfo("没有待处理任务", "队列中的任务均已生成 PMX。")
            return
        self._start_worker(indices)

    def _start_worker(self, task_ids: list[str]):
        if not self._validate_environment():
            return
        self._save_settings()
        self._save_tasks()
        self.stop_after_current.clear()
        self.current_indices = list(task_ids)
        self.is_running = True
        self.progress.configure(maximum=max(1, len(task_ids)))
        self.progress_var.set(0)
        self.status_var.set(f"准备处理 {len(task_ids)} 个舞台…")
        self._set_running_controls(True)
        snapshot = [
            dict(t) for t in self.tasks if t["id"] in set(task_ids)
        ]
        # Read Tk variables on the main thread; the worker receives plain values only.
        settings = {
            "project": self.project_var.get().strip(),
            "blender": self.blender_var.get().strip(),
            "output": self.output_var.get().strip(),
            "output_auto": bool(self.output_auto),
            "include_inactive": bool(self.include_inactive_var.get()),
            "scale": float(self.scale_var.get().strip()),
            "auto_restore": bool(self.auto_restore_var.get()),
            "floor_cleanup": bool(self.floor_cleanup_var.get()),
            "mme_preview": bool(self.mme_preview_var.get()),
            "enable_stage_effects": bool(self.enable_effect_var.get()),
            "effect_profile_dir": self.effect_profile_dir_var.get().strip(),
        }
        self.worker = threading.Thread(
            target=self._worker_main, args=(snapshot, settings), daemon=True
        )
        self.worker.start()

    def _validate_environment(self) -> bool:
        blender_text = self.blender_var.get().strip()
        if not blender_text or not Path(blender_text).is_file():
            messagebox.showerror("Blender 路径无效", "请选择有效的 blender.exe。")
            return False
        try:
            scale = float(self.scale_var.get().strip())
            if not math.isfinite(scale) or scale <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("比例无效", "PMX 比例必须是大于 0 的数字。")
            return False
        if not self.tasks:
            messagebox.showwarning("队列为空", "请先添加至少一个舞台任务。")
            return False

        return True

    def _set_running_controls(self, running: bool):
        state = "disabled" if running else "normal"
        for widget in [
            self.add_button, self.add_folders_button, self.remove_button, self.clear_button,
            self.run_batch_button, self.run_selected_button, self.edit_button, self.retry_button,
            self.effect_tool_button,
        ]:
            widget.configure(state=state)
        self.stop_button.configure(state="normal" if running else "disabled")

    def _request_stop(self):
        if self.is_running:
            self.stop_after_current.set()
            self.status_var.set("已请求停止：当前舞台完成后停止，不会强制中断 Blender。")
            self._log("用户请求停止批量任务；当前舞台完成后停止。", "info")

    def _worker_main(self, tasks_snapshot: list[dict], settings: dict):
        report = None
        try:
            report = BatchReport(settings["output"] or APP, tasks_snapshot, settings)
            self.events.put(("batch_report", str(report.folder / "index.html")))
            self._process_batch(tasks_snapshot, settings, report)
        except Exception as exc:
            if report:
                report.message = f"批次中断：{exc}"
            self.events.put(("log", traceback.format_exc(), "error"))
            self.events.put(("batch_error", str(exc)))
        finally:
            if report:
                try:
                    report.save()
                except OSError as exc:
                    self.events.put(("batch_error", str(exc)))
            self.events.put(("worker_finished",))

    def _process_batch(self, tasks_snapshot, settings, report):
        completed = failed = 0
        total = len(tasks_snapshot)
        # Check the selected Blender user's MMD Tools installation once before
        # spending time rebuilding any Unity scenes.
        try:
            self._preflight_mmd_tools(dict(settings, batch_folder=report.folder))
        except Exception as exc:
            self.events.put(("log", f"[环境检查失败] {exc}", "error"))
            self.events.put(("log", traceback.format_exc(), "error"))
            self.events.put(("log", "舞台任务仍保留为待处理；请修复 MMD Tools 环境后重新开始。", "info"))
            report.message = f"环境检查失败，待重新运行。{exc}"
            self.events.put(("batch_error", report.message))
            return

        for index, task in enumerate(tasks_snapshot, 1):
            self.events.put(("task_status", task["id"], STATUS_RUNNING, None))
            self.events.put(("status", f"[{index}/{total}] 正在处理：{task['root']}"))
            self.events.put((
                "log",
                f"\n{'=' * 72}\n开始舞台：{task['root']}  |  {task['scene']}\n"
                f"来源 scene-project：{task.get('project', settings.get('project', ''))}",
                "info",
            ))
            error = None
            try:
                options = dict(settings, include_inactive=effective_mode(task, settings["include_inactive"]))
                output_dir = self._convert_one(task, options)
                if settings.get("auto_restore") or settings.get("floor_cleanup"):
                    try:
                        result = restore_stage(task.get("project") or settings["project"], task["scene"],
                                               output_dir / (safe_name(task["root"]) + ".pmx"),
                                               output_dir / "AutoStage", root_name=task["root"],
                                               scale=options["scale"], mme_preview=settings.get("mme_preview", False),
                                               blender=options["blender"], floor_cleanup=settings.get("floor_cleanup", False),
                                               floor_only=not settings.get("auto_restore"))
                        auto_dir = output_dir / "AutoStage"
                        motions = result.get("vmd_outputs", [])
                        if motions:
                            detail = f"已生成 {result['effects']} 条控制，动作文件 {auto_dir / motions[0]['file']}"
                        elif result.get("output_pmx"):
                            detail = f"已生成处理版 PMX {auto_dir / result['output_pmx']}"
                        else:
                            detail = f"未识别到可生成动作的效果，详见 {auto_dir / 'AutoStage_Report.json'}"
                        self.events.put(("log", f"[V5.3.9] {detail}", "info"))
                        mme = result.get("mme_preview", {})
                        if mme.get("folder"):
                            self.events.put(("log", f"[V5.3.9] MME 试验包 {auto_dir / mme['folder']}", "info"))
                            if mme.get("particle_emitters"):
                                self.events.put(("log", f"[V5.3.9] 已转换 {mme['particle_emitters']} 组粒子发射器", "info"))
                            if mme.get("timeline_light_meshes"):
                                self.events.put(("log", f"[V5.3.9] 已按 Timeline 恢复 {mme['timeline_light_meshes']} 个光照网格", "info"))
                            lighting = result["scene_lighting"]
                            self.events.put(("log", f"[V5.3.9] 舞台灯光匹配 {lighting['receiver_materials']} 个受光材质和 "
                                                    f"{lighting['light_map_materials']} 个灯面材质", "info"))
                            if lighting["animated_receiver_materials"]:
                                self.events.put(("log", f"[V5.3.9] 灯光时序已绑定到 {lighting['animated_receiver_materials']} 个材质",
                                                 "info"))
                        elif settings.get("mme_preview") and settings.get("auto_restore"):
                            self.events.put(("log", f"[V5.3.9] MME 试验包未生成，参见 AutoStage_Report.json", "info"))
                        screen_preview = result.get("screen_preview")
                        if screen_preview:
                            self.events.put(("log", f"[V5.3.9] 屏幕验收动作 {auto_dir / screen_preview['file']}", "info"))
                        floor_repair = result.get("floor_repair", {})
                        if floor_repair.get("status") == "applied":
                            self.events.put(("log", f"[V5.3.9] 已应用地板分层，调整 {floor_repair['vertices_moved']} 个顶点", "info"))
                        shadows = result.get("floor_shadow_cleanup", {})
                        if shadows.get("status") == "applied":
                            self.events.put(("log", f"[V5.3.9] 地板黑影已处理 {len(shadows['floor_materials'])} 个地板材质，"
                                                    f"已移除 {len(shadows['shadow_faces'])} 个材质中的贴地阴影面", "info"))
                    except Exception as exc:
                        self.events.put(("log", f"[V5.3.9] 自动还原失败，基础 PMX 已导出：{exc}", "error"))
                # Optional V3.1 sidecar. It can never invalidate or modify the
                # already-successful V3.0 conversion and quality-check result.
                if settings.get("enable_stage_effects", False):
                    profile_dir=Path(settings.get("effect_profile_dir") or EFFECT_PROFILES_DIR)
                    profile=profile_dir/(safe_name(task["root"])+".json")
                    if profile.is_file():
                        try:
                            effect_out=output_dir/"StageEffects"
                            pmx_input=output_dir/(safe_name(task["root"])+".pmx")
                            result=build_effect_package(pmx_input,profile,effect_out)
                            self.events.put(("log",f"[V3.1 效果附加包] 已生成 {effect_out}，新增 {len(result['effects'])} 项控制；需 MMD 验收。", "success"))
                        except Exception as effect_exc:
                            self.events.put(("log",f"[V3.1 效果后处理警告] {task['root']}: {effect_exc}。原始 PMX 已成功，未受到影响。", "error"))
                    else:
                        self.events.put(("log",f"[V3.1] 没有 {profile.name}，跳过效果，保留原始舞台。", "info"))
                self.events.put(("task_status", task["id"], STATUS_DONE, str(output_dir)))
                self.events.put(("log", f"[完成] 已生成原生 PMX，贴图引用检查通过；仍建议 MMD 9.32 实机验收：{output_dir}", "success"))
            except Exception as exc:
                error = traceback.format_exc()
                failed += 1
                self._write_partial_quality_report(task)
                self.events.put(("task_status", task["id"], STATUS_FAILED, None))
                self.events.put(("log", f"[失败] {task['root']}：{exc}", "error"))
                self.events.put(("log", traceback.format_exc(), "error"))
            report.record(index - 1, task.get("_output_dir"), safe_name(task["root"]), error)
            completed += 1
            self.events.put(("progress", completed, total))
            if self.stop_after_current.is_set():
                self.events.put(("log", "已按要求停止后续任务。", "info"))
                break
        report.message = f"本轮处理 {completed}/{total} 项，成功 {completed-failed} 项，失败 {failed} 项。"
        self.events.put(("worker_done", completed, total, failed))

    def _preflight_mmd_tools(self, settings: dict):
        check_dir = Path(settings.get("batch_folder", CONFIG_DIR))
        report_path = check_dir / "mmd_tools_preflight.json"
        log_path = check_dir / "mmd_tools_preflight.log"
        command = [
            settings["blender"],
            "--background",
            "--disable-autoexec",
            "--python-exit-code", "1",
            "--python", str(MMD_TOOLS_CHECKER),
            "--",
            "--report", str(report_path),
        ]
        self.events.put(("log", "[环境检查] 正在确认 Blender 已加载 MMD Tools 原生导出器…", "info"))
        self._run_logged(command, log_path, APP, "MMD Tools 环境检查")
        report = read_json(report_path, {})
        if not isinstance(report, dict) or report.get("status") != "passed":
            details = report.get("error", "没有取得有效的 MMD Tools 检查报告。") if isinstance(report, dict) else "检查报告格式无效。"
            raise StageConversionError(f"MMD Tools 环境检查未通过：{details}")
        self.events.put((
            "log",
            "MMD Tools 已就绪：{} {}".format(
                report.get("mmd_tools_package", "unknown"),
                report.get("mmd_tools_version", "unknown"),
            ),
            "success",
        ))

    def _run_logged(self, command: list[str], log_path: Path, cwd: Path, title: str):
        log_path.parent.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        self.events.put(("log", f"\n[{title}] 启动：{subprocess.list2cmdline(command)}", "info"))
        with log_path.open("w", encoding="utf-8", errors="replace", newline="\n") as log:
            log.write("COMMAND:\n" + subprocess.list2cmdline(command) + "\n\n")
            log.flush()
            proc = subprocess.Popen(
                command,
                cwd=str(cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                log.write(line)
                log.flush()
                self.events.put(("log", line.rstrip("\r\n"), "normal"))
            return_code = proc.wait()
        self.events.put(("log", f"[{title}] 退出代码：{return_code}；日志：{log_path}",
                         "success" if return_code == 0 else "error"))
        if return_code != 0:
            raise StageConversionError(f"{title}失败（退出代码 {return_code}），详见日志：{log_path}")
        return return_code

    def _write_partial_quality_report(self, task: dict):
        """Write a partial quality report if conversion failed after its output folder was created."""
        output_text = str(task.get("_output_dir", "")).strip()
        if not output_text:
            return
        out_dir = Path(output_text)
        if not out_dir.is_dir():
            return
        project = str(task.get("project", "")).strip()
        root_name = str(task.get("root", "")).strip()
        if not project or not root_name:
            return
        quality_json = out_dir / f"{safe_name(root_name)}_quality_report.json"
        quality_text = out_dir / f"{safe_name(root_name)}_quality_report.txt"
        try:
            quality_spec = importlib.util.spec_from_file_location(
                "scsp_quality_check_failed_runtime", QUALITY_CHECKER
            )
            if quality_spec is None or quality_spec.loader is None:
                raise RuntimeError("无法加载 V2.4.9 质量检查模块。")
            quality_module = importlib.util.module_from_spec(quality_spec)
            quality_spec.loader.exec_module(quality_module)
            quality = quality_module.run_quality_check(
                out_dir / f"{safe_name(root_name)}_source_validation.json",
                out_dir / f"{safe_name(root_name)}_rebuild_report.json",
                out_dir / f"{safe_name(root_name)}_mmd_tools_report.json",
                out_dir / f"{safe_name(root_name)}.pmx",
                project, task.get("scene", ""), root_name, quality_json, quality_text,
            )
            summary = quality.get("summary", {})
            self.events.put((
                "task_quality", task["id"], summary.get("status", "FAIL"),
                str(quality_json), str(quality_text),
            ))
            self.events.put((
                "log",
                "[V2.4.9 部分质量报告] 已为失败舞台生成报告：{}（失败 {} 项，警告 {} 项）".format(
                    quality_json, summary.get("failures", 0), summary.get("warnings", 0)
                ),
                "info",
            ))
        except Exception as quality_exc:
            self.events.put(("log", f"[V2.4.9 部分质量报告失败] {quality_exc}", "error"))

    def _convert_one(self, task: dict, settings: dict) -> Path:
        project_text = str(task.get("project", "")).strip() or str(settings.get("project", "")).strip()
        if not project_text:
            raise StageConversionError("任务没有记录对应的 AssetRipper scene-project 路径。")
        project = Path(project_text).expanduser().resolve()
        blender = Path(settings["blender"]).expanduser().resolve()
        output_root = settings["output"]
        if output_root:
            output_root_path = Path(output_root).expanduser().resolve()
        else:
            output_root_path = project / "PMX_Output_GUI"

        scene_rel = task["scene"].replace("/", os.sep)
        scene_abs = (project / scene_rel).resolve()
        if not scene_abs.is_file() or scene_abs.suffix.lower() != ".unity":
            raise StageConversionError(f"Unity 场景文件不存在：{scene_abs}")
        try:
            scene_abs.relative_to(project)
        except ValueError:
            raise StageConversionError("Unity 场景必须位于 scene-project 根目录内部。")

        root_name = task["root"].strip()
        if not root_name:
            raise StageConversionError("舞台根 GameObject 名称为空。")

        source_label = str(task.get("source_folder", "")).strip()
        stage_label = stage_output_name(source_label, scene_abs.stem, root_name,
                                        mme_preview=settings.get("auto_restore") and settings.get("mme_preview"))
        out_dir = unique_dir(output_root_path, stage_label)
        task["_output_dir"] = str(out_dir)
        self.events.put(("task_output", task["id"], str(out_dir)))

        validation_json = out_dir / f"{safe_name(root_name)}_source_validation.json"
        validation_log = out_dir / f"{safe_name(root_name)}_source_validation.log"
        blend_path = out_dir / f"{safe_name(root_name)}_rebuilt.blend"
        rebuild_report = out_dir / f"{safe_name(root_name)}_rebuild_report.json"
        rebuild_log = out_dir / f"{safe_name(root_name)}_rebuild.log"
        pmx_path = out_dir / f"{safe_name(root_name)}.pmx"
        pmx_report = out_dir / f"{safe_name(root_name)}_mmd_tools_report.json"
        pmx_log = out_dir / f"{safe_name(root_name)}_mmd_tools_export.log"

        self.events.put(("log", "[1/3] 验证 Unity 场景和 Mesh 资源…", "info"))
        validate_cmd = [
            sys.executable, str(VALIDATOR),
            "--project", str(project),
            "--scene", task["scene"],
            "--root", root_name,
            "--out", str(validation_json),
        ]
        self._run_logged(validate_cmd, validation_log, project, "Unity 资源验证")
        validation = read_json(validation_json, {})
        if not validation or not validation.get("ok"):
            raise StageConversionError(f"Unity 资源验证报告未通过：{validation_json}")

        self.events.put(("log", "[2/3] Blender 后台重建舞台…", "info"))
        rebuild_cmd = [
            str(blender),
            "--background", "--factory-startup", "--disable-autoexec",
            "--python-exit-code", "1",
            "--python", str(REBUILDER), "--",
            "--project", str(project),
            "--scene", task["scene"],
            "--root", root_name,
            "--out", str(blend_path),
            "--include-inactive" if settings["include_inactive"] else "--exclude-inactive",
            "--report", str(rebuild_report),
        ]
        self._run_logged(rebuild_cmd, rebuild_log, project, "Blender 舞台重建")
        if not blend_path.is_file() or blend_path.stat().st_size == 0:
            raise StageConversionError(f"没有生成有效 BLEND：{blend_path}")
        rebuild_data = read_json(rebuild_report, {})
        stats = rebuild_data.get("stats", {}) if isinstance(rebuild_data, dict) else {}
        if not stats or int(stats.get("meshObjects", 0)) <= 0:
            raise StageConversionError(f"重建报告没有有效 Mesh：{rebuild_report}")

        self.events.put(("log", "[3/3] 使用 MMD Tools 原生写入器导出完整 PMX…", "info"))
        native_internal_log = out_dir / f"{safe_name(root_name)}_native_export_internal.log"
        export_cmd = [
            str(blender),
            "--background",
            "--disable-autoexec",
            str(blend_path),
            "--python-exit-code", "1",
            "--python", str(PMX_EXPORTER), "--",
            "--input", str(blend_path),
            "--output", str(pmx_path),
            "--name", root_name,
            "--scale", str(settings["scale"]),
            "--report", str(pmx_report),
            "--log", str(native_internal_log),
        ]
        # Intentionally do NOT use --factory-startup here: MMD Tools is loaded
        # from the selected Blender user's saved extension/add-on preferences.
        self._run_logged(export_cmd, pmx_log, project, "MMD Tools 原生 PMX 导出")
        pmx_data = read_json(pmx_report, {})
        texture_validation = pmx_data.get("texture_validation", {}) if isinstance(pmx_data, dict) else {}
        parser_check = pmx_data.get("mmd_tools_parser_check", {}) if isinstance(pmx_data, dict) else {}
        if (
            not pmx_path.is_file() or pmx_path.stat().st_size == 0
            or not isinstance(pmx_data, dict)
            or pmx_data.get("status") != "completed"
            or parser_check.get("status") != "PASSED"
            or texture_validation.get("status") != "PASSED"
            or int(texture_validation.get("unresolved_count", 1)) != 0
        ):
            raise StageConversionError(
                "原生 PMX 或贴图完整性检查未通过；请检查报告：{}".format(pmx_report)
            )

        self.events.put(("log", f"资源验证报告：{validation_json}", "normal"))
        self.events.put(("log", f"Blender 重建报告：{rebuild_report}", "normal"))
        self.events.put(("log", f"MMD Tools 原生导出报告：{pmx_report}", "normal"))
        texture_before = pmx_data.get("texture_validation_before_rewrite", {})
        path_rewrite = pmx_data.get("texture_path_rewrite", {})
        self.events.put((
            "log",
            "贴图检查通过：{} / {} 个引用已解析；绝对路径规范化 {} 项；"
            "文件名别名补齐 {} 项；PMX 贴图表改写 {} 项。".format(
                texture_validation.get("resolved_count", 0),
                texture_validation.get("reference_count", 0),
                texture_before.get("normalized_absolute_count", 0),
                texture_before.get("alias_count", 0),
                path_rewrite.get("rewritten_count", 0),
            ),
            "success",
        ))

        # V2.4.9 quality inspection is read-only and runs only after the existing
        # V2.3.2 conversion/export gates have succeeded. A checker problem must
        # never turn a valid PMX conversion into a failed batch task.
        quality_json = out_dir / f"{safe_name(root_name)}_quality_report.json"
        quality_text = out_dir / f"{safe_name(root_name)}_quality_report.txt"
        self.events.put(("log", "[V2.4.9] 正在执行静态舞台质量检查、Mesh 完整资源身份清单与对象引用追踪…", "info"))
        try:
            quality_spec = importlib.util.spec_from_file_location(
                "scsp_quality_check_runtime", QUALITY_CHECKER
            )
            if quality_spec is None or quality_spec.loader is None:
                raise RuntimeError("无法加载 V2.4.9 质量检查模块。")
            quality_module = importlib.util.module_from_spec(quality_spec)
            quality_spec.loader.exec_module(quality_module)
            quality = quality_module.run_quality_check(
                validation_json, rebuild_report, pmx_report, pmx_path,
                project, task["scene"], root_name, quality_json, quality_text,
            )
            quality_status = quality.get("summary", {}).get("status", "UNKNOWN")
            quality_summary = quality.get("summary", {})
            self.events.put((
                "task_quality", task["id"], quality_status,
                str(quality_json), str(quality_text),
            ))
            log_tag = "success" if quality_status == "PASS" else (
                "error" if quality_status == "FAIL" else "info"
            )
            self.events.put((
                "log",
                "[V2.4.9 质量检查] {}：通过 {} 项，警告 {} 项，失败 {} 项。报告：{}".format(
                    quality_status, quality_summary.get("passed", 0),
                    quality_summary.get("warnings", 0),
                    quality_summary.get("failures", 0), quality_json,
                ),
                log_tag,
            ))
        except Exception as quality_exc:
            self.events.put(("task_quality", task["id"], "检查异常", str(quality_json), str(quality_text)))
            self.events.put((
                "log",
                "[V2.4.9 质量检查异常] 不影响已生成 PMX；{}：{}".format(quality_json, quality_exc),
                "error",
            ))
            self.events.put(("log", traceback.format_exc(), "error"))
        return out_dir

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "log":
                    self._log(event[1], event[2] if len(event) > 2 else "normal")
                elif kind == "screen_video_done":
                    self._log(f"屏幕视频效果包已生成 {event[1]}", "info")
                    messagebox.showinfo("屏幕视频效果包已生成",event[1],parent=self.root)
                elif kind == "screen_video_error":
                    self._log(f"屏幕视频导入失败 {event[1]}", "error")
                    messagebox.showerror("屏幕视频导入失败",event[1],parent=self.root)
                elif kind == "status":
                    self.status_var.set(event[1])
                elif kind == "task_status":
                    self._set_task_status(event[1], event[2], event[3])
                elif kind == "task_output":
                    task = next((t for t in self.tasks if t["id"] == event[1]), None)
                    if task:
                        task["output"] = event[2]
                        if self.tree.exists(event[1]):
                            self.tree.set(event[1], "output", event[2])
                elif kind == "task_quality":
                    task = next((t for t in self.tasks if t["id"] == event[1]), None)
                    if task:
                        task["quality_status"] = event[2]
                        task["quality_report"] = event[3]
                        task["quality_report_text"] = event[4]
                        values = self._row_values(task)
                        if self.tree.exists(task["id"]):
                            self.tree.item(task["id"], values=values)
                        self._save_tasks()
                elif kind == "progress":
                    self.progress.configure(maximum=max(1, event[2]))
                    self.progress_var.set(event[1])
                elif kind == "batch_report":
                    self.last_report = event[1]
                    self._log(f"批量报告：{self.last_report}", "info")
                elif kind == "batch_error":
                    self.status_var.set("批次中断，详见日志")
                    self._log(event[1], "error")
                elif kind == "worker_finished":
                    self.is_running = False
                    self._set_running_controls(False)
                    self._save_tasks()
                    self._save_settings()
                elif kind == "worker_done":
                    completed, total, failed = event[1], event[2], event[3]
                    self.status_var.set(
                        f"本轮结束：处理 {completed}/{total} 个，失败 {failed} 个。"
                    )
                    self._log(
                        f"\n本轮结束：处理 {completed}/{total} 个，失败 {failed} 个。"
                        "PMX 仍需在 MMD 9.32 中逐个验收。",
                        "success" if failed == 0 else "error"
                    )
                    self._save_tasks()
                    self._save_settings()
        except queue.Empty:
            pass
        self.root.after(100, self._poll_events)

    def _log(self, message: str, tag: str = "normal"):
        stamp = time.strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{stamp}] {message}\n", tag)
        self.log_text.see("end")

    def _on_close(self):
        if self.is_running:
            if messagebox.askyesno(
                "转换正在进行",
                "当前舞台不会被强制中断。是否请求当前舞台完成后停止？\n\n"
                "请等待任务结束后再关闭窗口。"
            ):
                self._request_stop()
            return
        self._save_settings()
        self._save_tasks()
        self.root.destroy()


def main():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    missing = [p for p in (VALIDATOR, REBUILDER, PMX_EXPORTER, MMD_TOOLS_CHECKER) if not p.is_file()]
    if missing:
        print("缺少转换核心文件：")
        for path in missing:
            print(" -", path)
        input("按回车退出…")
        return 2
    root = tk.Tk()
    StageConverterGUI(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
