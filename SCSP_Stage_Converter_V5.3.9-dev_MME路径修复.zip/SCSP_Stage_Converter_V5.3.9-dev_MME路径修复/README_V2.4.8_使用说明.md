# SCSP Stage Converter V2.4.8-dev 使用说明

## 本版做什么

V2.4.8 在 V2.4.7 的质量报告和 Mesh 完整身份清单上，新增 **WARNING 精准定位**。它不是新的转换流程，不需要重新转换舞台。

## 推荐用法（主 GUI）

1. 双击 `RUN_GUI.bat`。
2. 点击「WARNING 精准定位…」。
3. 选择勾选 inactive GameObject 时生成的 Include 质量报告 JSON。
4. 选择取消勾选 inactive GameObject 时生成的 Exclude 质量报告 JSON。
5. 选择诊断 JSON 的保存位置。
6. 程序自动生成同名 TXT；可选择立即打开 TXT。

## 独立用法

双击 `RUN_WARNING_DIAGNOSTICS.bat`，操作相同。该入口只启动 WARNING 诊断窗口，不启动 Unity / Blender 转换。

## 当前已支持的精确定位

### SRC-005 法线覆盖率

列出纳入转换范围内所有缺少法线的唯一 Mesh：Mesh 名称、GUID/fileID、Assets 路径、顶点数、UV0 状态、法线证据分类、GameObject fileID、MeshFilter component fileID、完整 Hierarchy、材质和 MainTex 线索。

### BLD-004 inactive 对象排除

列出被排除的 inactive GameObject 清单，并通过完整 Mesh Inventory 关联 Excluded-only Mesh、GUID/fileID、MeshFilter component fileID、Hierarchy、材质和 MainTex。

### 跨模式比较

按 Mesh GUID + fileID 对比 SRC-005 缺法线清单，报告共有、Include 独有和 Exclude 独有项目。

## 诊断状态说明

- `COMPLETE`：本次出现的所有 WARNING 类型均有完整、可核对的证据映射。
- `PARTIAL`：至少有一种 WARNING 尚无可靠对象映射；原始 details 会保留，不会猜测。

`COMPLETE` 不表示 WARNING 消失。SRC-005 仍然是源数据缺法线提示；BLD-004 是 inactive 转换范围提示。它们都不会自动修复。

## 安全边界

- 只读取两份已有 JSON 质量报告。
- 不重新转换、不打开 Unity / Blender、不读写 PMX / BLEND / 贴图。
- 不修改 V2.3.2-dev 回退基线、V2.4.7 转换核心或 inactive 策略。
- UV0 缺失如果在源报告中是 INFO，不会被错误计入 WARNING。

## 输出

- `<舞台名>_warning_diagnostics.json`
- `<舞台名>_warning_diagnostics.txt`
