# -*- coding: utf-8 -*-
"""SCSP Stage Converter V2.4.10-dev: read-only Mesh normal / inactive association diagnostics.

Reads supported V2.4.7-dev / V2.4.9-dev quality JSON reports only. It does not open Unity,
Blender or PMX files and never changes conversion outputs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPORT_SCHEMA = "scsp-warning-diagnostics-v2"
SUPPORTED_QUALITY_SCHEMA = "scsp-stage-quality-report-v1"
SUPPORTED_MESH_SCHEMA = "scsp-mesh-channel-diagnostics-v6"


class DiagnosticError(ValueError):
    """Invalid or incompatible quality report input."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8-sig") as stream:
            value = json.load(stream)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise DiagnosticError(f"无法读取质量报告：{path}（{exc}）") from exc
    if not isinstance(value, dict):
        raise DiagnosticError(f"质量报告必须是 JSON 对象：{path}")
    return value


def _dict(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> list:
    return value if isinstance(value, list) else []


def _identity(row: dict) -> tuple[str, str] | None:
    guid = str(row.get("meshGUID") or "").lower()
    file_id = str(row.get("meshFileID") or "")
    if re.fullmatch(r"[0-9a-f]{32}", guid) and file_id not in ("", "0"):
        return guid, file_id
    return None


def _stage_key(report: dict) -> tuple[str, str, str]:
    stage = _dict(report.get("stage"))
    return tuple(str(stage.get(k) or "").replace("\\", "/").rstrip("/").casefold()
                 for k in ("root", "scene", "project"))


def _validate(report: dict, label: str, expected_policy: str) -> None:
    if report.get("schema") != SUPPORTED_QUALITY_SCHEMA:
        raise DiagnosticError(f"{label} 不是受支持的 SCSP 质量报告。")
    if report.get("version") not in ("2.4.7-dev", "2.4.9-dev"):
        raise DiagnosticError(f"{label} 不是受支持的 V2.4.7-dev / V2.4.9-dev 质量报告（version={report.get('version')!r}）。")
    stage = _dict(report.get("stage"))
    if not all(stage.get(k) for k in ("root", "scene", "project")):
        raise DiagnosticError(f"{label} 缺少舞台 root / scene / project 标识。")
    objects = _dict(report.get("objects"))
    mesh = _dict(report.get("meshDiagnostics"))
    if objects.get("inactivePolicy") != expected_policy:
        raise DiagnosticError(f"{label} 应为 inactivePolicy={expected_policy}。")
    if mesh.get("conversionPolicy") != expected_policy:
        raise DiagnosticError(f"{label} 的 Mesh conversionPolicy 与预期不一致。")
    if mesh.get("schema") != SUPPORTED_MESH_SCHEMA:
        raise DiagnosticError(f"{label} 缺少 {SUPPORTED_MESH_SCHEMA} Mesh 诊断数据。")
    if not isinstance(mesh.get("meshInventory"), list):
        raise DiagnosticError(f"{label} 缺少完整 meshInventory 清单。")
    if not isinstance(report.get("checks"), list):
        raise DiagnosticError(f"{label} 缺少 checks 检查清单。")


def _mesh_row_for_warning(row: dict) -> dict:
    """Keep the full source evidence needed to manually locate an affected Mesh."""
    return {
        "meshName": row.get("meshName"),
        "meshGUID": row.get("meshGUID"),
        "meshFileID": row.get("meshFileID"),
        "assetPath": row.get("assetPath"),
        "builtin": row.get("builtin"),
        "vertexCount": row.get("vertexCount"),
        "hasNormals": row.get("hasNormals"),
        "hasUV0": row.get("hasUV0"),
        "decodeStatus": row.get("decodeStatus"),
        "normalEvidence": row.get("normalEvidence"),
        "normalEvidenceNote": row.get("normalEvidenceNote"),
        "scope": row.get("scope"),
        "conversionIncluded": row.get("conversionIncluded"),
        "occurrenceCount": row.get("occurrenceCount"),
        "uniqueGameObjectCount": row.get("uniqueGameObjectCount"),
        "gameObjects": _list(row.get("gameObjects")),
    }


def _warning_rows(report: dict) -> list[dict]:
    return [c for c in _list(report.get("checks"))
            if isinstance(c, dict) and str(c.get("status", "")).upper() in ("WARNING", "FAIL")]


def _diagnose_normal_warning(report: dict, check: dict) -> dict:
    mesh_diag = _dict(report.get("meshDiagnostics"))
    rows = mesh_diag.get("conversionMissingNormals")
    if not isinstance(rows, list):
        rows = [r for r in _list(mesh_diag.get("missingNormals"))
                if isinstance(r, dict) and r.get("conversionIncluded") is True]
    affected = [_mesh_row_for_warning(r) for r in rows if isinstance(r, dict)]
    expected = _dict(check.get("details")).get("missingMeshCount")
    valid_ids = sum(1 for row in affected if _identity(row))
    object_occurrences = sum(len(row["gameObjects"]) for row in affected)
    evidence = {}
    for row in rows:
        key = str(_dict(row).get("normalEvidence") or "UNKNOWN")
        evidence[key] = evidence.get(key, 0) + 1
    inventory_rows = [r for r in _list(mesh_diag.get("meshInventory")) if isinstance(r, dict)]
    inventory_by_id = {_identity(r): r for r in inventory_rows if _identity(r)}
    inventory_summary = _dict(mesh_diag.get("meshInventorySummary"))
    inventory_crosscheck = all(
        _identity(row) in inventory_by_id
        and inventory_by_id[_identity(row)].get("hasNormals") is False
        and inventory_by_id[_identity(row)].get("conversionIncluded") is True
        for row in affected if _identity(row) is not None
    )
    complete = (
        isinstance(expected, int) and len(affected) == expected
        and valid_ids == len(affected)
        and all(row.get("decodeStatus") == "decoded" for row in affected)
        and inventory_summary.get("complete") is True
        and inventory_summary.get("identityComplete") is True
        and inventory_crosscheck
    )
    return {
        "mappingType": "meshInventory.conversionMissingNormals",
        "mappingComplete": complete,
        "expectedMeshCount": expected,
        "locatedMeshCount": len(affected),
        "identifiedMeshCount": valid_ids,
        "unidentifiedMeshCount": len(affected) - valid_ids,
        "gameObjectOccurrenceCount": object_occurrences,
        "inventoryCrosscheckPassed": inventory_crosscheck,
        "evidenceCounts": evidence,
        "affectedMeshes": affected,
        "interpretation": "定位到源 Mesh 缺少法线数据；这是数据通道诊断，不等同于已证明 MMD 中必然出现视觉错误。",
    }


def _inactive_state_fields(item: dict) -> dict:
    """Return a consistent effective state with explicit provenance.

    Older V2.4.7/V2.4.8 quality reports omitted activeInHierarchy from the
    inactiveInHierarchyObjects summary rows. Membership in that source list is
    itself evidence that the effective hierarchy state is false. Mark this as
    inferred rather than presenting it as a source field.
    """
    value = item.get("activeInHierarchy")
    if isinstance(value, bool):
        return {
            "activeInHierarchy": value,
            "activeInHierarchySource": item.get(
                "activeInHierarchySource", "quality_report.objects.inactiveInHierarchyObjects"
            ),
            "activeInHierarchyInferred": bool(item.get("activeInHierarchyInferred", False)),
        }
    return {
        "activeInHierarchy": False,
        "activeInHierarchySource": "inferred_from_inactiveInHierarchyObjects_membership",
        "activeInHierarchyInferred": True,
    }


def _is_same_or_descendant_path(candidate: str, ancestor: str) -> bool:
    candidate = str(candidate or "").replace("\\", "/").rstrip("/")
    ancestor = str(ancestor or "").replace("\\", "/").rstrip("/")
    return bool(candidate and ancestor and (candidate == ancestor or candidate.startswith(ancestor + "/")))


def _inactive_hierarchy_summary(report: dict) -> dict:
    """Group inactive GameObjects under top-most inactive roots and count Mesh impact."""
    objects = _dict(report.get("objects"))
    mesh_diag = _dict(report.get("meshDiagnostics"))
    raw_rows = [r for r in _list(objects.get("inactiveInHierarchyObjects")) if isinstance(r, dict)]
    inactive_rows = []
    state_conflicts = []
    for raw in raw_rows:
        state = _inactive_state_fields(raw)
        row = dict(raw)
        row.update(state)
        if row["activeInHierarchy"] is True:
            state_conflicts.append({
                "gameObjectName": row.get("name"),
                "gameObjectFileID": row.get("gameObjectFileID"),
                "hierarchyPath": row.get("hierarchyPath"),
                "reason": "对象列在 inactiveInHierarchyObjects 中，但显式 activeInHierarchy=true",
            })
            continue
        inactive_rows.append(row)

    # A root is the first inactive object on a path below the selected stage root.
    # Descendant inactive objects are assigned to that top-most inactive ancestor.
    unique_paths = sorted(
        {str(r.get("hierarchyPath") or "").replace("\\", "/").rstrip("/")
         for r in inactive_rows if r.get("hierarchyPath")},
        key=lambda value: (value.count("/"), len(value), value.casefold()),
    )
    root_paths = []
    for path in unique_paths:
        if not any(_is_same_or_descendant_path(path, parent) and path != parent
                   for parent in root_paths):
            root_paths.append(path)

    roots_by_path = {}
    for path in root_paths:
        matching = [r for r in inactive_rows if str(r.get("hierarchyPath") or "").replace("\\", "/").rstrip("/") == path]
        if matching:
            roots_by_path[path] = matching[0]

    row_to_root = {}
    for row in inactive_rows:
        path = str(row.get("hierarchyPath") or "").replace("\\", "/").rstrip("/")
        candidates = [root for root in root_paths if _is_same_or_descendant_path(path, root)]
        if candidates:
            chosen = min(candidates, key=lambda value: (value.count("/"), len(value)))
            row_to_root[str(row.get("gameObjectFileID"))] = chosen

    root_data = {}
    for path, root_row in roots_by_path.items():
        subtree = [r for r in inactive_rows
                   if _is_same_or_descendant_path(str(r.get("hierarchyPath") or ""), path)]
        root_data[path] = {
            "rootGameObjectName": root_row.get("name"),
            "rootGameObjectFileID": root_row.get("gameObjectFileID"),
            "rootHierarchyPath": path,
            "activeSelf": root_row.get("activeSelf"),
            "rootInactiveReason": (
                "root_object_activeSelf_false" if root_row.get("activeSelf") is False
                else "inactive_due_to_ancestor_outside_selected_subtree"
            ),
            **_inactive_state_fields(root_row),
            "conversionIncluded": root_row.get("conversionIncluded"),
            "conversionDecision": root_row.get("conversionDecision"),
            "inactiveCause": root_row.get("hierarchyInactiveCause") or root_row.get("conversionBlockingInactiveObject"),
            "affectedGameObjectCount": len(subtree),
            "affectedGameObjects": [{
                "gameObjectName": r.get("name"),
                "gameObjectFileID": r.get("gameObjectFileID"),
                "hierarchyPath": r.get("hierarchyPath"),
                "activeSelf": r.get("activeSelf"),
                **_inactive_state_fields(r),
                "conversionIncluded": r.get("conversionIncluded"),
                "conversionDecision": r.get("conversionDecision"),
            } for r in subtree],
            "_meshRows": {},
            "_meshBearingGameObjectIDs": set(),
            "_meshFilterComponentIDs": set(),
            "_scopeMeshIDs": {"included": set(), "excludedOnly": set(), "shared": set(), "unknown": set()},
        }

    inventory = [r for r in _list(mesh_diag.get("meshInventory")) if isinstance(r, dict)]
    all_root_mesh_ids = set()
    all_root_component_ids = set()
    all_root_mesh_gameobject_ids = set()
    unidentified_root_mesh_keys = set()
    for mesh in inventory:
        identity = _identity(mesh)
        mesh_key = identity if identity is not None else (
            "unidentified", str(mesh.get("assetPath") or ""), str(mesh.get("meshName") or "")
        )
        scope = str(mesh.get("scope") or "unknown")
        if scope not in ("included", "excludedOnly", "shared"):
            scope = "unknown"
        for go in _list(mesh.get("gameObjects")):
            if not isinstance(go, dict):
                continue
            go_id = str(go.get("gameObjectFileID"))
            root_path = row_to_root.get(go_id)
            if root_path is None:
                go_path = str(go.get("hierarchyPath") or "").replace("\\", "/").rstrip("/")
                candidates = [root for root in root_paths if _is_same_or_descendant_path(go_path, root)]
                if candidates:
                    root_path = min(candidates, key=lambda value: (value.count("/"), len(value)))
            if root_path not in root_data:
                continue
            root = root_data[root_path]
            if identity is None:
                unidentified_root_mesh_keys.add(mesh_key)
            mesh_entry = root["_meshRows"].setdefault(mesh_key, {
                "meshName": mesh.get("meshName"),
                "meshGUID": mesh.get("meshGUID"),
                "meshFileID": mesh.get("meshFileID"),
                "assetPath": mesh.get("assetPath"),
                "scope": scope,
                "gameObjects": {},
            })
            go_entry = mesh_entry["gameObjects"].setdefault(go_id, {
                "gameObjectName": go.get("gameObjectName"),
                "gameObjectFileID": go.get("gameObjectFileID"),
                "hierarchyPath": go.get("hierarchyPath"),
                "meshFilterComponentFileIDs": set(),
                "meshFilterComponentsFallback": 0,
            })
            component_ids = _list(go.get("meshFilterComponentFileIDs"))
            go_entry["meshFilterComponentFileIDs"].update(str(v) for v in component_ids)
            if not component_ids:
                go_entry["meshFilterComponentsFallback"] = max(
                    go_entry["meshFilterComponentsFallback"], int(go.get("meshFilterComponents") or 0)
                )
            root["_meshBearingGameObjectIDs"].add(go_id)
            all_root_mesh_gameobject_ids.add(go_id)
            for component_id in component_ids:
                component_key = (go_id, str(component_id))
                root["_meshFilterComponentIDs"].add(component_key)
                all_root_component_ids.add(component_key)
            root["_scopeMeshIDs"][scope].add(mesh_key)
            all_root_mesh_ids.add(mesh_key)

    root_summaries = []
    for path in root_paths:
        root = root_data.get(path)
        if root is None:
            continue
        mesh_rows = []
        component_count = len(root["_meshFilterComponentIDs"])
        fallback_component_count = 0
        for mesh in root["_meshRows"].values():
            go_rows = []
            for go in mesh["gameObjects"].values():
                component_ids = sorted(go["meshFilterComponentFileIDs"])
                fallback_component_count += go["meshFilterComponentsFallback"]
                go_rows.append({
                    "gameObjectName": go["gameObjectName"],
                    "gameObjectFileID": go["gameObjectFileID"],
                    "hierarchyPath": go["hierarchyPath"],
                    "meshFilterComponentFileIDs": component_ids,
                    "meshFilterComponentCount": len(component_ids) or go["meshFilterComponentsFallback"],
                })
            mesh_rows.append({
                "meshName": mesh["meshName"],
                "meshGUID": mesh["meshGUID"],
                "meshFileID": mesh["meshFileID"],
                "assetPath": mesh["assetPath"],
                "scope": mesh["scope"],
                "gameObjects": go_rows,
            })
        mesh_rows.sort(key=lambda row: (str(row.get("meshName") or "").casefold(), str(row.get("meshGUID") or ""), str(row.get("meshFileID") or "")))
        root_summaries.append({
            key: value for key, value in root.items() if not key.startswith("_")
        } | {
            "meshBearingGameObjectCount": len(root["_meshBearingGameObjectIDs"]),
            "affectedMeshFilterComponentCount": component_count + fallback_component_count,
            "affectedUniqueMeshCount": len(root["_meshRows"]),
            "uniqueMeshCountByScope": {
                scope: len(values) for scope, values in root["_scopeMeshIDs"].items()
            },
            "unidentifiedMeshCount": sum(1 for row in mesh_rows if not _identity(row)),
            "meshes": mesh_rows,
        })

    root_summaries.sort(key=lambda row: (-row["affectedUniqueMeshCount"], -row["affectedGameObjectCount"], str(row.get("rootHierarchyPath") or "").casefold()))
    total_inactive_ids = {str(r.get("gameObjectFileID")) for r in inactive_rows}
    assigned_inactive_ids = set(row_to_root)
    scope_union = {
        scope: len(set().union(*(root["_scopeMeshIDs"][scope] for root in root_data.values())) if root_data else set())
        for scope in ("included", "excludedOnly", "shared", "unknown")
    }
    return {
        "mappingType": "inactiveInHierarchyObjects grouped by top-most inactive hierarchy ancestor + meshInventory GameObject references",
        "inactiveGameObjectCount": len(inactive_rows),
        "inactiveRootObjectCount": len(root_summaries),
        "meshBearingGameObjectCount": len(all_root_mesh_gameobject_ids),
        "affectedMeshFilterComponentCount": len(all_root_component_ids),
        "affectedUniqueMeshCount": len(all_root_mesh_ids),
        "uniqueMeshCountByScope": scope_union,
        "unidentifiedMeshCount": len(unidentified_root_mesh_keys),
        "assignedInactiveGameObjectCount": len(assigned_inactive_ids),
        "unassignedInactiveGameObjectCount": len(total_inactive_ids - assigned_inactive_ids),
        "stateConflictCount": len(state_conflicts),
        "stateConflicts": state_conflicts,
        "groupingComplete": (
            len(assigned_inactive_ids) == len(total_inactive_ids)
            and not state_conflicts
            and not unidentified_root_mesh_keys
        ),
        "rootObjects": root_summaries,
        "interpretation": "根对象是所选舞台层级中路径上最先出现的 inactive GameObject；Mesh 按 GUID + fileID 去重。旧报告缺少 activeInHierarchy 字段时，依据 inactiveInHierarchyObjects 清单成员身份推导为 false，并明确标记 inferred。",
    }


def _diagnose_inactive_warning(report: dict, check: dict, hierarchy_summary: dict | None = None) -> dict:
    objects = _dict(report.get("objects"))
    mesh_diag = _dict(report.get("meshDiagnostics"))
    inactive_rows = [r for r in _list(objects.get("inactiveInHierarchyObjects"))
                     if isinstance(r, dict) and r.get("conversionIncluded") is False]
    inventory = [r for r in _list(mesh_diag.get("meshInventory"))
                 if isinstance(r, dict) and r.get("scope") == "excludedOnly"]
    go_by_id = {}
    for row in inventory:
        for go in _list(row.get("gameObjects")):
            if isinstance(go, dict) and go.get("gameObjectFileID") is not None:
                go_by_id.setdefault(str(go.get("gameObjectFileID")), []).append(row)
    affected_objects = []
    for item in inactive_rows:
        go_id = str(item.get("gameObjectFileID", ""))
        linked = go_by_id.get(go_id, [])
        affected_objects.append({
            "gameObjectName": item.get("name"),
            "gameObjectFileID": item.get("gameObjectFileID"),
            "hierarchyPath": item.get("hierarchyPath"),
            "activeSelf": item.get("activeSelf"),
            **_inactive_state_fields(item),
            "activeWithinSelectedRoot": item.get("activeWithinSelectedRoot"),
            "conversionIncluded": item.get("conversionIncluded"),
            "conversionDecision": item.get("conversionDecision"),
            "hierarchyInactiveCause": item.get("hierarchyInactiveCause"),
            "meshCount": len(linked),
            "meshes": [{
                "meshName": row.get("meshName"),
                "meshGUID": row.get("meshGUID"),
                "meshFileID": row.get("meshFileID"),
                "assetPath": row.get("assetPath"),
            } for row in linked],
        })
    mesh_records = [_mesh_row_for_warning(row) for row in inventory]
    expected_go = _dict(check.get("details")).get("skippedInactiveGameObjects")
    expected_mesh_filters = _dict(check.get("details")).get("skippedInactiveMeshFilters")
    mesh_filter_components = sum(
        sum(len(_list(go.get("meshFilterComponentFileIDs")))
            for go in _list(row.get("gameObjects")) if isinstance(go, dict))
        for row in inventory
    )
    identified = sum(1 for row in inventory if _identity(row))
    inventory_summary = _dict(mesh_diag.get("meshInventorySummary"))
    inventory_scope_counts = _dict(inventory_summary.get("scopeUniqueMeshReferences"))
    hierarchy_summary = hierarchy_summary or _inactive_hierarchy_summary(report)
    mapping_complete = (
        isinstance(expected_go, int) and len(affected_objects) == expected_go
        and isinstance(expected_mesh_filters, int) and mesh_filter_components == expected_mesh_filters
        and identified == len(inventory)
        and inventory_summary.get("complete") is True
        and inventory_summary.get("identityComplete") is True
        and inventory_summary.get("scopeCountsMatch") is True
        and inventory_scope_counts.get("excludedOnly") == len(inventory)
        and hierarchy_summary.get("groupingComplete") is True
    )
    return {
        "mappingType": "objects.inactiveInHierarchyObjects + meshDiagnostics.meshInventory(scope=excludedOnly) + topMostInactiveRootGrouping",
        "mappingComplete": mapping_complete,
        "expectedGameObjectCount": expected_go,
        "locatedGameObjectCount": len(affected_objects),
        "meshBearingGameObjectCount": sum(1 for row in affected_objects if row["meshCount"]),
        "expectedMeshFilterComponentCount": expected_mesh_filters,
        "locatedMeshFilterComponentCount": mesh_filter_components,
        "excludedOnlyUniqueMeshCount": len(mesh_records),
        "identifiedExcludedOnlyMeshCount": identified,
        "unidentifiedExcludedOnlyMeshCount": len(mesh_records) - identified,
        "inactiveRootObjectCount": hierarchy_summary.get("inactiveRootObjectCount"),
        "inactiveRootObjects": hierarchy_summary.get("rootObjects", []),
        "inactiveHierarchySummary": hierarchy_summary,
        "affectedGameObjects": affected_objects,
        "affectedMeshes": mesh_records,
        "interpretation": "这些对象因 inactive 层级策略未参与本次转换；该 WARNING 是范围提示，不代表转换器发生故障。inactive 根对象按所选舞台内最上层的 inactive 节点分组，Mesh 按 GUID + fileID 去重。",
    }


def _diagnose_generic_warning(report: dict, check: dict) -> dict:
    """Do not guess mappings for warning types without a proven source mapping."""
    return {
        "mappingType": "unmapped_check_details",
        "mappingComplete": False,
        "locatedMeshCount": 0,
        "locatedGameObjectCount": 0,
        "rawDetails": _dict(check.get("details")),
        "interpretation": "当前版本没有为此 WARNING 建立经过验证的对象/资源映射；保留原始 details，不猜测归属。",
    }


def _diagnose_report(report: dict, label: str, source_path: Path) -> dict:
    warnings = []
    hierarchy_summary = _inactive_hierarchy_summary(report)
    for check in _warning_rows(report):
        check_id = str(check.get("id") or "")
        if check_id == "SRC-005":
            mapping = _diagnose_normal_warning(report, check)
        elif check_id == "BLD-004":
            mapping = _diagnose_inactive_warning(report, check, hierarchy_summary)
        else:
            mapping = _diagnose_generic_warning(report, check)
        warnings.append({
            "checkId": check_id,
            "category": check.get("category"),
            "name": check.get("name"),
            "status": check.get("status"),
            "message": check.get("message"),
            "details": _dict(check.get("details")),
            "diagnosis": mapping,
        })
    summary = _dict(report.get("summary"))
    return {
        "mode": label,
        "inactivePolicy": _dict(report.get("objects")).get("inactivePolicy"),
        "generatedAt": report.get("generatedAt"),
        "qualitySummary": {
            "status": summary.get("status"),
            "passed": summary.get("passed"),
            "warnings": summary.get("warnings"),
            "failures": summary.get("failures"),
            "info": summary.get("info"),
            "totalChecks": summary.get("totalChecks"),
        },
        "inactiveHierarchySummary": hierarchy_summary,
        "warningCount": len(warnings),
        "fullyMappedWarningCount": sum(1 for w in warnings if w["diagnosis"].get("mappingComplete")),
        "unmappedWarningCount": sum(1 for w in warnings if not w["diagnosis"].get("mappingComplete")),
        "warnings": warnings,
        "input": {
            "fileName": source_path.name if source_path is not None else None,
            "path": str(source_path) if source_path is not None else None,
            "sha256": _sha256(source_path) if source_path is not None and source_path.is_file() else None,
        },
    }


def _warning_mesh_ids(mode_result: dict, check_id: str) -> set[tuple[str, str]]:
    for warning in mode_result.get("warnings", []):
        if warning.get("checkId") == check_id:
            return {identity for row in warning["diagnosis"].get("affectedMeshes", [])
                    if (identity := _identity(row)) is not None}
    return set()




def _inventory_by_identity(report: dict) -> dict[tuple[str, str], dict]:
    rows = [r for r in _list(_dict(report.get("meshDiagnostics")).get("meshInventory"))
            if isinstance(r, dict)]
    return {identity: row for row in rows if (identity := _identity(row)) is not None}


def _missing_normal_by_identity(report: dict) -> dict[tuple[str, str], dict]:
    mesh_diag = _dict(report.get("meshDiagnostics"))
    rows = mesh_diag.get("conversionMissingNormals")
    if not isinstance(rows, list):
        rows = [r for r in _list(mesh_diag.get("missingNormals"))
                if isinstance(r, dict) and r.get("conversionIncluded") is True]
    return {identity: row for row in rows if isinstance(row, dict)
            and (identity := _identity(row)) is not None}


def _inactive_rows_by_id(report: dict) -> dict[str, dict]:
    rows = _list(_dict(report.get("objects")).get("inactiveInHierarchyObjects"))
    return {
        str(row.get("gameObjectFileID")): row
        for row in rows if isinstance(row, dict) and row.get("gameObjectFileID") is not None
    }


def _root_for_occurrence(go: dict, hierarchy_summary: dict) -> dict | None:
    """Find the top-most inactive root associated with one Mesh/GameObject occurrence."""
    roots = [r for r in _list(hierarchy_summary.get("rootObjects")) if isinstance(r, dict)]
    if not roots:
        return None
    cause = _dict(go.get("hierarchyInactiveCause") or go.get("conversionBlockingInactiveObject"))
    cause_path = str(cause.get("hierarchyPath") or "").replace("\\", "/").rstrip("/")
    go_path = str(go.get("hierarchyPath") or "").replace("\\", "/").rstrip("/")
    candidates = []
    for root in roots:
        root_path = str(root.get("rootHierarchyPath") or "").replace("\\", "/").rstrip("/")
        if not root_path:
            continue
        if cause_path and _is_same_or_descendant_path(cause_path, root_path):
            candidates.append(root)
    if not candidates and go_path:
        for root in roots:
            root_path = str(root.get("rootHierarchyPath") or "").replace("\\", "/").rstrip("/")
            if root_path and _is_same_or_descendant_path(go_path, root_path):
                candidates.append(root)
    if not candidates:
        return None
    return min(
        candidates,
        key=lambda row: (
            str(row.get("rootHierarchyPath") or "").count("/"),
            len(str(row.get("rootHierarchyPath") or "")),
        ),
    )


def _resolve_occurrence_state(go: dict, inactive_by_id: dict[str, dict]) -> dict:
    """Resolve state with source provenance; never convert missing source data to raw state."""
    go_id = str(go.get("gameObjectFileID")) if go.get("gameObjectFileID") is not None else ""
    inactive_row = inactive_by_id.get(go_id)
    cause = _dict(go.get("hierarchyInactiveCause") or go.get("conversionBlockingInactiveObject"))
    value = go.get("activeInHierarchy")
    if isinstance(value, bool):
        return {
            "activeInHierarchy": value,
            "activeInHierarchySource": "quality_report.meshDiagnostics.meshInventory.gameObjects.activeInHierarchy",
            "activeInHierarchyInferred": False,
            "stateEvidence": "source_field",
            "inactiveListMember": inactive_row is not None,
            "stateConflict": bool(value is True and (inactive_row is not None or cause)),
        }
    if inactive_row is not None:
        inactive_value = inactive_row.get("activeInHierarchy")
        if isinstance(inactive_value, bool):
            return {
                "activeInHierarchy": inactive_value,
                "activeInHierarchySource": "quality_report.objects.inactiveInHierarchyObjects.activeInHierarchy",
                "activeInHierarchyInferred": False,
                "stateEvidence": "source_field",
                "inactiveListMember": True,
                "stateConflict": inactive_value is True,
            }
        return {
            "activeInHierarchy": False,
            "activeInHierarchySource": "inferred_from_inactiveInHierarchyObjects_membership",
            "activeInHierarchyInferred": True,
            "stateEvidence": "inactive_list_membership",
            "inactiveListMember": True,
            "stateConflict": False,
        }
    if cause:
        return {
            "activeInHierarchy": False,
            "activeInHierarchySource": "inferred_from_hierarchyInactiveCause",
            "activeInHierarchyInferred": True,
            "stateEvidence": "inactive_cause",
            "inactiveListMember": False,
            "stateConflict": False,
        }
    return {
        "activeInHierarchy": None,
        "activeInHierarchySource": "unavailable",
        "activeInHierarchyInferred": False,
        "stateEvidence": "missing",
        "inactiveListMember": False,
        "stateConflict": False,
    }


def _texture_status_for_occurrences(occurrences: list[dict]) -> str:
    values = []
    for go in occurrences:
        if isinstance(go.get("hasTexturedMaterial"), bool):
            values.append(go.get("hasTexturedMaterial"))
            continue
        materials = [m for m in _list(go.get("materials")) if isinstance(m, dict)]
        assigned = [m.get("mainTextureAssigned") for m in materials
                    if isinstance(m.get("mainTextureAssigned"), bool)]
        if assigned:
            values.append(any(assigned))
    if not values:
        return "unknown"
    if all(values):
        return "textured"
    if not any(values):
        return "non_textured"
    return "mixed"


def _mode_mesh_normal_details(
    mode_name: str,
    identity: tuple[str, str],
    missing_map: dict[tuple[str, str], dict],
    inventory_map: dict[tuple[str, str], dict],
    inactive_by_id: dict[str, dict],
    hierarchy_summary: dict,
) -> dict:
    missing = missing_map.get(identity)
    inventory = inventory_map.get(identity)
    source = inventory or missing or {}
    occurrences = []
    unresolved_state_count = 0
    inactive_unmapped_count = 0
    state_conflicts = []
    for go in _list(source.get("gameObjects")):
        if not isinstance(go, dict):
            continue
        state = _resolve_occurrence_state(go, inactive_by_id)
        cause = _dict(go.get("hierarchyInactiveCause") or go.get("conversionBlockingInactiveObject"))
        root = _root_for_occurrence(go, hierarchy_summary) if state["activeInHierarchy"] is False else None
        if state["activeInHierarchy"] is None:
            unresolved_state_count += 1
        if state["stateConflict"]:
            state_conflicts.append({
                "gameObjectName": go.get("gameObjectName"),
                "gameObjectFileID": go.get("gameObjectFileID"),
                "hierarchyPath": go.get("hierarchyPath"),
                "reason": "activeInHierarchy=true 与 inactive 清单或 inactive cause 冲突",
            })
        if state["activeInHierarchy"] is False and root is None:
            inactive_unmapped_count += 1
        occurrences.append({
            "gameObjectName": go.get("gameObjectName"),
            "gameObjectFileID": go.get("gameObjectFileID"),
            "hierarchyPath": go.get("hierarchyPath"),
            "activeSelf": go.get("activeSelf"),
            **state,
            "conversionIncluded": go.get("conversionIncluded"),
            "conversionDecision": go.get("conversionDecision"),
            "meshFilterComponentFileIDs": _list(go.get("meshFilterComponentFileIDs")),
            "hasTexturedMaterial": go.get("hasTexturedMaterial"),
            "materialUsageKnown": go.get("materialUsageKnown"),
            "materials": [{
                "name": m.get("name"),
                "materialGUID": m.get("materialGUID"),
                "materialFileID": m.get("materialFileID"),
                "mainTextureAssigned": m.get("mainTextureAssigned"),
                "mainTextureResolved": m.get("mainTextureResolved"),
                "mainTextureAssetPath": m.get("mainTextureAssetPath"),
                "assetPath": m.get("assetPath"),
            } for m in _list(go.get("materials")) if isinstance(m, dict)],
            "inactiveCause": ({
                "gameObjectFileID": cause.get("gameObjectFileID"),
                "name": cause.get("name"),
                "hierarchyPath": cause.get("hierarchyPath"),
                "isSelf": cause.get("isSelf"),
            } if cause else None),
            "inactiveRoot": ({
                "rootGameObjectName": root.get("rootGameObjectName"),
                "rootGameObjectFileID": root.get("rootGameObjectFileID"),
                "rootHierarchyPath": root.get("rootHierarchyPath"),
                "rootInactiveReason": root.get("rootInactiveReason"),
            } if root else None),
        })
    return {
        "missingNormalInConversion": missing is not None,
        "inventoryScope": source.get("scope"),
        "conversionIncluded": source.get("conversionIncluded"),
        "hasNormals": source.get("hasNormals"),
        "occurrenceCount": source.get("occurrenceCount"),
        "gameObjectOccurrenceCount": len(occurrences),
        "activeOccurrenceCount": sum(1 for row in occurrences if row["activeInHierarchy"] is True),
        "inactiveOccurrenceCount": sum(1 for row in occurrences if row["activeInHierarchy"] is False),
        "unknownStateOccurrenceCount": unresolved_state_count,
        "inactiveRootUnmappedOccurrenceCount": inactive_unmapped_count,
        "stateConflicts": state_conflicts,
        "gameObjects": occurrences,
    }


def _inactive_state_validation(report: dict) -> dict:
    """Cross-check inactive-list membership against raw MeshInventory state fields."""
    inactive_by_id = _inactive_rows_by_id(report)
    state_by_go: dict[str, set[bool]] = {}
    for mesh in _list(_dict(report.get("meshDiagnostics")).get("meshInventory")):
        if not isinstance(mesh, dict):
            continue
        for go in _list(mesh.get("gameObjects")):
            if not isinstance(go, dict) or go.get("gameObjectFileID") is None:
                continue
            value = go.get("activeInHierarchy")
            if isinstance(value, bool):
                state_by_go.setdefault(str(go.get("gameObjectFileID")), set()).add(value)

    direct_false = set()
    direct_true = set()
    field_rows = 0
    for go_id, row in inactive_by_id.items():
        value = row.get("activeInHierarchy")
        if isinstance(value, bool):
            field_rows += 1
            if value is False:
                direct_false.add(go_id)
            else:
                direct_true.add(go_id)
        states = state_by_go.get(go_id, set())
        if states == {False}:
            direct_false.add(go_id)
        elif True in states:
            direct_true.add(go_id)

    conflicts = sorted(direct_true)
    no_direct_state = set(inactive_by_id) - direct_false - direct_true
    return {
        "status": "CONSISTENT" if not conflicts else "CONFLICT",
        "inactiveGameObjectCount": len(inactive_by_id),
        "inactiveObjectRowsWithRawActiveInHierarchy": field_rows,
        "inactiveObjectsWithDirectMeshInventoryState": len(direct_false | direct_true),
        "directStateFalseCount": len(direct_false),
        "directStateTrueConflictCount": len(direct_true),
        "inferredFromInactiveListMembershipCount": len(no_direct_state),
        "stateConflicts": [{
            "gameObjectFileID": go_id,
            "reason": "inactiveInHierarchyObjects 成员在 MeshInventory 中出现 activeInHierarchy=true",
        } for go_id in conflicts],
        "interpretation": (
            "直接状态仅统计 inactive 对象清单中同时能在 MeshInventory GameObject 引用中找到原始 activeInHierarchy 字段的对象；"
            "其余对象依据 inactiveInHierarchyObjects 成员身份推导为 false。"
        ),
    }


def _compare_inactive_states(include: dict, exclude: dict) -> dict:
    def states(report: dict) -> dict[str, set[bool]]:
        result: dict[str, set[bool]] = {}
        for mesh in _list(_dict(report.get("meshDiagnostics")).get("meshInventory")):
            if not isinstance(mesh, dict):
                continue
            for go in _list(mesh.get("gameObjects")):
                if not isinstance(go, dict) or go.get("gameObjectFileID") is None:
                    continue
                value = go.get("activeInHierarchy")
                if isinstance(value, bool):
                    result.setdefault(str(go.get("gameObjectFileID")), set()).add(value)
        return result

    inc_states, exc_states = states(include), states(exclude)
    common_ids = set(inc_states) & set(exc_states)
    mismatches = [{
        "gameObjectFileID": go_id,
        "includeStates": sorted(inc_states[go_id]),
        "excludeStates": sorted(exc_states[go_id]),
    } for go_id in sorted(common_ids) if inc_states[go_id] != exc_states[go_id]]
    return {
        "status": "CONSISTENT" if not mismatches else "CONFLICT",
        "includeGameObjectCountWithRawState": len(inc_states),
        "excludeGameObjectCountWithRawState": len(exc_states),
        "crossModeComparedGameObjectCount": len(common_ids),
        "crossModeStateMismatchCount": len(mismatches),
        "stateMismatches": mismatches,
        "interpretation": "比较两份质量报告中相同 GameObject fileID 的 MeshInventory 原始 activeInHierarchy 字段；不以 inactivePolicy 推导状态。",
    }


def _build_normal_inactive_association(
    include: dict, exclude: dict, include_mode: dict, exclude_mode: dict
) -> dict:
    """Classify missing-normal Mesh identities across modes and map inactive occurrences to roots."""
    inc_missing = _missing_normal_by_identity(include)
    exc_missing = _missing_normal_by_identity(exclude)
    inc_missing_rows = _list(_dict(include.get("meshDiagnostics")).get("conversionMissingNormals"))
    exc_missing_rows = _list(_dict(exclude.get("meshDiagnostics")).get("conversionMissingNormals"))
    unidentified_missing_count = sum(
        1 for row in inc_missing_rows + exc_missing_rows
        if isinstance(row, dict) and _identity(row) is None
    )
    inc_inventory = _inventory_by_identity(include)
    exc_inventory = _inventory_by_identity(exclude)
    inc_inactive = _inactive_rows_by_id(include)
    exc_inactive = _inactive_rows_by_id(exclude)
    inc_hierarchy = _dict(include_mode.get("inactiveHierarchySummary"))
    exc_hierarchy = _dict(exclude_mode.get("inactiveHierarchySummary"))

    inc_ids, exc_ids = set(inc_missing), set(exc_missing)
    common_ids = inc_ids & exc_ids
    inc_only_ids = inc_ids - exc_ids
    exc_only_ids = exc_ids - inc_ids
    all_ids = inc_ids | exc_ids

    association_rows = []
    root_acc: dict[tuple[str, str], dict] = {}
    state_conflicts = []
    unknown_occurrences = 0
    inactive_unmapped_occurrences = 0
    missing_identity_count = 0
    no_gameobject_occurrence_count = 0
    category_counts = {
        "uv0": {"present": 0, "missing": 0, "unknown": 0},
        "materialTexture": {"textured": 0, "non_textured": 0, "mixed": 0, "unknown": 0},
        "normalEvidence": {},
        "uv0ByMaterialTexture": {},
    }

    for identity in sorted(all_ids):
        classification = (
            "common" if identity in common_ids
            else "include_only" if identity in inc_only_ids
            else "exclude_only"
        )
        inc_row = inc_missing.get(identity) or exc_missing.get(identity) or inc_inventory.get(identity) or exc_inventory.get(identity) or {}
        uv0 = inc_row.get("hasUV0")
        uv0_key = "present" if uv0 is True else "missing" if uv0 is False else "unknown"
        material_status = _texture_status_for_occurrences(_list(inc_row.get("gameObjects")))
        category_counts["uv0"][uv0_key] += 1
        category_counts["materialTexture"][material_status] += 1
        normal_evidence = str(inc_row.get("normalEvidence") or "UNKNOWN")
        category_counts["normalEvidence"][normal_evidence] = category_counts["normalEvidence"].get(normal_evidence, 0) + 1
        combo = f"UV0_{uv0_key}__MATERIAL_{material_status}"
        category_counts["uv0ByMaterialTexture"][combo] = category_counts["uv0ByMaterialTexture"].get(combo, 0) + 1

        inc_details = _mode_mesh_normal_details(
            "include", identity, inc_missing, inc_inventory, inc_inactive, inc_hierarchy
        )
        exc_details = _mode_mesh_normal_details(
            "exclude", identity, exc_missing, exc_inventory, exc_inactive, exc_hierarchy
        )
        if inc_details["gameObjectOccurrenceCount"] == 0 and exc_details["gameObjectOccurrenceCount"] == 0:
            no_gameobject_occurrence_count += 1
        for mode_name, details in (("include", inc_details), ("exclude", exc_details)):
            unknown_occurrences += details["unknownStateOccurrenceCount"]
            inactive_unmapped_occurrences += details["inactiveRootUnmappedOccurrenceCount"]
            for conflict in details["stateConflicts"]:
                state_conflicts.append({"mode": mode_name, **conflict})

        association_rows.append({
            "meshName": inc_row.get("meshName"),
            "meshGUID": identity[0],
            "meshFileID": identity[1],
            "assetPath": inc_row.get("assetPath"),
            "vertexCount": inc_row.get("vertexCount"),
            "hasNormals": inc_row.get("hasNormals"),
            "hasUV0": uv0,
            "normalEvidence": normal_evidence,
            "materialTextureStatus": material_status,
            "classification": classification,
            "include": inc_details,
            "exclude": exc_details,
        })

        # Root-level impact is counted from the Include mode's full occurrence list,
        # so a Mesh referenced by multiple GameObjects is associated with each real root.
        for occurrence in inc_details["gameObjects"]:
            root = occurrence.get("inactiveRoot")
            if not root:
                continue
            root_key = (
                str(root.get("rootGameObjectFileID") or ""),
                str(root.get("rootHierarchyPath") or ""),
            )
            bucket = root_acc.setdefault(root_key, {
                "rootGameObjectName": root.get("rootGameObjectName"),
                "rootGameObjectFileID": root.get("rootGameObjectFileID"),
                "rootHierarchyPath": root.get("rootHierarchyPath"),
                "rootInactiveReason": root.get("rootInactiveReason"),
                "meshIDs": set(),
                "includeOnlyMeshIDs": set(),
                "commonMeshIDs": set(),
                "excludeOnlyMeshIDs": set(),
                "gameObjectIDs": set(),
                "meshOccurrences": [],
            })
            bucket["meshIDs"].add(identity)
            bucket["gameObjectIDs"].add(str(occurrence.get("gameObjectFileID")))
            if classification == "include_only":
                bucket["includeOnlyMeshIDs"].add(identity)
            elif classification == "common":
                bucket["commonMeshIDs"].add(identity)
            else:
                bucket["excludeOnlyMeshIDs"].add(identity)
            bucket["meshOccurrences"].append({
                "meshName": inc_row.get("meshName"),
                "meshGUID": identity[0],
                "meshFileID": identity[1],
                "classification": classification,
                "hasUV0": uv0,
                "materialTextureStatus": material_status,
                "gameObjectName": occurrence.get("gameObjectName"),
                "gameObjectFileID": occurrence.get("gameObjectFileID"),
                "hierarchyPath": occurrence.get("hierarchyPath"),
                "activeInHierarchy": occurrence.get("activeInHierarchy"),
                "activeInHierarchySource": occurrence.get("activeInHierarchySource"),
                "activeInHierarchyInferred": occurrence.get("activeInHierarchyInferred"),
            })

    root_summaries = []
    for bucket in root_acc.values():
        bucket["meshOccurrences"].sort(key=lambda row: (
            str(row.get("meshName") or "").casefold(),
            str(row.get("gameObjectName") or "").casefold(),
            str(row.get("meshGUID") or ""),
            str(row.get("meshFileID") or ""),
        ))
        root_summaries.append({
            "rootGameObjectName": bucket["rootGameObjectName"],
            "rootGameObjectFileID": bucket["rootGameObjectFileID"],
            "rootHierarchyPath": bucket["rootHierarchyPath"],
            "rootInactiveReason": bucket["rootInactiveReason"],
            "affectedMissingNormalUniqueMeshCount": len(bucket["meshIDs"]),
            "includeOnlyMissingNormalUniqueMeshCount": len(bucket["includeOnlyMeshIDs"]),
            "commonMissingNormalUniqueMeshCount": len(bucket["commonMeshIDs"]),
            "excludeOnlyMissingNormalUniqueMeshCount": len(bucket["excludeOnlyMeshIDs"]),
            "affectedGameObjectOccurrenceCount": len(bucket["gameObjectIDs"]),
            "meshOccurrences": bucket["meshOccurrences"],
        })
    root_summaries.sort(key=lambda row: (
        -row["affectedMissingNormalUniqueMeshCount"],
        str(row.get("rootHierarchyPath") or "").casefold(),
    ))

    # Validate that Include-only missing-normal identities really were excluded
    # from conversion in Exclude mode, rather than silently treating absence as proof.
    excluded_only_verified = []
    excluded_only_unverified = []
    for identity in sorted(inc_only_ids):
        inventory = exc_inventory.get(identity)
        include_details = _mode_mesh_normal_details(
            "include", identity, inc_missing, inc_inventory, inc_inactive, inc_hierarchy
        )
        record = {
            "meshGUID": identity[0],
            "meshFileID": identity[1],
            "meshName": (inc_missing.get(identity) or {}).get("meshName"),
            "includeActiveOccurrenceCount": include_details["activeOccurrenceCount"],
            "includeInactiveOccurrenceCount": include_details["inactiveOccurrenceCount"],
            "includeUnknownStateOccurrenceCount": include_details["unknownStateOccurrenceCount"],
            "includeInactiveRootUnmappedOccurrenceCount": include_details["inactiveRootUnmappedOccurrenceCount"],
            "excludeInventoryScope": inventory.get("scope") if inventory else None,
            "excludeConversionIncluded": inventory.get("conversionIncluded") if inventory else None,
            "excludeHasNormals": inventory.get("hasNormals") if inventory else None,
        }
        if (
            inventory
            and inventory.get("scope") == "excludedOnly"
            and inventory.get("conversionIncluded") is False
            and include_details["inactiveOccurrenceCount"] > 0
            and include_details["activeOccurrenceCount"] == 0
            and include_details["unknownStateOccurrenceCount"] == 0
            and include_details["inactiveRootUnmappedOccurrenceCount"] == 0
        ):
            excluded_only_verified.append(record)
        else:
            excluded_only_unverified.append(record)

    mapping_complete = (
        len(association_rows) == len(all_ids)
        and all(len(row["meshGUID"]) == 32 and row["meshFileID"] not in ("", "0") for row in association_rows)
        and unidentified_missing_count == 0
        and no_gameobject_occurrence_count == 0
        and unknown_occurrences == 0
        and inactive_unmapped_occurrences == 0
        and not state_conflicts
        and not excluded_only_unverified
    )
    return {
        "status": "COMPLETE" if mapping_complete else "PARTIAL",
        "mappingComplete": mapping_complete,
        "includeMissingNormalUniqueMeshCount": len(inc_ids),
        "excludeMissingNormalUniqueMeshCount": len(exc_ids),
        "commonMissingNormalUniqueMeshCount": len(common_ids),
        "includeOnlyMissingNormalUniqueMeshCount": len(inc_only_ids),
        "excludeOnlyMissingNormalUniqueMeshCount": len(exc_only_ids),
        "includeOnlyInactiveExcludedMeshVerifiedCount": len(excluded_only_verified),
        "includeOnlyInactiveExcludedMeshUnverifiedCount": len(excluded_only_unverified),
        "includeOnlyInactiveExcludedMeshes": excluded_only_verified,
        "unverifiedIncludeOnlyMeshes": excluded_only_unverified,
        "inactiveRootAssociationCount": len(root_summaries),
        "inactiveAssociatedUniqueMeshCount": sum(
            1 for row in association_rows
            if any(go.get("activeInHierarchy") is False for go in row["include"]["gameObjects"])
        ),
        "unknownStateOccurrenceCount": unknown_occurrences,
        "inactiveRootUnmappedOccurrenceCount": inactive_unmapped_occurrences,
        "stateConflictCount": len(state_conflicts),
        "stateConflicts": state_conflicts,
        "noGameObjectOccurrenceMeshCount": no_gameobject_occurrence_count,
        "unidentifiedMissingNormalRowCount": unidentified_missing_count,
        "categoryCounts": category_counts,
        "inactiveRootAssociations": root_summaries,
        "meshes": association_rows,
        "interpretation": (
            "缺法线 Mesh 按 GUID + fileID 跨模式分类。common 表示两种模式的转换缺法线清单都包含该资源；"
            "include_only 表示仅 Include 转换清单包含。Include-only 只有在 Exclude 的 meshInventory 明确标记 "
            "scope=excludedOnly 且 conversionIncluded=false 时，才认定为因 inactive 策略未参与 Exclude 转换。"
            "inactive 根对象关联按 GameObject 原始 activeInHierarchy、inactive cause 和 Hierarchy 路径交叉定位；"
            "法线/UV/材质统计是源数据诊断，不代表已证明 MMD 中存在视觉缺陷。"
        ),
    }


def build_warning_diagnostics(include: dict, exclude: dict,
                              include_path: Path | None = None,
                              exclude_path: Path | None = None) -> dict:
    _validate(include, "include 报告", "include")
    _validate(exclude, "exclude 报告", "exclude")
    if _stage_key(include) != _stage_key(exclude):
        raise DiagnosticError("Include / Exclude 两份报告不是同一个舞台工程，无法进行 WARNING 对照。")
    include_path = Path(include_path) if include_path is not None else None
    exclude_path = Path(exclude_path) if exclude_path is not None else None
    inc = _diagnose_report(include, "include", include_path)
    exc = _diagnose_report(exclude, "exclude", exclude_path)
    inc_ids = {w["checkId"] for w in inc["warnings"]}
    exc_ids = {w["checkId"] for w in exc["warnings"]}
    common = sorted(inc_ids & exc_ids)
    inc_only = sorted(inc_ids - exc_ids)
    exc_only = sorted(exc_ids - inc_ids)
    inc_normals = _warning_mesh_ids(inc, "SRC-005")
    exc_normals = _warning_mesh_ids(exc, "SRC-005")
    identity_diff = {
        "checkId": "SRC-005",
        "includeMissingNormalMeshes": len(inc_normals),
        "excludeMissingNormalMeshes": len(exc_normals),
        "commonMissingNormalMeshes": len(inc_normals & exc_normals),
        "includeOnlyMissingNormalMeshes": len(inc_normals - exc_normals),
        "excludeOnlyMissingNormalMeshes": len(exc_normals - inc_normals),
        "includeOnlyIdentities": [{"meshGUID": g, "meshFileID": f} for g, f in sorted(inc_normals - exc_normals)],
        "excludeOnlyIdentities": [{"meshGUID": g, "meshFileID": f} for g, f in sorted(exc_normals - inc_normals)],
        "note": "身份集合按 Mesh GUID + fileID 比较；差异仅表示两种转换范围包含的缺法线 Mesh 不同，不表示法线被修复。",
    }
    all_mappings_complete = all(
        w["diagnosis"].get("mappingComplete")
        for mode in (inc, exc) for w in mode["warnings"]
    )
    normal_inactive = _build_normal_inactive_association(include, exclude, inc, exc)
    include_state_validation = _inactive_state_validation(include)
    exclude_state_validation = _inactive_state_validation(exclude)
    cross_mode_state = _compare_inactive_states(include, exclude)
    return {
        "schema": REPORT_SCHEMA,
        "tool": "SCSP Stage Converter - Mesh 法线与 inactive 关联诊断",
        "toolVersion": "2.4.10-dev",
        "generatedAt": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "stage": _dict(include.get("stage")),
        "summary": {
            "diagnosticStatus": "COMPLETE" if all_mappings_complete else "PARTIAL",
            "includeWarningCount": inc["warningCount"],
            "excludeWarningCount": exc["warningCount"],
            "commonWarningIds": common,
            "includeOnlyWarningIds": inc_only,
            "excludeOnlyWarningIds": exc_only,
            "fullyMappedWarningCount": inc["fullyMappedWarningCount"] + exc["fullyMappedWarningCount"],
            "unmappedWarningCount": inc["unmappedWarningCount"] + exc["unmappedWarningCount"],
            "normalInactiveAssociationStatus": normal_inactive.get("status"),
            "normalInactiveAssociationComplete": normal_inactive.get("mappingComplete"),
            "inactiveStateValidationStatus": cross_mode_state.get("status"),
            "qualityWarningsArePreserved": True,
            "conversionWasExecuted": False,
            "conversionFilesWereModified": False,
        },
        "warningIdentityComparison": identity_diff,
        "normalInactiveAssociation": normal_inactive,
        "inactiveStateValidation": {
            "include": include_state_validation,
            "exclude": exclude_state_validation,
            "crossMode": cross_mode_state,
        },
        "modes": {"include": inc, "exclude": exc},
        "limitations": [
            "本报告只读取两份质量检查 JSON，不会重新运行 Unity、Blender 或 PMX 转换。",
            "SRC-005 的定位依据是 MeshInventory / conversionMissingNormals；缺少法线数据不等同于已证明 MMD 视觉错误。",
            "BLD-004 是 inactive 转换范围提示；报告按最上层 inactive 根对象分组统计受影响 GameObject、MeshFilter 和唯一 Mesh，不代表这些对象都应该恢复。",
            "V2.4.7/V2.4.9 旧报告若未在 inactiveInHierarchyObjects 中保存 activeInHierarchy，则根据该列表的语义推导为 false，并通过 activeInHierarchyInferred=true 标记；不会冒充 Unity 原始字段。",
            "未建立已验证映射的其他 WARNING 会保留原始 details 并标记为未定位，不会猜测对象归属。",
            "UV0 在这两份输入报告中属于 INFO，而不是 WARNING，因此不会混入 WARNING 计数。",
        ],
    }


def diagnose_warning_files(include_path: str | Path, exclude_path: str | Path,
                           json_output: str | Path, text_output: str | Path | None = None) -> dict:
    include_path, exclude_path = Path(include_path).resolve(), Path(exclude_path).resolve()
    json_output = Path(json_output).resolve()
    text_output = Path(text_output).resolve() if text_output else None
    if json_output in (include_path, exclude_path) or (text_output and text_output in (include_path, exclude_path)):
        raise DiagnosticError("输出路径不能覆盖输入质量报告。")
    if json_output.suffix.lower() != ".json":
        raise DiagnosticError("JSON 输出文件必须使用 .json 扩展名。")
    if text_output and text_output.suffix.lower() != ".txt":
        raise DiagnosticError("TXT 输出文件必须使用 .txt 扩展名。")
    include = _read_json(include_path)
    exclude = _read_json(exclude_path)
    result = build_warning_diagnostics(include, exclude, include_path, exclude_path)
    json_output.parent.mkdir(parents=True, exist_ok=True)
    json_output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if text_output:
        text_output = Path(text_output)
        text_output.parent.mkdir(parents=True, exist_ok=True)
        write_text_report(result, text_output)
    return result


def write_text_report(report: dict, path: str | Path) -> None:
    lines = [
        "SCSP Stage Converter V2.4.10-dev — Mesh 法线与 inactive 关联诊断",
        "=" * 78,
        f"舞台：{_dict(report.get('stage')).get('root', '')} / {_dict(report.get('stage')).get('scene', '')}",
        f"WARNING 定位状态：{_dict(report.get('summary')).get('diagnosticStatus')} | "
        f"法线-inactive 关联：{_dict(report.get('summary')).get('normalInactiveAssociationStatus')} | "
        f"inactive 状态交叉核验：{_dict(report.get('summary')).get('inactiveStateValidationStatus')}",
        "说明：只读分析已有质量报告；不重新转换、不修改 Blender 或 PMX 文件。",
        "",
    ]
    for mode_name in ("include", "exclude"):
        mode = _dict(_dict(report.get("modes")).get(mode_name))
        qs = _dict(mode.get("qualitySummary"))
        lines += [
            f"[{mode_name.upper()}] inactivePolicy={mode.get('inactivePolicy')} 生成时间={mode.get('generatedAt')}",
            f"质量报告状态：{qs.get('status')} | PASS={qs.get('passed')} WARNING={qs.get('warnings')} FAIL={qs.get('failures')} INFO={qs.get('info')}",
            f"WARNING 数量：{mode.get('warningCount')} | 已完整定位：{mode.get('fullyMappedWarningCount')} | 未完整定位：{mode.get('unmappedWarningCount')}",
            "-" * 78,
        ]
        hierarchy = _dict(mode.get("inactiveHierarchySummary"))
        lines.append(
            f"inactive 层级汇总：GameObject={hierarchy.get('inactiveGameObjectCount')} | "
            f"最上层 inactive 根对象={hierarchy.get('inactiveRootObjectCount')} | "
            f"含 Mesh 的 GameObject={hierarchy.get('meshBearingGameObjectCount')} | "
            f"MeshFilter={hierarchy.get('affectedMeshFilterComponentCount')} | "
            f"唯一 Mesh={hierarchy.get('affectedUniqueMeshCount')} | "
            f"分组完整={hierarchy.get('groupingComplete')}"
        )
        lines.append("inactive 根对象影响清单：")
        for root in hierarchy.get("rootObjects", []):
            lines.append(
                f"  - {root.get('rootGameObjectName')} [fileID={root.get('rootGameObjectFileID')}] | "
                f"GameObject={root.get('affectedGameObjectCount')} | "
                f"含 Mesh GO={root.get('meshBearingGameObjectCount')} | "
                f"MeshFilter={root.get('affectedMeshFilterComponentCount')} | "
                f"唯一 Mesh={root.get('affectedUniqueMeshCount')} | "
                f"activeInHierarchy={root.get('activeInHierarchy')} (inferred={root.get('activeInHierarchyInferred')}) | "
                f"scope={root.get('uniqueMeshCountByScope')}"
            )
            lines.append(f"    {root.get('rootHierarchyPath')}")
        lines.append("-" * 78)
        for warning in mode.get("warnings", []):
            diag = _dict(warning.get("diagnosis"))
            lines += [
                f"{warning.get('checkId')} [{warning.get('status')}] {warning.get('name')}",
                f"说明：{warning.get('message')}",
                f"定位：{diag.get('mappingType')} | mappingComplete={diag.get('mappingComplete')}",
            ]
            if warning.get("checkId") == "SRC-005":
                lines.append(
                    f"缺少法线 Mesh：{diag.get('locatedMeshCount')} / 预期 {diag.get('expectedMeshCount')}；"
                    f"已识别 GUID/fileID：{diag.get('identifiedMeshCount')}"
                )
                for mesh in diag.get("affectedMeshes", []):
                    lines.append(
                        f"  - {mesh.get('meshName')} | GUID={mesh.get('meshGUID')} | fileID={mesh.get('meshFileID')}"
                    )
                    lines.append(
                        f"    Asset={mesh.get('assetPath')} | vertices={mesh.get('vertexCount')} | UV0={mesh.get('hasUV0')} | evidence={mesh.get('normalEvidence', '见 JSON') }"
                    )
                    for go in mesh.get("gameObjects", []):
                        lines.append(
                            f"    GO={go.get('gameObjectName')} [fileID={go.get('gameObjectFileID')}] | {go.get('hierarchyPath')}"
                        )
                        for material in go.get("materials", []):
                            lines.append(
                                f"      Material={material.get('name')} | GUID={material.get('materialGUID')} | fileID={material.get('materialFileID')} | MainTex={material.get('mainTextureAssetPath')}"
                            )
            elif warning.get("checkId") == "BLD-004":
                lines.append(
                    f"inactive GameObject：{diag.get('locatedGameObjectCount')} / 预期 {diag.get('expectedGameObjectCount')}；"
                    f"含 Mesh 的 GameObject={diag.get('meshBearingGameObjectCount')}；"
                    f"Excluded-only Mesh={diag.get('excludedOnlyUniqueMeshCount')}"
                )
                lines.append("被排除的 Mesh：")
                for mesh in diag.get("affectedMeshes", []):
                    lines.append(
                        f"  - {mesh.get('meshName')} | GUID={mesh.get('meshGUID')} | fileID={mesh.get('meshFileID')} | {mesh.get('assetPath')}"
                    )
                    for go in mesh.get("gameObjects", []):
                        lines.append(f"    GO={go.get('gameObjectName')} [fileID={go.get('gameObjectFileID')}] | {go.get('hierarchyPath')}")
                lines.append(f"inactive 根对象数量：{diag.get('inactiveRootObjectCount')}")
                for root in diag.get("inactiveRootObjects", []):
                    lines.append(
                        f"  ROOT={root.get('rootGameObjectName')} [fileID={root.get('rootGameObjectFileID')}] | "
                        f"GameObject={root.get('affectedGameObjectCount')} | "
                        f"含 Mesh GO={root.get('meshBearingGameObjectCount')} | "
                        f"MeshFilter={root.get('affectedMeshFilterComponentCount')} | "
                        f"唯一 Mesh={root.get('affectedUniqueMeshCount')} | "
                        f"activeInHierarchy={root.get('activeInHierarchy')} (inferred={root.get('activeInHierarchyInferred')})"
                    )
                    lines.append(f"    {root.get('rootHierarchyPath')}")
                lines.append("inactive GameObject 清单：")
                for go in diag.get("affectedGameObjects", []):
                    lines.append(
                        f"  - {go.get('gameObjectName')} [fileID={go.get('gameObjectFileID')}] | meshes={go.get('meshCount')} | activeInHierarchy={go.get('activeInHierarchy')} (inferred={go.get('activeInHierarchyInferred')}) | {go.get('hierarchyPath')}"
                    )
            else:
                lines.append("原始 details：" + json.dumps(warning.get("details", {}), ensure_ascii=False))
            lines.append("")
    diff = _dict(report.get("warningIdentityComparison"))
    lines += [
        "WARNING 跨模式身份比较",
        "-" * 78,
        f"缺法线 Mesh：Include={diff.get('includeMissingNormalMeshes')} Exclude={diff.get('excludeMissingNormalMeshes')}",
        f"两模式共有={diff.get('commonMissingNormalMeshes')} Include 独有={diff.get('includeOnlyMissingNormalMeshes')} Exclude 独有={diff.get('excludeOnlyMissingNormalMeshes')}",
        "Include 独有身份：",
    ]
    for item in diff.get("includeOnlyIdentities", []):
        lines.append(f"  - GUID={item.get('meshGUID')} | fileID={item.get('meshFileID')}")

    association = _dict(report.get("normalInactiveAssociation"))
    lines += [
        "",
        "缺法线 Mesh × inactive 关联分析",
        "-" * 78,
        f"关联状态：{association.get('status')} | 完整={association.get('mappingComplete')}",
        f"Include 缺法线 Mesh={association.get('includeMissingNormalUniqueMeshCount')} | "
        f"Exclude={association.get('excludeMissingNormalUniqueMeshCount')} | "
        f"共有={association.get('commonMissingNormalUniqueMeshCount')} | "
        f"Include 独有={association.get('includeOnlyMissingNormalUniqueMeshCount')} | "
        f"Exclude 独有={association.get('excludeOnlyMissingNormalUniqueMeshCount')}",
        f"Include 独有且在 Exclude 明确标记为 excludedOnly 的 Mesh："
        f"{association.get('includeOnlyInactiveExcludedMeshVerifiedCount')} / "
        f"{association.get('includeOnlyMissingNormalUniqueMeshCount')}",
        f"关联 inactive 根对象={association.get('inactiveRootAssociationCount')} | "
        f"关联缺法线 Mesh={association.get('inactiveAssociatedUniqueMeshCount')} | "
        f"状态未知 occurrence={association.get('unknownStateOccurrenceCount')} | "
        f"未映射 inactive 根 occurrence={association.get('inactiveRootUnmappedOccurrenceCount')}",
        "",
        "法线 / UV0 / 材质分类（按 Include 缺法线唯一 Mesh 统计）",
    ]
    categories = _dict(association.get("categoryCounts"))
    for key, values in categories.items():
        lines.append(f"  {key}: {json.dumps(values, ensure_ascii=False, sort_keys=True)}")
    lines += ["", "受影响的 inactive 根对象："]
    for root in association.get("inactiveRootAssociations", []):
        lines.append(
            f"  - {root.get('rootGameObjectName')} [fileID={root.get('rootGameObjectFileID')}] | "
            f"缺法线唯一 Mesh={root.get('affectedMissingNormalUniqueMeshCount')} | "
            f"Include 独有={root.get('includeOnlyMissingNormalUniqueMeshCount')} | "
            f"共有={root.get('commonMissingNormalUniqueMeshCount')}"
        )
        lines.append(f"    {root.get('rootHierarchyPath')}")
        for mesh in root.get("meshOccurrences", []):
            lines.append(
                f"    Mesh={mesh.get('meshName')} | GUID={mesh.get('meshGUID')} | fileID={mesh.get('meshFileID')} | "
                f"class={mesh.get('classification')} | UV0={mesh.get('hasUV0')} | "
                f"material={mesh.get('materialTextureStatus')} | GO={mesh.get('gameObjectName')} "
                f"[{mesh.get('gameObjectFileID')}]"
            )
            lines.append(
                f"      activeInHierarchy={mesh.get('activeInHierarchy')} | "
                f"source={mesh.get('activeInHierarchySource')} | inferred={mesh.get('activeInHierarchyInferred')} | "
                f"{mesh.get('hierarchyPath')}"
            )

    lines += ["", "Include-only / Exclude-only 缺法线 Mesh 明细："]
    for mesh in association.get("meshes", []):
        if mesh.get("classification") == "common" and not mesh.get("include", {}).get("inactiveOccurrenceCount"):
            continue
        inc_mode = _dict(mesh.get("include"))
        exc_mode = _dict(mesh.get("exclude"))
        lines.append(
            f"  - {mesh.get('meshName')} | GUID={mesh.get('meshGUID')} | fileID={mesh.get('meshFileID')} | "
            f"class={mesh.get('classification')} | UV0={mesh.get('hasUV0')} | "
            f"material={mesh.get('materialTextureStatus')}"
        )
        lines.append(
            f"    Include: missingNormal={inc_mode.get('missingNormalInConversion')} "
            f"scope={inc_mode.get('inventoryScope')} conversionIncluded={inc_mode.get('conversionIncluded')} | "
            f"Exclude: missingNormal={exc_mode.get('missingNormalInConversion')} "
            f"scope={exc_mode.get('inventoryScope')} conversionIncluded={exc_mode.get('conversionIncluded')}"
        )

    state_validation = _dict(report.get("inactiveStateValidation"))
    lines += ["", "inactive 状态来源与跨模式核验", "-" * 78]
    for mode_name in ("include", "exclude"):
        state = _dict(state_validation.get(mode_name))
        lines.append(
            f"{mode_name.upper()}: inactive GameObject={state.get('inactiveGameObjectCount')} | "
            f"对象清单原始 activeInHierarchy 字段={state.get('inactiveObjectRowsWithRawActiveInHierarchy')} | "
            f"MeshInventory 直接状态={state.get('inactiveObjectsWithDirectMeshInventoryState')} "
            f"(false={state.get('directStateFalseCount')}) | "
            f"由清单成员身份推导={state.get('inferredFromInactiveListMembershipCount')} | "
            f"冲突={state.get('directStateTrueConflictCount')} | status={state.get('status')}"
        )
    cross = _dict(state_validation.get("crossMode"))
    lines.append(
        f"跨模式原始状态比较：共同 GameObject={cross.get('crossModeComparedGameObjectCount')} | "
        f"状态不一致={cross.get('crossModeStateMismatchCount')} | status={cross.get('status')}"
    )
    lines += ["", "限制与解释："]
    lines.extend("- " + item for item in report.get("limitations", []))
    lines.append("")
    Path(path).write_text("\n".join(lines), encoding="utf-8-sig")


def _run_gui() -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox
    except Exception as exc:
        print(f"Tkinter 不可用：{exc}")
        return 2
    root = tk.Tk()
    root.withdraw()
    try:
        include = filedialog.askopenfilename(title="选择【勾选 inactive】Include 质量报告 JSON",
                                             filetypes=[("SCSP 质量报告", "*.json"), ("所有文件", "*.*")])
        if not include:
            return 0
        exclude = filedialog.askopenfilename(title="选择【取消勾选 inactive】Exclude 质量报告 JSON",
                                             filetypes=[("SCSP 质量报告", "*.json"), ("所有文件", "*.*")])
        if not exclude:
            return 0
        stage = _dict(_read_json(Path(include)).get("stage"))
        root_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(stage.get("root") or "stage"))
        target = filedialog.asksaveasfilename(title="保存 WARNING 诊断 JSON（自动生成同名 TXT）",
                                              initialdir=str(Path(exclude).parent),
                                              initialfile=f"{root_name}_warning_diagnostics.json",
                                              defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not target:
            return 0
        json_path = Path(target)
        text_path = json_path.with_suffix(".txt")
        result = diagnose_warning_files(include, exclude, json_path, text_path)
        summary = result["summary"]
        message = (f"WARNING 定位：{summary['diagnosticStatus']}\\n"
                   f"Include WARNING：{summary['includeWarningCount']}\\n"
                   f"Exclude WARNING：{summary['excludeWarningCount']}\\n"
                   f"法线 / inactive 关联：{summary.get('normalInactiveAssociationStatus')}\\n"
                   f"inactive 状态核验：{summary.get('inactiveStateValidationStatus')}\\n"
                   f"完整定位：{summary['fullyMappedWarningCount']}\\n"
                   f"未完整定位：{summary['unmappedWarningCount']}\\n\\nJSON：{json_path}\\nTXT：{text_path}\\n\\n是否打开 TXT 报告？")
        if messagebox.askyesno("WARNING / 法线关联诊断完成", message, parent=root):
            import os
            if hasattr(os, "startfile"):
                os.startfile(str(text_path))
            else:
                print(text_path)
        return 0
    except Exception as exc:
        messagebox.showerror("WARNING 诊断失败", str(exc), parent=root)
        return 1
    finally:
        root.destroy()


def main() -> int:
    parser = argparse.ArgumentParser(description="SCSP V2.4.10 Mesh 法线与 inactive 关联诊断（只读）")
    parser.add_argument("--include", default="")
    parser.add_argument("--exclude", default="")
    parser.add_argument("--json-out", default="")
    parser.add_argument("--text-out", default="")
    parser.add_argument("--gui", action="store_true")
    args = parser.parse_args()
    if args.gui:
        return _run_gui()
    if not all((args.include, args.exclude, args.json_out)):
        parser.error("命令行模式需要 --include、--exclude、--json-out；或使用 --gui。")
    result = diagnose_warning_files(args.include, args.exclude, args.json_out, args.text_out or None)
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    print("JSON:", Path(args.json_out).resolve())
    if args.text_out:
        print("TXT:", Path(args.text_out).resolve())
    return 0 if result["summary"]["diagnosticStatus"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
