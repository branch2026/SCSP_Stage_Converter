#!/usr/bin/env python3
"""Validate Unity scene mesh references, including supported built-in meshes."""
import argparse
import collections
import importlib.util
import json
import math
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
REBUILD_SCRIPT = HERE.parent / "SceneBuilder" / "rebuild_stage_blender.py"
spec = importlib.util.spec_from_file_location("scsp_rebuild", REBUILD_SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def _validate_mesh_data(mesh, index_format, label, result):
    """Accumulate mesh integrity checks shared by imported and built-in meshes."""
    result["decodedMeshes"] += 1
    result["vertices"] += mesh["vertexCount"]
    result["indices"] += len(mesh["indices"])
    result["withNormals"] += bool(mesh["normals"])
    result["withUV0"] += bool(mesh["uv"])

    isize = 4 if index_format == 1 else 2
    result["indexFormatCounts"][str(index_format)] += 1

    for sub in mesh["submeshes"]:
        result["submeshes"] += 1
        start = sub["firstByte"] // isize
        end = start + sub["indexCount"]
        if sub["firstByte"] % isize or end > len(mesh["indices"]):
            result["errors"].append({
                "mesh": label,
                "error": "Submesh index range invalid",
                "submesh": sub,
            })

    if mesh["indices"] and max(mesh["indices"]) >= mesh["vertexCount"]:
        result["errors"].append({
            "mesh": label,
            "error": "Index exceeds vertex count",
            "maxIndex": max(mesh["indices"]),
            "vertexCount": mesh["vertexCount"],
        })

    if any(not math.isfinite(v) for row in mesh["positions"] for v in row):
        result["errors"].append({"mesh": label, "error": "Non-finite position"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--scene", default="Assets/182_superd.unity")
    ap.add_argument("--root", default="182_SuperD")
    ap.add_argument("--out", default="SCSP_source_validation.json")
    a = ap.parse_args()

    project = Path(a.project).resolve()
    assets = project / "Assets"
    scene = project / a.scene
    objects, transforms, t_by_go, children, go_by_tid, roots, mf, mr, guid = (
        mod.parse_scene(scene, assets)
    )

    root = next((i for i, x in objects.items() if x["name"] == a.root), None)
    if root is None:
        raise SystemExit("Root not found: " + a.root)

    go_ids = []
    seen = set()

    def walk(go):
        if go in seen:
            return
        seen.add(go)
        go_ids.append(go)
        t = t_by_go.get(go)
        if t:
            for tid in children.get(t["id"], []):
                child = go_by_tid.get(tid)
                if child is not None:
                    walk(child)

    walk(root)

    mesh_filter_components = [
        x for go in go_ids for x in mf.get(go, [])
    ]
    mesh_refs = {}
    null_mesh_filters = 0
    builtin_component_counts = collections.Counter()

    for item in mesh_filter_components:
        mesh_ref = item.get("mesh") or {}
        mesh_guid = str(mesh_ref.get("guid", "")).lower()
        file_id = str(mesh_ref.get("fileID", ""))

        if not mesh_guid or not file_id or file_id == "0":
            null_mesh_filters += 1
            continue

        key = (mesh_guid, file_id)
        mesh_refs[key] = mesh_ref

        if mesh_guid == mod.BUILTIN_MESH_GUID:
            try:
                builtin_name = mod.BUILTIN_MESH_FILEIDS.get(int(file_id))
            except (TypeError, ValueError):
                builtin_name = None
            if builtin_name:
                builtin_component_counts[builtin_name] += 1

    matrefs = {
        x["guid"].lower()
        for go in go_ids
        for r in mr.get(go, [])
        for x in r["materials"]
        if x.get("guid")
    }

    result = {
        "scene": str(scene),
        "root": a.root,
        "gameObjects": len(go_ids),
        "meshFilterComponents": len(mesh_filter_components),
        "rendererComponents": sum(len(mr.get(x, [])) for x in go_ids),
        "uniqueMeshGUIDs": len({key[0] for key in mesh_refs}),
        "uniqueMeshReferences": len(mesh_refs),
        "decodedMeshes": 0,
        "builtinMeshesResolved": 0,
        "builtinMeshFilterComponents": sum(builtin_component_counts.values()),
        "builtinMeshTypes": dict(builtin_component_counts),
        "nullMeshFilters": null_mesh_filters,
        "resolvedMeshFilterComponents": 0,
        "vertices": 0,
        "indices": 0,
        "submeshes": 0,
        "materialSlots": sum(
            len(r["materials"]) for go in go_ids for r in mr.get(go, [])
        ),
        "uniqueMaterials": len(matrefs),
        "mainTextureRefs": 0,
        "resolvedMainTextures": 0,
        "withNormals": 0,
        "withUV0": 0,
        "indexFormatCounts": collections.Counter(),
        "errors": [],
        "warnings": [],
    }

    resolved_keys = set()
    for mesh_guid, file_id in sorted(mesh_refs):
        if mesh_guid == mod.BUILTIN_MESH_GUID:
            try:
                mesh = mod.parse_builtin_mesh(file_id)
                _validate_mesh_data(
                    mesh, mesh.get("indexFormat", 0),
                    f"{mesh['name']} (fileID {file_id})", result
                )
                result["builtinMeshesResolved"] += 1
                resolved_keys.add((mesh_guid, file_id))
            except Exception as exc:
                result["errors"].append({
                    "guid": mesh_guid,
                    "fileID": file_id,
                    "error": f"Unity built-in mesh unresolved: {exc}",
                })
            continue

        path = guid.get(mesh_guid)
        if not path:
            result["errors"].append({
                "guid": mesh_guid,
                "fileID": file_id,
                "error": "Mesh GUID unresolved",
            })
            continue

        try:
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            index_format = mod.number(text, "m_IndexFormat", 0)
            mesh = mod.parse_mesh(path)
            if not mesh:
                raise ValueError("Referenced asset does not contain a decodable Mesh")
            _validate_mesh_data(mesh, index_format, str(path), result)
            resolved_keys.add((mesh_guid, file_id))
        except Exception as exc:
            result["errors"].append({"path": str(path), "error": str(exc)})

    result["resolvedMeshFilterComponents"] = sum(
        1
        for item in mesh_filter_components
        if item.get("mesh")
        and (
            (str(item["mesh"].get("guid", "")).lower(),
             str(item["mesh"].get("fileID", ""))) in resolved_keys
        )
    )
    result["indexFormatCounts"] = dict(result["indexFormatCounts"])

    for mesh_guid in matrefs:
        path = guid.get(mesh_guid)
        if not path:
            continue
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        tm = re.search(
            r"_MainTex:\s*\n(.*?)(?=\n\s*_[A-Za-z0-9]+:|\n\s*\})",
            text,
            re.S,
        )
        if tm:
            tx = re.search(
                r"m_Texture:\s*\{[^}]*guid:\s*([0-9a-fA-F]{32})",
                tm.group(1),
            )
            if tx:
                result["mainTextureRefs"] += 1
                if tx.group(1).lower() in guid:
                    result["resolvedMainTextures"] += 1
                else:
                    result["warnings"].append({
                        "material": path.name,
                        "textureGUID": tx.group(1),
                        "warning": "Main texture unresolved",
                    })

    # Particle systems are runtime emitters, not static MeshFilter geometry.
    # Record their presence explicitly so the PMX report does not imply they
    # were baked into static PMX geometry.
    selected_component_ids = {
        component_id
        for go in go_ids
        for component_id in objects.get(go, {}).get("components", [])
    }
    scene_text = scene.read_text(encoding="utf-8-sig", errors="replace")
    particle_systems = 0
    particle_system_renderers = 0
    particle_renderer_builtin_meshes = collections.Counter()
    for class_id, component_id, document in mod.docs(scene_text):
        if component_id not in selected_component_ids:
            continue
        if class_id == 198:
            particle_systems += 1
        elif class_id == 199:
            particle_system_renderers += 1
            particle_mesh = mod.ref(document, "m_Mesh")
            if particle_mesh:
                p_guid = str(particle_mesh.get("guid", "")).lower()
                p_file_id = str(particle_mesh.get("fileID", ""))
                if p_guid == mod.BUILTIN_MESH_GUID:
                    p_name = mod.BUILTIN_MESH_FILEIDS.get(
                        int(p_file_id) if p_file_id.isdigit() else -1
                    )
                    if p_name:
                        particle_renderer_builtin_meshes[p_name] += 1

    result["particleSystemComponents"] = particle_systems
    result["particleSystemRendererComponents"] = particle_system_renderers
    result["renderersIncludingParticles"] = (
        result["rendererComponents"] + particle_system_renderers
    )
    result["particleSystemRendererBuiltinMeshes"] = dict(
        particle_renderer_builtin_meshes
    )
    if particle_systems:
        result["warnings"].append({
            "warning": (
                "Unity ParticleSystem components are dynamic runtime effects. "
                "They remain represented in the recovered hierarchy, but are "
                "not baked as live particle simulations into static PMX geometry."
            ),
            "particleSystems": particle_systems,
            "particleSystemRenderers": particle_system_renderers,
        })

    result["ok"] = (
        not result["errors"]
        and result["decodedMeshes"] == result["uniqueMeshReferences"]
        and result["resolvedMeshFilterComponents"]
            == result["meshFilterComponents"] - result["nullMeshFilters"]
    )

    out = Path(a.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print("REPORT:", out)
    if not result["ok"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
