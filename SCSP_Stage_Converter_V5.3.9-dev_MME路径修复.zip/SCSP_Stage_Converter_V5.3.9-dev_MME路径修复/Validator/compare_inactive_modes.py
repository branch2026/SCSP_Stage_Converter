# -*- coding: utf-8 -*-
"""SCSP V2.4.9: compare existing include/exclude quality reports; read-only.

No Unity project / Blender / PMX files are opened, created, or modified.
Only the explicitly requested comparison JSON and TXT are written.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPORT_SCHEMA = 'scsp-inactive-mode-comparison-v1'
ACCEPTED_MESH_SCHEMAS = {
    'scsp-mesh-channel-diagnostics-v4',
    'scsp-mesh-channel-diagnostics-v5',
    'scsp-mesh-channel-diagnostics-v6',
}


class ComparisonError(ValueError):
    """Raised when a report is invalid, incompatible, or output cannot be safely written."""


def _require_dict(value: Any, label: str) -> dict:
    if not isinstance(value, dict):
        raise ComparisonError(f'{label} 必须是 JSON 对象。')
    return value


def _int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ComparisonError(f'{label} 必须是非负整数。')
    return value


def _path_key(value: Any) -> str:
    return str(value or '').strip().replace('\\', '/').rstrip('/').casefold()


def _read_json(path: Path) -> dict:
    try:
        with path.open('r', encoding='utf-8-sig') as stream:
            result = json.load(stream)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ComparisonError(f'无法读取 JSON 报告：{path}（{exc}）') from exc
    return _require_dict(result, str(path))


def _policy(report: dict, label: str) -> str:
    obj = _require_dict(report.get('objects'), f'{label}.objects')
    mesh = _require_dict(report.get('meshDiagnostics'), f'{label}.meshDiagnostics')
    if mesh.get('schema') not in ACCEPTED_MESH_SCHEMAS:
        raise ComparisonError(
            f'{label} 缺少兼容的对象级 Mesh 诊断（需要 v4/v5/v6）。'
        )
    p1, p2 = obj.get('inactivePolicy'), mesh.get('conversionPolicy')
    if p1 != p2 or p1 not in ('include', 'exclude'):
        raise ComparisonError(f'{label} 的 inactivePolicy 与 conversionPolicy 不一致或无效。')
    return p1


def _validate_report(report: dict, label: str, expected_policy: str) -> None:
    if report.get('schema') != 'scsp-stage-quality-report-v1':
        raise ComparisonError(f'{label} 不是受支持的 SCSP 质量报告。')
    stage = _require_dict(report.get('stage'), f'{label}.stage')
    if not stage.get('root') or not stage.get('scene') or not stage.get('project'):
        raise ComparisonError(f'{label} 缺少舞台根对象、场景或项目路径。')
    for key in ('source', 'rebuild', 'pmx', 'summary'):
        _require_dict(report.get(key), f'{label}.{key}')
    if _policy(report, label) != expected_policy:
        raise ComparisonError(f'{label} 需要 {expected_policy} 策略的报告。')
    if not isinstance(report['objects'].get('inactiveInHierarchyObjects'), list):
        raise ComparisonError(f'{label} 缺少 inactive 对象清单。')
    if not isinstance(report['meshDiagnostics'].get('scopes'), dict):
        raise ComparisonError(f'{label} 缺少 Mesh 分范围统计。')


def _check_same_stage(include: dict, exclude: dict) -> None:
    for field in ('root', 'scene', 'project'):
        left = include['stage'].get(field)
        right = exclude['stage'].get(field)
        if _path_key(left) != _path_key(right):
            raise ComparisonError(
                f'两份报告的舞台标识不一致：stage.{field} 为 {left!r} / {right!r}。'
            )
    if include['source'] != exclude['source']:
        raise ComparisonError('两份报告的 Unity 源资源统计不一致，不能作为同一场景 A/B 对照。')


def _count(report: dict, *path: str) -> int:
    value: Any = report
    for key in path:
        value = _require_dict(value, '.'.join(path))[key] if isinstance(value, dict) and key in value else None
    return _int(value, '.'.join(path))


def _go_id(item: dict) -> int:
    return _int(item.get('gameObjectFileID'), 'gameObjectFileID')


def _read_mesh_inventory(report: dict, label: str) -> dict | None:
    """Read and validate the V2.4.7 full Mesh identity inventory when present."""
    diag = report.get('meshDiagnostics', {})
    if diag.get('schema') != 'scsp-mesh-channel-diagnostics-v6':
        return None
    rows = diag.get('meshInventory')
    summary = diag.get('meshInventorySummary')
    if not isinstance(rows, list) or not isinstance(summary, dict):
        return {
            'rows': [], 'by_id': {}, 'available': True, 'complete': False,
            'identity_complete': False, 'duplicate_count': 0,
            'invalid_identity_count': 0, 'expected_count': _count(diag, 'uniqueMeshReferences'),
            'summary': summary if isinstance(summary, dict) else {},
            'label': label,
        }
    by_id: dict[tuple[str, str], dict] = {}
    duplicate_count = 0
    invalid_identity_count = 0
    for row in rows:
        if not isinstance(row, dict):
            invalid_identity_count += 1
            continue
        identity = (str(row.get('meshGUID') or '').lower(), str(row.get('meshFileID') or ''))
        if not re.fullmatch(r'[0-9a-f]{32}', identity[0]) or identity[1] in ('', '0'):
            invalid_identity_count += 1
            continue
        if identity in by_id:
            duplicate_count += 1
            continue
        by_id[identity] = row
    expected_count = _count(diag, 'uniqueMeshReferences')
    complete = (
        summary.get('complete') is True
        and len(rows) == expected_count
        and len(by_id) == len(rows)
        and duplicate_count == 0
        and invalid_identity_count == 0
    )
    identity_complete = (
        summary.get('identityComplete') is True
        and invalid_identity_count == 0
        and len(by_id) == len(rows)
    )
    return {
        'rows': rows,
        'by_id': by_id,
        'available': True,
        'complete': complete,
        'identity_complete': identity_complete,
        'duplicate_count': duplicate_count,
        'invalid_identity_count': invalid_identity_count,
        'expected_count': expected_count,
        'summary': summary,
        'label': label,
    }


def _derive_mesh_inventory(include: dict, exclude: dict) -> dict:
    """Derive exact excluded-only Mesh identities from either V2.4.7 report.

    Prefer the include inventory because it describes every source occurrence.
    The exclude report's skippedInactive IDs then partition those occurrences into
    included, excluded-only, and shared references without guessing any GUID.
    """
    include_inventory = _read_mesh_inventory(include, 'include')
    exclude_inventory = _read_mesh_inventory(exclude, 'exclude')
    source_inventory = next((item for item in (include_inventory, exclude_inventory) if item and item.get('complete')), include_inventory or exclude_inventory)
    skipped = exclude['rebuild'].get('skippedInactive') or []
    excluded_go_ids = {_go_id(row) for row in skipped}

    expected_excluded_only = _count(exclude, 'meshDiagnostics', 'excludedOnlyUniqueMeshReferences')
    expected_shared = _int(exclude['meshDiagnostics'].get('sharedMeshReferencesAcrossIncludedAndExcludedObjects', 0), 'meshDiagnostics.sharedMeshReferencesAcrossIncludedAndExcludedObjects')
    mesh_refs_by_go: dict[int, dict[tuple[str, str], dict]] = {}
    excluded_only_meshes: list[dict] = []
    shared_meshes: list[dict] = []
    material_index: dict[tuple[str, str, str], dict] = {}
    invalid_occurrence_count = 0

    if source_inventory:
        for raw in source_inventory['rows']:
            if not isinstance(raw, dict):
                continue
            identity = (str(raw.get('meshGUID') or '').lower(), str(raw.get('meshFileID') or ''))
            if not re.fullmatch(r'[0-9a-f]{32}', identity[0]) or identity[1] in ('', '0'):
                continue
            occurrences = raw.get('gameObjects')
            if not isinstance(occurrences, list):
                invalid_occurrence_count += 1
                continue
            excluded_occurrences = []
            included_occurrences = []
            for occurrence in occurrences:
                if not isinstance(occurrence, dict):
                    invalid_occurrence_count += 1
                    continue
                try:
                    go_id = _go_id(occurrence)
                except ComparisonError:
                    invalid_occurrence_count += 1
                    continue
                if go_id in excluded_go_ids:
                    excluded_occurrences.append(occurrence)
                else:
                    included_occurrences.append(occurrence)
            if not excluded_occurrences:
                continue
            mesh_row = dict(raw)
            mesh_row['scope'] = 'shared' if included_occurrences else 'excludedOnly'
            mesh_row['excludedGameObjects'] = excluded_occurrences
            mesh_row['includedGameObjects'] = included_occurrences
            if included_occurrences:
                shared_meshes.append(mesh_row)
            else:
                excluded_only_meshes.append(mesh_row)

            for occurrence in excluded_occurrences:
                go_id = _go_id(occurrence)
                occurrence_materials = occurrence.get('materials', [])
                if not isinstance(occurrence_materials, list):
                    occurrence_materials = []
                mesh_detail = {
                    'meshName': raw.get('meshName'),
                    'meshGUID': identity[0],
                    'meshFileID': identity[1],
                    'assetPath': raw.get('assetPath'),
                    'hasNormals': raw.get('hasNormals'),
                    'hasUV0': raw.get('hasUV0'),
                    'vertexCount': raw.get('vertexCount'),
                    'decodeStatus': raw.get('decodeStatus', 'unknown'),
                    'scope': mesh_row['scope'],
                    'meshFilterComponentFileIDs': occurrence.get('meshFilterComponentFileIDs', []),
                    'rendererMaterials': occurrence_materials,
                }
                mesh_refs_by_go.setdefault(go_id, {})[identity] = mesh_detail

                if not included_occurrences:
                    for material in occurrence_materials:
                        if not isinstance(material, dict):
                            continue
                        material_guid = str(material.get('materialGUID') or '').lower()
                        material_file_id = str(material.get('materialFileID') or '')
                        material_name = str(material.get('name') or '<未知材质>')
                        # The fallback key is for deduplication only; no synthetic ID is emitted.
                        key = (material_guid, material_file_id, material_name if not material_guid else '')
                        if key not in material_index:
                            material_index[key] = {
                                'name': material_name,
                                'materialGUID': material_guid,
                                'materialFileID': material_file_id,
                                'assetPath': material.get('assetPath', ''),
                                'mainTextureGUID': material.get('mainTextureGUID', ''),
                                'mainTextureFileID': material.get('mainTextureFileID', 0),
                                'mainTextureAssetPath': material.get('mainTextureAssetPath', ''),
                                'mainTextureAssigned': material.get('mainTextureAssigned'),
                                'mainTextureResolved': material.get('mainTextureResolved'),
                                'identityComplete': bool(re.fullmatch(r'[0-9a-f]{32}', material_guid) and material_file_id not in ('', '0')),
                                'usedByMeshes': [],
                                'gameObjects': [],
                            }
                        target = material_index[key]
                        mesh_use = {'meshName': raw.get('meshName'), 'meshGUID': identity[0], 'meshFileID': identity[1]}
                        if mesh_use not in target['usedByMeshes']:
                            target['usedByMeshes'].append(mesh_use)
                        go_use = {
                            'gameObjectName': occurrence.get('gameObjectName'),
                            'gameObjectFileID': go_id,
                            'hierarchyPath': occurrence.get('hierarchyPath'),
                        }
                        if go_use not in target['gameObjects']:
                            target['gameObjects'].append(go_use)

    cross_report_match = None
    cross_report_mismatch_count = None
    cross_report_occurrence_match = None
    cross_report_occurrence_mismatch_count = None
    report_summary_scope_match = None
    if include_inventory and exclude_inventory:
        inc_ids = set(include_inventory['by_id'])
        exc_ids = set(exclude_inventory['by_id'])
        cross_report_match = inc_ids == exc_ids
        cross_report_mismatch_count = len(inc_ids.symmetric_difference(exc_ids))
        occurrence_mismatches = 0
        for identity in inc_ids.intersection(exc_ids):
            def occurrence_keys(row):
                result = set()
                for occurrence in row.get('gameObjects', []) if isinstance(row, dict) else []:
                    if not isinstance(occurrence, dict):
                        continue
                    try:
                        go_id = _go_id(occurrence)
                    except ComparisonError:
                        continue
                    component_ids = occurrence.get('meshFilterComponentFileIDs', [])
                    if not isinstance(component_ids, list):
                        component_ids = []
                    result.add((go_id, tuple(sorted(str(value) for value in component_ids))))
                return result
            if occurrence_keys(include_inventory['by_id'][identity]) != occurrence_keys(exclude_inventory['by_id'][identity]):
                occurrence_mismatches += 1
        cross_report_occurrence_match = occurrence_mismatches == 0
        cross_report_occurrence_mismatch_count = occurrence_mismatches
        report_summary_scope_match = bool(
            include_inventory['summary'].get('scopeCountsMatch') is True
            and exclude_inventory['summary'].get('scopeCountsMatch') is True
        )

    inventory_complete = bool(source_inventory and source_inventory['complete'])
    identity_complete = bool(source_inventory and source_inventory['identity_complete'])
    scope_counts_match = bool(
        source_inventory
        and len(excluded_only_meshes) == expected_excluded_only
        and len(shared_meshes) == expected_shared
    )
    identified_excluded = [
        item for item in excluded_only_meshes
        if item.get('meshGUID') and str(item.get('meshFileID') or '') not in ('', '0')
    ]
    material_rows = sorted(
        material_index.values(),
        key=lambda item: (str(item.get('name', '')).casefold(), str(item.get('materialGUID', ''))),
    )
    return {
        'available': bool(source_inventory),
        'source': source_inventory['label'] if source_inventory else None,
        'schema': 'scsp-mesh-channel-diagnostics-v6' if source_inventory else None,
        'sourceUniqueMeshReferences': source_inventory['expected_count'] if source_inventory else None,
        'recordedUniqueMeshReferences': len(source_inventory['rows']) if source_inventory else 0,
        'inventoryComplete': inventory_complete,
        'identityComplete': identity_complete,
        'duplicateIdentityCount': source_inventory['duplicate_count'] if source_inventory else 0,
        'invalidIdentityCount': source_inventory['invalid_identity_count'] if source_inventory else 0,
        'invalidOccurrenceCount': invalid_occurrence_count,
        'excludedOnlyUniqueMeshesExpected': expected_excluded_only,
        'excludedOnlyUniqueMeshesIdentified': len(identified_excluded),
        'unidentifiedExcludedOnlyMeshes': max(0, expected_excluded_only - len(identified_excluded)),
        'derivedExcludedOnlyUniqueMeshes': len(excluded_only_meshes),
        'derivedSharedUniqueMeshes': len(shared_meshes),
        'scopeCountsMatch': scope_counts_match,
        'crossReportIdentityMatch': cross_report_match,
        'crossReportIdentityMismatchCount': cross_report_mismatch_count,
        'crossReportOccurrenceMatch': cross_report_occurrence_match,
        'crossReportOccurrenceMismatchCount': cross_report_occurrence_mismatch_count,
        'reportSummaryScopeMatch': report_summary_scope_match,
        'meshRefsByGameObject': mesh_refs_by_go,
        'excludedOnlyMeshes': sorted(
            identified_excluded,
            key=lambda item: (str(item.get('meshName') or '').casefold(), str(item.get('meshGUID') or '')),
        ),
        'sharedMeshes': shared_meshes,
        'excludedMaterialInventory': material_rows,
        'excludedMaterialIdentityCount': sum(item['identityComplete'] for item in material_rows),
        'excludedMaterialUnidentifiedCount': sum(not item['identityComplete'] for item in material_rows),
    }


def _excluded_object_details(include: dict, exclude: dict, inventory_data: dict | None = None) -> tuple[list, list, list]:
    inc_objects = {_go_id(v): v for v in include['objects']['inactiveInHierarchyObjects']}
    exc_objects = {_go_id(v): v for v in exclude['objects']['inactiveInHierarchyObjects']}
    if len(inc_objects) != len(include['objects']['inactiveInHierarchyObjects']):
        raise ComparisonError('include 清单中发现重复 GameObject fileID。')
    if len(exc_objects) != len(exclude['objects']['inactiveInHierarchyObjects']):
        raise ComparisonError('exclude 清单中发现重复 GameObject fileID。')

    skipped = exclude['rebuild'].get('skippedInactive')
    if not isinstance(skipped, list):
        raise ComparisonError('exclude 重建报告缺少 skippedInactive 清单。')
    by_id: dict[int, dict] = {}
    for row in skipped:
        fid = _go_id(row)
        if fid in by_id:
            raise ComparisonError(f'skippedInactive 存在重复 GameObject fileID={fid}。')
        by_id[fid] = row

    mesh_refs_by_go: dict[int, dict[tuple[str, str], dict]] = {}
    if inventory_data and inventory_data.get('available'):
        mesh_refs_by_go = inventory_data.get('meshRefsByGameObject', {})
    else:
        # Legacy v4/v5 reports only preserve GUIDs for channel-deficient Meshes.
        diag = exclude['meshDiagnostics']
        for key in ('excludedOnlyMissingEither', 'excludedOnlyMissingNormals', 'excludedOnlyMissingUV0'):
            for mesh in diag.get(key, []):
                identity = (str(mesh.get('meshGUID', '')), str(mesh.get('meshFileID', '')))
                if not any(identity):
                    continue
                for occurrence in mesh.get('gameObjects', []):
                    if occurrence.get('conversionIncluded') is not False:
                        continue
                    fid = _go_id(occurrence)
                    mesh_refs_by_go.setdefault(fid, {})[identity] = {
                        'meshName': mesh.get('meshName'),
                        'meshGUID': identity[0],
                        'meshFileID': identity[1],
                        'assetPath': mesh.get('assetPath'),
                        'hasNormals': mesh.get('hasNormals'),
                        'hasUV0': mesh.get('hasUV0'),
                        'meshFilterComponentFileIDs': occurrence.get('meshFilterComponentFileIDs', []),
                        'normalEvidence': mesh.get('normalEvidence'),
                    }

    all_rows: list[dict] = []
    for fid, item in sorted(exc_objects.items(), key=lambda entry: (str(entry[1].get('hierarchyPath', '')).casefold(), entry[0])):
        skip = by_id.get(fid, {})
        records = list(mesh_refs_by_go.get(fid, {}).values())
        blocker = item.get('conversionBlockingInactiveObject')
        all_rows.append({
            'name': item.get('name'),
            'gameObjectFileID': fid,
            'hierarchyPath': item.get('hierarchyPath'),
            'activeSelf': item.get('activeSelf'),
            'conversionDecision': item.get('conversionDecision'),
            'hierarchyInactiveCause': item.get('hierarchyInactiveCause'),
            'conversionBlockingInactiveObject': blocker,
            'meshFilterCount': skip.get('meshFilters'),
            'identifiedMeshReferences': records,
            'wasIncludedInIncludeReport': inc_objects.get(fid, {}).get('conversionIncluded'),
        })
    mesh_rows = [row for row in all_rows if isinstance(row['meshFilterCount'], int) and row['meshFilterCount'] > 0]
    known: dict[tuple[str, str], dict] = {}
    for row in all_rows:
        for mesh in row['identifiedMeshReferences']:
            known[(mesh['meshGUID'], mesh['meshFileID'])] = mesh
    return all_rows, mesh_rows, list(known.values())


def _texture_refs(report: dict) -> list[str]:
    tex = _require_dict(report['pmx'].get('textureValidation'), 'pmx.textureValidation')
    refs = tex.get('normalized_references')
    if not isinstance(refs, list) or not all(isinstance(x, str) for x in refs):
        raise ComparisonError('PMX 报告缺少 normalized_references 贴图清单。')
    return refs


def _same_sets(left: list[str], right: list[str]) -> tuple[list[str], list[str]]:
    # Names are compared case-insensitively with slash normalization for Windows.
    la = {_path_key(x): x for x in left}
    rb = {_path_key(x): x for x in right}
    return ([la[k] for k in sorted(la.keys() - rb.keys())],
            [rb[k] for k in sorted(rb.keys() - la.keys())])


def _calc_delta(include: dict, exclude: dict, name: str, *path: str) -> dict:
    a, b = _count(include, *path), _count(exclude, *path)
    return {'name': name, 'include': a, 'exclude': b, 'removedByExclude': a - b}


def compare_reports(include: dict, exclude: dict, include_path: str = '', exclude_path: str = '') -> dict:
    """Return an independent, audit-friendly report; no files are accessed."""
    _validate_report(include, 'include', 'include')
    _validate_report(exclude, 'exclude', 'exclude')
    _check_same_stage(include, exclude)

    diag_a, diag_b = include['meshDiagnostics'], exclude['meshDiagnostics']
    scope_a, scope_b = diag_a['scopes'], diag_b['scopes']
    obj_a, obj_b = include['objects'], exclude['objects']
    rebuild_a, rebuild_b = include['rebuild'], exclude['rebuild']
    pmx_a, pmx_b = include['pmx'], exclude['pmx']
    parser_a, parser_b = pmx_a['parser'], pmx_b['parser']

    differences = {
        'gameObjects': _calc_delta(include, exclude, 'GameObject', 'objects', 'conversionIncludedGameObjects'),
        'meshFilters': _calc_delta(include, exclude, 'MeshFilter', 'meshDiagnostics', 'conversionMeshFilterComponents'),
        'uniqueMeshes': _calc_delta(include, exclude, 'unique Mesh', 'meshDiagnostics', 'conversionUniqueMeshReferences'),
        'blenderMeshObjects': _calc_delta(include, exclude, 'Blender mesh objects', 'rebuild', 'meshObjects'),
        'blenderTriangles': _calc_delta(include, exclude, 'Blender triangles', 'rebuild', 'triangles'),
        'pmxVertices': _calc_delta(include, exclude, 'PMX vertices', 'pmx', 'parser', 'vertices'),
        'pmxFaces': _calc_delta(include, exclude, 'PMX faces', 'pmx', 'parser', 'faces'),
        'pmxMaterials': _calc_delta(include, exclude, 'PMX materials', 'pmx', 'parser', 'materials'),
        'pmxTextures': _calc_delta(include, exclude, 'PMX textures', 'pmx', 'parser', 'textures'),
        'missingNormals': _calc_delta(include, exclude, 'missing normals', 'meshDiagnostics', 'conversionMissingNormalsCount'),
        'missingUV0': _calc_delta(include, exclude, 'missing UV0', 'meshDiagnostics', 'conversionMissingUV0Count'),
    }
    inventory_data = _derive_mesh_inventory(include, exclude)
    all_go, mesh_go, legacy_known_meshes = _excluded_object_details(include, exclude, inventory_data)
    if inventory_data.get('available'):
        known_meshes = inventory_data['excludedOnlyMeshes']
        known_count = len(known_meshes)
    else:
        known_meshes = legacy_known_meshes
        known_count = len(known_meshes)
    excluded_unique = _count(exclude, 'meshDiagnostics', 'excludedOnlyUniqueMeshReferences')
    inventory_data['excludedOnlyUniqueMeshesIdentified'] = known_count
    inventory_data['unidentifiedExcludedOnlyMeshes'] = max(0, excluded_unique - known_count)
    inc_tex, exc_tex = _texture_refs(include), _texture_refs(exclude)
    removed_textures, unexpectedly_added_textures = _same_sets(inc_tex, exc_tex)

    checks: list[dict] = []
    def check(name: str, ok: bool, message: str, severity: str = 'WARNING') -> None:
        checks.append({
            'name': name,
            'status': 'PASS' if ok else severity,
            'message': message,
        })

    source_total = _count(include, 'source', 'gameObjects')
    check('全量对象守恒',
          _count(include, 'objects', 'conversionIncludedGameObjects') == source_total
          and _count(include, 'objects', 'conversionExcludedGameObjects') == 0
          and _count(exclude, 'objects', 'conversionIncludedGameObjects')
          + _count(exclude, 'objects', 'conversionExcludedGameObjects') == source_total,
          'include 应纳入整个所选根子树，exclude 纳入数与排除数应等于源对象数。')
    check('inactive 对象清单完整',
          len(all_go) == _count(exclude, 'objects', 'conversionExcludedGameObjects')
          and len(all_go) == len(rebuild_b.get('skippedInactive', [])),
          '不勾选报告的 inactive 对象清单应与重建跳过记录一致。')
    check('include/exclude 对象逐项配对',
          all(row['wasIncludedInIncludeReport'] is True for row in all_go)
          and all(row['conversionDecision'] in ('excluded_self_inactive', 'excluded_by_inactive_ancestor') for row in all_go),
          'exclude 中的对象应能在 include 中找到，且记录自身或祖先 inactive 排除原因。')
    check('MeshFilter 组件守恒',
          _count(include, 'meshDiagnostics', 'conversionMeshFilterComponents')
          == _count(include, 'source', 'meshFilterComponents')
          and _count(exclude, 'meshDiagnostics', 'conversionMeshFilterComponents')
          + _count(exclude, 'meshDiagnostics', 'excludedMeshFilterComponents')
          == _count(exclude, 'source', 'meshFilterComponents')
          and sum(int(x.get('meshFilters', 0)) for x in rebuild_b.get('skippedInactive', []))
          == _count(exclude, 'meshDiagnostics', 'excludedMeshFilterComponents')
          and differences['meshFilters']['removedByExclude']
          == _count(exclude, 'meshDiagnostics', 'excludedMeshFilterComponents'),
          '参与与排除的 MeshFilter 应合计等于源数量；跳过清单也应一致。')
    check('唯一 Mesh 资源守恒',
          _count(include, 'meshDiagnostics', 'conversionUniqueMeshReferences')
          == _count(include, 'source', 'uniqueMeshReferences')
          and _count(exclude, 'meshDiagnostics', 'conversionUniqueMeshReferences')
          + excluded_unique == _count(exclude, 'source', 'uniqueMeshReferences')
          and differences['uniqueMeshes']['removedByExclude'] == excluded_unique
          and known_count <= excluded_unique,
          'Shared 属于 Included 子集；只有 Excluded-only 应计入真正被移除的唯一 Mesh。')
    check('源范围与诊断统计一致',
          scope_a.get('source') == scope_b.get('source')
          and diag_a.get('scopeAccounting', {}).get('countsMatch') is True
          and diag_b.get('scopeAccounting', {}).get('countsMatch') is True,
          '两组的 Source 统计及各自 Scope Accounting 应一致且通过。')
    check('缺失法线 / UV 范围守恒',
          all(
              _count(include, 'meshDiagnostics', 'conversion' + suffix + 'Count')
              == _count(exclude, 'meshDiagnostics', 'conversion' + suffix + 'Count')
              + _count(exclude, 'meshDiagnostics', 'excludedOnly' + suffix + 'Count')
              for suffix in ('MissingNormals', 'MissingUV0', 'MissingEither')
          ), '缺失通道统计应满足 include = exclude-Included + exclude-Excluded-only。')
    check('Blender Mesh 对象数量对应 MeshFilter',
          _count(include, 'rebuild', 'meshObjects') == _count(include, 'meshDiagnostics', 'conversionMeshFilterComponents')
          and _count(exclude, 'rebuild', 'meshObjects') == _count(exclude, 'meshDiagnostics', 'conversionMeshFilterComponents'),
          '两种模式的 Blender Mesh 对象数应与各自参与转换的 MeshFilter 数一致。')
    check('PMX 面数对应 Blender 三角面',
          _count(include, 'pmx', 'parser', 'faces') == _count(include, 'rebuild', 'triangles')
          and _count(exclude, 'pmx', 'parser', 'faces') == _count(exclude, 'rebuild', 'triangles')
          and differences['pmxFaces']['removedByExclude'] == differences['blenderTriangles']['removedByExclude'],
          '检查两组 PMX 面数与 Blender 三角面数，以及两组差值。')
    check('PMX / 贴图报告完成',
          all(
              x.get('status') == 'completed'
              and x.get('parser', {}).get('status') == 'PASSED'
              and x.get('textureValidation', {}).get('status') == 'PASSED'
              and x.get('textureValidation', {}).get('unresolved_count') == 0
              and x.get('textureValidation', {}).get('ambiguous_count') == 0
              for x in (pmx_a, pmx_b)
          ), '两组 PMX 与贴图报告均应成功，且无未解决或歧义引用。')
    check('PMX 贴图表引用计数',
          len(inc_tex) == _count(include, 'pmx', 'parser', 'textures')
          and len(exc_tex) == _count(exclude, 'pmx', 'parser', 'textures')
          and _count(include, 'pmx', 'textureValidation', 'reference_count') == len(inc_tex)
          and _count(exclude, 'pmx', 'textureValidation', 'reference_count') == len(exc_tex),
          '贴图引用清单与 PMX parser 应一致。')
    check('exclude 没有意外新增贴图',
          not unexpectedly_added_textures,
          'exclude 贴图应是 include 贴图的子集；新增贴图属于需要核查的差异。')
    check('PMX 主要数量变化方向',
          all(x['removedByExclude'] >= 0 for x in differences.values()),
          '正常排除 inactive 后，主要数量通常不会增加；增加需要人工核实。')
    inventory_ok = (
        inventory_data.get('available')
        and inventory_data.get('inventoryComplete')
        and inventory_data.get('identityComplete')
        and inventory_data.get('scopeCountsMatch')
        and inventory_data.get('invalidOccurrenceCount') == 0
        and inventory_data.get('unidentifiedExcludedOnlyMeshes') == 0
        and inventory_data.get('crossReportIdentityMatch') is not False
        and inventory_data.get('crossReportOccurrenceMatch') is not False
        and inventory_data.get('reportSummaryScopeMatch') is not False
    )
    check(
        'Mesh 完整资源身份清单',
        bool(inventory_ok),
        ('V2.4.7 完整 Mesh GUID/fileID 清单与排除范围守恒检查通过。'
         if inventory_data.get('available') else
         '输入为旧版 v4/v5 报告，未提供完整 meshInventory；不会推测缺失 GUID。请用 V2.4.7-dev 重新生成至少一份质量报告。'),
        severity='WARNING' if inventory_data.get('available') else 'INFO',
    )

    unexpected = [x for x in checks if x['status'] not in ('PASS', 'INFO')]
    full_inventory_count = excluded_unique - known_count
    limits = []
    if inventory_data.get('available'):
        limits.append(
            f"完整 Mesh 身份清单来自 {inventory_data.get('source')} 报告；记录 {inventory_data.get('recordedUniqueMeshReferences')} / {inventory_data.get('sourceUniqueMeshReferences')} 个唯一 Mesh 引用。"
        )
        limits.append(
            f"Excluded-only Mesh：{known_count}/{excluded_unique} 个已识别；清单完整性={inventory_data.get('inventoryComplete')}；跨报告 GUID/fileID 一致性={inventory_data.get('crossReportIdentityMatch')}。"
        )
        limits.append(
            'Unity 材质身份来自被排除 GameObject 上的 Renderer 材质引用；这是 GameObject 级关联证据，不保证多 MeshFilter / 多 Renderer 场景中的一对一材质归属；同一 GUID 下多个 Material 子资产的名称/MainTex 仍需按 fileID 人工复核。'
        )
    else:
        limits.append('旧版 v4/v5 质量报告不包含完整 Mesh GUID/fileID 资源清单；只能识别缺失法线或 UV0 明细中已经记录的 Mesh。')
        limits.append(
            f'本次可以列出 {len(all_go)} 个排除 GameObject、{len(mesh_go)} 个带 MeshFilter 的对象、{known_count} 个已知 GUID 的 Excluded-only Mesh；其余 {max(0, full_inventory_count)} 个唯一 Mesh 的 GUID 未包含于源报告。'
        )
    limits.extend([
        '本报告列出的材质身份是 Unity 源 Renderer 材质引用；PMX 导出报告仍只提供材质数量，未提供完整 PMX 材质槽身份清单。',
        '本工具不读取真实 PMX 的材质渲染结果或 MMD 实时画面；数量和资源引用一致不等于材质、阴影或动态演出已经视觉验收。',
    ])
    if diag_a.get('schema') == 'scsp-mesh-channel-diagnostics-v5' and include.get('version') == '2.4.4-dev':
        limits.append('旧版 V2.4.5 实机 JSON 的顶层 version 仍写为 2.4.4-dev（历史检查器元数据）；本次以 meshDiagnostics.schema 与 inactivePolicy 为准。')

    return {
        'schema': REPORT_SCHEMA,
        'tool': 'SCSP Stage Converter - Inactive Mode Comparison',
        'toolVersion': '2.4.9-dev',
        'generatedAt': datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'),
        'inputReports': {
            'include': {'path': include_path, 'generatedAt': include.get('generatedAt'), 'qualityHeaderVersion': include.get('version'), 'meshSchema': diag_a.get('schema')},
            'exclude': {'path': exclude_path, 'generatedAt': exclude.get('generatedAt'), 'qualityHeaderVersion': exclude.get('version'), 'meshSchema': diag_b.get('schema')},
        },
        'stage': {key: include['stage'].get(key) for key in ('project', 'scene', 'root')},
        'summary': {
            'status': 'WARNING' if unexpected else 'PASS',
            'checks': len(checks),
            'passed': sum(item['status'] == 'PASS' for item in checks),
            'info': sum(item['status'] == 'INFO' for item in checks),
            'warnings': len(unexpected),
            'qualityChecks': {'include': include.get('summary'), 'exclude': exclude.get('summary')},
            'excludedGameObjects': len(all_go),
            'excludedMeshFilterObjects': len(mesh_go),
            'excludedMeshFilterComponents': _count(exclude, 'meshDiagnostics', 'excludedMeshFilterComponents'),
            'excludedOnlyUniqueMeshes': excluded_unique,
            'identifiedExcludedMeshGUIDCount': known_count,
            'unidentifiedExcludedMeshGUIDCount': max(0, full_inventory_count),
            'meshInventoryAvailable': inventory_data.get('available', False),
            'excludedMaterialIdentityCount': inventory_data.get('excludedMaterialIdentityCount', 0),
            'excludedMaterialUnidentifiedCount': inventory_data.get('excludedMaterialUnidentifiedCount', 0),
        },
        'differences': differences,
        'meshScopes': {'include': scope_a, 'exclude': scope_b},
        'excludedObjects': all_go,
        'excludedMeshFilterObjects': mesh_go,
        'identifiedExcludedOnlyMeshes': sorted(known_meshes, key=lambda x: (str(x.get('meshName') or '').casefold(), str(x.get('meshGUID') or ''))),
        'meshInventoryCoverage': {key: value for key, value in inventory_data.items() if key not in ('meshRefsByGameObject', 'excludedOnlyMeshes', 'sharedMeshes', 'excludedMaterialInventory')},
        'excludedMaterialInventory': inventory_data.get('excludedMaterialInventory', []),
        'pmxTextureDifferences': {
            'removedFromExclude': removed_textures,
            'unexpectedlyAddedInExclude': unexpectedly_added_textures,
            'includeTextureReferences': inc_tex,
            'excludeTextureReferences': exc_tex,
        },
        'checks': checks,
        'limitations': limits,
    }


def render_text(result: dict) -> str:
    s = result['summary']
    lines = [
        'SCSP Stage Converter V2.4.9-dev — inactive GameObject 双模式转换对比 / Excluded Mesh 完整追踪',
        '=' * 78,
        f"舞台：{result['stage'].get('root')}  /  {result['stage'].get('scene')}",
        f"对比结论：{s['status']}（自检 {s['passed']}/{s['checks']} 通过，需复查 {s['warnings']} 项）",
        '说明：只读比较已有质量报告，既不重新转换也不修改 PMX。',
        '', '输入报告', '-' * 78,
        f"include: {result['inputReports']['include']['path']}",
        f"exclude: {result['inputReports']['exclude']['path']}",
        '', '数量对比（removed = include - exclude）', '-' * 78,
        f"{'指标':<23}{'include':>12}{'exclude':>12}{'removed':>12}",
    ]
    for diff in result['differences'].values():
        lines.append(f"{diff['name']:<23}{diff['include']:>12}{diff['exclude']:>12}{diff['removedByExclude']:>12}")
    lines += [
        '', '检查结果', '-' * 78,
    ]
    for check in result['checks']:
        lines.append(f"[{check['status']}] {check['name']}：{check['message']}")
    lines += [
        '', '仅被排除对象引用的 Mesh 统计', '-' * 78,
        f"Excluded-only 唯一 Mesh：{s['excludedOnlyUniqueMeshes']}",
        f"被排除 GameObject：{s['excludedGameObjects']}",
        f"其中带 MeshFilter 的 GameObject：{s['excludedMeshFilterObjects']}",
        f"被排除 MeshFilter 组件：{s['excludedMeshFilterComponents']}",
        f"具备 GUID/fileID 明细的被排除唯一 Mesh：{s['identifiedExcludedMeshGUIDCount']}",
        f"因源报告没有完整 Mesh 资源清单而无法标识的唯一 Mesh：{s['unidentifiedExcludedMeshGUIDCount']}",
        '', 'Mesh 完整资源清单状态', '-' * 78,
        f"资源清单可用：{result['meshInventoryCoverage'].get('available')}；来源：{result['meshInventoryCoverage'].get('source')}；"
        f"完整：{result['meshInventoryCoverage'].get('inventoryComplete')}；GUID/fileID 完整：{result['meshInventoryCoverage'].get('identityComplete')}",
        f"Excluded-only Mesh：{result['meshInventoryCoverage'].get('excludedOnlyUniqueMeshesIdentified', s['identifiedExcludedMeshGUIDCount'])}/{s['excludedOnlyUniqueMeshes']}；"
        f"未识别：{s['unidentifiedExcludedMeshGUIDCount']}；材质身份：{s.get('excludedMaterialIdentityCount', 0)} 个",
        '', '全部被排除的带 MeshFilter 对象（保留 Hierarchy / fileID / 原因）', '-' * 78,
    ]
    for row in result['excludedMeshFilterObjects']:
        blocker = row.get('conversionBlockingInactiveObject') or {}
        lines.append(
            f"- {row.get('name')} [GameObject fileID={row['gameObjectFileID']}; MeshFilter x{row['meshFilterCount']}] "
            f"| {row.get('conversionDecision')}"
        )
        lines.append(f"  路径：{row.get('hierarchyPath')}")
        if blocker:
            lines.append(f"  关闭来源：{blocker.get('name')} [fileID={blocker.get('gameObjectFileID')}] | {blocker.get('hierarchyPath')}")
        for mesh in row['identifiedMeshReferences']:
            lines.append(f"  Mesh：{mesh.get('meshName')} [GUID={mesh.get('meshGUID')}, fileID={mesh.get('meshFileID')}, MeshFilter component fileIDs={mesh.get('meshFilterComponentFileIDs')}]")
            if mesh.get('assetPath'):
                lines.append(f"    资源：{mesh.get('assetPath')} | normals={mesh.get('hasNormals')} | UV0={mesh.get('hasUV0')} | decode={mesh.get('decodeStatus')} | scope={mesh.get('scope')}")
            for material in mesh.get('rendererMaterials', []):
                lines.append(f"    Unity Material：{material.get('name')} [GUID={material.get('materialGUID')}, fileID={material.get('materialFileID')}] | MainTex GUID={material.get('mainTextureGUID')} fileID={material.get('mainTextureFileID')}")
    lines += [
        '', '其他被排除 GameObject（无 MeshFilter）', '-' * 78,
    ]
    for row in result['excludedObjects']:
        if row['meshFilterCount'] != 0:
            continue
        lines.append(f"- {row.get('name')} [fileID={row['gameObjectFileID']}] {row.get('hierarchyPath')} | {row.get('conversionDecision')}")
    lines += [
        '', '仅被排除 Mesh 使用的 Unity Renderer 材质身份', '-' * 78,
    ]
    for material in result.get('excludedMaterialInventory', []):
        lines.append(f"- {material.get('name')} [GUID={material.get('materialGUID') or '未提供'}, fileID={material.get('materialFileID') or '未提供'}] | {material.get('assetPath')}")
        lines.append(f"  MainTex GUID={material.get('mainTextureGUID') or '未提供'} | fileID={material.get('mainTextureFileID')} | 路径={material.get('mainTextureAssetPath')}")
        lines.append(f"  关联 Mesh={len(material.get('usedByMeshes', []))}；关联 GameObject={len(material.get('gameObjects', []))}")
    if not result.get('excludedMaterialInventory'):
        lines.append('（无可用的 Unity Renderer 材质身份明细；旧版报告可能未保存。）')
    lines += [
        '', 'PMX 贴图差异（来自 PMX 导出报告的引用清单）', '-' * 78,
        'include 有、exclude 没有的贴图：',
    ]
    lines += [f"  - {name}" for name in result['pmxTextureDifferences']['removedFromExclude']] or ['  （无）']
    lines.append('exclude 意外新增的贴图：')
    lines += [f"  - {name}" for name in result['pmxTextureDifferences']['unexpectedlyAddedInExclude']] or ['  （无）']
    lines += ['', '证据边界和后续验收说明', '-' * 78]
    for i, limit in enumerate(result['limitations'], 1):
        lines.append(f'{i}. {limit}')
    return '\n'.join(lines) + '\n'


def compare_report_files(include_path: str | Path, exclude_path: str | Path,
                         json_out: str | Path, text_out: str | Path) -> dict:
    paths = [Path(include_path), Path(exclude_path), Path(json_out), Path(text_out)]
    if paths[2].suffix.lower() != '.json' or paths[3].suffix.lower() != '.txt':
        raise ComparisonError('输出文件必须分别为 .json 和 .txt，禁止将对比结果写入 PMX 或其他文件。')
    canon = [p.resolve() for p in paths]
    if len(set(canon)) != 4:
        raise ComparisonError('输入报告和两个输出文件必须是四个不同的路径，不能覆盖源报告。')
    inc, exc = _read_json(paths[0]), _read_json(paths[1])
    result = compare_reports(inc, exc, str(paths[0]), str(paths[1]))
    text_report = render_text(result)
    for p in paths[2:]:
        p.parent.mkdir(parents=True, exist_ok=True)
    # Prepare entire reports before writing; only the comparison outputs are touched.
    paths[2].write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    paths[3].write_text(text_report, encoding='utf-8-sig')
    return result


def launch_gui() -> int:
    # Tkinter is only imported when explicitly invoked; CLI remains headless-safe.
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox
    except ImportError as exc:
        raise ComparisonError('当前 Python 环境不包含 Tkinter，请使用命令行参数。') from exc
    root = tk.Tk()
    root.withdraw()
    try:
        inc = filedialog.askopenfilename(title='选择【勾选 inactive】include 的质量报告 JSON', filetypes=[('JSON', '*.json')], parent=root)
        if not inc:
            return 0
        exc = filedialog.askopenfilename(title='选择【未勾选 inactive】exclude 的质量报告 JSON', filetypes=[('JSON', '*.json')], parent=root)
        if not exc:
            return 0
        try:
            sample = _read_json(Path(inc))
            stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(sample.get('stage', {}).get('root', 'stage')))[:60] or 'stage'
        except ComparisonError:
            stem = 'stage'
        target = filedialog.asksaveasfilename(
            title='保存双模式对比报告 JSON（自动同时生成 TXT）',
            initialdir=str(Path(exc).parent), initialfile=f'{stem}_inactive_mode_comparison.json',
            filetypes=[('JSON', '*.json')], defaultextension='.json', parent=root,
        )
        if not target:
            return 0
        dest = Path(target)
        result = compare_report_files(inc, exc, dest, dest.with_suffix('.txt'))
        messagebox.showinfo('双模式对比完成',
            f"对比结果：{result['summary']['status']}\n"
            f"自检：{result['summary']['passed']}/{result['summary']['checks']}\n"
            f"排除对象：{result['summary']['excludedGameObjects']}\n"
            f"JSON：{dest}\nTXT：{dest.with_suffix('.txt')}", parent=root)
        return 0 if result['summary']['status'] == 'PASS' else 1
    finally:
        root.destroy()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='V2.4.9 双模式质量报告只读对比（支持 v4/v5/v6 Mesh 诊断）。')
    parser.add_argument('--include', help='勾选 inactive GameObject 时的质量报告 JSON')
    parser.add_argument('--exclude', help='未勾选 inactive GameObject 时的质量报告 JSON')
    parser.add_argument('--json-out', help='输出对比 JSON')
    parser.add_argument('--text-out', help='输出对比 TXT')
    parser.add_argument('--gui', action='store_true', help='打开文件选择窗口，适合双击 BAT')
    opts = parser.parse_args(argv)
    try:
        if opts.gui:
            return launch_gui()
        missing = [flag for flag, v in (('--include', opts.include), ('--exclude', opts.exclude), ('--json-out', opts.json_out), ('--text-out', opts.text_out)) if not v]
        if missing:
            parser.error('命令行模式缺少参数：' + ', '.join(missing))
        report = compare_report_files(opts.include, opts.exclude, opts.json_out, opts.text_out)
        print(f"[V2.4.9] 对比 {report['summary']['status']}：{opts.json_out} / {opts.text_out}")
        return 0 if report['summary']['status'] == 'PASS' else 1
    except (ComparisonError, OSError, TypeError, KeyError) as exc:
        print(f'[V2.4.9] 对比失败：{exc}', file=sys.stderr)
        if opts.gui:
            try:
                from tkinter import messagebox
                messagebox.showerror('双模式对比失败', str(exc))
            except Exception:
                pass
        return 2


if __name__ == '__main__':
    sys.exit(main())
