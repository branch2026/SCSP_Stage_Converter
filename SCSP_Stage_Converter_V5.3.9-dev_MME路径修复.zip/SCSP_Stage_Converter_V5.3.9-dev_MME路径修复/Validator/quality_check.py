# -*- coding: utf-8 -*-
"""SCSP Stage Converter V2.4.9 read-only quality inspection with scoped Mesh diagnostics.

This module is deliberately read-only: it inspects the reports and PMX produced
by the V2.3.2 conversion pipeline. It does not modify Unity assets, BLEND files,
PMX files, or texture files.
"""
from __future__ import annotations

import argparse
import collections
import importlib.util
import json
import math
import os
import re
import sys
from datetime import datetime
from pathlib import Path, PureWindowsPath

HERE = Path(__file__).resolve().parent
APP = HERE.parent
REBUILD_SCRIPT = APP / "SceneBuilder" / "rebuild_stage_blender.py"
PMX_EXPORTER_DIR = APP / "PMXExporter"
if str(PMX_EXPORTER_DIR) not in sys.path:
    sys.path.insert(0, str(PMX_EXPORTER_DIR))

try:
    from pmx_texture_table import read_texture_table_bytes
except Exception:  # pragma: no cover - surfaced as a quality-check failure
    read_texture_table_bytes = None


def _read_json(path):
    if not path:
        return None
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except Exception:
        return None


def _count(value):
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _load_scene_parser():
    spec = importlib.util.spec_from_file_location("scsp_quality_scene_parser", REBUILD_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("无法加载 Unity 场景解析器")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _material_usage_for_game_object(go_id, renderer_by_go, guid_index, project, cache):
    """Read material MainTex assignments for one GameObject without changing assets."""
    usage = []
    seen = set()
    for renderer in renderer_by_go.get(go_id, []):
        for material_ref in renderer.get("materials", []):
            material_guid = str(material_ref.get("guid", "")).lower()
            material_file_id = str(material_ref.get("fileID", ""))
            key = (material_guid, material_file_id) if material_guid else ("fileID", material_file_id)
            if key in seen:
                continue
            seen.add(key)
            if not material_guid:
                usage.append({
                    "name": "<内置或空材质引用>",
                    "materialGUID": "",
                    "materialFileID": material_file_id,
                    "mainTextureGUID": "",
                    "mainTextureFileID": 0,
                    "mainTextureAssetPath": "",
                    "mainTextureAssigned": None,
                    "mainTextureResolved": None,
                    "assetPath": "",
                })
                continue
            if key not in cache:
                material_path = guid_index.get(material_guid)
                record = {
                    "name": "GUID:" + material_guid,
                    "materialGUID": material_guid,
                    "materialFileID": material_file_id,
                    "mainTextureGUID": "",
                    "mainTextureFileID": 0,
                    "mainTextureAssetPath": "",
                    "mainTextureAssigned": None,
                    "mainTextureResolved": None,
                    "assetPath": "",
                }
                if material_path and Path(material_path).is_file():
                    try:
                        material_text = Path(material_path).read_text(
                            encoding="utf-8-sig", errors="replace"
                        )
                        name_match = re.search(r"^\s*m_Name:\s*(.*?)\s*$", material_text, re.M)
                        record["name"] = (
                            name_match.group(1).strip(' \"')
                            if name_match else Path(material_path).stem
                        )
                        try:
                            record["assetPath"] = str(Path(material_path).resolve().relative_to(project))
                        except ValueError:
                            record["assetPath"] = str(material_path)
                        main_tex = re.search(
                            r"_MainTex:\s*\n(.*?)(?=\n\s*_[A-Za-z0-9]+:|\Z)",
                            material_text,
                            re.S,
                        )
                        texture_ref_match = (
                            re.search(r"m_Texture:\s*\{([^}]*)\}", main_tex.group(1))
                            if main_tex else None
                        )
                        if texture_ref_match:
                            texture_ref_text = texture_ref_match.group(1)
                            texture_guid_match = re.search(
                                r"guid:\s*([0-9a-fA-F]{32})", texture_ref_text
                            )
                            texture_file_id_match = re.search(
                                r"fileID:\s*(-?\d+)", texture_ref_text
                            )
                            texture_guid = (
                                texture_guid_match.group(1).lower()
                                if texture_guid_match else ""
                            )
                            texture_file_id = (
                                int(texture_file_id_match.group(1))
                                if texture_file_id_match else 0
                            )
                            record["mainTextureGUID"] = texture_guid
                            record["mainTextureFileID"] = texture_file_id
                            record["mainTextureAssigned"] = bool(texture_guid or texture_file_id)
                            if texture_guid:
                                texture_path = guid_index.get(texture_guid)
                                record["mainTextureResolved"] = bool(
                                    texture_path and Path(texture_path).is_file()
                                )
                                if texture_path:
                                    try:
                                        record["mainTextureAssetPath"] = str(
                                            Path(texture_path).resolve().relative_to(project)
                                        )
                                    except ValueError:
                                        record["mainTextureAssetPath"] = str(texture_path)
                            else:
                                record["mainTextureResolved"] = None
                        else:
                            record["mainTextureAssigned"] = False
                            record["mainTextureResolved"] = None
                    except OSError:
                        pass
                cache[key] = record
            usage.append(dict(cache[key]))
    return usage


def _new_mesh_scope():
    """Create counters for one disjoint/overlapping Mesh diagnostic scope."""
    return {
        "uniqueMeshReferences": 0,
        "meshFilterComponents": 0,
        "decodedMeshes": 0,
        "withNormals": 0,
        "missingNormalsCount": 0,
        "withUV0": 0,
        "missingUV0Count": 0,
        "missingEitherCount": 0,
        "uv0MissingRiskCounts": {
            "TEXTURED_MATERIAL_ASSIGNED": 0,
            "MATERIAL_USAGE_UNKNOWN": 0,
            "NO_MAIN_TEXTURE_DETECTED": 0,
        },
        "normalMissingEvidenceCounts": {
            "RENDERER_WITH_TEXTURED_MATERIAL": 0,
            "RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL": 0,
            "RENDERER_MATERIAL_USAGE_UNKNOWN": 0,
            "NO_RENDERER_DETECTED": 0,
        },
    }


def _classify_uv0_risk(game_objects):
    """Classify missing-UV risk from the material evidence in one scope."""
    textured_count = sum(bool(item.get("hasTexturedMaterial")) for item in game_objects)
    unknown_count = sum(not item.get("materialUsageKnown") for item in game_objects)
    if textured_count:
        risk = "TEXTURED_MATERIAL_ASSIGNED"
    elif unknown_count:
        risk = "MATERIAL_USAGE_UNKNOWN"
    else:
        risk = "NO_MAIN_TEXTURE_DETECTED"
    return risk, textured_count, unknown_count


def _classify_normal_evidence(game_objects):
    """Classify missing-normal context from read-only Renderer/material evidence.

    This is an evidence category, not a prediction that shading is visibly broken.
    """
    renderers = [item for item in game_objects if _count(item.get("rendererCount")) > 0]
    if not renderers:
        return "NO_RENDERER_DETECTED"
    if any(item.get("hasTexturedMaterial") for item in renderers):
        return "RENDERER_WITH_TEXTURED_MATERIAL"
    if any(not item.get("materialUsageKnown") for item in renderers):
        return "RENDERER_MATERIAL_USAGE_UNKNOWN"
    return "RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL"


def _record_scope_channels(scope, has_normals, has_uv0, uv_risk=None, normal_evidence=None):
    scope["decodedMeshes"] += 1
    if has_normals:
        scope["withNormals"] += 1
    else:
        scope["missingNormalsCount"] += 1
        if normal_evidence in scope["normalMissingEvidenceCounts"]:
            scope["normalMissingEvidenceCounts"][normal_evidence] += 1
    if has_uv0:
        scope["withUV0"] += 1
    else:
        scope["missingUV0Count"] += 1
        if uv_risk in scope["uv0MissingRiskCounts"]:
            scope["uv0MissingRiskCounts"][uv_risk] += 1
    if not has_normals or not has_uv0:
        scope["missingEitherCount"] += 1


def _read_mesh_filter_component_index(parser, scene_path, selected_go_ids):
    """Map each serialized MeshFilter component fileID to its GO and Mesh reference.

    The conversion parser intentionally remains untouched; this read-only pass
    reuses its YAML document/ref helpers to enrich diagnostics with exact component IDs.
    """
    scene_text = Path(scene_path).read_text(encoding="utf-8-sig", errors="replace")
    selected = set(selected_go_ids)
    index = collections.defaultdict(list)
    for class_id, component_file_id, document in parser.docs(scene_text):
        if class_id != 33:  # Unity MeshFilter
            continue
        go_ref = parser.ref(document, "m_GameObject") or {}
        mesh_ref = parser.ref(document, "m_Mesh") or {}
        try:
            go_id = int(go_ref.get("fileID", 0) or 0)
        except (TypeError, ValueError):
            continue
        if go_id not in selected:
            continue
        mesh_guid = str(mesh_ref.get("guid", "")).lower()
        mesh_file_id = str(mesh_ref.get("fileID", ""))
        index[(go_id, mesh_guid, mesh_file_id)].append(int(component_file_id))
    return index


def _inspect_mesh_channel_diagnostics(
    parser, project, selected_go_ids, go_paths, objects,
    mesh_filters_by_go, renderers_by_go, guid_index,
    mesh_filter_component_index=None,
):
    """Decode each unique Mesh once and report source/included/excluded scopes."""
    occurrences_by_mesh = collections.defaultdict(list)
    mesh_filter_component_count = 0
    null_mesh_filter_component_count = 0
    component_id_queues = {
        key: list(value) for key, value in (mesh_filter_component_index or {}).items()
    }
    identified_component_ids = 0
    null_component_details = []
    for go_id in selected_go_ids:
        for mesh_filter in mesh_filters_by_go.get(go_id, []):
            mesh_filter_component_count += 1
            mesh_ref = mesh_filter.get("mesh") or {}
            mesh_guid = str(mesh_ref.get("guid", "")).lower()
            mesh_file_id = str(mesh_ref.get("fileID", ""))
            component_queue = component_id_queues.get((go_id, mesh_guid, mesh_file_id), [])
            component_file_id = component_queue.pop(0) if component_queue else None
            if component_file_id is not None:
                identified_component_ids += 1
            if not mesh_guid or not mesh_file_id or mesh_file_id == "0":
                null_mesh_filter_component_count += 1
                obj = objects.get(go_id, {})
                null_component_details.append({
                    "gameObjectName": obj.get("name", "GO_{}".format(go_id)),
                    "gameObjectFileID": go_id,
                    "hierarchyPath": go_paths.get(go_id, obj.get("name", "GO_{}".format(go_id))),
                    "meshFilterComponentFileID": component_file_id,
                    "meshGUID": mesh_guid,
                    "meshFileID": mesh_file_id,
                    "reason": "missing_or_null_mesh_reference",
                })
                continue
            occurrences_by_mesh[(mesh_guid, mesh_file_id)].append({
                "gameObjectFileID": go_id,
                "meshFilterComponentFileID": component_file_id,
            })

    diagnostics = {
        "schema": "scsp-mesh-channel-diagnostics-v6",
        "basis": "unique Mesh GUID + fileID references; source, conversion-included, excluded-only and shared scopes are reported separately",
        "meshInventorySchema": "scsp-mesh-resource-inventory-v1",
        "meshInventory": [],
        "meshInventorySummary": {},
        "meshFilterComponents": mesh_filter_component_count,
        "validMeshFilterComponents": mesh_filter_component_count - null_mesh_filter_component_count,
        "nullMeshFilterComponents": null_mesh_filter_component_count,
        "uniqueMeshReferences": len(occurrences_by_mesh),
        "decodedMeshes": 0,
        "withNormals": 0,
        "withUV0": 0,
        "missingNormals": [],
        "missingUV0": [],
        "missingEither": [],
        "unresolvedMeshReferences": [],
        "decodeErrors": [],
        "conversionPolicy": "exclude",
        "conversionMeshFilterComponents": 0,
        "excludedMeshFilterComponents": 0,
        "conversionUniqueMeshReferences": 0,
        "excludedOnlyUniqueMeshReferences": 0,
        "sharedMeshReferencesAcrossIncludedAndExcludedObjects": 0,
        "conversionMissingNormals": [],
        "conversionMissingUV0": [],
        "conversionMissingEither": [],
        "excludedOnlyMissingNormals": [],
        "excludedOnlyMissingUV0": [],
        "excludedOnlyMissingEither": [],
        "sharedMissingNormals": [],
        "sharedMissingUV0": [],
        "sharedMissingEither": [],
        "conversionMissingUV0WarningCount": 0,
        "conversionMissingUV0InfoCount": 0,
        "scopes": {
            "source": _new_mesh_scope(),
            "included": _new_mesh_scope(),
            "excludedOnly": _new_mesh_scope(),
            "shared": _new_mesh_scope(),
        },
    }
    scopes = diagnostics["scopes"]
    scopes["source"]["uniqueMeshReferences"] = len(occurrences_by_mesh)
    scopes["source"]["meshFilterComponents"] = mesh_filter_component_count - null_mesh_filter_component_count
    diagnostics["nullMeshFilterComponentDetails"] = null_component_details
    diagnostics["meshFilterComponentIdCoverage"] = {
        "totalMeshFilterComponents": mesh_filter_component_count,
        "identifiedComponentFileIDs": identified_component_ids,
        "missingComponentFileIDs": mesh_filter_component_count - identified_component_ids,
        "complete": identified_component_ids == mesh_filter_component_count,
    }
    material_cache = {}

    for mesh_guid, mesh_file_id in sorted(occurrences_by_mesh):
        occurrence_rows = occurrences_by_mesh[(mesh_guid, mesh_file_id)]
        go_component_ids = collections.defaultdict(list)
        for occurrence in occurrence_rows:
            go_component_ids[occurrence["gameObjectFileID"]].append(
                occurrence["meshFilterComponentFileID"]
            )
        go_counts = {go_id: len(component_ids) for go_id, component_ids in go_component_ids.items()}
        game_objects = []
        for go_id, component_count in go_counts.items():
            obj = objects.get(go_id, {})
            materials = _material_usage_for_game_object(
                go_id, renderers_by_go, guid_index, project, material_cache
            )
            game_objects.append({
                "gameObjectName": obj.get("name", "GO_{}".format(go_id)),
                "gameObjectFileID": go_id,
                "hierarchyPath": go_paths.get(
                    go_id, obj.get("name", "GO_{}".format(go_id))
                ),
                "activeSelf": bool(obj.get("active", True)),
                "activeInHierarchy": bool(obj.get("activeInHierarchy", True)),
                "conversionIncluded": bool(obj.get("conversionIncluded", True)),
                "activeWithinSelectedRoot": bool(obj.get("activeWithinSelectedRoot", True)),
                "conversionDecision": obj.get("conversionDecision", "unknown"),
                "hierarchyInactiveCause": obj.get("hierarchyInactiveCause"),
                "conversionBlockingInactiveObject": obj.get("conversionBlockingInactiveObject"),
                "meshFilterComponents": component_count,
                "meshFilterComponentFileIDs": sorted(
                    item for item in go_component_ids[go_id] if item is not None
                ),
                "meshFilterComponentFileIDsComplete": all(
                    item is not None for item in go_component_ids[go_id]
                ) and len(go_component_ids[go_id]) == component_count,
                "rendererCount": len(renderers_by_go.get(go_id, [])),
                "materials": materials,
                "hasTexturedMaterial": any(
                    item.get("mainTextureAssigned") is True for item in materials
                ),
                "materialUsageKnown": bool(materials) and all(
                    item.get("mainTextureAssigned") is not None for item in materials
                ),
            })
        game_objects.sort(
            key=lambda item: (item["hierarchyPath"].casefold(), item["gameObjectFileID"])
        )

        included_occurrences = [item for item in game_objects if item["conversionIncluded"]]
        excluded_occurrences = [item for item in game_objects if not item["conversionIncluded"]]
        is_included = bool(included_occurrences)
        is_excluded_only = bool(excluded_occurrences) and not is_included
        is_shared = bool(included_occurrences and excluded_occurrences)
        included_component_count = sum(item["meshFilterComponents"] for item in included_occurrences)
        excluded_component_count = sum(item["meshFilterComponents"] for item in excluded_occurrences)
        inventory_scope = "shared" if is_shared else ("excludedOnly" if is_excluded_only else "included")
        occurrence_count = sum(item["meshFilterComponents"] for item in game_objects)

        # Count references and occurrences before decoding, so unresolved references
        # remain visible in the scope accounting instead of silently disappearing.
        if is_included:
            diagnostics["conversionUniqueMeshReferences"] += 1
            diagnostics["conversionMeshFilterComponents"] += included_component_count
            scopes["included"]["uniqueMeshReferences"] += 1
            scopes["included"]["meshFilterComponents"] += included_component_count
        if is_excluded_only:
            diagnostics["excludedOnlyUniqueMeshReferences"] += 1
            scopes["excludedOnly"]["uniqueMeshReferences"] += 1
            scopes["excludedOnly"]["meshFilterComponents"] += excluded_component_count
        if is_shared:
            diagnostics["sharedMeshReferencesAcrossIncludedAndExcludedObjects"] += 1
            scopes["shared"]["uniqueMeshReferences"] += 1
            scopes["shared"]["meshFilterComponents"] += included_component_count + excluded_component_count
            scopes["shared"]["includedMeshFilterComponents"] = scopes["shared"].get("includedMeshFilterComponents", 0) + included_component_count
            scopes["shared"]["excludedMeshFilterComponents"] = scopes["shared"].get("excludedMeshFilterComponents", 0) + excluded_component_count
        diagnostics["excludedMeshFilterComponents"] += excluded_component_count

        asset_path = None
        try:
            if mesh_guid == str(getattr(parser, "BUILTIN_MESH_GUID", "")).lower():
                mesh = parser.parse_builtin_mesh(mesh_file_id)
            else:
                asset_path = guid_index.get(mesh_guid)
                if not asset_path or not Path(asset_path).is_file():
                    unresolved_record = {
                        "meshGUID": mesh_guid,
                        "meshFileID": mesh_file_id,
                        "gameObjects": game_objects,
                    }
                    diagnostics["unresolvedMeshReferences"].append(unresolved_record)
                    diagnostics["meshInventory"].append({
                        "meshName": None,
                        "meshGUID": mesh_guid,
                        "meshFileID": mesh_file_id,
                        "assetPath": str(asset_path or ""),
                        "builtin": False,
                        "decodeStatus": "unresolved",
                        "decodeError": "GUID 对应的 Mesh 资源文件不存在或无法定位。",
                        "scope": inventory_scope,
                        "conversionIncluded": is_included,
                        "conversionOccurrenceCount": included_component_count,
                        "excludedOccurrenceCount": excluded_component_count,
                        "hasIncludedAndExcludedOccurrences": is_shared,
                        "occurrenceCount": occurrence_count,
                        "uniqueGameObjectCount": len(game_objects),
                        "gameObjects": game_objects,
                    })
                    continue
                mesh = parser.parse_mesh(Path(asset_path))
                if not mesh:
                    raise ValueError("引用资源未解析为 Mesh")
        except Exception as exc:
            diagnostics["decodeErrors"].append({
                "meshGUID": mesh_guid,
                "meshFileID": mesh_file_id,
                "assetPath": str(asset_path or "<Unity Built-in Mesh>"),
                "error": str(exc),
                "gameObjects": game_objects,
            })
            diagnostics["meshInventory"].append({
                "meshName": None,
                "meshGUID": mesh_guid,
                "meshFileID": mesh_file_id,
                "assetPath": str(asset_path or "<Unity Built-in Mesh>"),
                "builtin": asset_path is None,
                "decodeStatus": "decode_error",
                "decodeError": str(exc),
                "scope": inventory_scope,
                "conversionIncluded": is_included,
                "conversionOccurrenceCount": included_component_count,
                "excludedOccurrenceCount": excluded_component_count,
                "hasIncludedAndExcludedOccurrences": is_shared,
                "occurrenceCount": occurrence_count,
                "uniqueGameObjectCount": len(game_objects),
                "gameObjects": game_objects,
            })
            continue

        has_normals = bool(mesh.get("normals"))
        has_uv0 = bool(mesh.get("uv"))
        if asset_path is None:
            asset_label = "<Unity Built-in Mesh>"
            builtin = True
        else:
            try:
                asset_label = str(Path(asset_path).resolve().relative_to(project))
            except ValueError:
                asset_label = str(asset_path)
            builtin = False
        record = {
            "meshName": mesh.get("name", "<未命名 Mesh>"),
            "meshGUID": mesh_guid,
            "meshFileID": mesh_file_id,
            "assetPath": asset_label,
            "builtin": builtin,
            "vertexCount": int(mesh.get("vertexCount", 0) or 0),
            "hasNormals": has_normals,
            "hasUV0": has_uv0,
            "occurrenceCount": occurrence_count,
            "uniqueGameObjectCount": len(game_objects),
            "gameObjects": game_objects,
            "decodeStatus": "decoded",
            "scope": inventory_scope,
        }
        record["conversionIncluded"] = is_included
        record["conversionOccurrenceCount"] = included_component_count
        record["excludedOccurrenceCount"] = excluded_component_count
        record["hasIncludedAndExcludedOccurrences"] = is_shared
        diagnostics["meshInventory"].append(record)

        source_uv_risk = None
        conversion_uv_risk = None
        excluded_uv_risk = None
        source_normal_evidence = None
        conversion_normal_evidence = None
        excluded_normal_evidence = None
        if not has_normals:
            source_normal_evidence = _classify_normal_evidence(game_objects)
            if is_included:
                conversion_normal_evidence = _classify_normal_evidence(included_occurrences)
            if is_excluded_only:
                excluded_normal_evidence = _classify_normal_evidence(excluded_occurrences)
        if not has_uv0:
            source_uv_risk = _classify_uv0_risk(game_objects)[0]
            if is_included:
                conversion_uv_risk = _classify_uv0_risk(included_occurrences)[0]
            if is_excluded_only:
                excluded_uv_risk = _classify_uv0_risk(excluded_occurrences)[0]

        diagnostics["decodedMeshes"] += 1
        diagnostics["withNormals"] += int(has_normals)
        diagnostics["withUV0"] += int(has_uv0)
        _record_scope_channels(scopes["source"], has_normals, has_uv0, source_uv_risk, source_normal_evidence)
        if is_included:
            _record_scope_channels(scopes["included"], has_normals, has_uv0, conversion_uv_risk, conversion_normal_evidence)
        if is_excluded_only:
            _record_scope_channels(scopes["excludedOnly"], has_normals, has_uv0, excluded_uv_risk, excluded_normal_evidence)
        if is_shared:
            _record_scope_channels(scopes["shared"], has_normals, has_uv0, conversion_uv_risk, conversion_normal_evidence)

        if not has_normals:
            normal_record = dict(record)
            normal_record["normalEvidence"] = source_normal_evidence
            normal_record["normalEvidenceNote"] = "仅根据 Renderer 与材质引用可见性分类；不代表实际 MMD 光照结果或法线视觉缺陷已被证明。"
            diagnostics["missingNormals"].append(normal_record)
            if is_included:
                conversion_normal_record = dict(normal_record)
                conversion_normal_record["normalEvidence"] = conversion_normal_evidence
                diagnostics["conversionMissingNormals"].append(conversion_normal_record)
            if is_excluded_only:
                excluded_normal_record = dict(normal_record)
                excluded_normal_record["normalEvidence"] = excluded_normal_evidence
                diagnostics["excludedOnlyMissingNormals"].append(excluded_normal_record)
            if is_shared:
                shared_normal_record = dict(normal_record)
                shared_normal_record["normalEvidence"] = conversion_normal_evidence
                diagnostics["sharedMissingNormals"].append(shared_normal_record)

        if not has_uv0:
            source_risk, source_textured, source_unknown = _classify_uv0_risk(game_objects)
            uv_record = dict(record)
            uv_record.update({
                "uvRisk": source_risk,
                "texturedMaterialOccurrences": source_textured,
                "unknownMaterialOccurrences": source_unknown,
            })
            diagnostics["missingUV0"].append(uv_record)

            if is_included:
                conversion_risk, conversion_textured, conversion_unknown = _classify_uv0_risk(included_occurrences)
                conversion_record = dict(uv_record)
                conversion_record.update({
                    "sourceUvRisk": source_risk,
                    "uvRisk": conversion_risk,
                    "texturedMaterialOccurrences": conversion_textured,
                    "unknownMaterialOccurrences": conversion_unknown,
                    "sourceTexturedMaterialOccurrences": source_textured,
                    "sourceUnknownMaterialOccurrences": source_unknown,
                })
                diagnostics["conversionMissingUV0"].append(conversion_record)
                if conversion_risk == "NO_MAIN_TEXTURE_DETECTED":
                    diagnostics["conversionMissingUV0InfoCount"] += 1
                else:
                    diagnostics["conversionMissingUV0WarningCount"] += 1
            if is_excluded_only:
                excluded_risk, excluded_textured, excluded_unknown = _classify_uv0_risk(excluded_occurrences)
                excluded_record = dict(uv_record)
                excluded_record.update({
                    "uvRisk": excluded_risk,
                    "texturedMaterialOccurrences": excluded_textured,
                    "unknownMaterialOccurrences": excluded_unknown,
                })
                diagnostics["excludedOnlyMissingUV0"].append(excluded_record)
            if is_shared:
                shared_risk, shared_textured, shared_unknown = _classify_uv0_risk(included_occurrences)
                shared_record = dict(uv_record)
                shared_record.update({
                    "uvRisk": shared_risk,
                    "texturedMaterialOccurrences": shared_textured,
                    "unknownMaterialOccurrences": shared_unknown,
                    "sourceUvRisk": source_risk,
                })
                diagnostics["sharedMissingUV0"].append(shared_record)

        if not has_normals or not has_uv0:
            diagnostics["missingEither"].append(record)
            if is_included:
                diagnostics["conversionMissingEither"].append(record)
            if is_excluded_only:
                diagnostics["excludedOnlyMissingEither"].append(record)
            if is_shared:
                diagnostics["sharedMissingEither"].append(record)

    diagnostics["missingNormalsCount"] = len(diagnostics["missingNormals"])
    diagnostics["missingUV0Count"] = len(diagnostics["missingUV0"])
    diagnostics["missingEitherCount"] = len(diagnostics["missingEither"])
    diagnostics["unresolvedMeshReferenceCount"] = len(diagnostics["unresolvedMeshReferences"])
    diagnostics["decodeErrorCount"] = len(diagnostics["decodeErrors"])
    diagnostics["conversionMissingNormalsCount"] = len(diagnostics["conversionMissingNormals"])
    diagnostics["conversionMissingUV0Count"] = len(diagnostics["conversionMissingUV0"])
    diagnostics["conversionMissingEitherCount"] = len(diagnostics["conversionMissingEither"])
    diagnostics["excludedOnlyMissingNormalsCount"] = len(diagnostics["excludedOnlyMissingNormals"])
    diagnostics["excludedOnlyMissingUV0Count"] = len(diagnostics["excludedOnlyMissingUV0"])
    diagnostics["excludedOnlyMissingEitherCount"] = len(diagnostics["excludedOnlyMissingEither"])
    diagnostics["sharedMissingNormalsCount"] = len(diagnostics["sharedMissingNormals"])
    diagnostics["sharedMissingUV0Count"] = len(diagnostics["sharedMissingUV0"])
    diagnostics["sharedMissingEitherCount"] = len(diagnostics["sharedMissingEither"])
    inventory = diagnostics["meshInventory"]
    inventory_scope_counts = {
        # Included is an overlapping scope: it includes both included-only and shared Mesh references.
        "included": sum(item.get("scope") in ("included", "shared") for item in inventory),
        "excludedOnly": sum(item.get("scope") == "excludedOnly" for item in inventory),
        "shared": sum(item.get("scope") == "shared" for item in inventory),
    }
    inventory_status_counts = {
        status: sum(item.get("decodeStatus") == status for item in inventory)
        for status in ("decoded", "unresolved", "decode_error")
    }
    identity_complete_count = sum(
        bool(re.fullmatch(r"[0-9a-fA-F]{32}", str(item.get("meshGUID", ""))))
        and str(item.get("meshFileID", "")) not in ("", "0")
        for item in inventory
    )
    diagnostics["meshInventorySummary"] = {
        "schema": "scsp-mesh-resource-inventory-v1",
        "totalUniqueMeshReferences": len(occurrences_by_mesh),
        "recordedUniqueMeshReferences": len(inventory),
        "identifiedUniqueMeshReferences": identity_complete_count,
        "unidentifiedUniqueMeshReferences": len(inventory) - identity_complete_count,
        "decodedUniqueMeshReferences": inventory_status_counts["decoded"],
        "unresolvedUniqueMeshReferences": inventory_status_counts["unresolved"],
        "decodeErrorUniqueMeshReferences": inventory_status_counts["decode_error"],
        "scopeUniqueMeshReferences": inventory_scope_counts,
        "complete": len(inventory) == len(occurrences_by_mesh),
        "identityComplete": identity_complete_count == len(inventory),
        "scopeCountsMatch": (
            inventory_scope_counts["included"] == diagnostics["conversionUniqueMeshReferences"]
            and inventory_scope_counts["excludedOnly"] == diagnostics["excludedOnlyUniqueMeshReferences"]
            and inventory_scope_counts["shared"] == diagnostics["sharedMeshReferencesAcrossIncludedAndExcludedObjects"]
        ),
    }
    source_scope = scopes["source"]
    included_scope = scopes["included"]
    excluded_scope = scopes["excludedOnly"]
    shared_scope = scopes["shared"]
    accounting_checks = {
        "meshFilterComponentsMatch": source_scope["meshFilterComponents"] == diagnostics["conversionMeshFilterComponents"] + diagnostics["excludedMeshFilterComponents"],
        "uniqueMeshReferencesMatch": source_scope["uniqueMeshReferences"] == included_scope["uniqueMeshReferences"] + excluded_scope["uniqueMeshReferences"],
        "decodedMeshesMatch": source_scope["decodedMeshes"] == included_scope["decodedMeshes"] + excluded_scope["decodedMeshes"],
        "withNormalsMatch": source_scope["withNormals"] == included_scope["withNormals"] + excluded_scope["withNormals"],
        "missingNormalsMatch": source_scope["missingNormalsCount"] == included_scope["missingNormalsCount"] + excluded_scope["missingNormalsCount"],
        "withUV0Match": source_scope["withUV0"] == included_scope["withUV0"] + excluded_scope["withUV0"],
        "missingUV0Match": source_scope["missingUV0Count"] == included_scope["missingUV0Count"] + excluded_scope["missingUV0Count"],
        "missingEitherMatch": source_scope["missingEitherCount"] == included_scope["missingEitherCount"] + excluded_scope["missingEitherCount"],
        "sourceUvRiskCountsMatch": sum(source_scope["uv0MissingRiskCounts"].values()) == source_scope["missingUV0Count"],
        "includedUvRiskCountsMatch": sum(included_scope["uv0MissingRiskCounts"].values()) == included_scope["missingUV0Count"],
        "excludedOnlyUvRiskCountsMatch": sum(excluded_scope["uv0MissingRiskCounts"].values()) == excluded_scope["missingUV0Count"],
    }
    for scope_name, scope_data in (("source", source_scope), ("included", included_scope), ("excludedOnly", excluded_scope), ("shared", shared_scope)):
        evidence_total = sum(scope_data.get("normalMissingEvidenceCounts", {}).values())
        accounting_checks[scope_name + "NormalEvidenceCountsMatch"] = evidence_total == scope_data["missingNormalsCount"]
    accounting_checks["countsMatch"] = all(accounting_checks.values())
    diagnostics["scopeAccounting"] = accounting_checks
    return diagnostics


def inspect_scene_objects(project, scene_rel, root_name, inactive_policy="exclude"):
    """Inspect hierarchy/component relationships without changing source files."""
    project = Path(project).expanduser().resolve()
    scene = (project / str(scene_rel).replace("/", os.sep)).resolve()
    if not scene.is_file():
        raise FileNotFoundError("Unity 场景文件不存在：{}".format(scene))
    try:
        scene.relative_to(project)
    except ValueError as exc:
        raise ValueError("Unity 场景路径超出 scene-project：{}".format(scene)) from exc

    parser = _load_scene_parser()
    objects, transforms, t_by_go, children, go_by_tid, roots, by_go_mf, by_go_mr, guid = (
        parser.parse_scene(scene, project / "Assets")
    )
    root_matches = [go_id for go_id, item in objects.items() if item["name"] == root_name]
    if len(root_matches) != 1:
        raise RuntimeError(
            "舞台根对象名称应唯一，实际匹配 {} 个：{}".format(len(root_matches), root_name)
        )
    root_go = root_matches[0]
    root_transform = t_by_go.get(root_go)
    if not root_transform:
        raise RuntimeError("舞台根对象没有 Transform：{}".format(root_name))

    selected_go_ids = []
    selected_transform_ids = set()
    go_paths = {}
    active_in_hierarchy = {}
    active_within_selected_root = {}
    conversion_included = {}
    inactive_policy = "include" if str(inactive_policy).lower() == "include" else "exclude"
    visited_go = set()
    active_go = set()
    cycles = []

    # Unity activeInHierarchy includes ancestors above the selected stage root.
    # The existing converter intentionally starts traversal at the selected root,
    # so its include/exclude decision must be tracked separately (root-relative).
    root_transform_id = root_transform.get("id")
    ancestor_chain_near_to_far = []
    ancestor_transform_ids = set()
    parent_transform_id = transforms.get(root_transform_id, {}).get("father", 0)
    ancestor_cycle = False
    while parent_transform_id:
        if parent_transform_id in ancestor_transform_ids:
            ancestor_cycle = True
            break
        ancestor_transform_ids.add(parent_transform_id)
        parent_transform = transforms.get(parent_transform_id)
        if not parent_transform:
            break
        parent_go_id = parent_transform.get("go")
        if parent_go_id in objects:
            parent_obj = objects[parent_go_id]
            ancestor_chain_near_to_far.append({
                "gameObjectFileID": parent_go_id,
                "name": parent_obj.get("name", "GO_{}".format(parent_go_id)),
                "transformFileID": parent_transform_id,
                "activeSelf": bool(parent_obj.get("active", True)),
            })
        parent_transform_id = parent_transform.get("father", 0)

    external_parent_active = all(item["activeSelf"] for item in ancestor_chain_near_to_far)
    nearest_external_inactive = next(
        (item for item in ancestor_chain_near_to_far if not item["activeSelf"]), None
    )
    ancestor_path = ""
    for item in reversed(ancestor_chain_near_to_far):
        ancestor_path = (ancestor_path + "/" if ancestor_path else "") + item["name"]
        item["hierarchyPath"] = ancestor_path

    external_inactive_cause = None
    if nearest_external_inactive:
        external_inactive_cause = dict(nearest_external_inactive)
        external_inactive_cause["isSelf"] = False

    def walk(
        go_id, parent_path="", parent_hierarchy_active=True,
        parent_root_active=True, parent_hierarchy_cause=None, parent_root_cause=None,
    ):
        if go_id in active_go:
            cycles.append(go_id)
            return
        if go_id in visited_go:
            return
        visited_go.add(go_id)
        active_go.add(go_id)
        selected_go_ids.append(go_id)
        go_name = objects.get(go_id, {}).get("name", "GO_{}".format(go_id))
        go_paths[go_id] = parent_path + "/" + go_name if parent_path else go_name
        own_active = bool(objects.get(go_id, {}).get("active", True))
        hierarchy_active = bool(parent_hierarchy_active and own_active)
        root_active = bool(parent_root_active and own_active)
        hierarchy_cause = None
        if not own_active:
            hierarchy_cause = {
                "gameObjectFileID": go_id, "name": go_name,
                "hierarchyPath": go_paths[go_id], "isSelf": True,
            }
        elif not parent_hierarchy_active:
            hierarchy_cause = parent_hierarchy_cause
        root_cause = None
        if not own_active:
            root_cause = {
                "gameObjectFileID": go_id, "name": go_name,
                "hierarchyPath": go_paths[go_id], "isSelf": True,
            }
        elif not parent_root_active:
            root_cause = parent_root_cause

        is_included = inactive_policy == "include" or root_active
        if is_included and not root_active:
            decision = "included_by_inactive_policy_override"
        elif is_included:
            decision = "included_active_within_selected_root"
        elif not own_active:
            decision = "excluded_self_inactive"
        else:
            decision = "excluded_by_inactive_ancestor"

        active_in_hierarchy[go_id] = hierarchy_active
        active_within_selected_root[go_id] = root_active
        conversion_included[go_id] = is_included
        objects[go_id]["activeInHierarchy"] = hierarchy_active
        objects[go_id]["activeWithinSelectedRoot"] = root_active
        objects[go_id]["conversionIncluded"] = is_included
        objects[go_id]["conversionDecision"] = decision
        objects[go_id]["hierarchyInactiveCause"] = hierarchy_cause
        objects[go_id]["conversionBlockingInactiveObject"] = root_cause

        transform = t_by_go.get(go_id)
        if transform:
            transform_id = transform["id"]
            selected_transform_ids.add(transform_id)
            for child_transform_id in children.get(transform_id, []):
                child_go = go_by_tid.get(child_transform_id)
                if child_go is not None:
                    walk(
                        child_go, go_paths[go_id], hierarchy_active, root_active,
                        hierarchy_cause, root_cause,
                    )
        active_go.remove(go_id)

    walk(
        root_go, parent_hierarchy_active=external_parent_active,
        parent_root_active=True, parent_hierarchy_cause=external_inactive_cause,
    )

    mesh_filter_objects = []
    renderer_objects = []
    mesh_filters_without_renderer = []
    renderers_without_mesh_filter = []
    renderers_without_materials = []
    missing_material_assets = []
    missing_texture_assets = []
    empty_game_objects = []
    inactive_game_objects = []
    duplicate_names = collections.defaultdict(list)
    non_finite_transforms = []
    zero_scale_transforms = []

    for go_id in selected_go_ids:
        obj = objects[go_id]
        name = obj.get("name", "GO_{}".format(go_id))
        duplicate_names[name].append(go_id)
        filters = by_go_mf.get(go_id, [])
        renderers = by_go_mr.get(go_id, [])
        if filters:
            mesh_filter_objects.append(go_id)
        if renderers:
            renderer_objects.append(go_id)
        if filters and not renderers:
            mesh_filters_without_renderer.append({"name": name, "gameObjectFileID": go_id, "meshFilters": len(filters)})
        if renderers and not filters:
            renderers_without_mesh_filter.append({"name": name, "gameObjectFileID": go_id, "renderers": len(renderers)})
        if not filters and not renderers:
            empty_game_objects.append({"name": name, "gameObjectFileID": go_id})
        if not obj.get("active", True):
            inactive_game_objects.append({"name": name, "gameObjectFileID": go_id})

        transform = t_by_go.get(go_id)
        if transform:
            transform_data = transforms.get(transform["id"], {})
            position = transform_data.get("pos", (0, 0, 0))
            rotation = transform_data.get("rot", (0, 0, 0, 1))
            scale = transform_data.get("scale", (1, 1, 1))
            values = tuple(position) + tuple(rotation) + tuple(scale)
            if any(not math.isfinite(float(value)) for value in values):
                non_finite_transforms.append({"name": name, "gameObjectFileID": go_id, "transformFileID": transform["id"]})
            if any(abs(float(value)) < 1e-8 for value in scale):
                zero_scale_transforms.append({"name": name, "gameObjectFileID": go_id, "scale": list(scale)})

        for renderer in renderers:
            materials = renderer.get("materials", [])
            if not materials:
                renderers_without_materials.append({"name": name, "gameObjectFileID": go_id})
            for material_ref in materials:
                material_guid = str(material_ref.get("guid", "")).lower()
                if not material_guid:
                    # Built-in or empty material slots are not assumed to be a
                    # missing external asset; report only when a GUID was supplied.
                    continue
                material_path = guid.get(material_guid)
                if not material_path or not Path(material_path).is_file():
                    missing_material_assets.append({
                        "object": name,
                        "materialGUID": material_guid,
                    })
                    continue
                try:
                    material_text = Path(material_path).read_text(encoding="utf-8-sig", errors="replace")
                except OSError:
                    missing_material_assets.append({
                        "object": name,
                        "materialGUID": material_guid,
                        "materialPath": str(material_path),
                    })
                    continue
                main_tex = re.search(
                    r"_MainTex:\s*\n(.*?)(?=\n\s*_[A-Za-z0-9]+:|\n\s*\})",
                    material_text,
                    re.S,
                )
                if main_tex:
                    texture_match = re.search(
                        r"m_Texture:\s*\{[^}]*guid:\s*([0-9a-fA-F]{32})",
                        main_tex.group(1),
                    )
                    if texture_match:
                        texture_guid = texture_match.group(1).lower()
                        texture_path = guid.get(texture_guid)
                        if not texture_path or not Path(texture_path).is_file():
                            missing_texture_assets.append({
                                "object": name,
                                "material": Path(material_path).name,
                                "textureGUID": texture_guid,
                            })

    duplicate_name_groups = [
        {"name": name, "gameObjectFileIDs": ids, "count": len(ids)}
        for name, ids in sorted(duplicate_names.items()) if len(ids) > 1
    ]
    mesh_filter_component_index = _read_mesh_filter_component_index(
        parser, scene, selected_go_ids
    )
    mesh_channel_diagnostics = _inspect_mesh_channel_diagnostics(
        parser, project, selected_go_ids, go_paths, objects,
        by_go_mf, by_go_mr, guid, mesh_filter_component_index,
    )
    mesh_channel_diagnostics["conversionPolicy"] = inactive_policy

    return {
        "rootMatches": len(root_matches),
        "gameObjectsInRoot": len(selected_go_ids),
        "meshFilterObjects": len(mesh_filter_objects),
        "meshRendererObjects": len(renderer_objects),
        "meshFiltersWithoutMeshRenderer": mesh_filters_without_renderer,
        "meshRenderersWithoutMeshFilter": renderers_without_mesh_filter,
        "meshRenderersWithoutMaterials": renderers_without_materials,
        "missingMaterialAssets": missing_material_assets,
        "missingMainTextureAssets": missing_texture_assets,
        "emptyHierarchyObjects": empty_game_objects,
        "inactiveGameObjects": inactive_game_objects,
        "inactiveInHierarchyObjects": [
            {"name": objects[go_id].get("name", "GO_{}".format(go_id)),
             "gameObjectFileID": go_id, "hierarchyPath": go_paths.get(go_id, ""),
             "activeSelf": bool(objects[go_id].get("active", True)),
             "activeInHierarchy": active_in_hierarchy.get(go_id, False),
             "activeInHierarchySource": "computed_by_unity_hierarchy_walk",
             "activeInHierarchyInferred": False,
             "activeWithinSelectedRoot": active_within_selected_root.get(go_id, True),
             "conversionIncluded": conversion_included.get(go_id, True),
             "conversionDecision": objects[go_id].get("conversionDecision"),
             "hierarchyInactiveCause": objects[go_id].get("hierarchyInactiveCause"),
             "conversionBlockingInactiveObject": objects[go_id].get("conversionBlockingInactiveObject")}
            for go_id in selected_go_ids if not active_in_hierarchy.get(go_id, True)
        ],
        "rootExternalAncestors": ancestor_chain_near_to_far,
        "rootExternalAncestorChainActive": external_parent_active,
        "rootExternalAncestorCycle": ancestor_cycle,
        "rootActiveInHierarchy": active_in_hierarchy.get(root_go, True),
        "rootActiveWithinSelectedRoot": active_within_selected_root.get(root_go, True),
        "activeInHierarchyGameObjects": sum(active_in_hierarchy.values()),
        "inactiveInHierarchyGameObjects": len(active_in_hierarchy) - sum(active_in_hierarchy.values()),
        "conversionIncludedGameObjects": sum(conversion_included.values()),
        "conversionExcludedGameObjects": len(conversion_included) - sum(conversion_included.values()),
        "inactivePolicy": inactive_policy,
        "duplicateGameObjectNames": duplicate_name_groups,
        "transformCycles": cycles,
        "nonFiniteTransforms": non_finite_transforms,
        "zeroScaleTransforms": zero_scale_transforms,
        "transformCountInRoot": len(selected_transform_ids),
        "meshChannelDiagnostics": mesh_channel_diagnostics,
    }


def _safe_texture_target(pmx_path: Path, reference: str):
    """Resolve one PMX texture path; never follow a relative path outside output."""
    ref = str(reference or "").strip().replace("\\", "/")
    if not ref:
        return None, "empty"

    win_path = PureWindowsPath(ref)
    native_path = Path(ref)
    is_absolute = native_path.is_absolute() or win_path.is_absolute()
    if is_absolute:
        # On Windows Path() can resolve a native absolute path. On other hosts a
        # Windows absolute path is intentionally treated as non-portable.
        try:
            target = native_path.resolve()
            exists = target.is_file()
        except Exception:
            target, exists = native_path, False
        if exists:
            try:
                target.relative_to(pmx_path.parent.resolve())
                return target, "ok"
            except ValueError:
                return target, "absolute_external"
        return target, "missing_absolute"

    target = (pmx_path.parent / Path(ref)).resolve()
    try:
        target.relative_to(pmx_path.parent.resolve())
    except ValueError:
        return target, "unsafe_relative"
    if not target.is_file() or target.stat().st_size <= 0:
        return target, "missing"
    return target, "ok"


def _add_check(checks, check_id, category, name, status, message, details=None):
    checks.append({
        "id": check_id,
        "category": category,
        "name": name,
        "status": status,
        "message": message,
        "details": details if details is not None else {},
    })


def _status_from_checks(checks):
    if any(item["status"] == "FAIL" for item in checks):
        return "FAIL"
    if any(item["status"] == "WARNING" for item in checks):
        return "WARNING"
    return "PASS"


def build_quality_report(
    source_validation=None,
    rebuild_report=None,
    pmx_report=None,
    pmx_path=None,
    project=None,
    scene=None,
    root_name="",
):
    """Build a non-mutating quality report from the three pipeline reports."""
    checks = []
    source_validation = source_validation if isinstance(source_validation, dict) else None
    rebuild_report = rebuild_report if isinstance(rebuild_report, dict) else None
    pmx_report = pmx_report if isinstance(pmx_report, dict) else None
    pmx_file = Path(pmx_path).expanduser().resolve() if pmx_path else None

    # 1) Unity source and Mesh integrity.
    if source_validation is None:
        _add_check(checks, "SRC-001", "Unity 资源", "Unity 资源验证报告", "FAIL", "缺少或无法读取 Unity 资源验证报告。")
    else:
        source_errors = source_validation.get("errors", []) or []
        source_ok = bool(source_validation.get("ok"))
        if source_ok and not source_errors:
            _add_check(checks, "SRC-001", "Unity 资源", "Unity 资源验证", "PASS", "Unity 场景 Mesh 引用及解码检查通过。")
        else:
            _add_check(checks, "SRC-001", "Unity 资源", "Unity 资源验证", "FAIL", "Unity 资源验证未通过。", {"errors": source_errors})

        mesh_filters = _count(source_validation.get("meshFilterComponents"))
        resolved_filters = _count(source_validation.get("resolvedMeshFilterComponents"))
        null_filters = _count(source_validation.get("nullMeshFilters"))
        decoded_meshes = _count(source_validation.get("decodedMeshes"))
        unique_refs = _count(source_validation.get("uniqueMeshReferences"))
        if mesh_filters != resolved_filters + null_filters:
            _add_check(checks, "SRC-002", "Mesh", "MeshFilter 资源数量核对", "FAIL", "MeshFilter 总数与已解析/空引用数量不一致。", {
                "meshFilterComponents": mesh_filters,
                "resolvedMeshFilterComponents": resolved_filters,
                "nullMeshFilters": null_filters,
            })
        else:
            _add_check(checks, "SRC-002", "Mesh", "MeshFilter 资源数量核对", "PASS", "MeshFilter 资源数量核对一致。", {
                "meshFilterComponents": mesh_filters,
                "resolvedMeshFilterComponents": resolved_filters,
                "nullMeshFilters": null_filters,
            })
        if decoded_meshes != unique_refs:
            _add_check(checks, "SRC-003", "Mesh", "Mesh 解码数量", "FAIL", "唯一 Mesh 引用与成功解码数量不一致。", {
                "uniqueMeshReferences": unique_refs,
                "decodedMeshes": decoded_meshes,
            })
        else:
            _add_check(checks, "SRC-003", "Mesh", "Mesh 解码数量", "PASS", "所有唯一 Mesh 引用均已解码。", {
                "uniqueMeshReferences": unique_refs,
                "decodedMeshes": decoded_meshes,
            })
        if null_filters:
            _add_check(checks, "SRC-004", "Mesh", "空 MeshFilter 引用", "WARNING", "发现没有有效 Mesh 引用的 MeshFilter；这些组件不会生成可见网格。", {"count": null_filters})
        if decoded_meshes and _count(source_validation.get("withNormals")) < decoded_meshes:
            _add_check(checks, "SRC-005", "Mesh", "法线覆盖率", "WARNING", "部分 Mesh 缺少法线数据，可能影响 MMD 中的明暗表现。", {
                "withNormals": _count(source_validation.get("withNormals")),
                "decodedMeshes": decoded_meshes,
            })
        else:
            _add_check(checks, "SRC-005", "Mesh", "法线覆盖率", "PASS", "已解码 Mesh 均包含法线数据。")
        if decoded_meshes and _count(source_validation.get("withUV0")) < decoded_meshes:
            _add_check(checks, "SRC-006", "Mesh", "UV0 覆盖率", "WARNING", "部分 Mesh 缺少 UV0，相关贴图可能无法按预期显示。", {
                "withUV0": _count(source_validation.get("withUV0")),
                "decodedMeshes": decoded_meshes,
            })
        else:
            _add_check(checks, "SRC-006", "Mesh", "UV0 覆盖率", "PASS", "已解码 Mesh 均包含 UV0。")

        texture_refs = _count(source_validation.get("mainTextureRefs"))
        resolved_textures = _count(source_validation.get("resolvedMainTextures"))
        if texture_refs > resolved_textures:
            _add_check(checks, "SRC-007", "贴图", "Unity 材质主贴图引用", "WARNING", "部分 Unity 材质的主贴图 GUID 无法在 Assets 中解析。", {
                "mainTextureRefs": texture_refs,
                "resolvedMainTextures": resolved_textures,
            })
        else:
            _add_check(checks, "SRC-007", "贴图", "Unity 材质主贴图引用", "PASS", "已扫描的 Unity 主贴图引用均可解析。", {
                "mainTextureRefs": texture_refs,
                "resolvedMainTextures": resolved_textures,
            })
        source_warnings = source_validation.get("warnings", []) or []
        non_particle_warnings = [
            item for item in source_warnings
            if "particlesystem" not in str(item).casefold()
        ]
        if non_particle_warnings:
            _add_check(checks, "SRC-008", "Unity 资源", "Unity 资源警告", "WARNING", "Unity 资源验证报告包含其他警告，请查看详情。", {
                "warnings": non_particle_warnings[:30],
            })

    # 2) Scene object and hierarchy diagnostics.
    if project and scene and root_name:
        try:
            inactive_policy = (rebuild_report or {}).get("inactivePolicy", "exclude")
            object_data = inspect_scene_objects(project, scene, root_name, inactive_policy)
            if object_data["transformCycles"]:
                _add_check(checks, "OBJ-001", "场景对象", "Transform 层级循环", "FAIL", "舞台层级中发现 Transform 循环引用。", {
                    "transformCycles": object_data["transformCycles"][:30],
                })
            else:
                _add_check(checks, "OBJ-001", "场景对象", "Transform 层级结构", "PASS", "舞台根对象的 Transform 层级没有检测到循环。")
            if object_data["nonFiniteTransforms"]:
                _add_check(checks, "OBJ-006", "场景对象", "非有限 Transform 数值", "FAIL", "发现包含 NaN 或 Infinity 的 Transform 数值。", {
                    "items": object_data["nonFiniteTransforms"][:30],
                })
            else:
                _add_check(checks, "OBJ-006", "场景对象", "Transform 数值", "PASS", "未发现 NaN 或 Infinity 的 Transform 数值。")
            if object_data["zeroScaleTransforms"]:
                _add_check(checks, "OBJ-007", "场景对象", "零缩放对象", "WARNING", "发现一个或多个轴为零缩放的对象；这些对象可能不可见，也可能是场景中的有意占位节点。", {
                    "items": object_data["zeroScaleTransforms"][:30],
                })
            else:
                _add_check(checks, "OBJ-007", "场景对象", "对象缩放", "PASS", "未发现零缩放 Transform。")
            if object_data["meshFiltersWithoutMeshRenderer"]:
                _add_check(checks, "OBJ-002", "场景对象", "MeshFilter 缺少 MeshRenderer", "WARNING", "部分对象有 MeshFilter，但未找到 MeshRenderer；请确认是否由其他 Renderer 类型负责显示。", {
                    "count": len(object_data["meshFiltersWithoutMeshRenderer"]),
                    "items": object_data["meshFiltersWithoutMeshRenderer"][:30],
                })
            else:
                _add_check(checks, "OBJ-002", "场景对象", "MeshFilter / MeshRenderer 配对", "PASS", "未发现缺少 MeshRenderer 的 MeshFilter 对象。")
            if object_data["meshRenderersWithoutMeshFilter"]:
                _add_check(checks, "OBJ-003", "场景对象", "MeshRenderer 缺少 MeshFilter", "WARNING", "部分 MeshRenderer 所在对象没有 MeshFilter。", {
                    "count": len(object_data["meshRenderersWithoutMeshFilter"]),
                    "items": object_data["meshRenderersWithoutMeshFilter"][:30],
                })
            else:
                _add_check(checks, "OBJ-003", "场景对象", "MeshRenderer / MeshFilter 配对", "PASS", "未发现 MeshRenderer 缺少 MeshFilter 的对象。")
            if object_data["meshRenderersWithoutMaterials"]:
                _add_check(checks, "MAT-001", "材质", "空材质槽", "WARNING", "部分 MeshRenderer 没有材质槽，导入时可能使用默认材质。", {
                    "count": len(object_data["meshRenderersWithoutMaterials"]),
                    "items": object_data["meshRenderersWithoutMaterials"][:30],
                })
            else:
                _add_check(checks, "MAT-001", "材质", "MeshRenderer 材质槽", "PASS", "未发现完全没有材质槽的 MeshRenderer。")
            if object_data["missingMaterialAssets"]:
                _add_check(checks, "MAT-002", "材质", "缺失 Unity 材质资源", "WARNING", "部分材质 GUID 无法定位到 Assets 中的材质文件。", {
                    "count": len(object_data["missingMaterialAssets"]),
                    "items": object_data["missingMaterialAssets"][:30],
                })
            else:
                _add_check(checks, "MAT-002", "材质", "Unity 材质资源", "PASS", "已引用的 Unity 材质资源均可定位。")
            if object_data["missingMainTextureAssets"]:
                _add_check(checks, "MAT-003", "贴图", "缺失 Unity 主贴图资源", "WARNING", "部分 Unity 材质的 MainTex 指向缺失资源。", {
                    "count": len(object_data["missingMainTextureAssets"]),
                    "items": object_data["missingMainTextureAssets"][:30],
                })
            else:
                _add_check(checks, "MAT-003", "贴图", "Unity 主贴图资源", "PASS", "未发现缺失的 MainTex 资源。")
            _add_check(checks, "OBJ-004", "场景对象", "空层级对象", "INFO", "空层级对象是常见的 Unity 组织节点，不会自动判为错误。", {
                "count": len(object_data["emptyHierarchyObjects"]),
                "samples": object_data["emptyHierarchyObjects"][:15],
            })
            if object_data["duplicateGameObjectNames"]:
                _add_check(checks, "OBJ-005", "场景对象", "重复 GameObject 名称", "INFO", "发现重复对象名称；Unity 允许重名，转换器会在 Blender 中自动处理名称冲突。", {
                    "groups": object_data["duplicateGameObjectNames"][:30],
                })
            else:
                _add_check(checks, "OBJ-005", "场景对象", "GameObject 名称", "PASS", "舞台根对象下没有重复 GameObject 名称。")
        except Exception as exc:
            _add_check(checks, "OBJ-000", "场景对象", "Hierarchy 对象检查", "WARNING", "无法完成额外的 Hierarchy 诊断；不影响已生成的 PMX 文件。", {"error": str(exc)})
            object_data = {"error": str(exc)}
    else:
        object_data = None
        _add_check(checks, "OBJ-000", "场景对象", "Hierarchy 对象检查", "INFO", "未提供 Unity 场景路径，跳过额外对象关系检查。")

    mesh_diagnostics = (
        object_data.get("meshChannelDiagnostics", {})
        if isinstance(object_data, dict) else {}
    )
    if isinstance(mesh_diagnostics, dict) and mesh_diagnostics.get("schema") in (
        "scsp-mesh-channel-diagnostics-v5", "scsp-mesh-channel-diagnostics-v6"
    ):
        scopes = mesh_diagnostics.get("scopes", {})
        source_scope = scopes.get("source", {})
        included_scope = scopes.get("included", {})
        excluded_scope = scopes.get("excludedOnly", {})
        shared_scope = scopes.get("shared", {})
        scope_details = {
            "sourceScope": source_scope,
            "includedScope": included_scope,
            "excludedOnlyScope": excluded_scope,
            "sharedScope": shared_scope,
        }
        for check in checks:
            if check.get("id") == "SRC-005":
                missing_count = mesh_diagnostics.get("conversionMissingNormalsCount", 0)
                included_decoded = _count(included_scope.get("decodedMeshes"))
                included_with_normals = _count(included_scope.get("withNormals"))
                if missing_count:
                    status = "WARNING"
                    message = "参与转换的 Mesh 中仍有对象缺少法线数据。"
                elif not included_decoded:
                    status = "PASS"
                    message = "本次没有成功解码的 Mesh 纳入转换；被排除对象的法线缺失不计入本项警告。"
                else:
                    status = "PASS"
                    message = "参与转换的 Mesh 均包含法线数据；仅被排除对象的缺失法线不计入本项警告。"
                check["status"] = status
                check["message"] = message
                check.setdefault("details", {}).update({
                    "withNormals": included_with_normals,
                    "decodedMeshes": included_decoded,
                    "missingMeshCount": missing_count,
                    "diagnosticsAvailable": True,
                    "diagnosticScope": "conversion_included_meshes",
                    "scopeStats": scope_details,
                    "missingMeshSamples": mesh_diagnostics.get("conversionMissingNormals", [])[:10],
                    "normalEvidenceCounts": included_scope.get("normalMissingEvidenceCounts", {}),
                    "normalEvidenceNote": "仅根据 Renderer 与材质引用可见性分类；不是实际 MMD 阴影/光照结果的判定，也不会自动重算法线。",
                    "evidenceSamplesByCategory": {
                        category: [item for item in mesh_diagnostics.get("conversionMissingNormals", []) if item.get("normalEvidence") == category][:10]
                        for category in included_scope.get("normalMissingEvidenceCounts", {})
                    },
                })
            elif check.get("id") == "SRC-006":
                missing_count = mesh_diagnostics.get("conversionMissingUV0Count", 0)
                warning_count = mesh_diagnostics.get("conversionMissingUV0WarningCount", 0)
                info_count = mesh_diagnostics.get("conversionMissingUV0InfoCount", 0)
                risk_counts = included_scope.get("uv0MissingRiskCounts", {})
                included_decoded = _count(included_scope.get("decodedMeshes"))
                included_with_uv = _count(included_scope.get("withUV0"))
                if warning_count:
                    status = "WARNING"
                    message = "参与转换的 Mesh 中存在缺少 UV0 且检测到 MainTex 或材质用途未知的对象；需要人工确认。"
                elif info_count:
                    status = "INFO"
                    message = "参与转换的 Mesh 中存在缺少 UV0，但关联材质未检测到 MainTex；本项降为 INFO。MainTex 检测不覆盖 Shader 的其他自定义纹理属性。"
                elif missing_count:
                    status = "INFO"
                    message = "参与转换的 Mesh 存在缺少 UV0 的对象，但无法判定其贴图风险；请查看对象级诊断。"
                else:
                    status = "PASS"
                    message = "参与转换的 Mesh 均包含 UV0；仅被排除对象的缺失 UV0 不计入本项警告。"
                check["status"] = status
                check["message"] = message
                check.setdefault("details", {}).update({
                    "withUV0": included_with_uv,
                    "decodedMeshes": included_decoded,
                    "missingMeshCount": missing_count,
                    "warningMeshCount": warning_count,
                    "infoMeshCount": info_count,
                    "uvRiskCounts": risk_counts,
                    "diagnosticsAvailable": True,
                    "diagnosticScope": "conversion_included_meshes",
                    "scopeStats": scope_details,
                    "missingMeshSamples": mesh_diagnostics.get("conversionMissingUV0", [])[:10],
                    "warningMeshSamples": [item for item in mesh_diagnostics.get("conversionMissingUV0", []) if item.get("uvRisk") != "NO_MAIN_TEXTURE_DETECTED"][:10],
                    "infoMeshSamples": [item for item in mesh_diagnostics.get("conversionMissingUV0", []) if item.get("uvRisk") == "NO_MAIN_TEXTURE_DETECTED"][:10],
                    "uvRiskNote": "NO_MAIN_TEXTURE_DETECTED 仅表示当前只读检查未在 Unity 材质中找到 _MainTex；不代表没有其他 Shader 纹理属性。",
                })
        source_comparison = {}
        if source_validation:
            source_comparison = {
                "sourceMeshFilterComponents": _count(source_validation.get("meshFilterComponents")),
                "diagnosticMeshFilterComponents": _count(mesh_diagnostics.get("meshFilterComponents")),
                "sourceNullMeshFilters": _count(source_validation.get("nullMeshFilters")),
                "diagnosticNullMeshFilters": _count(mesh_diagnostics.get("nullMeshFilterComponents")),
                "sourceUniqueMeshReferences": _count(source_validation.get("uniqueMeshReferences")),
                "diagnosticUniqueMeshReferences": _count(mesh_diagnostics.get("uniqueMeshReferences")),
                "sourceDecodedMeshes": _count(source_validation.get("decodedMeshes")),
                "diagnosticDecodedMeshes": _count(mesh_diagnostics.get("decodedMeshes")),
                "sourceWithNormals": _count(source_validation.get("withNormals")),
                "diagnosticWithNormals": _count(mesh_diagnostics.get("withNormals")),
                "sourceWithUV0": _count(source_validation.get("withUV0")),
                "diagnosticWithUV0": _count(mesh_diagnostics.get("withUV0")),
            }
            source_comparison["countsMatch"] = all((
                source_comparison["sourceMeshFilterComponents"] == source_comparison["diagnosticMeshFilterComponents"],
                source_comparison["sourceNullMeshFilters"] == source_comparison["diagnosticNullMeshFilters"],
                source_comparison["sourceUniqueMeshReferences"] == source_comparison["diagnosticUniqueMeshReferences"],
                source_comparison["sourceDecodedMeshes"] == source_comparison["diagnosticDecodedMeshes"],
                source_comparison["sourceWithNormals"] == source_comparison["diagnosticWithNormals"],
                source_comparison["sourceWithUV0"] == source_comparison["diagnosticWithUV0"],
            ))
        mesh_diagnostics["sourceCountComparison"] = source_comparison
        diagnostic_complete = (
            mesh_diagnostics.get("decodedMeshes") == mesh_diagnostics.get("uniqueMeshReferences")
            and not mesh_diagnostics.get("unresolvedMeshReferenceCount")
            and not mesh_diagnostics.get("decodeErrorCount")
        )
        scope_accounting = mesh_diagnostics.get("scopeAccounting", {})
        scope_accounting_ok = bool(scope_accounting.get("countsMatch"))
        inventory_summary = mesh_diagnostics.get("meshInventorySummary", {})
        inventory_complete = bool(
            inventory_summary.get("complete")
            and inventory_summary.get("identityComplete")
            and inventory_summary.get("scopeCountsMatch")
        )
        if diagnostic_complete and scope_accounting_ok and inventory_complete and (not source_comparison or source_comparison.get("countsMatch")):
            diagnostic_message = (
                "对象级 Mesh 诊断与完整 GUID/fileID 资源清单均通过，且与 Unity 资源验证的法线/UV 汇总数量一致。"
                if source_comparison else
                "对象级 Mesh 诊断与完整 GUID/fileID 资源清单均通过；本次没有可用于交叉核对的 Unity 资源汇总。"
            )
            _add_check(checks, "SRC-009", "Mesh", "Mesh 对象级诊断一致性", "PASS", diagnostic_message, {
                **source_comparison,
                "missingNormals": mesh_diagnostics.get("missingNormalsCount", 0),
                "missingUV0": mesh_diagnostics.get("missingUV0Count", 0),
                "conversionMissingNormals": mesh_diagnostics.get("conversionMissingNormalsCount", 0),
                "conversionMissingUV0": mesh_diagnostics.get("conversionMissingUV0Count", 0),
                "conversionUniqueMeshReferences": mesh_diagnostics.get("conversionUniqueMeshReferences", 0),
                "excludedOnlyUniqueMeshReferences": mesh_diagnostics.get("excludedOnlyUniqueMeshReferences", 0),
                "sharedMeshReferencesAcrossIncludedAndExcludedObjects": mesh_diagnostics.get("sharedMeshReferencesAcrossIncludedAndExcludedObjects", 0),
                "scopes": mesh_diagnostics.get("scopes", {}),
                "scopeAccounting": scope_accounting,
                "meshInventorySummary": inventory_summary,
            })
        else:
            _add_check(checks, "SRC-009", "Mesh", "Mesh 对象级诊断一致性", "WARNING", "对象级 Mesh 诊断未能完整解码、资源身份清单不完整、范围分解不一致，或与 Unity 资源验证汇总数量不一致；请查看诊断详情。", {
                **source_comparison,
                "scopeAccounting": scope_accounting,
                "meshInventorySummary": inventory_summary,
                "unresolvedMeshReferences": mesh_diagnostics.get("unresolvedMeshReferences", [])[:10],
                "decodeErrors": mesh_diagnostics.get("decodeErrors", [])[:10],
            })
    else:
        _add_check(checks, "SRC-009", "Mesh", "Mesh 对象级诊断一致性", "INFO", "未执行对象级 Mesh 通道诊断。")

    # 3) Blender rebuild report.
    if rebuild_report is None:
        _add_check(checks, "BLD-001", "Blender 重建", "Blender 重建报告", "FAIL", "缺少或无法读取 Blender 重建报告。")
        rebuild_stats = {}
    else:
        rebuild_stats = rebuild_report.get("stats", {}) if isinstance(rebuild_report.get("stats"), dict) else {}
        mesh_objects = _count(rebuild_stats.get("meshObjects"))
        mesh_filters_seen = _count(rebuild_stats.get("meshFiltersEncountered"))
        mesh_filter_accounting = _count(rebuild_stats.get("meshFilterAccounting"))
        missing_mesh = rebuild_stats.get("missingMesh", []) or []
        mesh_errors = rebuild_stats.get("meshErrors", []) or []
        if missing_mesh or mesh_errors:
            _add_check(checks, "BLD-001", "Blender 重建", "Mesh 重建错误", "FAIL", "Blender 重建阶段存在缺失 Mesh 或 Mesh 解码错误。", {
                "missingMesh": missing_mesh[:30],
                "meshErrors": mesh_errors[:30],
            })
        elif mesh_objects > 0:
            _add_check(checks, "BLD-001", "Blender 重建", "Mesh 重建", "PASS", "Blender 已生成有效 Mesh 对象。", {
                "meshObjects": mesh_objects,
                "meshAssetsDecoded": _count(rebuild_stats.get("meshAssetsDecoded")),
                "triangles": _count(rebuild_stats.get("triangles")),
            })
        else:
            _add_check(checks, "BLD-001", "Blender 重建", "Mesh 重建", "FAIL", "重建报告中没有有效 Mesh 对象。")

        if source_validation is not None and "meshFilterComponents" in source_validation:
            source_mesh_filters = _count(source_validation.get("meshFilterComponents"))
            if mesh_filter_accounting != source_mesh_filters:
                _add_check(checks, "BLD-002", "Blender 重建", "源 MeshFilter 数量核对", "FAIL", "Unity 源场景与 Blender 重建报告的 MeshFilter 总数不一致。", {
                    "sourceMeshFilterComponents": source_mesh_filters,
                    "rebuildMeshFilterAccounting": mesh_filter_accounting,
                })
            else:
                _add_check(checks, "BLD-002", "Blender 重建", "源 MeshFilter 数量核对", "PASS", "Unity 与 Blender 的 MeshFilter 数量一致。", {
                    "sourceMeshFilterComponents": source_mesh_filters,
                    "rebuildMeshFilterAccounting": mesh_filter_accounting,
                })
        if mesh_objects < mesh_filters_seen:
            _add_check(checks, "BLD-003", "Blender 重建", "MeshFilter 输出覆盖", "WARNING", "有 MeshFilter 未生成 Blender Mesh 对象；可能是空网格、非三角拓扑或没有有效面。", {
                "meshFiltersEncountered": mesh_filters_seen,
                "meshObjects": mesh_objects,
            })
        elif mesh_objects > mesh_filters_seen:
            _add_check(checks, "BLD-003", "Blender 重建", "MeshFilter 输出覆盖", "WARNING", "生成的 Mesh 对象数量多于记录的 MeshFilter 数量，请检查重建报告。", {
                "meshFiltersEncountered": mesh_filters_seen,
                "meshObjects": mesh_objects,
            })
        else:
            _add_check(checks, "BLD-003", "Blender 重建", "MeshFilter 输出覆盖", "PASS", "每个已处理 MeshFilter 均生成了 Blender Mesh 对象。")

        skipped = rebuild_stats.get("skippedInactive", []) or []
        skipped_mesh_filters = sum(_count(item.get("meshFilters")) for item in skipped if isinstance(item, dict))
        if skipped_mesh_filters:
            _add_check(checks, "BLD-004", "场景对象", "inactive 对象排除", "WARNING", "转换时排除了带 MeshFilter 的 inactive 对象；PMX 可能缺少这些隐藏对象的几何。", {
                "skippedInactiveGameObjects": len(skipped),
                "skippedInactiveMeshFilters": skipped_mesh_filters,
            })
        else:
            _add_check(checks, "BLD-004", "场景对象", "inactive 对象排除", "PASS", "未发现因 inactive 策略而排除的 MeshFilter。")

        material_warnings = rebuild_stats.get("materialWarnings", []) or []
        if material_warnings:
            _add_check(checks, "BLD-005", "材质", "Blender 材质重建警告", "WARNING", "Blender 重建材质时出现警告。", {"warnings": material_warnings[:30]})
        else:
            _add_check(checks, "BLD-005", "材质", "Blender 材质重建", "PASS", "未记录材质重建异常。")

        if _count(rebuild_stats.get("particleSystemComponents")):
            _add_check(checks, "BLD-006", "动态效果", "ParticleSystem 动态效果", "WARNING", "舞台含 Unity ParticleSystem；静态 PMX 不会保留实时粒子模拟。", {
                "particleSystemComponents": _count(rebuild_stats.get("particleSystemComponents")),
                "particleSystemRendererComponents": _count(rebuild_stats.get("particleSystemRendererComponents")),
            })
        else:
            _add_check(checks, "BLD-006", "动态效果", "ParticleSystem 动态效果", "PASS", "未检测到 Unity ParticleSystem 组件。")

        material_count = _count(rebuild_stats.get("materials"))
        textured_material_count = _count(rebuild_stats.get("texturedMaterials"))
        if mesh_objects and material_count == 0:
            _add_check(checks, "BLD-007", "材质", "材质数量", "WARNING", "舞台包含 Mesh，但 Blender 重建报告中的材质数量为 0。")
        elif material_count > textured_material_count:
            _add_check(checks, "BLD-007", "材质", "未使用主贴图的材质", "INFO", "部分材质没有可识别的 MainTex；纯色材质可能是正常情况。", {
                "materials": material_count,
                "texturedMaterials": textured_material_count,
                "withoutMainTexture": material_count - textured_material_count,
            })
        else:
            _add_check(checks, "BLD-007", "材质", "材质数量", "PASS", "材质数量检查通过。", {
                "materials": material_count,
                "texturedMaterials": textured_material_count,
            })

    # 4) PMX parser, structure and texture paths.
    if pmx_report is None:
        _add_check(checks, "PMX-001", "PMX", "MMD Tools 导出报告", "FAIL", "缺少或无法读取 MMD Tools 原生导出报告。")
    else:
        if pmx_report.get("status") == "completed":
            _add_check(checks, "PMX-001", "PMX", "MMD Tools 导出状态", "PASS", "MMD Tools 原生 PMX 导出完成。")
        else:
            _add_check(checks, "PMX-001", "PMX", "MMD Tools 导出状态", "FAIL", "MMD Tools 导出报告未标记为 completed。", {"status": pmx_report.get("status"), "error": pmx_report.get("error", "")})

        parser_check = pmx_report.get("mmd_tools_parser_check") or pmx_report.get("mmd_tools_parser_check_after_texture_rewrite") or {}
        if not parser_check and isinstance(pmx_report.get("readback_validation"), dict):
            parser_check = pmx_report.get("readback_validation")
            parser_ok = True
        else:
            parser_ok = str(parser_check.get("status", "")).upper() == "PASSED"
        if parser_ok:
            _add_check(checks, "PMX-002", "PMX", "PMX 结构回读", "PASS", "MMD Tools 已成功重新读取 PMX 结构。", {
                key: parser_check.get(key) for key in ("vertices", "faces", "materials", "textures", "bones", "morphs", "rigid_bodies", "joints") if key in parser_check
            })
        else:
            _add_check(checks, "PMX-002", "PMX", "PMX 结构回读", "FAIL", "PMX 结构回读检查未通过。", parser_check)

        parser_counts = parser_check if isinstance(parser_check, dict) else {}
        vertices = _count(parser_counts.get("vertices"))
        faces = _count(parser_counts.get("faces"))
        materials = _count(parser_counts.get("materials"))
        bones = _count(parser_counts.get("bones"))
        if parser_ok and (vertices <= 0 or faces <= 0 or materials <= 0 or bones <= 0):
            _add_check(checks, "PMX-003", "PMX", "PMX 核心数据数量", "FAIL", "PMX 缺少顶点、面、材质或根骨骼数据。", {
                "vertices": vertices, "faces": faces, "materials": materials, "bones": bones,
            })
        elif parser_ok:
            _add_check(checks, "PMX-003", "PMX", "PMX 核心数据数量", "PASS", "PMX 顶点、面、材质和骨骼数量均大于 0。", {
                "vertices": vertices, "faces": faces, "materials": materials, "bones": bones,
            })

        texture_validation = pmx_report.get("texture_validation", {})
        if not isinstance(texture_validation, dict):
            texture_validation = {}
        texture_ok = (
            str(texture_validation.get("status", "")).upper() == "PASSED"
            and _count(texture_validation.get("unresolved_count")) == 0
            and _count(texture_validation.get("ambiguous_count")) == 0
        )
        if texture_ok:
            _add_check(checks, "PMX-004", "贴图", "PMX 贴图引用报告", "PASS", "PMX 贴图引用报告全部解析成功。", {
                "reference_count": _count(texture_validation.get("reference_count")),
                "resolved_count": _count(texture_validation.get("resolved_count")),
                "unresolved_count": _count(texture_validation.get("unresolved_count")),
                "ambiguous_count": _count(texture_validation.get("ambiguous_count")),
            })
        else:
            _add_check(checks, "PMX-004", "贴图", "PMX 贴图引用报告", "FAIL", "PMX 贴图引用报告存在缺失、歧义或未通过状态。", texture_validation)

    if pmx_file is None and pmx_report:
        reported_pmx = pmx_report.get("output_pmx")
        if reported_pmx:
            pmx_file = Path(reported_pmx)
    if pmx_file is None or not pmx_file.is_file() or pmx_file.stat().st_size <= 0:
        _add_check(checks, "PMX-005", "PMX", "PMX 文件", "FAIL", "PMX 文件不存在或文件大小为 0。", {"pmx": str(pmx_file) if pmx_file else ""})
    else:
        actual_bytes = pmx_file.stat().st_size
        reported_bytes = _count(pmx_report.get("output_pmx_bytes")) if pmx_report else 0
        if reported_bytes and reported_bytes != actual_bytes:
            _add_check(checks, "PMX-005", "PMX", "PMX 文件大小", "FAIL", "PMX 实际文件大小与导出报告不一致。", {
                "actualBytes": actual_bytes,
                "reportedBytes": reported_bytes,
            })
        else:
            _add_check(checks, "PMX-005", "PMX", "PMX 文件", "PASS", "PMX 文件存在且大小有效。", {"bytes": actual_bytes})

        if read_texture_table_bytes is None:
            _add_check(checks, "PMX-006", "贴图", "PMX 贴图表读取", "WARNING", "无法加载 PMX 贴图表读取器，跳过二进制贴图表复核。")
        else:
            try:
                table = read_texture_table_bytes(pmx_file.read_bytes())
                refs = table.get("textures", [])
                _add_check(checks, "PMX-006", "PMX", "PMX 二进制结构", "PASS", "PMX 文件头和贴图字符串表可正常读取。", {
                    "version": table.get("version"),
                    "textureCount": table.get("texture_count"),
                    "tailBytes": table.get("tail_bytes"),
                })
                path_ok = []
                path_missing = []
                path_unsafe = []
                path_external = []
                path_empty = []
                for index, ref in enumerate(refs):
                    target, status = _safe_texture_target(pmx_file, ref)
                    item = {"index": index, "reference": ref, "resolvedPath": str(target) if target else ""}
                    if status == "ok":
                        path_ok.append(item)
                    elif status in ("missing", "missing_absolute"):
                        path_missing.append(item)
                    elif status == "unsafe_relative":
                        path_unsafe.append(item)
                    elif status == "absolute_external":
                        path_external.append(item)
                    else:
                        path_empty.append(item)
                if path_missing or path_unsafe:
                    _add_check(checks, "PMX-007", "贴图", "PMX 实际贴图文件", "FAIL", "PMX 中存在缺失或越界的贴图路径。", {
                        "missing": path_missing[:30],
                        "unsafe": path_unsafe[:30],
                    })
                elif path_external or path_empty:
                    _add_check(checks, "PMX-007", "贴图", "PMX 实际贴图文件", "WARNING", "部分贴图路径为外部绝对路径或空引用；请确认资源可移植性。", {
                        "resolved": len(path_ok),
                        "externalAbsolute": path_external[:30],
                        "empty": path_empty[:30],
                    })
                else:
                    _add_check(checks, "PMX-007", "贴图", "PMX 实际贴图文件", "PASS", "PMX 中所有贴图引用均指向输出目录内的有效文件。", {
                        "textureCount": len(refs),
                        "resolved": len(path_ok),
                    })
                if pmx_report and isinstance(pmx_report.get("texture_references"), list):
                    report_refs = pmx_report.get("texture_references", [])
                    if report_refs != refs:
                        _add_check(checks, "PMX-008", "贴图", "贴图表与导出报告一致性", "FAIL", "PMX 实际贴图表与导出报告记录的贴图引用不一致。", {
                            "pmxTextureCount": len(refs),
                            "reportTextureCount": len(report_refs),
                        })
                    else:
                        _add_check(checks, "PMX-008", "贴图", "贴图表与导出报告一致性", "PASS", "PMX 实际贴图表与导出报告一致。", {"textureCount": len(refs)})
            except Exception as exc:
                _add_check(checks, "PMX-006", "PMX", "PMX 二进制结构", "FAIL", "无法读取 PMX 二进制结构或贴图表。", {"error": str(exc)})

    status = _status_from_checks(checks)
    summary = {
        "status": status,
        "passed": sum(item["status"] == "PASS" for item in checks),
        "warnings": sum(item["status"] == "WARNING" for item in checks),
        "failures": sum(item["status"] == "FAIL" for item in checks),
        "info": sum(item["status"] == "INFO" for item in checks),
        "totalChecks": len(checks),
    }
    recommendations = []
    if summary["failures"]:
        recommendations.append("先处理所有 FAIL 项，再将该 PMX 用于正式 MMD 场景。")
    if summary["warnings"]:
        recommendations.append("检查 WARNING 项；特别留意 inactive 几何、缺少 UV/法线、材质引用和动态粒子。")
    if not summary["failures"] and not summary["warnings"]:
        recommendations.append("静态资源检查通过；仍建议在 MMD 9.32 中实际打开并检查舞台外观。")

    return {
        "schema": "scsp-stage-quality-report-v1",
        "tool": "SCSP Stage Converter",
        "version": "2.4.9-dev",
        "generatedAt": datetime.now().astimezone().isoformat(timespec="seconds"),
        "stage": {
            "root": root_name,
            "scene": str(scene or ""),
            "project": str(project or ""),
            "pmx": str(pmx_file or ""),
        },
        "summary": summary,
        "source": {
            key: source_validation.get(key)
            for key in ("gameObjects", "meshFilterComponents", "rendererComponents", "uniqueMeshReferences", "decodedMeshes", "nullMeshFilters", "resolvedMeshFilterComponents", "vertices", "indices", "submeshes", "materialSlots", "uniqueMaterials", "mainTextureRefs", "resolvedMainTextures", "withNormals", "withUV0")
        } if source_validation else {},
        "meshDiagnostics": mesh_diagnostics if isinstance(mesh_diagnostics, dict) else {},
        "objects": object_data,
        "rebuild": rebuild_stats,
        "pmx": {
            "status": pmx_report.get("status") if pmx_report else None,
            "parser": (pmx_report.get("mmd_tools_parser_check") or pmx_report.get("mmd_tools_parser_check_after_texture_rewrite") or {}) if pmx_report else {},
            "textureValidation": pmx_report.get("texture_validation", {}) if pmx_report else {},
        },
        "checks": checks,
        "recommendations": recommendations,
    }


def write_text_report(report, path):
    summary = report.get("summary", {})
    lines = [
        "SCSP Stage Converter V2.4.9-dev — inactive 状态一致性与根对象追踪增强版",
        "=" * 68,
        "舞台根对象：{}".format(report.get("stage", {}).get("root", "")),
        "Unity 场景：{}".format(report.get("stage", {}).get("scene", "")),
        "PMX 文件：{}".format(report.get("stage", {}).get("pmx", "")),
        "生成时间：{}".format(report.get("generatedAt", "")),
        "",
        "总体结果：{}".format(summary.get("status", "UNKNOWN")),
        "检查项：{}  通过：{}  警告：{}  失败：{}  信息：{}".format(
            summary.get("totalChecks", 0), summary.get("passed", 0),
            summary.get("warnings", 0), summary.get("failures", 0), summary.get("info", 0),
        ),
        "",
        "检查详情",
        "-" * 68,
    ]
    for item in report.get("checks", []):
        lines.append("[{}] {} / {} — {}".format(item.get("status"), item.get("category"), item.get("name"), item.get("message")))
        details = item.get("details")
        if details:
            lines.append(json.dumps(details, ensure_ascii=False, indent=2))
    diagnostics = report.get("meshDiagnostics", {})
    lines.extend(["", "Mesh 缺失数据定位", "-" * 68])
    if diagnostics.get("schema") not in ("scsp-mesh-channel-diagnostics-v5", "scsp-mesh-channel-diagnostics-v6"):
        lines.append("未生成对象级 Mesh 诊断数据；请查看 OBJ-000 / SRC-009 检查项中的具体原因。")
    else:
        lines.append("统计口径：按唯一 Mesh GUID + fileID 统计；同时区分 activeInHierarchy 与实际转换纳入范围。")
        object_summary = report.get("objects", {})
        lines.append("inactive 策略：{}；参与转换 GameObject：{}；排除 GameObject：{}".format(
            diagnostics.get("conversionPolicy", "exclude"),
            object_summary.get("conversionIncludedGameObjects", 0),
            object_summary.get("conversionExcludedGameObjects", 0),
        ))
        lines.append("所选根对象 Unity activeInHierarchy：{}；根对象在所选子树内 active：{}；根对象外部祖先链 active：{}".format(
            object_summary.get("rootActiveInHierarchy", True),
            object_summary.get("rootActiveWithinSelectedRoot", True),
            object_summary.get("rootExternalAncestorChainActive", True),
        ))
        lines.append("MeshFilter 组件 fileID 定位：已识别 {} / {}；未识别 {}；完整：{}".format(
            diagnostics.get("meshFilterComponentIdCoverage", {}).get("identifiedComponentFileIDs", 0),
            diagnostics.get("meshFilterComponentIdCoverage", {}).get("totalMeshFilterComponents", 0),
            diagnostics.get("meshFilterComponentIdCoverage", {}).get("missingComponentFileIDs", 0),
            "是" if diagnostics.get("meshFilterComponentIdCoverage", {}).get("complete") else "否",
        ))
        for ancestor in object_summary.get("rootExternalAncestors", []):
            lines.append("根对象外部祖先：{} [GameObject fileID={}; Transform fileID={}] | activeSelf={}".format(
                ancestor.get("hierarchyPath", ancestor.get("name", "")),
                ancestor.get("gameObjectFileID", ""), ancestor.get("transformFileID", ""),
                ancestor.get("activeSelf", True),
            ))
        for item in diagnostics.get("nullMeshFilterComponentDetails", []):
            lines.append("空 Mesh 引用：{} [GameObject fileID={}] | MeshFilter component fileID={} | GUID={} | Mesh fileID={}".format(
                item.get("hierarchyPath", item.get("gameObjectName", "")),
                item.get("gameObjectFileID", ""), item.get("meshFilterComponentFileID", "未识别"),
                item.get("meshGUID", ""), item.get("meshFileID", ""),
            ))
        lines.append("参与转换 Mesh：{}；仅被排除对象引用的 Mesh：{}；跨纳入/排除对象共享 Mesh：{}".format(
            diagnostics.get("conversionUniqueMeshReferences", 0),
            diagnostics.get("excludedOnlyUniqueMeshReferences", 0),
            diagnostics.get("sharedMeshReferencesAcrossIncludedAndExcludedObjects", 0),
        ))
        lines.append("MeshFilter 组件：{}；有效引用：{}；空引用：{}；唯一 Mesh 引用：{}".format(
            diagnostics.get("meshFilterComponents", 0),
            diagnostics.get("validMeshFilterComponents", 0),
            diagnostics.get("nullMeshFilterComponents", 0),
            diagnostics.get("uniqueMeshReferences", 0),
        ))
        scopes = diagnostics.get("scopes", {})
        for scope_key, scope_label in (
            ("source", "全场景 Source"),
            ("included", "实际参与转换 Included"),
            ("excludedOnly", "仅被排除对象引用 Excluded-only"),
            ("shared", "Active / Inactive Shared"),
        ):
            scope = scopes.get(scope_key, {})
            lines.append(
                "{}：唯一 Mesh={}；有效 MeshFilter={}；解码={}；有法线={}；缺少法线={}；有 UV0={}；缺少 UV0={}；缺失通道并集={}".format(
                    scope_label,
                    scope.get("uniqueMeshReferences", 0),
                    scope.get("meshFilterComponents", 0),
                    scope.get("decodedMeshes", 0),
                    scope.get("withNormals", 0),
                    scope.get("missingNormalsCount", 0),
                    scope.get("withUV0", 0),
                    scope.get("missingUV0Count", 0),
                    scope.get("missingEitherCount", 0),
                )
            )
        accounting = diagnostics.get("scopeAccounting", {})
        lines.append("四范围数量分解一致：{}".format("是" if accounting.get("countsMatch") else "否"))
        included_uv_risks = scopes.get("included", {}).get("uv0MissingRiskCounts", {})
        lines.append(
            "参与转换 UV0 风险分类：MainTex 已分配={}；材质用途未知={}；未检测到 MainTex（INFO）={}".format(
                included_uv_risks.get("TEXTURED_MATERIAL_ASSIGNED", 0),
                included_uv_risks.get("MATERIAL_USAGE_UNKNOWN", 0),
                included_uv_risks.get("NO_MAIN_TEXTURE_DETECTED", 0),
            )
        )
        included_normal_evidence = scopes.get("included", {}).get("normalMissingEvidenceCounts", {})
        lines.append("参与转换法线缺失证据分类：带纹理材质 Renderer={}；已知非纹理材质 Renderer={}；材质用途未知 Renderer={}；未检测到 Renderer={}".format(
            included_normal_evidence.get("RENDERER_WITH_TEXTURED_MATERIAL", 0),
            included_normal_evidence.get("RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL", 0),
            included_normal_evidence.get("RENDERER_MATERIAL_USAGE_UNKNOWN", 0),
            included_normal_evidence.get("NO_RENDERER_DETECTED", 0),
        ))
        lines.append("注意：法线证据分类只依据 Renderer / 材质引用，不代表已证明实际 MMD 阴影效果异常；不会自动重算法线。")
        inventory_summary = diagnostics.get("meshInventorySummary", {})
        lines.append("Mesh 完整资源身份清单：记录 {} / {}；GUID/fileID 完整 {}；清单完整={}；范围计数一致={}".format(
            inventory_summary.get("recordedUniqueMeshReferences", 0),
            inventory_summary.get("totalUniqueMeshReferences", 0),
            inventory_summary.get("identifiedUniqueMeshReferences", 0),
            "是" if inventory_summary.get("complete") else "否",
            "是" if inventory_summary.get("scopeCountsMatch") else "否",
        ))
        if diagnostics.get("conversionPolicy") == "exclude":
            excluded_inventory = [
                item for item in diagnostics.get("meshInventory", [])
                if item.get("scope") == "excludedOnly"
            ]
            lines.append("仅被排除对象引用的 Mesh 完整清单：{} 个".format(len(excluded_inventory)))
            for item in excluded_inventory:
                lines.append("  - {} | GUID={} | fileID={} | 顶点={} | 法线={} | UV0={} | 状态={} | 资源={}".format(
                    item.get("meshName") or "<未解码>", item.get("meshGUID", ""),
                    item.get("meshFileID", ""), item.get("vertexCount", 0),
                    "有" if item.get("hasNormals") else "无/未知",
                    "有" if item.get("hasUV0") else "无/未知",
                    item.get("decodeStatus", "unknown"), item.get("assetPath", ""),
                ))
                for obj in item.get("gameObjects", []):
                    if obj.get("conversionIncluded"):
                        continue
                    lines.append("      GameObject: {} [fileID={}] | MeshFilter component fileID={} | 决策={}".format(
                        obj.get("hierarchyPath", obj.get("gameObjectName", "")),
                        obj.get("gameObjectFileID", ""),
                        ",".join(str(value) for value in obj.get("meshFilterComponentFileIDs", [])) or "未识别",
                        obj.get("conversionDecision", "unknown"),
                    ))
                    for material in obj.get("materials", []):
                        lines.append("        Unity Material: {} | GUID={} | fileID={} | MainTex GUID={} | MainTex fileID={}".format(
                            material.get("name", "<未知材质>"), material.get("materialGUID", ""),
                            material.get("materialFileID", ""), material.get("mainTextureGUID", ""),
                            material.get("mainTextureFileID", 0),
                        ))
        lines.append("参与转换 Mesh 的法线缺失：{} 个唯一 Mesh".format(diagnostics.get("conversionMissingNormalsCount", 0)))
        for item in diagnostics.get("conversionMissingNormals", []):
            lines.append("- {} | Mesh fileID={} | 顶点={} | 法线证据={} | 资源={}".format(
                item.get("meshName", "<未命名>"), item.get("meshFileID", ""),
                item.get("vertexCount", 0), item.get("normalEvidence", "UNKNOWN"), item.get("assetPath", ""),
            ))
            for obj in item.get("gameObjects", []):
                lines.append("    GameObject: {} [fileID={}] | MeshFilter x{} [component fileID={}] | activeSelf={} | activeInHierarchy={} | conversionIncluded={} | decision={}".format(
                    obj.get("hierarchyPath", obj.get("gameObjectName", "")),
                    obj.get("gameObjectFileID", ""), obj.get("meshFilterComponents", 1),
                    ",".join(str(value) for value in obj.get("meshFilterComponentFileIDs", [])) or "未识别",
                    obj.get("activeSelf", True), obj.get("activeInHierarchy", True),
                    obj.get("conversionIncluded", True), obj.get("conversionDecision", "unknown"),
                ))
                hierarchy_cause = obj.get("hierarchyInactiveCause")
                if hierarchy_cause:
                    lines.append("        Unity activeInHierarchy 原因：{} [fileID={}] | {}".format(
                        hierarchy_cause.get("name", "<unknown>"),
                        hierarchy_cause.get("gameObjectFileID", ""),
                        hierarchy_cause.get("hierarchyPath", ""),
                    ))
                blocker = obj.get("conversionBlockingInactiveObject")
                if blocker:
                    lines.append("        转换排除原因对象：{} [fileID={}] | {}".format(
                        blocker.get("name", "<unknown>"), blocker.get("gameObjectFileID", ""),
                        blocker.get("hierarchyPath", ""),
                    ))
        lines.append("")
        lines.append("参与转换 Mesh 的 UV0 缺失：{} 个唯一 Mesh".format(diagnostics.get("conversionMissingUV0Count", 0)))
        for item in diagnostics.get("conversionMissingUV0", []):
            lines.append("- {} | Mesh fileID={} | 顶点={} | UV 风险={} | 资源={}".format(
                item.get("meshName", "<未命名>"), item.get("meshFileID", ""),
                item.get("vertexCount", 0), item.get("uvRisk", "UNKNOWN"),
                item.get("assetPath", ""),
            ))
            for obj in item.get("gameObjects", []):
                lines.append("    GameObject: {} [fileID={}] | MeshFilter x{} [component fileID={}] | 纹理材质={} | activeSelf={} | activeInHierarchy={} | conversionIncluded={} | decision={}".format(
                    obj.get("hierarchyPath", obj.get("gameObjectName", "")),
                    obj.get("gameObjectFileID", ""), obj.get("meshFilterComponents", 1),
                    ",".join(str(value) for value in obj.get("meshFilterComponentFileIDs", [])) or "未识别",
                    "是" if obj.get("hasTexturedMaterial") else "否/未知",
                    obj.get("activeSelf", True), obj.get("activeInHierarchy", True),
                    obj.get("conversionIncluded", True), obj.get("conversionDecision", "unknown"),
                ))
                hierarchy_cause = obj.get("hierarchyInactiveCause")
                if hierarchy_cause:
                    lines.append("        Unity activeInHierarchy 原因：{} [fileID={}] | {}".format(
                        hierarchy_cause.get("name", "<unknown>"),
                        hierarchy_cause.get("gameObjectFileID", ""),
                        hierarchy_cause.get("hierarchyPath", ""),
                    ))
                blocker = obj.get("conversionBlockingInactiveObject")
                if blocker:
                    lines.append("        转换排除原因对象：{} [fileID={}] | {}".format(
                        blocker.get("name", "<unknown>"), blocker.get("gameObjectFileID", ""),
                        blocker.get("hierarchyPath", ""),
                    ))
                for material in obj.get("materials", []):
                    lines.append("        Material: {} | MainTex={}".format(
                        material.get("name", "<未知材质>"),
                        "已分配" if material.get("mainTextureAssigned") is True else (
                            "未检测到" if material.get("mainTextureAssigned") is False else "未知"
                        ),
                    ))
        lines.append("")
        lines.append("缺少法线或 UV0 的唯一 Mesh（去重并集）：{} 个".format(
            diagnostics.get("conversionMissingEitherCount", 0)
        ))
        lines.append("注意：法线缺失与 UV0 缺失清单可能有重叠，不能直接相加。")
        for scope_label, normals_key, uv_key in (
            ("仅被排除对象引用 Excluded-only", "excludedOnlyMissingNormals", "excludedOnlyMissingUV0"),
            ("跨纳入/排除对象共享 Shared", "sharedMissingNormals", "sharedMissingUV0"),
        ):
            normals_rows = diagnostics.get(normals_key, [])
            uv_rows = diagnostics.get(uv_key, [])
            lines.append("")
            lines.append("{} — 缺少法线：{} 个；缺少 UV0：{} 个".format(
                scope_label, len(normals_rows), len(uv_rows)
            ))
            for item in normals_rows:
                lines.append("  [法线] {} | GUID={} | fileID={} | {}".format(
                    item.get("meshName", "<未命名>"), item.get("meshGUID", ""),
                    item.get("meshFileID", ""), item.get("assetPath", ""),
                ))
                for obj in item.get("gameObjects", []):
                    lines.append("      {} [GameObject fileID={}] | MeshFilter component fileID={} | activeSelf={} | activeInHierarchy={} | conversionIncluded={} | decision={}".format(
                        obj.get("hierarchyPath", obj.get("gameObjectName", "")),
                        obj.get("gameObjectFileID", ""),
                        ",".join(str(value) for value in obj.get("meshFilterComponentFileIDs", [])) or "未识别",
                        obj.get("activeSelf", True), obj.get("activeInHierarchy", True),
                        obj.get("conversionIncluded", False), obj.get("conversionDecision", "unknown"),
                    ))
            for item in uv_rows:
                lines.append("  [UV0] {} | 风险={} | GUID={} | fileID={} | {}".format(
                    item.get("meshName", "<未命名>"), item.get("uvRisk", "UNKNOWN"),
                    item.get("meshGUID", ""), item.get("meshFileID", ""), item.get("assetPath", ""),
                ))
                for obj in item.get("gameObjects", []):
                    lines.append("      {} [GameObject fileID={}] | MeshFilter component fileID={} | activeSelf={} | activeInHierarchy={} | conversionIncluded={} | decision={}".format(
                        obj.get("hierarchyPath", obj.get("gameObjectName", "")),
                        obj.get("gameObjectFileID", ""),
                        ",".join(str(value) for value in obj.get("meshFilterComponentFileIDs", [])) or "未识别",
                        obj.get("activeSelf", True), obj.get("activeInHierarchy", True),
                        obj.get("conversionIncluded", False), obj.get("conversionDecision", "unknown"),
                    ))
        comparison = diagnostics.get("sourceCountComparison", {})
        if comparison:
            lines.append("与 Unity 源验证汇总数量一致：{}".format(
                "是" if comparison.get("countsMatch") else "否"
            ))
        if diagnostics.get("unresolvedMeshReferenceCount"):
            lines.append("无法定位的 Mesh 引用：")
            for item in diagnostics.get("unresolvedMeshReferences", []):
                lines.append("- GUID={} | fileID={}".format(
                    item.get("meshGUID", ""), item.get("meshFileID", "")
                ))
                for obj in item.get("gameObjects", []):
                    lines.append("    GameObject: {} [fileID={}]".format(
                        obj.get("hierarchyPath", obj.get("gameObjectName", "")),
                        obj.get("gameObjectFileID", ""),
                    ))
        if diagnostics.get("decodeErrorCount"):
            lines.append("Mesh 解码异常：")
            for item in diagnostics.get("decodeErrors", []):
                lines.append("- {} | GUID={} | fileID={} | {}".format(
                    item.get("assetPath", ""), item.get("meshGUID", ""),
                    item.get("meshFileID", ""), item.get("error", ""),
                ))

    lines.extend(["", "建议", "-" * 68])
    lines.extend("- " + item for item in report.get("recommendations", []))
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


def run_quality_check(
    source_validation_path,
    rebuild_report_path,
    pmx_report_path,
    pmx_path,
    project,
    scene,
    root_name,
    json_output,
    text_output=None,
):
    source_validation = _read_json(source_validation_path)
    rebuild_report = _read_json(rebuild_report_path)
    pmx_report = _read_json(pmx_report_path)
    report = build_quality_report(
        source_validation=source_validation,
        rebuild_report=rebuild_report,
        pmx_report=pmx_report,
        pmx_path=pmx_path,
        project=project,
        scene=scene,
        root_name=root_name,
    )
    json_output = Path(json_output)
    json_output.parent.mkdir(parents=True, exist_ok=True)
    json_output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if text_output:
        text_output = Path(text_output)
        text_output.parent.mkdir(parents=True, exist_ok=True)
        write_text_report(report, text_output)
    return report


def main():
    parser = argparse.ArgumentParser(description="SCSP V2.4.9 stage quality inspection")
    parser.add_argument("--source-validation", required=True)
    parser.add_argument("--rebuild-report", required=True)
    parser.add_argument("--pmx-report", required=True)
    parser.add_argument("--pmx", required=True)
    parser.add_argument("--project", required=True)
    parser.add_argument("--scene", required=True)
    parser.add_argument("--root", required=True)
    parser.add_argument("--json-out", required=True)
    parser.add_argument("--text-out", default="")
    args = parser.parse_args()
    report = run_quality_check(
        args.source_validation,
        args.rebuild_report,
        args.pmx_report,
        args.pmx,
        args.project,
        args.scene,
        args.root,
        args.json_out,
        args.text_out or None,
    )
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    print("REPORT:", Path(args.json_out).resolve())
    if args.text_out:
        print("TEXT REPORT:", Path(args.text_out).resolve())
    return {"PASS": 0, "WARNING": 1, "FAIL": 2}.get(report["summary"]["status"], 3)


if __name__ == "__main__":
    raise SystemExit(main())
