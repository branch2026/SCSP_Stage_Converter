# V2.4.6-dev — Inactive Mode Comparison 双模式转换对比

## 新增（独立只读模块）

- 新增 `Validator/compare_inactive_modes.py`：自动比较同一舞台 include / exclude 两份质量报告 JSON，生成独立 JSON + TXT 对比报告。
- 新增 `RUN_COMPARE.bat`：双击弹出文件选择窗口，依次选择勾选与未勾选报告，选择输出位置即可生成对比报告。
- 主 GUI 增加「双模式对比…」按钮（仅新建输出报告，不触发重新转换）。
- 进行 13 项跨报告一致性检查：同一场景、资源守恒、对象清单、MeshFilter、唯一 Mesh、范围诊断、法线/UV0、Blender 对象、PMX 三角面、贴图引用、异常新增贴图和输出数量变化。
- 保留 311 个被排除 GameObject 的完整路径、fileID 和自身/父级 inactive 原因；其中带 MeshFilter 对象的清单独立呈现。
- 自动列出 PMX 贴图表中的差异文件名；材质仅报告数量差值，不虚构原报告没有提供的材质名称。
- 对缺失 GUID 的 Mesh 明确标注数据来源限制；不把 133 个排除 Mesh 的数量误当成 133 条 GUID 明细。
- 可自动识别 JSON 旧版顶层 version 字段与实际 Mesh 诊断 Schema 的历史差异；以结构和策略字段判断合法输入。

## 兼容性与保护

- 以 V2.4.5-dev 源码为开发基线。
- `SceneBuilder`、`PMXExporter`、`UnityParser/batch_folder_discovery.py`、`Validator/validate_source.py` 和 `RUN_GUI.bat` 等 15 个转换保护文件保持逐字节一致。
- 仅新增报告比较器及调用按钮，不修改原有转换函数、`Validator/quality_check.py`、Mesh/法线/UV/材质/贴图、inactive 决策或 PMX 文件。
- 输入错误、策略相同、不同舞台、源资源不一致时拒绝比较；数值不一致时以 WARNING 输出可审计结果，不擅自修复。

## 真实报告回归

- `185_SankaF` V2.4.5-dev 2026-11-20 include/exclude JSON 实机报告：对比 13/13 PASS。
- 311 个排除对象，其中 133 个带 MeshFilter；133 个 Excluded-only 唯一 Mesh。
- 可从缺失通道列表识别 7 个 Mesh 的 GUID，剩余 126 个 GUID 无法仅凭已有报告恢复。
- PMX 面数差 4,649，顶点差 5,995，材质数差 4，贴图数差 3，三张差异贴图均被准确列出。
- 原始质量 WARNING 保留；MMD 9.32 外观验收及其他舞台 Windows 回归仍需实机验证。
