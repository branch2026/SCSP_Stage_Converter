"""Non-destructive optional stage-effects pipeline for Unity stage PMX."""
