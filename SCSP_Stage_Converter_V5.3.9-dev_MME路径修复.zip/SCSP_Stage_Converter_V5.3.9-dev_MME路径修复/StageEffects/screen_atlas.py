"""Use one capture surface and UV morphs to play a video texture atlas."""
from collections import defaultdict
import json
from math import ceil, isfinite
from pathlib import Path
from struct import pack_into, unpack_from
import subprocess

from .output_staging import staging_directory
from .pmx_binary import Model, i32
from .screen_input import copy_screen_assets, load_screen_target, package_file, read_screen_png
from .screen_sequence import read_sequence
from .stage_effects import check_dependencies, resolve_effects
from .vmd_codec import parse_vmd, write_vmd


GAP = 4
ATLAS_LIMIT = 4096


def atlas_layout(width, height, count):
    layouts = []
    for columns in range(1,count+1):
        rows = ceil(count/columns)
        w,h = columns*(width+GAP)+GAP, rows*(height+GAP)+GAP
        if w<=ATLAS_LIMIT and h<=ATLAS_LIMIT:
            layouts.append((w*h,max(w,h),columns,rows,w,h))
    if not layouts:
        raise ValueError('画面图集超过 4096×4096，请缩短视频或降低取帧数量')
    _,_,columns,rows,w,h = min(layouts)
    return columns,rows,w,h


def atlas_model(model, index, tile_size, layout, count):
    target = model.materials[index]
    selected = set(model.face_indices(target.start,target.faces))
    if any(selected.intersection(model.face_indices(mat.start,mat.faces))
           for other,mat in enumerate(model.materials) if other!=index):
        raise ValueError('屏幕与其他材质共用顶点，无法独立使用图集')
    ref = 'textures/ScreenVideo/atlas.png'
    texture_id = len(model.textures)
    if texture_id>=2**(model.tex_width*8-1) or ref in model.textures:
        raise ValueError('PMX 的纹理索引空间不足或图集路径冲突')
    width,height = tile_size
    columns,_,atlas_width,atlas_height = layout
    data = bytearray(model.data)
    for vertex in selected:
        at = model.vertex_offsets[vertex]+24
        u,v = unpack_from('<2f',data,at)
        if not all(isfinite(value) and -.0001<=value<=1.0001 for value in (u,v)):
            raise ValueError('屏幕 UV 超出单张贴图，暂不支持重复采样的屏幕')
        u,v = (min(1,max(0,value)) for value in (u,v))
        pack_into('<2f',data,at,(GAP+.5+u*(width-1))/atlas_width,
                  (GAP+.5+v*(height-1))/atlas_height)
    at = target.sphere_at-model.tex_width
    data[at:target.sphere_at] = model.idx(texture_id,model.tex_width)
    texture_at = model.texture_table_at
    data[texture_at:texture_at+4] = i32(texture_id+1)
    data[model.material_table_at:model.material_table_at] = model.encode_str(ref)
    prepared=Model(bytes(data))
    effects = [
        dict(name=f'Atlas{i:03d}',type='uv_offset',material_indices=[index],
             offset=[(i%columns)*(width+GAP)/atlas_width,(i//columns)*(height+GAP)/atlas_height])
        for i in range(1,count)
    ]
    resolved,_ = resolve_effects(prepared,dict(schema_version=1,effects=effects))
    payload = prepared.add_morphs(resolved)
    return payload,ref,[fx['name'] for fx in effects]


def atlas_motion(model_name, motion, names, step):
    original = parse_vmd(motion)
    if original['model']!=model_name or any(original[key] for key in
            ('bone_keys','camera_keys','light_keys','self_shadow_keys','model_display_keys')):
        raise ValueError('需要当前舞台的纯表情 VMD')
    last = original['last_morph_frame']
    if last>108000:
        raise ValueError('屏幕动作超过支持的帧范围')
    # Frame zero uses the baked first cell. Later cells use one UV offset.
    tracks = defaultdict(dict)
    for name in names:
        tracks[name][0] = 0
    old = 0
    for frame in range(step,last+1,step):
        new = (frame//step)%(len(names)+1)
        if old:
            tracks[names[old-1]].update({frame-1:1,frame:0})
        if new:
            tracks[names[new-1]].update({frame-1:0,frame:1})
        old = new
    for i,name in enumerate(names,1):
        tracks[name][last] = int(old==i)
    frames = [(key['name'],key['frame'],key['weight']) for key in original['morph_frames']]
    frames.extend((name,frame,weight) for name,track in tracks.items() for frame,weight in track.items())
    return write_vmd(model_name,frames)


def bind_video_atlas(folder, frames, output, *, material, step, executable, video_source):
    ordered,pngs,dimensions = read_sequence(frames)
    count = len(ordered)
    del pngs
    source,model,report,evidence,index = load_screen_target(folder,material)
    authored = [fx for fx in evidence.get('effects',[]) if any(row['index']==index for row in fx['materials'])]
    if (len(authored)!=1 or authored[0]['type']!='material_alpha' or
            len(authored[0]['materials'])!=1 or model.materials[index].sphere_mode):
        raise ValueError('屏幕需要一个独占的显隐控制和空闲的主 UV')
    layout = atlas_layout(*dimensions,count)
    payload,ref,names = atlas_model(model,index,dimensions,layout,count)
    checked = Model(payload)
    assert checked.face_index_count==model.face_index_count
    assert len(checked.materials)==len(model.materials)
    assert checked.original_tail==model.original_tail
    originals = [row['file'] for row in report.get('vmd_outputs',[]) if row['mode']=='morph-only']
    if len(originals)!=1:
        raise ValueError('效果包需要唯一的正式表情 VMD')
    motions = {source.stem+'_单材质屏幕.vmd':originals[0]}
    if report.get('screen_preview'):
        motions[source.stem+'_单材质屏幕验收.vmd'] = report['screen_preview']['file']
    with staging_directory(output.parent) as temp:
        pack=temp/'package'
        pack.mkdir()
        copy_screen_assets(folder,pack,model)
        atlas=pack/ref
        atlas.parent.mkdir(parents=True,exist_ok=True)
        columns,rows,width,height = layout
        cmd=[str(executable),'-hide_banner','-nostdin','-v','error','-framerate','1',
             '-start_number','1','-i',str(frames/'frame_%03d.png'),
             '-vf',f'tile={columns}x{rows}:nb_frames={count}:padding={GAP}:margin={GAP}:color=black',
             '-frames:v','1','-threads:v','1',str(atlas)]
        try:
            result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',
                                  timeout=120,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired as error:
            raise ValueError('生成屏幕图集超时') from error
        if result.returncode:
            raise ValueError('FFmpeg 无法生成屏幕图集\n'+result.stderr[-1200:])
        if read_screen_png(atlas)[1]!=(width,height):
            raise ValueError('屏幕图集尺寸与布局不一致')
        pmx=pack/(source.stem+'_单材质屏幕.pmx')
        pmx.write_bytes(payload)
        for filename,original in motions.items():
            source_vmd=package_file(folder,original).read_bytes()
            (pack/filename).write_bytes(atlas_motion(model.name,source_vmd,names,step))
        assert not check_dependencies(pmx,checked)[1]
        result=dict(output_pmx=pmx.name,vmd_files=list(motions),material=model.materials[index].name,
                    atlas=ref,atlas_dimensions=[width,height],screen_dimensions=list(dimensions),
                    frame_count=count,video_source=video_source,source_screen_visibility_preserved=True)
        (pack/'屏幕视频报告.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf8')
        (pack/'使用说明.txt').write_text(
            '先打开单材质屏幕 PMX，再选中舞台载入对应的其中一份 VMD。\n'
            '如附带验收 VMD，可从第 0 帧快速查看原有屏幕切换。正式 VMD 按舞台原时序。\n',
            encoding='utf-8-sig')
        pack.rename(output)
    return result
