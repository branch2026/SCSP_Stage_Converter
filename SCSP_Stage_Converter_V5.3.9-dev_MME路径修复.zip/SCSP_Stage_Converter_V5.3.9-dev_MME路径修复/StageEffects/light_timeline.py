"""Read bound Timeline light curves and EffectPlayer activation markers."""
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache
from math import isfinite, isnan
from pathlib import Path
import re

from .timeline_visibility import array, field, reference, track_clips
from .unity_effect_probe import YAML_BLOCK, guid_of, yaml_name


PLAY_MARKER = 'f76f11df31b83276827104e85e4cc004'
ANIMATION_PLAYABLE = 'c31c7cbc024ee92b63890de66c0c98fc'
PROPERTIES = {'m_Enabled', 'm_Intensity', 'm_Range', 'm_Color.r', 'm_Color.g', 'm_Color.b'}
SNAP = 0.000025


@dataclass(frozen=True)
class Curve:
    times: tuple
    keys: tuple

    def value(self, seconds, discrete=False):
        right = bisect_right(self.times, seconds + SNAP)
        if not right or right == len(self.times):
            return self.keys[0 if not right else -1][0]
        start, end = self.times[right-1:right+1]
        left_value, _, slope_out = self.keys[right-1]
        right_value, slope_in, _ = self.keys[right]
        if discrete or not isfinite(slope_out) or not isfinite(slope_in):
            return left_value
        span = end - start
        w = max(0.0, (seconds - start) / span)
        return ((2*w**3-3*w*w+1)*left_value + (w**3-2*w*w+w)*span*slope_out +
                (-2*w**3+3*w*w)*right_value + (w**3-w*w)*span*slope_in)


def read_curves(block, axes=()):
    fields = re.findall(r'^ *time: ([^\n]+)\n +value: ([^\n]+)\n +inSlope: ([^\n]+)\n +outSlope: ([^\n]+)',
                        block, re.M)
    weights = re.findall(r'^ +weightedMode: (\d+)', block, re.M)
    if not fields or len(fields) != len(weights) or any(w != '0' for w in weights):
        raise ValueError('无可读关键帧或使用了加权切线')
    times = tuple(float(values[0]) for values in fields)
    if (not all(isfinite(v) and v >= 0 for v in times) or
            any(a >= b for a,b in zip(times,times[1:]))):
        raise ValueError('关键帧时间无效')
    curves = []
    for axis in axes or ('',):
        keys = []
        for _, *values in fields:
            if axis:
                values = [dict(re.findall(r'([xyz]): *([^,}]+)', token))[axis] for token in values]
            key = tuple(float(value) for value in values)
            if not isfinite(key[0]) or any(isnan(x) for x in key[1:]):
                raise ValueError('关键帧数值无效')
            keys.append(key)
        curves.append(Curve(times,tuple(keys)))
    return curves


def nested_field(block, name, default):
    match = re.search(r'^    '+name+r': *([^\n]+)',block,re.M)
    return match[1] if match else default


@dataclass(frozen=True)
class Clip:
    start: float
    duration: float
    clip_in: float
    speed: float
    source_length: float
    loop: bool
    before: float
    after: float
    blend_in: float
    blend_out: float
    mix_in: Curve | None
    mix_out: Curve | None

    @property
    def end(self):
        return self.start+self.duration

    def sample(self, seconds):
        elapsed = min(self.duration,max(0,seconds-self.start))
        mapped = self.clip_in + elapsed*self.speed
        if self.loop and self.source_length > 0:
            mapped %= self.source_length
        else:
            mapped = min(mapped,self.source_length)
        weight = 1.
        if self.mix_in and elapsed < self.blend_in:
            weight *= self.mix_in.value(elapsed/self.blend_in)
        if self.mix_out and self.duration-elapsed < self.blend_out:
            weight *= self.mix_out.value(1-(self.duration-elapsed)/self.blend_out)
        return mapped, max(0., min(1.,weight))


def read_clip(block, playable, source):
    def number(name, default='0'):
        return float(field(block,name) or default)
    start,duration,clip_in,speed = (number('m_Start'),number('m_Duration'),number('m_ClipIn'),
                                    number('m_TimeScale','1'))
    length = float(nested_field(source,'m_StopTime','0'))
    mode = field(playable,'m_Loop') or '0'
    if (not all(isfinite(n) and n>=0 for n in (start,duration,clip_in,speed,length)) or
            not duration or not speed or mode not in ('0','1','2')):
        raise ValueError('不支持此灯光片段的时间设置')
    looping = mode=='1' or (mode=='0' and nested_field(source,'m_LoopTime','0')=='1')
    blends = [max(number('m_Blend'+side+'Duration'),number('m_Ease'+side+'Duration'),0)
              for side in ('In','Out')]
    mix = [read_curves(array(block,'m_Mix'+side+'Curve'))[0] if span else None
           for side,span in zip(('In','Out'),blends)]
    holds = []
    for side in ('Pre','Post'):
        mode = field(block,'m_'+side+'ExtrapolationMode') or '0'
        if mode not in ('0','1'):
            raise ValueError('灯光片段使用了不支持的外推模式')
        holds.append(number('m_'+side+'ExtrapolationTime') if mode=='1' else 0)
    return Clip(start,duration,clip_in,speed,length,looping,*holds,*blends,*mix)


def refs(block):
    return [reference(token) for token in re.findall(r'\{fileID:[^}\n]+\}',block)
            if reference(token)[0] not in ('','0')]


class LightTimeline:
    def __init__(self):
        self.channels = {}
        self.markers = {}
        self.effect_events = defaultdict(list)
        self.sources = []

    def value(self, go, channel, seconds, default):
        curves = self.channels.get((go,channel),())
        if channel == 'm_IsActive':
            trigger = self.markers.get(go)
            if trigger is not None and seconds + SNAP >= trigger:
                default = True
        current = [(clip,curve) for clip,curve in curves if clip.start-SNAP <= seconds < clip.end-SNAP]
        if not current:
            current = [(clip,curve) for clip,curve in curves
                       if ((clip.before>0 and clip.start-clip.before-SNAP <= seconds < clip.start-SNAP) or
                           (clip.after>0 and clip.end-SNAP <= seconds < clip.end+clip.after-SNAP))]
            if not current:
                return default
        discrete = channel in ('m_IsActive','m_Enabled')
        samples = []
        for clip,curve in current:
            mapped,weight = clip.sample(seconds)
            samples.append((curve.value(mapped,discrete),weight))
        if discrete:
            return max(samples,key=lambda item:item[1])[0] >= 0.5
        weight = sum(weight for _,weight in samples)
        return (sum(value*w for value,w in samples) + default*max(0,1-weight)) / max(1,weight)


def read_light_timeline(assets, scene):
    schedule = LightTimeline()

    @lru_cache(maxsize=None)
    def documents(path):
        return {fileid:(kind,block) for kind,fileid,block in
                YAML_BLOCK.findall(path.read_text('utf-8-sig',errors='replace'))}

    scene_docs = documents(Path(scene))
    directors = [block for kind,block in scene_docs.values()
                 if kind=='320' and field(block,'m_Enabled')=='1' and field(block,'m_InitialTime')=='0']
    if not directors:
        return schedule
    asset_paths = {g:p for suffix in ('*.asset','*.playable','*.anim') for p in assets.rglob(suffix)
                   if (g:=guid_of(p))}

    def resolve(ref, local):
        key,guid = ref
        path = asset_paths.get(guid) if guid else local
        return (path,key,documents(path).get(key,('',''))[1]) if path else (None,key,'')

    objects = {key:yaml_name(block) for key,(kind,block) in scene_docs.items() if kind=='1'}
    transforms = {key:(reference(field(block,'m_GameObject'))[0],reference(field(block,'m_Father'))[0])
                  for key,(kind,block) in scene_docs.items() if kind in ('4','224')}
    parents = {go:transforms.get(parent,('',''))[0] for go,parent in transforms.values()}
    children = defaultdict(list)
    for go, parent in parents.items():
        children[parent,objects.get(go)].append(go)

    def lineage(go):
        result = set()
        while go and go not in result:
            result.add(go)
            go = parents.get(go)
        return result

    owners = {reference(field(block,'m_GameObject'))[0] for kind,block in scene_docs.values() if kind=='108'}
    relevant = set().union(*(lineage(go) for go in owners))
    player_objects = {go for go in relevant if any(objects.get(a)=='EffectPlayer' for a in lineage(go)-{go})}
    by_name = defaultdict(list)
    for go in player_objects:
        by_name[objects.get(go)].append(go)
    channel_tracks = defaultdict(list)
    failed = set()
    for director in directors:
        timeline_path, _, timeline = resolve(reference(field(director,'m_PlayableAsset')),None)
        if not timeline:
            continue
        track_map = {}
        queue = [(track,timeline_path,True,None) for track in refs(array(timeline,'m_Tracks'))]
        visited = set()
        while queue:
            ref, local, parent_active, grade = queue.pop()
            path,key,block = resolve(ref,local)
            identity = (path,key)
            if not block or identity in visited:
                continue
            visited.add(identity)
            name = yaml_name(block) or ''
            variant = re.fullmatch(r'Grade_(\d+)',name,re.I)
            if variant:
                grade = int(variant[1])
            active = parent_active and field(block,'m_Muted')=='0' and 'focusonly' not in name.casefold()
            if active:
                track_map[identity] = block
                for marker in refs(array(block,'m_Markers')):
                    mp,_,marker_block = resolve(marker,path)
                    effect = field(marker_block,'_effectName')
                    matches = by_name.get(effect,())
                    try:
                        time = float(field(marker_block,'m_Time'))
                    except ValueError:
                        continue
                    if (not effect or not isfinite(time) or time<0 or
                            reference(field(marker_block,'m_Script'))[1]!=PLAY_MARKER):
                        continue
                    schedule.effect_events[effect].append(dict(time=time,grade=grade,asset=str(mp.relative_to(assets))))
                    if len(matches)==1:
                        target = matches[0]
                        schedule.markers[target] = min(schedule.markers.get(target,time),time)
                        schedule.sources.append(dict(type='effect_play_marker', object=effect, time=time,
                                                     asset=str(mp.relative_to(assets)), track=name))
            queue.extend((child,path,active,grade) for child in refs(array(block,'m_Children')))
        bindings = re.findall(r'^  - key: (\{[^\n]+\})\n    value: (\{[^\n]+\})',array(director,'m_SceneBindings'),re.M)
        for track_ref,object_ref in bindings:
            path,key,_ = resolve(reference(track_ref),timeline_path)
            track = track_map.get((path,key))
            if not track:
                continue
            fileid,guid = reference(object_ref)
            kind,component = scene_docs.get(fileid,('',''))
            if guid or kind!='95':
                continue
            bind_go = reference(field(component,'m_GameObject'))[0]
            track_channels = defaultdict(list)
            for block in track_clips(track):
                play_path,_,playable = resolve(reference(field(block,'m_Asset')),path)
                clip_path,_,source = resolve(reference(field(playable,'m_Clip')),play_path)
                if not source or reference(field(playable,'m_Script'))[1] != ANIMATION_PLAYABLE:
                    continue
                for group, axes, prefix in (('m_FloatCurves',(),r'^  - serializedVersion:.*$'),
                                            ('m_PositionCurves','xyz',r'^  - curve:.*$')):
                    for curve in re.split(prefix,array(source,group),flags=re.M)[1:]:
                        object_path = re.search(r'^    path:[ \t]*(.*)$',curve,re.M)
                        if not object_path:
                            continue
                        go = bind_go
                        for part in filter(None,object_path[1].strip().strip('"').split('/')):
                            options = children.get((go,part),())
                            go = options[0] if len(options)==1 else ''
                        if go not in relevant:
                            continue
                        prop = re.search(r'^    attribute: *(.+)$',curve,re.M)
                        klass = re.search(r'^    classID: *(\d+)',curve,re.M)
                        if axes:
                            channels = tuple('position.'+axis for axis in axes)
                        elif not prop or not klass:
                            continue
                        elif (klass[1]=='108' and go in owners and prop[1] in PROPERTIES or
                              klass[1]=='1' and prop[1]=='m_IsActive'):
                            channels = (prop[1],)
                        else:
                            continue
                        try:
                            timing = read_clip(block,playable,source)
                            values = read_curves(curve,axes)
                        except (KeyError,ValueError):
                            failed.update((go,name) for name in channels)
                            continue
                        for channel,value in zip(channels,values):
                            track_channels[go,channel].append((timing,value))
                        schedule.sources.append(dict(type='animation_clip', object=objects[go],
                                                     asset=str(clip_path.relative_to(assets)), fields=list(channels),
                                                     start=timing.start, duration=timing.duration))
            for channel,curves in track_channels.items():
                channel_tracks[channel].append(curves)
    schedule.channels = {channel:tracks[0] for channel,tracks in channel_tracks.items()
                         if len(tracks)==1 and channel not in failed}
    return schedule
