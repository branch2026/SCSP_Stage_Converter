# V3.1 舞台效果后处理模块

这是**额外的效果层**，不会修改 V3.0 原生导出的 PMX 或它的质量报告。

## 能够做到

- 读取 PMX 2.0 / 2.1 的材质槽、形态键、基础 UV / 附加 UV 信息，以及依赖贴图路径。
- 通过 JSON 精确选定材质，为舞台增加**透明度、材质色彩、基础/附加 UV 偏移**形态键。支持已经带形态键/骨骼的 PMX。
- 在完整复用原始网格、材质、骨骼和物理尾数据的前提下，独立打包效果 PMX、贴图、测试 VMD 和 JSON 追踪报告。
- GUI 可手动制作控制项，也可勾选**批量后处理**，让有同名 `StageEffects/profiles/<舞台根对象名>.json` 的舞台自动应用。
- 一个舞台效果后处理失败不会导致原始 PMX 转换失败，原始 PMX 保持不变。

## 不能擅自宣称做到

- 材质形态键变化不是 MME Bloom / 加法混合；不会自动模拟真实 Unity Light。
- VMD 示例为**测试动作**，不代表原版 MV 演出时序。
- 未取得 Unity Animator/Timeline 时不会猜测骨骼、屏幕或 Shader 动画；`unity-verified` 需要在 JSON 记录出处。
- MME/EMM/APNG 依赖目前做识别和检查，不捆绑第三方作者的 FX。

## 使用方法

### A. GUI

1. 启动 `RUN_GUI.bat`，在主界面点击「舞台效果工具…」，选择现有 PMX。
2. 查看材质槽列表；**只选实际需要改变的材质**，指定名称和效果类型，再保存独立效果版。
3. 用汉化版 MMD932 加载新 PMX，拉动表情操作滑杆，导入测试 VMD 验收。

### B. 命令行与批量模式

```
py -3 StageEffects/stage_effects.py inspect "G:\\STAGE\\PMX\\某舞台\\stage.pmx" --out stage_inspect.json
py -3 StageEffects/stage_effects.py build --pmx stage.pmx --profile StageEffects/profiles/182_SuperD.example.json --out "G:\\STAGE\\StageEffects_Output"
```

如果需要**批量自动加入已确认的手动效果**，先复制 `.example.json` 为精确的 `182_SuperD.json`，并放到主程序的 `StageEffects/profiles`；在 GUI 勾选「批量转换后添加效果（实验）」后开始转换。没有匹配 JSON 的舞台保持原样，原始 PMX 不变。原始质量报告只验证原始 PMX，效果版有单独的 `StageEffects_Report.json`。

## 研发记录及旧参考

- `182_SuperD` 已存在 Codex 编写的灯面控制、音箱橙色和光帯移动样板；这些样板不自动作为通用转换规则。
- ITTW46 的 404/682 示例证明 PMX 材质/骨骼/UV + VMD + EMM/FX 能协同完成演出；本模块只实现有明确定义和可验证的安全子集。
- 对每个新舞台，请先选取真实 Unity 资源有依据的可控层，后续才能自动推导并扩展到骨骼与 Timeline。

## 源头数据与 ITTW46 参考检查

Unity 证据采集（只读，不生成虚构动画）：

```
py -3 StageEffects/unity_effect_probe.py --project "G:\\STAGE\\Stage\\SUPER DUPER DREAMER\\scene-project" --scene Assets/182_superd.unity --out UnityEffectEvidence.json
```

独立扫描 PMX、VMD、EMD/EMM、FX、APNG 的依赖：

```
py -3 StageEffects/dependency_audit.py "D:\\MMD\\参考舞台" --out StageDependencyAudit.json
```

该报告只标记第三方 FX 绑定和是否存在 APNG，不会自动复制 FX、改变其路径，或把 `EMM` 中原作者的绝对路径当作可移植配置。未来需要根据有许可证的效果库实现相应的 MME 映射。

**CP932 约束**：VMD 形态键名称只有 15 字节，不支持的简体字或超长名称会被明确拒绝。GUI 默认使用 `灯面消去`，已适配 MMD；如果自定义名称报错，请改为可编码的日文或短名称。

## V3.1.1-dev：多材质 Phase 与 VMD 兼容性诊断

### 多材质 Phase 形态键

新增 `type: "material_state"`。一个 PMX 材质形态键可以同时控制多个材质槽，支持 PMX 标准的 28 个材质系数：diffuse、specular、shininess、ambient、edge、texture、sphere 和 toon 系数。

- `operation: "multiply"`：PMX operation 0，未填写通道使用 1.0 作为乘法单位值。
- `operation: "add"`：PMX operation 1，未填写通道使用 0.0 作为加法单位值。
- 每个 offset 必须精确指定一个 `material` 名称或 `material_index`。
- 不允许同一 Phase morph 对同一材质重复写入 offset。

可编辑模板：`Examples/Phase_MultiMaterial/Phase_MultiMaterial_Template.json`。
ITTW46 404 的实际 Phase1～Phase5 数据摘录位于 `References/ITTW46_404_Phase_Reference_READONLY.json`，只作只读学习参考，不是其他舞台的可直接套用 profile。

### VMD A/B 兼容性诊断

新的 `StageEffects/vmd_codec.py` 会验证完整 VMD 0002 结构。若 profile 指定：

```json
"vmd": { "neutral_anchor_bone": "全ての親" }
```

效果包会输出两份独立动作：

- `*_效果测试.vmd`
- `*_效果测试_中性骨骼锚点.vmd`

第二份只在第 0 帧增加一个零位移、单位四元数的骨骼帧。它是用来排查“只有形态键轨道时 MMD 是否正常载入”的 A/B 诊断变体，不代表已经证明兼容性问题得到修复。

如用户从 MMD 手动注册并保存了同模型动作，可运行：

```bat
py -3 StageEffects\\vmd_compare.py "MMD保存的动作.vmd" "程序生成的动作.vmd" --out "VMD结构对比.json"
```

比较结果包括模型标识、骨骼/形态键轨道、关键帧、权重、各区段数量及 SHA-256。实际播放仍需在 MMD 9.32 中验收。
