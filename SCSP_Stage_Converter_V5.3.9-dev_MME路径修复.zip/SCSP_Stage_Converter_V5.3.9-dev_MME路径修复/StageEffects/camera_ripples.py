"""Translate the source camera-bound water ripple into a Timeline-driven MME effect."""
import re
from struct import pack

from SceneBuilder.rebuild_stage_blender import parse_mesh, parse_scene, vec
from .external_lights import material_record
from .particles import number, particle_size_curve, scalar_range, section
from .pmx_binary import Model, i32
from .timeline_visibility import array, field, reference
from .unity_effect_probe import YAML_BLOCK


RIPPLE_MESH = 'b962484eb16ac4d4dae71a54e6cfd570'
RIPPLE_MATERIAL = 'a09171a8e0a4ecb418a4681c642e2e96'
CAMERA_CONSTRAINT = 'e09ffc8a5afa0fc58df656a55b8446fb'


def shader(cue, lifetime, center, size_keys, alpha, tint, distortion, scroll):
    def curve(var, keys):
        lines = [f'    float {var} = {keys[0][1]:.8f};']
        for (a,v),(b,w) in zip(keys,keys[1:]):
            if b>a and v!=w:
                lines.append(f'    {var} += ({w-v:.8f}) * saturate((phase - {a:.8f}) / {b-a:.8f});')
        return '\n'.join(lines)
    xyz = ', '.join(f'{v:.8f}' for v in center)
    rgb = ', '.join(f'{v:.8f}' for v in tint)
    return f'''float Seconds : TIME < bool SyncInEditMode = true; >;
float4x4 Project : PROJECTION;
texture RingAtlas : MATERIALTEXTURE;
texture DriftTexture < string ResourceName = "textures/AutoStageParticles/RippleDistortion.png"; >;
sampler2D Ring = sampler_state {{
    Texture = <RingAtlas>; MinFilter = Linear; MagFilter = Linear; MipFilter = None;
    AddressU = Wrap; AddressV = Clamp;
}};
sampler2D Drift = sampler_state {{
    Texture = <DriftTexture>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
struct Vertex {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; }};
struct Result {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; float2 state : TEXCOORD1; }};
Result MoveRing(Vertex input) {{
    Result o;
    float age = Seconds - {cue:.8f};
    float phase = saturate(age / {lifetime:.8f});
{curve('radius',size_keys)}
{curve('opacity',alpha)}
    float4 pointInView = float4({xyz}, 1.0);
    pointInView.xy += input.pos.xy * radius;
    o.pos = mul(pointInView, Project);
    o.uv = input.uv;
    o.state = float2(phase, opacity * step(0.0, age) * (1.0 - step({lifetime:.8f}, age)));
    return o;
}}
float4 PaintRing(Result input) : COLOR0 {{
    float phase = input.state.x;
    float frame = min(5.0, floor(phase * 6.0));
    float2 driftUV = input.uv + float2(0.0, phase * {lifetime*scroll:.8f});
    float drift = tex2D(Drift, driftUV).r - 0.5;
    float radial = saturate(input.uv.y + drift * {distortion:.8f});
    float signal = tex2D(Ring, float2(input.uv.x, (frame + lerp(0.006, 0.994, radial)) / 6.0)).r;
    float alpha = signal * input.state.y;
    clip(alpha - 0.0001);
    return float4({rgb}, alpha);
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{kind}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_2_0 MoveRing();
        PixelShader = compile ps_2_0 PaintRing();
        AlphaBlendEnable = true; SrcBlend = SRCALPHA; DestBlend = ONE;
        CullMode = NONE; ZEnable = false; ZWriteEnable = false;
    }}
}}
''' for name,kind in (('CameraRipple','object'),('CameraRippleSS','object_ss')))


def append_camera_ripple(model, scene, assets, schedule, scale):
    empty = (model,{},[])
    if scene is None or schedule is None or not schedule.effect_events or not model.vertex_offsets or not model.bones:
        return empty
    text = scene.read_text('utf-8-sig',errors='replace')
    if RIPPLE_MESH not in text or RIPPLE_MATERIAL not in text:
        return empty
    objects,transforms,by_go,_,by_tid,_,_,_,paths = parse_scene(scene,assets or scene.parent)
    material = paths.get(RIPPLE_MATERIAL)
    mesh = paths.get(RIPPLE_MESH)
    if not material or not mesh:
        return empty
    material_text = material.read_text('utf-8-sig',errors='replace')

    def material_texture(slot):
        match = re.search(r'(?m)^      '+slot+r':\n        m_Texture: (.*)$',material_text)
        return paths.get(reference(match[1])[1]) if match else None

    atlas,drift = (material_texture(slot) for slot in ('_MainTex','_SubTex'))
    if any(not p or p.suffix.lower()!='.png' or not p.is_file() for p in (atlas,drift)):
        return empty
    if any(number(material_text,prop,6)!=value for prop,value in
           (('_BlendSrc',5),('_BlendDst',1),('_ZWriteMode',0),('_DistortSwitch',1))):
        return empty
    blocks = YAML_BLOCK.findall(text)
    renderers = {reference(field(b,'m_GameObject'))[0]:b for k,_,b in blocks
                 if k=='199' and field(b,'m_Enabled')=='1'}
    constraints = {int(reference(field(b,'m_GameObject'))[0]):reference(field(b,'baseTransform'))[0]
                   for k,_,b in blocks if k=='114' and field(b,'m_Enabled')=='1' and
                   reference(field(b,'m_Script'))[1]==CAMERA_CONSTRAINT and
                   reference(field(b,'m_GameObject'))[0]}
    for kind,fileid,block in blocks:
        if kind!='198' or field(block,'looping')!='0' or field(block,'playOnAwake')!='1':
            continue
        go = reference(field(block,'m_GameObject'))[0]
        renderer = renderers.get(go,'')
        if (field(renderer,'m_RenderMode')!='4' or reference(field(renderer,'m_Mesh'))[1]!=RIPPLE_MESH or
                RIPPLE_MATERIAL not in array(renderer,'m_Materials')):
            continue
        try:
            offset,cues,camera,seen = [0.,0.,0.],[],False,set()
            current = int(go)
            while current:
                if not objects[current]['active'] or current in seen:
                    raise ValueError
                seen.add(current)
                if not camera:
                    offset = [a+b for a,b in zip(offset,by_go[current]['pos'])]
                if current in constraints:
                    target = transforms.get(int(constraints[current]))
                    camera = target is not None and objects[target['go']]['name']=='LiveCamera'
                cues.extend(schedule.effect_events.get(objects[current]['name'],()))
                parent = by_go[current]['father']
                current = by_tid[parent] if parent else 0
            times = {event['time'] for event in cues}
            if not camera or len(times)!=1 or abs(offset[2])<0.1:
                continue
            cue = next(iter(times))
            initial, emission, uv = (section(block,name,2) for name in ('InitialModule','EmissionModule','UVModule'))
            lifetime, max_life = scalar_range(initial,'startLifetime')
            size, max_size = scalar_range(initial,'startSize')
            burst = re.findall(r'(?m)^      time: ([^\n]+)$',emission)
            if (not 0<lifetime==max_life<=2 or not 0<size==max_size<=2 or burst!=['0'] or
                    number(emission,'m_BurstCount',4)!=1 or number(uv,'enabled',4)!=1 or
                    number(uv,'tilesX',4)!=1 or number(uv,'tilesY',4)!=6):
                continue
            gradient = section(section(section(block,'ColorModule',2),'gradient',4),'maxGradient',6)
            alpha = [(number(gradient,'atime'+str(i),8)/65535,number_rgba(gradient,i))
                     for i in range(int(number(gradient,'m_NumAlphaKeys',8)))]
            if not alpha:
                continue
            source_color = section(initial,'startColor',4)
            tint = vec(source_color,'maxColor',('r','g','b'),(1,1,1))
            geom = parse_mesh(mesh)
            if not geom or len(geom['positions'])!=len(geom['uv']):
                continue
        except (KeyError,ValueError):
            continue
        count = len(geom['positions'])
        index = len(model.materials)
        tex = len(model.textures)
        if (model.vertex_count+count>2**(8*model.vertex_width) or
                index>=2**(8*model.mat_width-1) or tex>=2**(8*model.tex_width-1)):
            return empty
        vertex = model.vertex_offsets[0]
        face = model.face_index_start-4
        texture_table = model.texture_table_at
        material_at = model.material_table_at
        bone = model.bone_table_at
        positions = b''.join(pack('<8f',x,y,z,0,0,1,u,1-v)+bytes(16*model.uv_count)
                             +b'\0'+Model.idx(0,model.bone_width)+bytes(4)
                             for (x,y,z),(u,v) in zip(geom['positions'],geom['uv']))
        faces = b''.join(Model.idx(model.vertex_count+n,model.vertex_width,signed=False) for n in geom['indices'])
        name = 'AutoCameraRipple_'+fileid
        texture = 'textures/AutoStageParticles/RippleAtlas.png'
        data = model.data
        new = b''.join((data[:vertex-4],i32(model.vertex_count+count),data[vertex:face],positions,
                        i32(model.face_index_count+len(geom['indices'])),data[face+4:texture_table],faces,
                        i32(tex+1),data[texture_table+4:material_at],model.encode_str(texture),
                        i32(index+1),data[material_at+4:bone],
                        material_record(model,name,(1,1,1,1),tex,len(geom['indices'])),data[bone:]))
        center = (offset[0]*scale,offset[1]*scale,abs(offset[2])*scale)
        size_keys = [(t,v*size*scale) for t,v in particle_size_curve(block)]
        fx = shader(cue,lifetime,center,size_keys,alpha,tint,number(material_text,'_DistortAmount',6),
                    number(material_text,'_SubAutoScrollY',6))
        row = dict(material_index=index,material=name,mode='camera_ripple',shader='Unity ParticleSystem',
                   source_emitter=fileid,source_object=objects[int(go)]['name'],cue_seconds=cue,
                   lifetime=lifetime,marker=cues[0]['asset'],fx_code=fx)
        return Model(new),{texture:atlas,'textures/AutoStageParticles/RippleDistortion.png':drift},[row]
    return empty


def number_rgba(gradient, index):
    match = re.search(r'^        key'+str(index)+r': \{[^\n]*\ba: ([^,}]+)',gradient,re.M)
    return float(match[1]) if match else 0.
