"""Trace the source of screen content without inventing a runtime image."""
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
import re

from .dependency_audit import apng_info
from .timeline_visibility import array, field, reference
from .unity_effect_probe import YAML_BLOCK, guid_of, yaml_name
from .vmd_codec import write_vmd


def screen_sources(scene, assets, materials, image_paths, root_name):
    text = scene.read_text('utf-8-sig',errors='replace')
    docs = {fid:(kind,block) for kind,fid,block in YAML_BLOCK.findall(text)}
    game_objects = {fid:yaml_name(block) for fid,(kind,block) in docs.items() if kind=='1'}
    root_ids = [fid for fid,name in game_objects.items() if name==root_name]
    transforms = {fid:(reference(field(block,'m_GameObject'))[0],reference(field(block,'m_Father'))[0])
                  for fid,(kind,block) in docs.items() if kind in ('4','224')}
    parent = {go:transforms.get(father,('', ''))[0] for go,father in transforms.values()}

    def under_root(go):
        seen = set()
        while go and go not in seen:
            if root_ids==[go]:
                return True
            seen.add(go)
            go = parent.get(go)
        return False

    material_map = {mat['guid']:mat for mat in materials}
    local_render_textures = {fid for fid,(kind,_) in docs.items() if kind=='84'}
    external_render_textures = {guid_of(path) for path in assets.rglob('*.renderTexture')}
    cameras = defaultdict(list)
    captures = defaultdict(list)
    renderers = defaultdict(list)
    for fid,(kind,block) in docs.items():
        go = reference(field(block,'m_GameObject'))[0]
        if kind=='20':
            texture = reference(field(block,'m_TargetTexture'))
            if texture[0] not in ('','0'):
                cameras[texture].append(dict(camera_file_id=fid, object=game_objects.get(go)))
        elif kind in ('23','137'):
            for item in re.findall(r'^  - (\{[^\n]+\})',array(block,'m_Materials'),re.M):
                _,guid = reference(item)
                if guid in material_map:
                    renderers[go].append(material_map[guid])
        elif kind=='114':
            component,ext = reference(field(block,'_captureDisplay'))
            if ext or component in ('','0'):
                continue
            target_kind,target = docs.get(component,('',''))
            target_go = component if target_kind=='1' else reference(field(target,'m_GameObject'))[0]
            if target_go in game_objects:
                captures[target_go].append(dict(controller_file_id=fid, target_component_file_id=component,
                                                controller_script_guid=reference(field(block,'m_Script'))[1]))

    @lru_cache(maxsize=None)
    def animated_png(guid):
        path = image_paths.get(guid)
        if path and path.suffix.lower()=='.png' and path.is_file():
            try:
                info = apng_info(path)
                if info and info['animated']:
                    return info
            except OSError:
                pass
        return None

    @lru_cache(maxsize=None)
    def main_reference(path):
        source = Path(path).read_text('utf-8-sig',errors='replace')
        match = re.search(r'^\s*_MainTex:[ \t]*\n\s*m_Texture: (\{[^\n]+\})',source,re.M)
        return reference(match[1]) if match else ('','')

    screens = []
    for go in sorted(set(renderers)|set(captures)):
        entries = []
        for mat in renderers.get(go,[]):
            fileid,guid = main_reference(mat['path'])
            name = mat['name']
            ref = (fileid,guid)
            apng = animated_png(guid)
            image = image_paths.get(guid)
            runtime = fileid not in ('','0') and (ref in cameras or guid in external_render_textures or
                                                   not guid and fileid in local_render_textures)
            named = bool(re.search(r'screen|monitor|display',f'{name} {game_objects.get(go)}',re.I))
            if not (go in captures or apng or runtime or named):
                continue
            if runtime:
                source = 'camera_render_texture' if ref in cameras else 'render_texture_producer_unknown'
            elif go in captures:
                source = 'capture_controller_input_unresolved'
            elif apng:
                source = 'animated_png'
            else:
                source = 'static_texture' if image and image.is_file() else 'texture_unresolved'
            entries.append(dict(material=name, source_type=source, texture_guid=guid or None,
                                texture_file_id=fileid or None, cameras=cameras.get(ref,[]), apng=apng,
                                exported_source_image=str(image.relative_to(assets)) if image and image.is_file() else None))
        if entries or go in captures:
            screens.append(dict(object=game_objects.get(go), object_file_id=go, inside_export_root=under_root(go),
                                capture_bindings=captures.get(go,[]),materials=entries))
    return screens


def screen_preview(model_name, screen_rows, visibility):
    screen_ids = {row['object_file_id'] for row in screen_rows if row['inside_export_root']}
    frames,items = [],[]
    for fx in visibility:
        item = fx['unity_evidence']
        if item.get('source_type')!='animation_clip' or item.get('file_id') not in screen_ids:
            continue
        keys = fx['keys']
        changes = [(frame,weight) for i,(frame,weight) in enumerate(keys) if i==0 or weight!=keys[i-1][1]]
        if len(changes)<2 or any(weight not in (0,1) for _,weight in changes):
            continue
        name = fx['name']
        frames.append((name,0,changes[0][1]))
        marks = []
        for i,(source_frame,weight) in enumerate(changes[1:3],1):
            preview_frame = 30 if i==1 else 90
            frames.extend(((name,preview_frame-1,changes[i-1][1]),(name,preview_frame,weight)))
            marks.append(dict(source_frame=source_frame, preview_frame=preview_frame, morph_weight=weight))
        frames.append((name,120,changes[len(marks)][1]))
        items.append(dict(object=item['object'], morph=name, switches=marks))
    return (write_vmd(model_name,frames),items) if frames else (None,[])
