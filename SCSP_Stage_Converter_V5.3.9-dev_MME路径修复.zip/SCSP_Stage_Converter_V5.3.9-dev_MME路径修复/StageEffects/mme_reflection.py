"""MME reflection from the custom cubemap assigned in Unity RenderSettings."""
import re
from pathlib import Path
import subprocess


def stage_probe(scene, assets, guid_of):
    info = Path(scene).read_text('utf-8-sig', errors='replace')
    match = re.search(r'^  m_CustomReflection: \{fileID: 8900000, guid: ([a-f0-9]{32}),', info, re.M)
    if not match:
        return None
    sources = [path for path in assets.rglob('*.exr') if guid_of(path) == match[1]]
    if len(sources) != 1:
        return None
    ambient = re.search(r'^  m_AmbientEquatorColor: \{r: ([\d.]+), g: ([\d.]+), b: ([\d.]+),', info, re.M)
    colors = tuple(float(value) for value in ambient.groups()) if ambient else (0.0, 0.0, 0.0)
    return sources[0], colors


def convert_probe(source, target, blender):
    script = Path(__file__).with_name('probe_to_dds.py')
    subprocess.run([str(blender), '--factory-startup', '-b', '-t', '2', '--python-exit-code', '1',
                    '--python', str(script), '--', str(source), str(target)],
                   check=True, capture_output=True, timeout=90)


def reflection_shader(roughness, metallic, ambient):
    # The probe is baked and tone-mapped for MME. Roughness mixes toward
    # low-frequency normal lighting in the absence of Unity's filtered mips.
    ambient_color = ', '.join(f'{min(1, max(0, value)):.8f}' for value in ambient)
    code = f'''float4x4 Transform : WORLDVIEWPROJECTION;
float4x4 World : WORLD;
float4x4 NormalWorld : WORLDINVERSETRANSPOSE;
float3 CameraPosition : POSITION < string Object = "Camera"; >;
float4 ModelTint : DIFFUSE < string Object = "Geometry"; >;
textureCUBE Probe < string ResourceName = "SceneReflection.dds"; string ResourceType = "CUBE"; >;
samplerCUBE ProbeSampler = sampler_state {{
    Texture = <Probe>;
    MinFilter = Linear; MagFilter = Linear;
    AddressU = Clamp; AddressV = Clamp; AddressW = Clamp;
}};
struct Input {{ float4 position : POSITION0; float3 normal : NORMAL0; }};
struct Surface {{ float4 position : POSITION0; float3 world : TEXCOORD0; float3 normal : TEXCOORD1; }};
Surface TransformVertex(Input input) {{
    Surface o;
    o.position = mul(input.position, Transform);
    o.world = mul(input.position, World).xyz;
    o.normal = mul(float4(input.normal, 0), NormalWorld).xyz;
    return o;
}}
float4 RenderSurface(Surface input) : COLOR0 {{
    clip(ModelTint.a - 0.0001);
    float3 normal = normalize(input.normal);
    float3 view = normalize(input.world - CameraPosition);
    float3 reflected = reflect(view, normal);
    // PMX export reverses Unity Z.
    float3 axisSign = float3(1, 1, -1);
    float3 sharp = texCUBE(ProbeSampler, reflected * axisSign).rgb;
    float3 diffuse = texCUBE(ProbeSampler, normal * axisSign).rgb;
    float3 env = lerp(sharp, diffuse, {roughness:.8f});
    float hemiFill = 0.10 + 0.26 * saturate(normal.y * 0.5 + 0.5);
    env += (1.0 - env) * float3({ambient_color}) * hemiFill;
    return float4(ModelTint.rgb * lerp(float3(0.24, 0.24, 0.24), env, {metallic:.8f}), ModelTint.a);
}}
'''
    for name, kind in (('Reflection', 'object'), ('ReflectionSS', 'object_ss')):
        code += f'''
technique {name} < string MMDPass = "{kind}"; bool UseTexture = false; > {{
    pass P {{
        VertexShader = compile vs_2_0 TransformVertex();
        PixelShader = compile ps_2_0 RenderSurface();
        AlphaBlendEnable = true;
        SrcBlend = SRCALPHA;
        DestBlend = INVSRCALPHA;
        ZWriteEnable = true;
    }}
}}
'''
    return code
