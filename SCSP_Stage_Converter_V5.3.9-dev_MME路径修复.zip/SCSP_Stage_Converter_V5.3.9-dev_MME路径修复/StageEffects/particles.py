"""Bake supported Unity bubble and glitter emitters into MME billboards."""
from math import ceil, cos, isfinite, pi, radians, sin, sqrt, tan
from random import Random
import re
from struct import pack

from SceneBuilder.rebuild_stage_blender import parse_scene, vec
from .external_lights import local_matrix, material_record, multiply
from .light_timeline import read_curves
from .pmx_binary import Model, i32
from .timeline_visibility import array, field, reference
from .unity_effect_probe import YAML_BLOCK


BUBBLE_MATERIAL = '4dfc72206a7ffac46a76d01047da925d'
GLITTER_MATERIAL = '0fa3aa3c21a119146a1040fe0b6118e9'
SPLASH_MATERIAL = 'e3e1136a925b3bc4ab8d489129ac7572'


def section(text, name, indent):
    marker = ' ' * indent
    match = re.search(r'^'+marker+re.escape(name)+r': *\n((?:(?:'+marker+r' +\S[^\n]*\n)|\n)+)',
                      text,re.M)
    return match[1] if match else ''


def number(text, name, indent, default=0):
    match = re.search(r'^'+' '*indent+re.escape(name)+r': *([^\n]+)',text,re.M)
    value = float(match[1]) if match else default
    if not isfinite(value):
        raise ValueError('粒子参数无效')
    return value


def scalar_range(text, name):
    prop = section(text,name,4)
    mode = number(prop,'minMaxState',6,-1)
    if mode not in (0,3):
        raise ValueError('粒子初始数值使用了不支持的曲线类型')
    high = number(prop,'scalar',6)
    return (number(prop,'minScalar',6),high) if mode==3 else (high,high)


def bubble_births(rate, period, limit=90):
    power = number(rate,'scalar',6)
    if not 0<power<=60 or not 0<period<=10:
        raise ValueError('粒子发射速率或循环长度超限')
    mode = number(rate,'minMaxState',6)
    curve = read_curves(section(rate,'maxCurve',6))[0] if mode==1 else None
    if mode not in (0,1):
        raise ValueError('当前粒子不支持随机发射速率')
    steps = max(1,round(period*120))
    mass = 0.
    births = []
    for i in range(steps):
        density = power*max(0,curve.value((i+.5)/steps) if curve else 1)
        before = mass
        mass += density*period/steps
        for target in range(len(births)+1,int(mass+1e-9)+1):
            offset = min(1,max(0,(target-before)/(mass-before)))
            births.append((i+offset)*period/steps)
    if not births or len(births)>limit:
        raise ValueError('发射曲线没有可导出的粒子或数量超限')
    return births


def bubble_parameters(block):
    initial = section(block,'InitialModule',2)
    shape = section(block,'ShapeModule',2)
    emission = section(block,'EmissionModule',2)
    velocity = section(block,'VelocityModule',2)
    uv = section(block,'UVModule',2)
    color = section(initial,'startColor',4)
    duration = float(field(block,'lengthInSec'))
    lifetime = scalar_range(initial,'startLifetime')
    size = scalar_range(initial,'startSize')
    rise = scalar_range(velocity,'y')
    if (number(shape,'type',4)!=10 or number(emission,'m_BurstCount',4) or
            number(uv,'tilesX',4)!=2 or number(uv,'tilesY',4)!=2 or
            not 0<min(lifetime)<=max(lifetime)<=duration or not 0<min(size)<=max(size)<=2 or
            any(abs(v)>0.001 for v in scalar_range(initial,'startSpeed')) or
            any(abs(v)>0.001 for axis in 'xz' for v in scalar_range(velocity,axis))):
        raise ValueError('气泡形状、初始速度或图集布局与支持的源设置不同')
    gradient = section(section(section(block,'ColorModule',2),'gradient',4),'maxGradient',6)
    alpha = []
    for index in range(int(number(gradient,'m_NumAlphaKeys',8,0))):
        key = vec(gradient,'key'+str(index),('a',),(1,))[0]
        alpha.append((number(gradient,'atime'+str(index),8)/65535,key))
    if not alpha:
        alpha = [(0.,0.),(.21,1.),(1.,1.)]
    return dict(duration=duration,births=bubble_births(section(emission,'rateOverTime',4),duration),
                lifetime=lifetime,size=size,rise=rise,alpha=alpha,size_keys=particle_size_curve(block),
                radius=number(section(shape,'radius',4),'value',6),
                start_color=[vec(color,key,tuple('rgba'),(1,1,1,1)) for key in ('minColor','maxColor')])


def particle_size_curve(block):
    size_module = section(block,'SizeModule',2)
    size_curve = section(size_module,'curve',4)
    if number(size_module,'enabled',4)==1 and number(size_curve,'minMaxState',6)==1:
        shape_size = read_curves(section(size_curve,'maxCurve',6))[0]
        return [(i/8,max(0,shape_size.value(i/8))*number(size_curve,'scalar',6)) for i in range(9)]
    return [(0.,1.),(1.,1.)]


def glitter_parameters(block, world):
    initial = section(block,'InitialModule',2)
    shape = section(block,'ShapeModule',2)
    emission = section(block,'EmissionModule',2)
    velocity = section(block,'VelocityModule',2)
    color = section(initial,'startColor',4)
    palette = section(color,'maxGradient',6)
    duration = float(field(block,'lengthInSec'))
    lifetime = scalar_range(initial,'startLifetime')
    size = scalar_range(initial,'startSize')
    speed = scalar_range(initial,'startSpeed')
    rate = section(emission,'rateOverTime',4)
    rate_hz = number(rate,'scalar',6)
    radius = number(section(shape,'radius',4),'value',6)
    depth = number(shape,'length',4)
    angle = number(shape,'angle',4)
    if (number(shape,'type',4)!=8 or number(emission,'m_BurstCount',4) or
            number(section(block,'UVModule',2),'enabled',4) or number(rate,'minMaxState',6)!=0 or
            number(color,'minMaxState',6)!=4 or number(palette,'m_NumColorKeys',8)!=2 or
            number(velocity,'inWorldSpace',4) or not 0<min(lifetime)<=max(lifetime)<=duration or
            not 0<min(size)<=max(size)<=2 or speed[0]!=speed[1] or not 0<=angle<70 or
            not 0<=depth<=50 or not 0<radius<=100):
        raise ValueError('闪粉发射器参数与支持的源设置不同')
    velocities = [list(scalar_range(velocity,axis)) for axis in 'xyz']
    velocities[2] = [z+speed[0] for z in velocities[2]]
    return dict(duration=duration,births=bubble_births(rate,duration,limit=180),
                lifetime=lifetime,size=size,rise=(0,0),alpha=[(0.,1.),(1.,1.)],
                size_keys=particle_size_curve(block),radius=radius,depth=depth,angle=angle,
                start_color=[vec(palette,'key'+str(i),tuple('rgba'),(1,1,1,1)) for i in range(2)],
                motion_axes=[[world[j][i]*sign for j,sign in enumerate((1,1,-1))] for i in range(3)],
                drift=velocities,rate_hz=rate_hz)


def splash_parameters(block, world, cue, alignment):
    initial,shape,emission,velocity = (section(block,name,2) for name in
                                       ('InitialModule','ShapeModule','EmissionModule','VelocityModule'))
    period = float(field(block,'lengthInSec'))
    lifetime = sorted(scalar_range(initial,'startLifetime'))
    size = sorted(scalar_range(initial,'startSize'))
    speed = sorted(scalar_range(initial,'startSpeed'))
    gravity = scalar_range(initial,'gravityModifier')
    angle = number(shape,'angle',4)
    if (number(shape,'type',4)!=4 or number(emission,'m_BurstCount',4) or
            number(section(block,'UVModule',2),'enabled',4) or not 0<period<=2 or
            not 0<lifetime[0]<=lifetime[1]<=2 or not 0<size[0]<=size[1]<=2 or
            not 0<=speed[0]<=speed[1]<=20 or gravity[0]!=gravity[1] or not 0<=gravity[0]<=2 or
            not 0<=angle<80 or vec(shape,'m_Rotation',('x','y','z'),(0,0,0))!=(-90,0,0) or
            (number(velocity,'enabled',4) and any(v for axis in 'xyz' for v in scalar_range(velocity,axis)))):
        raise ValueError('水花使用了当前不支持的发射方向或运动参数')
    color = section(initial,'startColor',4)
    gradient = section(section(section(block,'ColorModule',2),'gradient',4),'maxGradient',6)
    alpha = [(number(gradient,'atime'+str(i),8)/65535,vec(gradient,'key'+str(i),('a',),(1,))[0])
             for i in range(int(number(gradient,'m_NumAlphaKeys',8)))]
    duration = period*ceil(lifetime[1]/period)
    return dict(duration=duration,births=bubble_births(section(emission,'rateOverTime',4),duration),
                lifetime=lifetime,size=size,rise=(0,0),radius=number(section(shape,'radius',4),'value',6),
                alpha=alpha or [(0.,1.),(1.,1.)],size_keys=particle_size_curve(block),
                start_color=[vec(color,key,tuple('rgba'),(1,1,1,1)) for key in ('minColor','maxColor')],
                splash=True,alignment=alignment,cue=cue,gravity=gravity[0]*9.81,
                angle=radians(angle),speed=speed,
                splash_axes=[[world[j][i]*sign for j,sign in enumerate((1,1,-1))] for i in range(3)])


def bubble_shader(config, scale):
    floats = lambda values: ', '.join(f'{v:.8f}' for v in values)
    life,size,rise = [floats(config[name]) for name in ('lifetime','size','rise')]
    a,b = [floats(color) for color in config['start_color']]
    births = floats(config['births'])
    speed = config['duration']
    def sample_curve(variable, keys):
        lines = [f'    float {variable} = {keys[0][1]:.8f};']
        for (lo,v0),(hi,v1) in zip(keys,keys[1:]):
            if hi>lo and v0!=v1:
                lines.append(f'    {variable} += ({v1-v0:.8f}) * saturate((phase - {lo:.8f}) / {hi-lo:.8f});')
        return '\n'.join(lines)
    gradient = sample_curve('fade',config['alpha'])
    growth = sample_curve('growth',config['size_keys'])
    launch_table = f"static const float Starts[{len(config['births'])}] = {{ {births} }};"
    birth = 'Starts[index]'
    movement = f'''    float2 rise = float2({rise});
    float velocity = lerp(rise.x, rise.y, RandomValue(index + 0.8)) * {scale:.8f};
    float4 viewPosition = mul(input.pos, WorldView);
    viewPosition.xyz += mul(float4(0.0, age * velocity, 0.0, 0.0), View).xyz;'''
    uv = '''    float tile = floor(RandomValue(index + 8.82) * 4.0);
    result.uv = (float2(tile - 2.0 * floor(tile / 2.0), floor(tile / 2.0)) + lerp(0.002, 0.998, corner)) * 0.5;'''
    elapsed = 'max(Seconds, 0.0)'
    billboard = '    viewPosition.xy += (corner - 0.5) * diameter * max(0.0, growth);'
    dst = 'ONE'
    if 'motion_axes' in config:
        launch_table = ''
        birth = f'(index + 1.0) / {config["rate_hz"]:.8f}'
        terms = [f'float3({floats(axis)}) * lerp({v0:.8f}, {v1:.8f}, RandomValue(index + {seed:.1f}))'
                 for axis,(v0,v1),seed in zip(config['motion_axes'],config['drift'],(0.8,2.2,4.3))]
        movement = ('    float3 drift = '+ ' +\n                   '.join(terms) + ';\n'
                    f'    float4 viewPosition = mul(input.pos + float4(drift * age * {scale:.8f}, 0.0), WorldView);')
        uv = '    result.uv = lerp(0.002, 0.998, corner);'
    if config.get('splash'):
        axes = [f'float3({floats(axis)})' for axis in config['splash_axes']]
        lo,hi = config['speed']
        elapsed = f'Seconds - {config["cue"]:.8f}'
        movement = f'''    float azimuth = RandomValue(index + 8.11) * 6.28318531;
    float angle = sqrt(RandomValue(index + 5.41)) * {config["angle"]:.8f};
    float3 heading = {axes[1]} * cos(angle) +
                     ({axes[0]} * cos(azimuth) + {axes[2]} * sin(azimuth)) * sin(angle);
    float speed = lerp({lo:.8f}, {hi:.8f}, RandomValue(index + 1.1));
    float3 trajectory = (heading * speed * age - float3(0.0, {0.5*config["gravity"]:.8f} * age * age, 0.0)) * {scale:.8f};
    float4 viewPosition = mul(input.pos + float4(trajectory, 0.0), WorldView);'''
        if config['alignment']==2:
            billboard = f'''    float2 offset = (corner - 0.5) * diameter * max(0.0, growth);
    viewPosition.xyz += mul(float4({axes[0]} * offset.x + {axes[2]} * offset.y, 0.0), WorldView).xyz;'''
        uv = '    result.uv = lerp(0.002, 0.998, corner);'
        dst = 'INVSRCALPHA'
    return f'''float Seconds : TIME < bool SyncInEditMode = true; >;
float4x4 WorldView : WORLDVIEW;
float4x4 View : VIEW;
float4x4 Projection : PROJECTION;
texture BubbleTexture : MATERIALTEXTURE;
sampler2D Bubbles = sampler_state {{
    Texture = <BubbleTexture>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Clamp; AddressV = Clamp;
}};
{launch_table}
float RandomValue(float seed) {{ return frac(sin(seed * 12.9898 + 19.17) * 43758.5453); }}
struct Vertex {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; }};
struct Output {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; float4 tint : COLOR0; }};
Output MoveBubble(Vertex input) {{
    Output result;
    int index = (int)floor(input.uv.x * 0.5);
    float2 corner = float2(input.uv.x - 2.0 * index, input.uv.y);
    float elapsed = {elapsed} - {birth};
    float age = frac(elapsed / {speed:.8f}) * {speed:.8f};
    float2 lifetime = float2({life});
    float phase = age / lerp(lifetime.x, lifetime.y, RandomValue(index + 0.1));
{gradient}
{growth}
{movement}
    float2 sizes = float2({size});
    float diameter = lerp(sizes.x, sizes.y, RandomValue(index + 3.7)) * {scale:.8f};
{billboard}
    result.pos = mul(viewPosition, Projection);
{uv}
    result.tint = lerp(float4({a}), float4({b}), RandomValue(index + 6.4));
    result.tint.a *= saturate(fade) * step(0.0, elapsed) * (1.0 - step(1.0, phase));
    return result;
}}
float4 PaintBubble(Output input) : COLOR0 {{
    float4 color = tex2D(Bubbles, input.uv) * input.tint;
    color.rgb *= float3({floats(config["material_color"])});
    clip(color.a - 0.0001);
    return color;
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{kind}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_3_0 MoveBubble();
        PixelShader = compile ps_3_0 PaintBubble();
        AlphaBlendEnable = true; SrcBlend = SRCALPHA; DestBlend = {dst};
        CullMode = NONE; ZWriteEnable = false;
    }}
}}
''' for name,kind in (('BubblesVisible','object'),('BubblesVisibleSS','object_ss')))


def append_particles(model, scene, scale, assets=None, schedule=None):
    textures,rows = {},[]
    if scene is not None:
        scene_text = scene.read_text('utf-8-sig',errors='replace')
        for guid,mode,label,texture_name in (
                (BUBBLE_MATERIAL,'bubble_particles','AutoBubble','BubbleAtlas.png'),
                (GLITTER_MATERIAL,'glitter_particles','AutoGlitter','Glitter.png'),
                (SPLASH_MATERIAL,'splash_particles','AutoSplash','Splash.png')):
            if guid in scene_text:
                model,refs,bindings = append_emitters(model,scene,scene_text,scale,assets,guid,mode,label,texture_name,schedule)
                textures.update(refs)
                rows.extend(bindings)
    return model,textures,rows


def append_emitters(model, scene, scene_text, scale, assets, guid, mode, label, texture_name, schedule=None):
    """Append supported source billboards to the MME-only PMX copy."""
    if scene is None or not model.bones or not model.vertex_offsets:
        return model,{},[]
    if not re.search(r'(?m)^--- !u!198 &',scene_text):
        return model,{},[]
    assets = assets or scene.parent
    objects,_,by_go,_,by_tid,_,_,_,paths = parse_scene(scene,assets)
    source_material = paths.get(guid)
    if not source_material:
        return model,{},[]
    mat_text = source_material.read_text('utf-8-sig')
    main = re.search(r'(?m)^      _MainTex:\n        m_Texture: (.*)',mat_text)
    texture = paths.get(reference(main[1])[1]) if main else None
    if not texture or texture.suffix.lower()!='.png' or not texture.is_file():
        return model,{},[]
    splash = mode=='splash_particles'
    if not all(re.search(r'(?m)^ *'+key+r': '+value+r'\s*$',mat_text)
               for key,value in (('_BlendSrc','5'),('_BlendDst','10' if splash else '1'),('_ZWriteMode','0'))):
        return model,{},[]
    material_color = (1,1,1) if splash and number(mat_text,'_ColorSwitch',6)==0 else vec(mat_text,'_Color',tuple('rgb'),(1,1,1))
    if not all(0<=value<=8 for value in material_color):
        return model,{},[]
    blocks = YAML_BLOCK.findall(scene_text)
    renderers = {reference(field(block,'m_GameObject'))[0]:block for kind,_,block in blocks
                 if kind=='199' and field(block,'m_Enabled')=='1'}
    vertices,faces,materials,rows = [],[],[],[]
    texture_name = 'textures/AutoStageParticles/'+texture_name
    if texture_name in model.textures or len(model.textures)>=2**(8*model.tex_width-1):
        return model,{},[]
    tex_index = len(model.textures)
    for kind,fileid,block in blocks:
        if kind!='198' or field(block,'playOnAwake')!='1' or field(block,'looping')!='1':
            continue
        go = reference(field(block,'m_GameObject'))[0]
        obj = objects.get(int(go))
        renderer = renderers.get(go,'')
        alignment = field(renderer,'m_RenderAlignment')
        if (not obj or field(renderer,'m_RenderMode')!='0' or alignment not in (('0','2') if splash else ('0',)) or
                guid not in array(renderer,'m_Materials')):
            continue
        try:
            current = int(go)
            chain,cues = [],[]
            seen = set()
            while current:
                if current in seen or not objects[current]['active']:
                    raise ValueError('发射器层级初始未启用')
                seen.add(current)
                if splash and schedule:
                    cues.extend(schedule.effect_events.get(objects[current]['name'],()))
                transform = by_go[current]
                chain.append(local_matrix(transform))
                current = by_tid[transform['father']] if transform['father'] else 0
            world = chain.pop()
            while chain:
                world = multiply(world,chain.pop())
            if splash:
                times = {event['time'] for event in cues}
                if len(times)!=1:
                    continue
                config = splash_parameters(block,world,next(iter(times)),int(alignment))
            else:
                config = glitter_parameters(block,world) if mode=='glitter_particles' else bubble_parameters(block)
            config['material_color'] = material_color
        except (KeyError,ValueError):
            continue
        count = len(config['births'])
        if (len(model.materials)+len(rows)>=2**(8*model.mat_width-1) or
                model.vertex_count+len(vertices)+4*count>2**(8*model.vertex_width)):
            break
        name = label+'_'+fileid
        rng = Random(int(fileid))
        for i in range(count):
            angle = 2*pi*rng.random()
            distance = rng.uniform(0, config['depth']) if 'depth' in config else 0
            radius = config['radius']
            if 'angle' in config:
                radius += tan(radians(config['angle'])) * distance
            radius *= sqrt(rng.random())
            local = ((radius*cos(angle),0,-radius*sin(angle),1) if splash else
                     (radius*cos(angle),radius*sin(angle),distance,1))
            point = [scale*sum(a*b for a,b in zip(row,local))*sign for row,sign in zip(world,(1,1,-1))]
            first = model.vertex_count+len(vertices)
            for u,v in ((0,0),(1,0),(0,1),(1,1)):
                data = pack('<8f',*point,0,1,0,2*i+u,v)
                vertices.append(data+bytes(16*model.uv_count)+b'\0'+Model.idx(0,model.bone_width)+pack('<f',0))
            faces.extend(Model.idx(first+v,model.vertex_width,signed=False) for v in (0,1,2,2,1,3))
        materials.append(material_record(model,name,(1,1,1,1),tex_index,count*6))
        rows.append(dict(material_index=len(model.materials)+len(rows),material=name,mode=mode,
                         shader='Unity ParticleSystem', source_emitter=fileid,source_object=obj['name'],spawn_count=count,
                         lifetime=list(config['lifetime']),loop_seconds=config['duration'],
                         fx_code=bubble_shader(config,scale)))
        if splash:
            rows[-1].update(cue_seconds=config['cue'],marker=cues[0]['asset'],gravity=config['gravity'])
    if not rows:
        return model,{},[]
    data = model.data
    vertex = model.vertex_offsets[0]
    face = model.face_index_start-4
    texture_table = model.texture_table_at
    material = model.material_table_at
    bone = model.bone_table_at
    payload = b''.join((data[:vertex-4],i32(model.vertex_count+len(vertices)),data[vertex:face],b''.join(vertices),
                        i32(model.face_index_count+len(faces)),data[face+4:texture_table],b''.join(faces),
                        i32(tex_index+1),data[texture_table+4:material],model.encode_str(texture_name),
                        i32(len(model.materials)+len(rows)),data[material+4:bone],b''.join(materials),data[bone:]))
    return Model(payload),{texture_name:texture},rows
