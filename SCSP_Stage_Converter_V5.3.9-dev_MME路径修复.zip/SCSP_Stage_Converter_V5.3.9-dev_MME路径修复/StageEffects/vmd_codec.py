# -*- coding: utf-8 -*-
"""Strict VMD 0002 reader/writer used by SCSP Stage Effects.

The writer supports morph-only files and files with an optional neutral bone
anchor. The anchor is diagnostic compatibility scaffolding, not an animation.
"""
from __future__ import annotations

import math
import struct
from pathlib import Path

HEADER = b"Vocaloid Motion Data 0002".ljust(30, b"\0")
BONE_FRAME_SIZE = 111
MORPH_FRAME_SIZE = 23
CAMERA_FRAME_SIZE = 61
LIGHT_FRAME_SIZE = 28
SELF_SHADOW_FRAME_SIZE = 9

# Interpolation bytes copied from a neutral frame in the user-provided ITTW46
# 404 reference VMD. They are a valid, conservative MMD interpolation block.
REFERENCE_NEUTRAL_INTERPOLATION = bytes.fromhex(
    "14140000141414146b6b6b6b6b6b6b6b"
    "141414141414146b6b6b6b6b6b6b6b"
    "001414141414146b6b6b6b6b6b6b6b"
    "000014141414146b6b6b6b6b6b6b6b"
    "000000"
)
assert len(REFERENCE_NEUTRAL_INTERPOLATION) == 64


class VMDError(ValueError):
    pass


def encode_name(value: str, size: int, label: str) -> bytes:
    if not isinstance(value, str) or not value:
        raise VMDError(f"{label} must be a non-empty string")
    if "\0" in value:
        raise VMDError(f"{label} cannot contain an embedded NUL byte")
    try:
        raw = value.encode("cp932", errors="strict")
    except UnicodeEncodeError as exc:
        raise VMDError(f"{label} is not CP932 encodable: {value!r}") from exc
    if len(raw) > size:
        raise VMDError(f"{label} exceeds {size} CP932 bytes: {value!r} ({len(raw)} bytes)")
    return raw.ljust(size, b"\0")


def _finite(values, label):
    for value in values:
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)):
            raise VMDError(f"{label} contains a non-finite/non-numeric value")


def pack_bone_frame(name, frame, position=(0.0, 0.0, 0.0), rotation=(0.0, 0.0, 0.0, 1.0), interpolation=None):
    if type(frame) is not int or not 0 <= frame <= 0xFFFFFFFF:
        raise VMDError("Bone frame number must be an unsigned 32-bit integer")
    if len(position) != 3 or len(rotation) != 4:
        raise VMDError("Bone position/rotation have invalid dimensions")
    _finite(position, "Bone position")
    _finite(rotation, "Bone rotation")
    interpolation = REFERENCE_NEUTRAL_INTERPOLATION if interpolation is None else bytes(interpolation)
    if len(interpolation) != 64:
        raise VMDError("Bone interpolation must be exactly 64 bytes")
    return (
        encode_name(name, 15, "VMD bone name")
        + struct.pack("<I3f4f", frame, *map(float, position), *map(float, rotation))
        + interpolation
    )


def pack_morph_frame(name, frame, weight):
    if type(frame) is not int or not 0 <= frame <= 0xFFFFFFFF:
        raise VMDError("Morph frame number must be an unsigned 32-bit integer")
    _finite([weight], "Morph weight")
    if not 0.0 <= float(weight) <= 1.0:
        raise VMDError("Morph weight must be in 0..1")
    return encode_name(name, 15, "VMD morph name") + struct.pack("<If", frame, float(weight))


def write_vmd(model_name, morph_frames, bone_frames=()):
    """Build a complete VMD 0002 file.

    morph_frames: iterable of (morph_name, frame, weight)
    bone_frames: iterable of (bone_name, frame, position3, rotation4[, interpolation64])
    """
    model_field = encode_name(model_name, 20, "VMD model name")
    morph_frames = list(morph_frames)
    bone_frames = list(bone_frames)
    if len(morph_frames) > 5_000_000 or len(bone_frames) > 5_000_000:
        raise VMDError("Too many VMD frames")

    morph_seen = set()
    morph_encoded_names = {}
    for name, frame, weight in morph_frames:
        encoded = encode_name(name, 15, "VMD morph name")
        prior = morph_encoded_names.get(encoded)
        if prior is not None and prior != name:
            raise VMDError(f"VMD morph names collide in the 15-byte field: {prior!r} / {name!r}")
        morph_encoded_names[encoded] = name
        key = (name, frame)
        if key in morph_seen:
            raise VMDError(f"Duplicate morph key: {name!r} at frame {frame}")
        morph_seen.add(key)
    bone_seen = set()
    bone_encoded_names = {}
    for item in bone_frames:
        if len(item) not in (4, 5):
            raise VMDError("Bone frame tuple must contain 4 or 5 items")
        name, frame = item[:2]
        encoded = encode_name(name, 15, "VMD bone name")
        prior = bone_encoded_names.get(encoded)
        if prior is not None and prior != name:
            raise VMDError(f"VMD bone names collide in the 15-byte field: {prior!r} / {name!r}")
        bone_encoded_names[encoded] = name
        key = (name, frame)
        if key in bone_seen:
            raise VMDError(f"Duplicate bone key: {name!r} at frame {frame}")
        bone_seen.add(key)

    morph_frames.sort(key=lambda item: (item[1], item[0]))
    bone_frames.sort(key=lambda item: (item[1], item[0]))
    out = [HEADER, model_field, struct.pack("<I", len(bone_frames))]
    for item in bone_frames:
        if len(item) == 4:
            out.append(pack_bone_frame(*item))
        else:
            out.append(pack_bone_frame(*item))
    out.append(struct.pack("<I", len(morph_frames)))
    out.extend(pack_morph_frame(*item) for item in morph_frames)
    # Camera, light, self-shadow and model-display/IK frame counts, all zero.
    out.append(struct.pack("<IIII", 0, 0, 0, 0))
    data = b"".join(out)
    parse_vmd(data, strict=True)
    return data


def _read_name(raw, label):
    try:
        return raw.split(b"\0", 1)[0].decode("cp932", errors="strict")
    except UnicodeDecodeError as exc:
        raise VMDError(f"Invalid CP932 in {label}") from exc


def parse_vmd(data, strict=True):
    """Parse and validate the VMD sections used by MMD 0002."""
    if isinstance(data, (str, Path)):
        data = Path(data).read_bytes()
    if len(data) < 54 or data[:30] != HEADER:
        raise VMDError("Not a VMD 0002 file")
    model_name = _read_name(data[30:50], "model name")
    pos = 50

    def count(label):
        nonlocal pos
        if pos + 4 > len(data):
            raise VMDError(f"Truncated {label} count")
        value, = struct.unpack_from("<I", data, pos)
        pos += 4
        if value > 5_000_000:
            raise VMDError(f"Unreasonable {label} count: {value}")
        return value

    bone_count = count("bone")
    if pos + bone_count * BONE_FRAME_SIZE > len(data):
        raise VMDError("Truncated bone section")
    bone_tracks = {}
    bone_frames = []
    for _ in range(bone_count):
        item = data[pos:pos + BONE_FRAME_SIZE]
        name = _read_name(item[:15], "bone name")
        frame, = struct.unpack_from("<I", item, 15)
        position = struct.unpack_from("<3f", item, 19)
        rotation = struct.unpack_from("<4f", item, 31)
        bone_tracks[name] = bone_tracks.get(name, 0) + 1
        bone_frames.append({"name": name, "frame": frame, "position": position, "rotation": rotation})
        pos += BONE_FRAME_SIZE

    morph_count = count("morph")
    if pos + morph_count * MORPH_FRAME_SIZE > len(data):
        raise VMDError("Truncated morph section")
    morph_tracks = {}
    morph_frames = []
    for _ in range(morph_count):
        item = data[pos:pos + MORPH_FRAME_SIZE]
        name = _read_name(item[:15], "morph name")
        frame, weight = struct.unpack_from("<If", item, 15)
        if not math.isfinite(weight):
            raise VMDError(f"Non-finite morph weight for {name!r}")
        morph_tracks[name] = morph_tracks.get(name, 0) + 1
        morph_frames.append({"name": name, "frame": frame, "weight": weight})
        pos += MORPH_FRAME_SIZE

    camera_count = count("camera")
    if pos + camera_count * CAMERA_FRAME_SIZE > len(data):
        raise VMDError("Truncated camera section")
    pos += camera_count * CAMERA_FRAME_SIZE

    light_count = count("light")
    if pos + light_count * LIGHT_FRAME_SIZE > len(data):
        raise VMDError("Truncated light section")
    pos += light_count * LIGHT_FRAME_SIZE

    shadow_count = count("self-shadow")
    if pos + shadow_count * SELF_SHADOW_FRAME_SIZE > len(data):
        raise VMDError("Truncated self-shadow section")
    pos += shadow_count * SELF_SHADOW_FRAME_SIZE

    model_display_count = count("model-display/IK")
    model_display_frames = []
    for _ in range(model_display_count):
        if pos + 9 > len(data):
            raise VMDError("Truncated model-display/IK frame")
        frame, = struct.unpack_from("<I", data, pos)
        visible = data[pos + 4]
        ik_count, = struct.unpack_from("<I", data, pos + 5)
        pos += 9
        if ik_count > 100_000 or pos + ik_count * 21 > len(data):
            raise VMDError("Truncated model-display/IK entries")
        ik_entries = []
        for _ in range(ik_count):
            ik_name = _read_name(data[pos:pos + 20], "IK name")
            enabled = data[pos + 20]
            if enabled not in (0, 1):
                raise VMDError("Invalid IK enabled flag")
            ik_entries.append({"name": ik_name, "enabled": bool(enabled)})
            pos += 21
        model_display_frames.append({"frame": frame, "visible": bool(visible), "ik": ik_entries})

    trailing = len(data) - pos
    if strict and trailing:
        raise VMDError(f"Unexpected {trailing} trailing bytes after VMD sections")
    return {
        "model": model_name,
        "bone_keys": bone_count,
        "bone_tracks": bone_tracks,
        "bone_frames": bone_frames,
        "morph_keys": morph_count,
        "morph_tracks": morph_tracks,
        "morph_frames": morph_frames,
        "camera_keys": camera_count,
        "light_keys": light_count,
        "self_shadow_keys": shadow_count,
        "model_display_keys": model_display_count,
        "last_bone_frame": max((x["frame"] for x in bone_frames), default=0),
        "last_morph_frame": max((x["frame"] for x in morph_frames), default=0),
        "trailing_bytes": trailing,
    }
