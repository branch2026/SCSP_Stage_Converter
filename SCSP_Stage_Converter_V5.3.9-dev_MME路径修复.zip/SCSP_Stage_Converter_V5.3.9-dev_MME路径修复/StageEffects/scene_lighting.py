"""Read serialized Unity lights and generate a diffuse-light approximation for MME."""
from functools import lru_cache
from math import cos, hypot, isfinite, radians
import re
from struct import pack, pack_into, unpack_from

from SceneBuilder.rebuild_stage_blender import docs, ref, scalar, vec
from .external_lights import local_matrix, multiply


def scene_lights(scene, scale, *, schedule=None, frames=0, programs=None):
    objects, transforms, lights = {}, {}, []
    for kind, file_id, text in docs(scene.read_text('utf-8-sig', errors='replace')):
        if kind == 1:
            objects[file_id] = (scalar(text, 'm_Name', str(file_id)),
                                scalar(text, 'm_IsActive', '1') == '1')
        elif kind in (4, 224, 108):
            owner = ref(text, 'm_GameObject')
            if not owner:
                continue
            go = int(owner['fileID'])
            if kind == 108:
                lights.append((file_id, go, text))
            else:
                transforms[file_id] = (go, text)
    by_go = {go: key for key, (go, _) in transforms.items()}
    parents = {go:int((ref(text,'m_Father') or {'fileID':0})['fileID']) for go,text in transforms.values()}
    animated_objects = ({int(go) for go,_ in schedule.channels} | {int(go) for go in schedule.markers}
                        if schedule else set())
    visited = set()

    @lru_cache(maxsize=None)
    def world(file_id):
        if file_id in visited:
            raise ValueError('循环引用的灯光变换')
        visited.add(file_id)
        try:
            go, text = transforms[file_id]
            parent = ref(text, 'm_Father')
            parent_id = int(parent['fileID']) if parent else 0
            transform = dict(
                pos=vec(text, 'm_LocalPosition', ('x', 'y', 'z'), (0, 0, 0)),
                rot=vec(text, 'm_LocalRotation', ('x', 'y', 'z', 'w'), (0, 0, 0, 1)),
                scale=vec(text, 'm_LocalScale', ('x', 'y', 'z'), (1, 1, 1)))
            local = local_matrix(transform)
            _, active = objects[go]
            if parent_id:
                matrix, parent_active = world(parent_id)
                return multiply(matrix, local), active and parent_active
            return local, active
        finally:
            visited.remove(file_id)

    def timed_samples(go, kind, matrix, intensity, color, radius, enabled):
        chain = []
        member = go
        while member:
            parent_id = parents[member]
            if member in chain:
                raise ValueError('循环引用的灯光层级')
            chain.append(member)
            member = transforms[parent_id][0] if parent_id else 0
        if not (animated_objects & set(chain)):
            return None
        offsets = []
        for member in chain:
            if not any((str(member),'position.'+axis) in schedule.channels for axis in 'xyz'):
                continue
            _, source = transforms[by_go[member]]
            origin = vec(source,'m_LocalPosition',('x','y','z'),(0,0,0))
            parent_id = parents[member]
            parent_matrix = world(parent_id)[0] if parent_id else ((1,0,0,0),(0,1,0,0),(0,0,1,0))
            offsets.append((str(member),origin,parent_matrix))
        hierarchy = [(str(member),objects[member][1]) for member in chain]
        key = str(go)
        output = []
        for frame in range(frames+1):
            time = frame/30
            current = matrix[0][3],matrix[1][3],matrix[2][3]
            for member, origin, parent_matrix in offsets:
                delta = [schedule.value(member,'position.'+axis,time,value)-value
                         for axis,value in zip('xyz',origin)]
                current = tuple(value+sum(coef*change for coef,change in zip(line,delta))
                                for value,line in zip(current,parent_matrix))
            position = (current[0]*scale,current[1]*scale,-current[2]*scale)
            active = (schedule.value(key,'m_Enabled',time,enabled) and
                      all(schedule.value(member,'m_IsActive',time,initial) for member,initial in hierarchy))
            strength = schedule.value(key,'m_Intensity',time,intensity) if active else 0.
            rgb = tuple(schedule.value(key,'m_Color.'+axis,time,value) for axis,value in zip('rgb',color))
            distance = (schedule.value(key,'m_Range',time,radius/scale)*scale
                        if kind!='directional' else 1.)
            if not all(isfinite(v) and abs(v)<=1000000 for v in (*position,distance,strength,*rgb)):
                raise ValueError('灯光动画超出预览数值范围')
            radiance = tuple(min(32,max(0,v))*min(10000,max(0,strength)) if distance>0 else 0. for v in rgb)
            output.append((*radiance,strength,*position,max(.0001,distance)))
        return output

    result = []
    kinds = {'0': 'spot', '1': 'directional', '2': 'point'}
    for file_id, go, text in lights:
        name = objects.get(go, (str(go), False))[0]
        kind = kinds.get(scalar(text, 'm_Type', ''), 'unsupported')
        row = dict(file_id=file_id, object=name, type=kind, status='skipped')
        result.append(row)
        try:
            mask = re.search(r'(?m)^  m_CullingMask:.*\n(?:    [^\n]*\n)*?    m_Bits: (\d+)', text)
            cookie = ref(text, 'm_Cookie')
            enabled = scalar(text, 'm_Enabled', '1') == '1'
            if name.casefold() == 'dropshadowlight':
                raise ValueError('源场景的角色投影辅助灯')
            if kind == 'unsupported' or scalar(text, 'm_Lightmapping', '4') not in ('1', '4'):
                raise ValueError('灯型或烘焙模式暂不支持')
            if (mask and int(mask[1]) != 0xffffffff or
                    scalar(text, 'm_RenderingLayerMask', '1') != '1' or
                    cookie and int(cookie['fileID']) or scalar(text, 'm_UseColorTemperature', '0') != '0'):
                raise ValueError('灯光使用了专用层、投影片或色温')
            intensity = float(scalar(text, 'm_Intensity', '0'))
            color = vec(text, 'm_Color', ('r','g','b'), (1,1,1))
            radius = float(scalar(text, 'm_Range', '0')) * scale
            if not 0 <= intensity <= 10000 or not all(0 <= v <= 32 for v in color):
                raise ValueError('源灯光的初始强度或颜色无效')
            matrix, active = world(by_go[go])
            if not all(isfinite(v) for line in matrix for v in line):
                raise ValueError('源灯光变换无效')
            samples = timed_samples(go,kind,matrix,intensity,color,radius,enabled) if programs is not None else None
            lit = [sample for sample in samples if any(sample[:3])] if samples else []
            if not lit:
                if samples is not None:
                    raise ValueError('灯光在预览帧范围内保持熄灭')
                if not enabled:
                    raise ValueError('源灯光组件已禁用')
                if not active:
                    raise ValueError('灯光初始时处于非活动层级，未找到可用的激活曲线')
                if not intensity or not any(color):
                    raise ValueError('源灯光的初始强度或颜色为零')
            row.update(intensity=intensity, color=color)
            if kind != 'directional':
                if not 0 < radius <= 1000000 and not lit:
                    raise ValueError('灯光范围无效')
                row.update(position=tuple(matrix[i][3] * scale * s for i,s in enumerate((1,1,-1))),
                           range=radius)
            if kind != 'point':
                # Unity light direction is local +Z. The PMX exporter flips Z.
                forward = (matrix[0][2],matrix[1][2],-matrix[2][2])
                length = hypot(*forward)
                if not length:
                    raise ValueError('灯光方向无效')
                row['direction'] = tuple(v / length for v in forward)
            if kind == 'spot':
                outer = float(scalar(text, 'm_SpotAngle', '30'))
                inner = float(scalar(text, 'm_InnerSpotAngle', str(outer * 0.8)))
                if not 0 <= inner <= outer < 180 or outer <= 0:
                    raise ValueError('灯光锥角无效')
                row.update(outer_angle=outer,inner_angle=inner)
            if lit:
                first = next(i for i,sample in enumerate(samples) if any(sample[:3]))
                transitions = [i for i in range(1,len(samples))
                               if bool(any(samples[i][:3]))!=bool(any(samples[i-1][:3]))]
                row.update(animated=True, first_lit_frame=first, on_off_frames=transitions,
                           maximum_intensity=max(s[3] for s in lit))
                if kind!='directional':
                    row['motion_bounds'] = [(min(s[i]-s[7] for s in lit),max(s[i]+s[7] for s in lit))
                                            for i in (4,5,6)]
                programs[file_id] = samples
            row['status'] = 'supported'
        except (KeyError, ValueError) as error:
            row['reason'] = str(error)
    return result


def lights_for_surface(model, slot, lights):
    supported = [light for light in lights if light['status']=='supported']
    if not supported:
        return []
    vertices = set(model.face_indices(slot.start, slot.faces))
    coords = [unpack_from('<3f',model.data,model.vertex_offsets[vertex]) for vertex in vertices]
    bounds = [(min(axis), max(axis)) for axis in zip(*coords)]
    candidates = []
    for light in supported:
        if light['type'] != 'directional':
            if 'motion_bounds' in light:
                if any(hi<low or lo>high for (lo,hi),(low,high) in zip(bounds,light['motion_bounds'])):
                    continue
            else:
                distance = hypot(*(max(lo-v,0,v-hi) for v,(lo,hi) in zip(light['position'],bounds)))
                if distance >= light['range']:
                    continue
        candidates.append(light)
    # The ps_3_0 receiver has a bounded instruction budget on MMD's DirectX 9 path.
    candidates.sort(key=lambda light: (light['type']!='directional',
                                       -light.get('maximum_intensity',light['intensity']),light['file_id']))
    return candidates[:16]


def timeline_atlas(programs):
    if not programs:
        return None,None
    frames = len(next(iter(programs.values())))
    width = 1024
    rows = (frames*len(programs)*2+width-1)//width
    height = 1 << (rows-1).bit_length()
    if height>4096:
        raise ValueError('灯光关键帧贴图超过 4096 行')
    header = [124,0x100F,height,width,width*16,0,0] + [0]*11
    header += [32,4,116,0,0,0,0,0,0x1000,0,0,0,0]
    image = bytearray(width*height*16)
    offsets = {}
    for index,(key,samples) in enumerate(sorted(programs.items())):
        offsets[key] = index*frames*2
        for frame,sample in enumerate(samples):
            pack_into('<8f',image,(offsets[key]+2*frame)*16,*sample)
    return (width,height,frames-1,offsets), b'DDS '+pack('<31I',*header)+image


def light_receiver_shader(lights, influence, timeline=None):
    def vector(values):
        return 'float3(' + ', '.join(f'{v:.8f}' for v in values) + ')'
    contributions = []
    animated = timeline and any(light['file_id'] in timeline[3] for light in lights)
    resource = ''
    if animated:
        width,height,last_frame,offsets = timeline
        resource = f'''float Seconds : TIME < bool SyncInEditMode = true; >;
texture LightTimelineTexture < string ResourceName = "StageLightTimeline.dds"; >;
sampler2D LightTimelineSampler = sampler_state {{
    Texture = <LightTimelineTexture>;
    MinFilter = Point; MagFilter = Point; MipFilter = None;
    AddressU = Clamp; AddressV = Clamp;
}};
float4 ReadLightFrame(float cell) {{
    float row = floor(cell / {width}.0);
    float col = cell - row * {width}.0;
    return tex2D(LightTimelineSampler, (float2(col, row) + 0.5) / float2({width}.0, {height}.0));
}}
'''
        contributions.append(f'    float lightFrame = clamp(floor(Seconds * 30.0 + 0.001), 0.0, {last_frame}.0);')
    for index, light in enumerate(lights):
        color = vector(v*light['intensity'] for v in light['color'])
        position = vector(light.get('position',(0,0,0)))
        radius = f'{light.get("range",1):.8f}'
        if animated and light['file_id'] in offsets:
            contributions.append(f'    float cell{index} = {offsets[light["file_id"]]}.0 + 2.0 * lightFrame;')
            color = f'ReadLightFrame(cell{index}).rgb'
            if light['type'] != 'directional':
                contributions.append(f'    float4 moving{index} = ReadLightFrame(cell{index} + 1.0);')
                position,radius = f'moving{index}.xyz',f'moving{index}.w'
        if light['type'] == 'directional':
            forward = vector(light['direction'])
            contributions.append(f'    incoming += saturate(dot(n, -{forward})) * {color};')
        else:
            if light['type']=='spot':
                outer = cos(radians(light['outer_angle']/2))
                inner = cos(radians(light['inner_angle']/2))
                cone = ('smoothstep(' + f'{outer:.8f}, {max(inner,outer+0.00001):.8f}, ' +
                        f'dot(-unit{index}, {vector(light["direction"])}))')
            else:
                cone = '1.0'
            contributions.append(f'''    float3 light{index} = {position} - input.worldPosition;
    float distance{index} = length(light{index});
    float3 unit{index} = light{index} / max(distance{index}, 0.0001);
    float falloff{index} = saturate(1.0 - distance{index} / {radius});
    incoming += ({cone}) * falloff{index} * falloff{index} * saturate(dot(n, unit{index})) * {color};''')
    body = '\n'.join(contributions)
    return f'''float4x4 Transform : WORLDVIEWPROJECTION;
float4x4 World : WORLD;
float4x4 NormalWorld : WORLDINVERSETRANSPOSE;
float4 ModelTint : DIFFUSE < string Object = "Geometry"; >;
float3 ModelAmbient : AMBIENT < string Object = "Geometry"; >;
float3 MmdColor : DIFFUSE < string Object = "Light"; >;
float3 MmdDirection : DIRECTION < string Object = "Light"; >;
texture BaseTexture : MATERIALTEXTURE;
sampler2D BaseSampler = sampler_state {{
    Texture = <BaseTexture>;
    MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
{resource}struct MeshVertex {{ float4 position : POSITION0; float3 normal : NORMAL0; float2 uv : TEXCOORD0; }};
struct Surface {{
    float4 position : POSITION0; float2 uv : TEXCOORD0;
    float3 worldPosition : TEXCOORD1; float3 normal : TEXCOORD2;
}};
Surface TransformVertex(MeshVertex input) {{
    Surface output;
    output.position = mul(input.position, Transform);
    output.uv = input.uv;
    output.worldPosition = mul(input.position, World).xyz;
    output.normal = mul(float4(input.normal, 0), NormalWorld).xyz;
    return output;
}}
float4 RenderSurface(Surface input) : COLOR0 {{
    float4 texel = tex2D(BaseSampler, input.uv);
    float opacity = texel.a * ModelTint.a;
    clip(opacity - 0.0001);
    float3 n = normalize(input.normal);
    float3 baseline = saturate(ModelAmbient + ModelTint.rgb * MmdColor *
                              (0.5 + 0.5 * dot(n, -normalize(MmdDirection))));
    float3 incoming = 0.0;
{body}
    float3 lighting = incoming / (1.0 + incoming);
    float3 tint = baseline + (1.0 - baseline) * lighting * {influence:.8f};
    return float4(texel.rgb * tint, opacity);
}}
''' + ''.join(f'''
technique {technique} < string MMDPass = "{kind}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_3_0 TransformVertex();
        PixelShader = compile ps_3_0 RenderSurface();
        AlphaBlendEnable = true; SrcBlend = SRCALPHA; DestBlend = INVSRCALPHA;
        ZWriteEnable = true;
    }}
}}
''' for technique,kind in (('SceneLight','object'),('SceneLightSS','object_ss')))
