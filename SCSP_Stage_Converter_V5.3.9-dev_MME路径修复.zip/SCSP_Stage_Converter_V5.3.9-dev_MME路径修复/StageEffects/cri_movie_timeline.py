"""Read scene-bound CRI movie cues without interpreting compressed frame data."""
from functools import lru_cache
from math import isfinite
from pathlib import Path
import re

from .timeline_visibility import array, field, reference, track_clips
from .unity_effect_probe import YAML_BLOCK, guid_of, yaml_name


CRI_TRACK = '3c2963dc85d7268e6bfcef73b34cf9af'
CRI_CLIP = '5360d8694200ba2ee251b39445faf0fc'
REFERENCE = re.compile(r'\{[^{}\n]+\}')
BINDING = re.compile(r'^  - key: (\{[^\n]+\})\n    value: (\{[^\n]+\})',re.M)


def movie_timeline(assets, scene):
    assets,scene = Path(assets),Path(scene)

    @lru_cache(maxsize=None)
    def docs(path):
        return {file_id:(kind,body) for kind,file_id,body in
                YAML_BLOCK.findall(path.read_text('utf-8-sig',errors='replace'))}

    scene_docs = docs(scene)
    directors = [body for kind,body in scene_docs.values()
                 if kind=='320' and field(body,'m_Enabled')=='1']
    if not directors:
        return []
    assets_by_guid = {guid:path for pattern in ('*.asset','*.playable','*.bytes','*.usm')
                      for path in assets.rglob(pattern) if (guid:=guid_of(path))}

    def locate(ref, owner):
        file_id,guid = reference(ref)
        return (assets_by_guid.get(guid) if guid else owner),file_id

    def body_at(path, file_id):
        return docs(path).get(file_id,('', ''))[1] if path and path.is_file() else ''

    def controller_name(file_id):
        kind,body = scene_docs.get(file_id,('', ''))
        if kind!='1':
            file_id = reference(field(body,'m_GameObject'))[0]
        return yaml_name(scene_docs.get(file_id,('', ''))[1])

    rows = []
    for director in directors:
        path,file_id = locate(field(director,'m_PlayableAsset'),scene)
        timeline = body_at(path,file_id)
        bindings = {locate(key,path):reference(value)[0]
                    for key,value in BINDING.findall(array(director,'m_SceneBindings'))}
        queue = [(locate(ref,path),None) for ref in REFERENCE.findall(array(timeline,'m_Tracks'))]
        visited = set()
        while queue:
            identity,grade = queue.pop()
            track_path,track_id = identity
            if identity in visited:
                continue
            visited.add(identity)
            track = body_at(track_path,track_id)
            label = yaml_name(track) or ''
            if not track or field(track,'m_Muted')=='1' or 'focusonly' in label.casefold():
                continue
            variant = re.fullmatch(r'Grade_(\d+)',label,re.I)
            if variant:
                grade = int(variant[1])
            queue.extend((locate(ref,track_path),grade)
                         for ref in REFERENCE.findall(array(track,'m_Children')))
            if reference(field(track,'m_Script'))[1]!=CRI_TRACK:
                continue
            binding = bindings.get(identity)
            for clip in track_clips(track):
                clip_path,clip_id = locate(field(clip,'m_Asset'),track_path)
                source = body_at(clip_path,clip_id)
                if reference(field(source,'m_Script'))[1]!=CRI_CLIP:
                    continue
                try:
                    start,duration,clip_in,speed = (float(field(clip,key)) for key in
                                                    ('m_Start','m_Duration','m_ClipIn','m_TimeScale'))
                    fps = float(field(source,'m_movieFrameRate'))
                    source_duration = float(field(source,'m_clipDuration'))
                except ValueError:
                    continue
                if (not all(isfinite(v) for v in (start,duration,clip_in,speed,fps,source_duration))
                        or min(start,clip_in)<0 or min(duration,speed,fps,source_duration)<=0):
                    continue
                media,_ = locate(field(source,'m_movieData'),clip_path)
                media_type = None
                if media and media.is_file() and media.suffix.casefold() in ('.bytes','.usm'):
                    with media.open('rb') as stream:
                        media_type = 'CRI_USM' if stream.read(4)==b'CRID' else None
                rows.append(dict(track=label, target=controller_name(binding), target_file_id=binding,
                                 grade=grade,start_seconds=start,duration_seconds=duration,
                                 end_seconds=start+duration,media_start_seconds=clip_in,speed=speed,
                                 source_fps=fps,source_duration_seconds=source_duration,
                                 loop_within_clip=field(source,'m_loopWithinClip')=='1',
                                 media=str(media.relative_to(assets)) if media_type else None,
                                 media_type=media_type,
                                 status='source_detected' if media_type else 'source_unresolved'))
    return sorted(rows,key=lambda row:(row['start_seconds'],row['track']))

