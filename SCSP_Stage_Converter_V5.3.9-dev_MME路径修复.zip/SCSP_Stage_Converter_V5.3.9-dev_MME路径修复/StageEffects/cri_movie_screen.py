"""Restore the verified KjunBL screen from its embedded USM video streams."""
from decimal import Decimal
from math import ceil
import os
from pathlib import Path
import re
import shutil
from struct import unpack_from
import subprocess

from SceneBuilder.rebuild_stage_blender import parse_mesh, parse_scene
from .activation_curves import frame_at
from .external_lights import local_matrix, material_record, mesh_records, multiply
from .pmx_binary import Model, i32
from .unity_effect_probe import material_info


WIDTH, HEIGHT, COLUMNS, ROWS, GAP = 256,156,13,16,2
PAGE_FRAMES = COLUMNS*ROWS
SCREEN_DIR = 'textures/AutoStageMovie/'


def unpack_cri_ivf(data):
    """Extract the complete embedded IVF stream from a single USM video channel."""
    if not data.startswith(b'CRID'):
        raise ValueError('源文件不是 CRI USM')
    offset = 0
    payloads = []
    while offset < len(data):
        if len(data)-offset<32:
            raise ValueError('USM 数据块头不完整')
        tag,size,payload_offset,padding = unpack_from('>4sIHH',data,offset)
        end = offset+8+size
        if not 24<=payload_offset<=size or end>len(data) or padding>size-payload_offset:
            raise ValueError('USM 数据块边界无效')
        if tag==b'@SFV' and data[offset+15]==0:
            if data[offset+12]!=0:
                raise ValueError('当前仅支持单一 CRI 视频通道')
            payloads.append(data[offset+8+payload_offset:end-padding])
        offset = end
    video = b''.join(payloads)
    if len(video)<32 or not video.startswith(b'DKIF\0\0\x20\0VP90'):
        raise ValueError('CRI 视频流不含受支持的 IVF/VP9 数据')
    width,height,rate,timescale,count = unpack_from('<HHIII',video,12)
    if min(width,height,rate,timescale,count)<=0 or count>10000:
        raise ValueError('IVF 视频参数无效')
    cursor = 32
    for timestamp in range(count):
        if cursor+12>len(video):
            raise ValueError('IVF 视频缺帧')
        length,pts = unpack_from('<IQ',video,cursor)
        if not length or pts!=timestamp:
            raise ValueError('IVF 需要恒定帧率及连续时间戳')
        cursor+=12+length
    if cursor!=len(video):
        raise ValueError('IVF 帧长度与源流不一致')
    return video,(width,height,rate,timescale,count)


def ffmpeg_path():
    override = os.environ.get('SCSP_FFMPEG')
    if override:
        return Path(override) if Path(override).is_file() else None
    executable = shutil.which('ffmpeg')
    if executable:
        return Path(executable)
    # The user's current workstation already provides FFmpeg with Jianying.
    return next((p for p in sorted(Path('C:/Dpan/APP/JianyingPro').glob('*/ffmpeg.exe'),reverse=True)
                 if p.is_file()),None)


def build_pages(ffmpeg, work, name, video, count):
    source = work/(name+'.ivf')
    source.write_bytes(video)
    names = []
    for page,start in enumerate(range(0,count,PAGE_FRAMES)):
        frames = min(PAGE_FRAMES,count-start)
        rows = ceil(frames/COLUMNS)
        target = work/(f'{name}_{page:02}.png')
        filters = (f"select=between(n\\,{start}\\,{start+frames-1}),scale={WIDTH}:{HEIGHT}:flags=lanczos,"
                   f'tile={COLUMNS}x{rows}:nb_frames={frames}:padding={GAP}:margin={GAP}:color=black')
        args = [str(ffmpeg),'-nostdin','-hide_banner','-v','error','-xerror','-n','-threads','2',
                '-i',str(source),'-vf',filters,'-frames:v','1','-threads:v','1',str(target)]
        run = subprocess.run(args,capture_output=True,text=True,encoding='utf8',errors='replace',
                             timeout=120,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if run.returncode or not target.is_file():
            raise ValueError('FFmpeg 无法生成屏幕图集 '+run.stderr[-600:])
        names.append((SCREEN_DIR+target.name,target,rows))
    return names


def movie_shader(clips):
    # D3D9 may lower fmod to frac of a reciprocal multiply. Protect the
    # integer quotient at exact row/loop boundaries and subtract whole rows.
    declarations,branches,slots = [],[],{}
    for cue,count,pages in clips:
        start = frame_at(Decimal(str(cue['start_seconds'])))
        end = frame_at(Decimal(str(cue['end_seconds'])))
        phase = f'elapsed - floor((elapsed + 0.5) / {count}.0) * {count}.0' if cue['loop_within_clip'] else f'min(elapsed, {count-1}.0)'
        statements = []
        for page,(ref,_,rows) in enumerate(pages):
            if ref not in slots:
                number = slots[ref] = len(declarations)
                declarations.append(f'''texture Movie{number} < string ResourceName = "{ref}"; >;
sampler2D Page{number} = sampler_state {{
    Texture = <Movie{number}>; MinFilter = Linear; MagFilter = Linear; MipFilter = None;
    AddressU = Clamp; AddressV = Clamp;
}};''')
            number = slots[ref]
            page_end = min((page+1)*PAGE_FRAMES,count)
            atlas_width = COLUMNS*(WIDTH+GAP)+GAP
            atlas_height = rows*(HEIGHT+GAP)+GAP
            statements.append(f'''        if (local < {page_end}.0) {{
            float tile = local - {page*PAGE_FRAMES}.0;
            float row = floor((tile + 0.5) / {COLUMNS}.0);
            float2 cell = float2(tile - row * {COLUMNS}.0, row);
            float2 uv = (cell * float2({WIDTH+GAP}.0,{HEIGHT+GAP}.0)
                       + {GAP+.5:.2f} + saturate(input.uv) * float2({WIDTH-1}.0,{HEIGHT-1}.0))
                       / float2({atlas_width}.0,{atlas_height}.0);
            return float4(tex2D(Page{number},uv).rgb,1);
        }}''')
        branches.append(f'''    if (frame >= {start}.0 && frame < {end}.0) {{
        float elapsed = frame - {start}.0;
        float local = {phase};
{chr(10).join(statements)}
    }}''')
    return f'''float Seconds : TIME < bool SyncInEditMode = true; >;
float4x4 Transform : WORLDVIEWPROJECTION;
{chr(10).join(declarations)}
struct Vertex {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; }};
Vertex Pose(Vertex input) {{
    input.pos = mul(input.pos,Transform);
    return input;
}}
float4 Paint(Vertex input) : COLOR0 {{
    float frame = floor(max(Seconds,0) * 30.0 + 0.001);
{chr(10).join(branches)}
    clip(-1.0);
    return 0;
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{tag}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_3_0 Pose();
        PixelShader = compile ps_3_0 Paint();
        AlphaBlendEnable = false; CullMode = NONE; ZEnable = true; ZWriteEnable = true;
    }}
}}
''' for name,tag in (('MovieScreen','object'),('MovieScreenSS','object_ss')))


def append_cri_movie(model, scene, assets, scale, cues, work):
    clips = [cue for cue in cues if cue['grade'] is None and cue['media_type']=='CRI_USM']
    names = [Path(cue['media']).stem for cue in clips]
    if (not clips or not all(re.fullmatch(r'MONITOR_Movie_[AB]',cue['target'] or '') for cue in clips)
            or scene is None or not model.vertex_offsets or not model.bones):
        return model,{},[],{}
    try:
        return build_movie(model,scene,assets,scale,clips,names,work)
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, TypeError) as error:
        return model,{},[],dict(status='source_decode_or_binding_failed',reason=str(error))


def build_movie(model, scene, assets, scale, clips, names, work):
    executable = ffmpeg_path()
    if not executable:
        return model,{},[],{'status':'ffmpeg_not_found'}
    objects,transforms,by_go,_,_,_,filters,renderers,paths = parse_scene(scene,assets)

    def world_for(go):
        chain = []
        tid = by_go[go]['id']
        while tid and tid not in chain and tid in transforms:
            chain.append(tid)
            tid = transforms[tid]['father']
        if tid:
            raise ValueError('屏幕父变换缺失')
        matrix = local_matrix(transforms[chain.pop()])
        while chain:
            matrix = multiply(matrix,local_matrix(transforms[chain.pop()]))
        return matrix

    matrices,mesh_ids,screen_roots = [],set(),set()
    transitions = [(frame_at(Decimal(str(x['start_seconds']))),frame_at(Decimal(str(x['end_seconds'])))) for x in clips]
    if any(first<0 or last<=first for first,last in transitions) or any(
            end>start for (_,end),(start,_) in zip(transitions,transitions[1:])):
        raise ValueError('有重叠或无效的视频区间')
    if not all(re.fullmatch(r'[A-Za-z0-9_]+',name) for name in names):
        raise ValueError('屏幕片段名称无法用作 MME 资源路径')
    for cue in clips:
        if cue['media_start_seconds']!=0 or cue['speed']!=1 or cue['source_fps']!=30:
            raise ValueError('当前屏幕支持 30fps 的原始播放速度')
        matches = [go for go,obj in objects.items() if obj['name']==cue['target']]
        if len(matches)!=1:
            raise ValueError('屏幕绑定不唯一')
        go = matches[0]
        meshes = filters.get(go,())
        mesh_id = (meshes[0]['mesh'] or {}).get('guid') if len(meshes)==1 else None
        if not mesh_id or not renderers.get(go) or not by_go[go]['father']:
            raise ValueError('屏幕网格或材质与源绑定不一致')
        mesh_ids.add(mesh_id)
        screen_roots.add(by_go[go]['father'])
        matrices.append(world_for(go))
    if len(mesh_ids)!=1 or len(screen_roots)!=1 or any(m!=matrices[0] for m in matrices[1:]):
        raise ValueError('屏幕播放层不重合')
    mesh = parse_mesh(paths[next(iter(mesh_ids))])
    if not mesh:
        raise ValueError('屏幕网格无法解码')
    vertices,indices = mesh_records(mesh,matrices[0],scale,(1,1,0,0))
    if (model.vertex_count+len(vertices)>2**(8*model.vertex_width)
            or len(model.textures)>=2**(8*model.tex_width-1)
            or len(model.materials)>=2**(8*model.mat_width-1)):
        raise ValueError('屏幕网格超出 PMX 索引容量')

    work.mkdir()
    compiled,cache = [],{}
    media_root = assets.resolve()
    for cue,name in zip(clips,names):
        media = (assets/cue['media']).resolve()
        if not media.is_relative_to(media_root):
            raise ValueError('视频路径超出 Unity Assets')
        if name not in cache:
            stream,(width,height,rate,den,count) = unpack_cri_ivf(media.read_bytes())
            if (width,height)!=(1536,936) or rate!=den*30 or abs(count-cue['source_duration_seconds']*30)>.01:
                raise ValueError('影片尺寸、帧率或帧数与源屏幕不符')
            if sum(len(entry[2]) for entry in cache.values())+ceil(count/PAGE_FRAMES)>12:
                raise ValueError('视频图集超过当前 MME 可用纹理数量')
            cache[name] = (media,count,build_pages(executable,work,name,stream,count))
        existing,count,pages = cache[name]
        if existing!=media:
            raise ValueError('不同影片使用了同一输出名称')
        compiled.append((cue,count,pages))
    files = {ref:path for _,_,pages in compiled for ref,path,_ in pages}
    prefix = names[0].split('_',1)[0]
    first = work/(prefix+'_first.png')
    result = subprocess.run([str(executable),'-nostdin','-v','error','-xerror','-n','-i',str(work/(names[0]+'.ivf')),
                             '-frames:v','1','-threads:v','1',str(first)],capture_output=True,timeout=30,
                            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode or not first.is_file():
        raise ValueError('屏幕静态首帧生成失败')
    screen_id = next(iter(mesh_ids))
    screen_parent = next(iter(screen_roots))
    surfaces = {}
    for go,transform in by_go.items():
        if transform['father']!=screen_parent or not objects[go]['name'].startswith('MONITOR_'):
            continue
        filters_on_go = filters.get(go,())
        if len(filters_on_go)!=1 or (filters_on_go[0]['mesh'] or {}).get('guid')!=screen_id:
            continue
        positions = mesh_records(mesh,world_for(go),scale,(1,1,0,0))[0]
        for renderer in renderers.get(go,()):
            for source in renderer['materials']:
                path = paths.get(source.get('guid'))
                if path and path.is_file():
                    info = material_info(path)
                    for label in (info['name'],path.stem):
                        surfaces.setdefault(label,set()).update(point_key(record,0) for record in positions)
    model,deduplicated = suppress_screen_layers(model,surfaces)
    static_ref = SCREEN_DIR+first.name
    files[static_ref] = first
    model_name = 'AutoMovie_'+prefix
    records = b''.join(v+bytes(16*model.uv_count)+b'\0'+Model.idx(0,model.bone_width)+bytes(4) for v in vertices)
    faces = b''.join(Model.idx(model.vertex_count+j,model.vertex_width,signed=False) for j in indices)
    material = material_record(model,model_name,(1,1,1,1),len(model.textures),len(indices))
    data = model.data
    v,f = model.vertex_offsets[0],model.face_index_start-4
    t,m,b = model.texture_table_at,model.material_table_at,model.bone_table_at
    payload = b''.join((data[:v-4],i32(model.vertex_count+len(vertices)),data[v:f],records,
                        i32(model.face_index_count+len(indices)),data[f+4:t],faces,
                        i32(len(model.textures)+1),data[t+4:m],model.encode_str(static_ref),
                        i32(len(model.materials)+1),data[m+4:b],material,data[b:]))
    binding = dict(material_index=len(model.materials),material=model_name,mode='cri_movie_screen',
                   sources=names,fx_code=movie_shader(compiled))
    status = dict(status='generated',video_frames=sum(entry[1] for entry in cache.values()),fps=30,
                  atlas_frame_size=[WIDTH,HEIGHT],atlas_pages=len(files)-1,
                  cue_frames=[frame_at(Decimal(str(cue['start_seconds']))) for cue in clips],
                  last_frame=frame_at(Decimal(str(clips[-1]['end_seconds'])))-1)
    if deduplicated:
        status['removed_overlapping_screen_layers'] = deduplicated
    return Model(payload),files,[binding],status


def point_key(data, offset):
    return tuple(round(v,3) for v in unpack_from('<3f',data,offset))


def suppress_screen_layers(model, surfaces):
    """Remove only faces on verified sibling screen layers, leaving stage meshes intact."""
    data = model.data
    faces,records,removed = [],[],{}
    ends = [slot.record_at for slot in model.materials[1:]]+[model.bone_table_at]
    for slot,end in zip(model.materials,ends):
        start = model.face_index_start + slot.start*model.vertex_width
        chunk = data[start:start+slot.faces*model.vertex_width]
        points = surfaces.get(slot.name)
        if points and slot.faces:
            indices = model.face_indices(slot.start,slot.faces)
            contained = {i for i in set(indices) if point_key(data,model.vertex_offsets[i]) in points}
            count = 0
            keep = []
            width = model.vertex_width
            for j in range(0,len(indices),3):
                if all(i in contained for i in indices[j:j+3]):
                    count+=3
                else:
                    keep.append(chunk[j*width:(j+3)*width])
            if count:
                removed[slot.name] = removed.get(slot.name,0)+count//3
                chunk = b''.join(keep)
        faces.append(chunk)
        records.append(data[slot.record_at:end-4]+i32(len(chunk)//model.vertex_width))
    if not removed:
        return model,{}
    payload = b''.join((data[:model.face_index_start-4],i32(sum(map(len,faces))//model.vertex_width),
                        b''.join(faces),data[model.texture_table_at:model.material_table_at+4],
                        b''.join(records),data[model.bone_table_at:]))
    return Model(payload),removed

