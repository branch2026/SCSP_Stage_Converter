"""Play an explicitly supplied PNG sequence on a verified stage screen."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
from struct import pack_into

from .output_staging import staging_directory
from .pmx_binary import Model, i32
from .screen_input import copy_screen_assets, load_screen_target, package_file, read_screen_png
from .stage_effects import check_dependencies, resolve_effects
from .vmd_codec import parse_vmd, write_vmd


def read_sequence(folder):
    images = []
    for path in folder.iterdir():
        if path.is_file() and path.suffix.lower()=='.png':
            match = re.fullmatch(r'(.*?)(\d+)',path.stem)
            if not match:
                raise ValueError('PNG 文件名须以帧编号结尾，例如 frame_001.png')
            images.append((match[1],int(match[2]),path))
    if not 2<=len(images)<=120 or len({prefix for prefix,_,_ in images})!=1:
        raise ValueError('请选择同一序列的 2 至 120 张编号 PNG')
    ordered = sorted(images)
    numbers = [n for _,n,_ in ordered]
    if numbers != list(range(numbers[0],numbers[0]+len(numbers))):
        raise ValueError('PNG 帧编号须连续且唯一')
    total_size = sum(path.stat().st_size for _,_,path in ordered)
    if total_size>256*1024**2:
        raise ValueError('PNG 序列大小超过 256 MiB')
    payloads = [read_screen_png(path) for _,_,path in ordered]
    sizes = {size for _,size in payloads}
    if len(sizes)!=1:
        raise ValueError('各张屏幕 PNG 必须大小相同')
    return ordered,[data for data,_ in payloads],sizes.pop()


def append_screen_frames(model,index,refs):
    target = model.materials[index]
    extra = len(refs)-1
    if (len(model.textures)+len(refs)>2**(8*model.tex_width-1) or
            len(model.materials)+extra>2**(8*model.mat_width-1)):
        raise ValueError('序列超过 PMX 的纹理或材质索引容量')
    if any(ref in model.textures for ref in refs):
        raise ValueError('屏幕序列贴图路径冲突')
    raw = bytearray(model.data)
    first_texture = len(model.textures)
    at = target.sphere_at-model.tex_width
    raw[at:target.sphere_at] = model.idx(first_texture,model.tex_width)
    record_end = (model.materials[index+1].record_at if index+1<len(model.materials)
                  else model.bone_table_at)
    template = raw[target.diffuse_at:record_end]
    at = at-target.diffuse_at
    extra_materials = []
    for image_index in range(1,len(refs)):
        name = f'ScreenSeq_{image_index:03d}'
        fields = bytearray(template)
        pack_into('<f',fields,12,0)
        flags = 16+12+4+12
        fields[flags] &= ~0x0e
        fields[at:at+model.tex_width] = model.idx(first_texture+image_index,model.tex_width)
        extra_materials.append(model.encode_str(name)+model.encode_str(name)+fields)

    face_at = model.face_index_start
    texture_at = model.texture_table_at
    material_at = model.material_table_at
    start = face_at + target.start*model.vertex_width
    stop = start + target.faces*model.vertex_width
    return Model(b''.join((raw[:face_at-4], i32(model.face_index_count+extra*target.faces),
                           raw[face_at:texture_at], raw[start:stop]*extra,
                           i32(first_texture+len(refs)),raw[texture_at+4:material_at],
                           b''.join(model.encode_str(ref) for ref in refs),
                           i32(len(model.materials)+extra),raw[material_at+4:model.bone_table_at],
                           b''.join(extra_materials), raw[model.bone_table_at:])))


def sequence_motion(model_name, motion, original_morph, names, step):
    parsed = parse_vmd(motion)
    if parsed['model']!=model_name or any(parsed[key] for key in
            ('bone_keys','camera_keys','light_keys','self_shadow_keys','model_display_keys')):
        raise ValueError('需要当前舞台的纯表情 VMD')
    keys = sorted((key['frame'],key['weight']) for key in parsed['morph_frames'] if key['name']==original_morph)
    if (not keys or keys[0][0]!=0 or any(weight not in (0,1) for _,weight in keys) or
            any(a[1]!=b[1] and b[0]!=a[0]+1 for a,b in zip(keys,keys[1:]))):
        raise ValueError('屏幕需要从第 0 帧开始的明确显隐关键帧')
    last = parsed['last_morph_frame']
    if last>108000:
        raise ValueError('屏幕序列动作超过支持的帧范围')
    states = {}
    for frame,weight in keys:
        states[frame] = bool(weight)
    out = defaultdict(dict)
    selected = None
    hidden = states[0]
    for frame in range(last+1):
        hidden = states.get(frame,hidden)
        new = None if hidden else (frame//step)%len(names)
        if frame==0:
            for i in range(len(names)):
                out[names[i]][0] = int(new!=0) if i==0 else int(new==i)
        elif new!=selected:
            for i in {selected,new}-{None}:
                before,after = (int(selected!=0),int(new!=0)) if i==0 else (int(selected==i),int(new==i))
                out[names[i]][frame-1] = before
                out[names[i]][frame] = after
        selected = new
    for i,name in enumerate(names):
        out[name][last] = int(selected!=0) if i==0 else int(selected==i)
    updated = [(key['name'],key['frame'],key['weight']) for key in parsed['morph_frames']
               if key['name']!=original_morph and key['frame']<=last]
    updated.extend((name,frame,value) for name,track in out.items() for frame,value in track.items())
    return write_vmd(model_name,updated)


def bind_screen_sequence(folder, image_folder, output, *, step=5, material=None, video_source=None):
    folder,image_folder,output = (Path(path).resolve() for path in (folder,image_folder,output))
    if output.exists():
        raise FileExistsError(output)
    if not isinstance(step,int) or not 1<=step<=120:
        raise ValueError('每张 PNG 的持续帧数必须为 1 至 120')
    ordered,images,dimensions = read_sequence(image_folder)
    source,model,report,evidence,index = load_screen_target(folder,material)
    morphs = [fx for fx in evidence.get('effects',[]) if any(row['index']==index for row in fx['materials'])]
    if (len(morphs)!=1 or morphs[0]['type']!='material_alpha' or len(morphs[0]['materials'])!=1 or
            model.materials[index].diffuse[3]!=1.0 or model.materials[index].sphere_mode):
        raise ValueError('屏幕必须仅由一个独占的透明度控制驱动，且无球贴图')
    original_morph = morphs[0]['name']
    refs = [f'textures/ScreenSequence/frame_{i:03d}.png' for i in range(len(images))]
    prepared = append_screen_frames(model,index,refs)
    slots = [index,*range(len(model.materials),len(prepared.materials))]
    names = [f'Seq{i:03d}' for i in range(len(slots))]
    effects = [dict(type='material_alpha',name=name,material_indices=[slot],target_alpha=int(i>0))
               for i,(name,slot) in enumerate(zip(names,slots))]
    parsed,_ = resolve_effects(prepared,dict(schema_version=1,effects=effects))
    payload = prepared.add_morphs(parsed)
    checked = Model(payload)
    assert checked.original_tail==model.original_tail
    assert checked.face_indices(0,model.face_index_count)==model.face_indices(0,model.face_index_count)
    original_vmds = [row['file'] for row in report.get('vmd_outputs',[]) if row['mode']=='morph-only']
    if len(original_vmds)!=1:
        raise ValueError('效果包需要唯一的正式表情 VMD')
    reference = package_file(folder,original_vmds[0])
    motions = {source.stem+'_屏幕序列.vmd':
               sequence_motion(model.name,reference.read_bytes(),original_morph,names,step)}
    if report.get('screen_preview'):
        reference = package_file(folder,report['screen_preview']['file'])
        motions[source.stem+'_屏幕序列验收.vmd'] = sequence_motion(model.name,reference.read_bytes(),original_morph,names,step)
    output.parent.mkdir(parents=True,exist_ok=True)
    with staging_directory(output.parent) as tmp:
        stage = tmp/'package'
        stage.mkdir()
        copy_screen_assets(folder,stage,model)
        for ref,data in zip(refs,images):
            image = stage/ref
            image.parent.mkdir(parents=True,exist_ok=True)
            image.write_bytes(data)
        pmx = stage/(source.stem+'_屏幕序列.pmx')
        pmx.write_bytes(payload)
        for name,data in motions.items():
            (stage/name).write_bytes(data)
        assert not check_dependencies(pmx,checked)[1]
        result = dict(output_pmx=pmx.name,vmd_files=list(motions),material=model.materials[index].name,
                      screen_frames=[path.name for _,_,path in ordered],dimensions=list(dimensions),
                      mmd_frames_per_image=step,fps=30,source_screen_visibility_preserved=True)
        if video_source is not None:
            result['video_source'] = video_source
        (stage/'屏幕序列报告.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf8')
        (stage/'使用说明.txt').write_text(
            '先在 MMD 打开本目录的屏幕序列 PMX，再选中舞台载入一种 VMD。\n'
            '正式 VMD 使用原舞台的屏幕显隐帧。若附带验收 VMD，可从第 0 帧快速查看两次切换。\n',
            encoding='utf-8-sig')
        stage.rename(output)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('package','frames','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--step',type=int,default=5)
    parser.add_argument('--material')
    args=parser.parse_args()
    print(bind_screen_sequence(args.package,args.frames,args.out,step=args.step,material=args.material))
