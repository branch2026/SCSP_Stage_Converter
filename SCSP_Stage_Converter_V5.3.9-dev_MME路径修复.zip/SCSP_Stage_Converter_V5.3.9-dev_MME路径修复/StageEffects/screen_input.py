"""Bind a user-supplied still image to a verified capture-display material."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
from struct import unpack_from
from zlib import crc32

from .output_staging import staging_directory
from .pmx_binary import Model, i32
from .stage_effects import check_dependencies, safe_texture_path


def package_file(folder, name):
    if not name or Path(name).name != name or '/' in name or '\\' in name:
        raise ValueError('效果包文件名无效')
    path = (folder/name).resolve()
    if path.parent != folder or not path.is_file():
        raise ValueError('效果包缺少 '+name)
    return path


def read_screen_png(path):
    data = path.read_bytes()
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('屏幕输入需要有效的静态 PNG')
    size = None
    has_pixels = False
    offset = 8
    while offset+12 <= len(data):
        count,tag = unpack_from('>I4s',data,offset)
        end = offset+8+count
        if end+4 > len(data) or crc32(data[offset+4:end]) != unpack_from('>I',data,end)[0]:
            break
        if offset==8:
            if tag!=b'IHDR' or count!=13:
                break
            size = unpack_from('>II',data,offset+8)
            if not all(size):
                break
        if tag in (b'acTL',b'fcTL',b'fdAT'):
            raise ValueError('屏幕输入当前只支持静态 PNG')
        if tag==b'IDAT' and count:
            has_pixels = True
        if tag==b'IEND' and count==0 and end+4==len(data) and has_pixels:
            return data,size
        offset = end+4
    raise ValueError('PNG 文件结构不完整')


def load_screen_target(folder, material=None):
    report = json.loads(package_file(folder,'AutoStage_Report.json').read_text('utf-8-sig'))
    evidence = json.loads(package_file(folder,'StageEffects_Report.json').read_text('utf-8-sig'))
    source = package_file(folder,report.get('output_pmx'))
    payload = source.read_bytes()
    if evidence.get('output_pmx_sha256') != sha256(payload).hexdigest():
        raise ValueError('当前 PMX 与效果包报告不匹配')
    model = Model(payload)
    approved = {row['object_file_id']:{item['material'] for item in row['materials']}
                for row in report.get('screen_sources',[])
                if row['inside_export_root'] and row['capture_bindings']}
    candidates = {}
    for row in report.get('animation_clip_visibility',[]):
        if row.get('status') != 'generated' or row.get('file_id') not in approved:
            continue
        indices = row.get('material_indices',[])
        if len(indices) != 1 or not 0 <= indices[0] < len(model.materials):
            continue
        index = indices[0]
        name = model.materials[index].name
        if name in approved[row["file_id"]]:
            candidates[index] = name
    targets = [index for index,name in candidates.items() if material is None or material==name]
    if len(targets) != 1:
        options = ', '.join(candidates.values()) if candidates else '无已验证屏幕'
        raise ValueError('需要唯一的屏幕材质。可选项 ' + options)
    index = targets[0]
    target = model.materials[index]
    if target.texture_index < 0 or target.texture_index >= len(model.textures) or not target.faces:
        raise ValueError('目标屏幕没有有效的原贴图')
    _,missing = check_dependencies(source,model)
    if missing:
        raise ValueError('源效果包贴图缺失或不可访问 '+str(missing))
    return source,model,report,evidence,index


def copy_screen_assets(folder, stage, model):
    for path in set(model.textures)-{''}:
        relative = safe_texture_path(path)
        destination = stage/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(folder/relative,destination)


def bind_screen_image(folder, image, output, *, material=None):
    folder, image, output = (Path(path).resolve() for path in (folder,image,output))
    if output.exists() or output == folder:
        raise FileExistsError(output)
    if image.suffix.lower() != '.png' or not image.is_file():
        raise ValueError('请选择静态 PNG 作为屏幕画面')
    image_bytes, dimensions = read_screen_png(image)
    source,model,report,_,index = load_screen_target(folder,material)
    target = model.materials[index]
    payload = model.data
    ref = 'textures/ScreenInput/'+sha256(image_bytes).hexdigest()[:24]+'.png'
    new_index = len(model.textures)
    if new_index>=2**(model.tex_width*8-1) or ref in model.textures:
        raise ValueError('纹理索引空间不足或已存在相同输入')
    data = bytearray(payload)
    at = target.sphere_at-model.tex_width
    data[at:target.sphere_at] = Model.idx(new_index,model.tex_width)
    texture_at, material_at = model.texture_table_at, model.material_table_at
    data[texture_at:texture_at+4] = i32(new_index+1)
    data[material_at:material_at] = model.encode_str(ref)
    checked = Model(bytes(data))
    assert checked.materials[index].texture_index==new_index
    assert checked.morph_names==model.morph_names and checked.original_tail==model.original_tail
    assert checked.data[:texture_at]==model.data[:texture_at]
    motions = [row['file'] for row in report.get('vmd_outputs',[])]
    if report.get('screen_preview'):
        motions.append(report['screen_preview']['file'])
    output.parent.mkdir(parents=True,exist_ok=True)
    with staging_directory(output.parent) as tmp:
        stage = tmp/'package'
        stage.mkdir()
        copy_screen_assets(folder,stage,model)
        new_texture = stage/ref
        new_texture.parent.mkdir(parents=True,exist_ok=True)
        new_texture.write_bytes(image_bytes)
        generated = stage/(source.stem+'_自定义屏幕.pmx')
        generated.write_bytes(data)
        for motion in motions:
            shutil.copy2(package_file(folder,motion),stage/motion)
        assert not check_dependencies(generated,checked)[1]
        result = {'source_pmx':source.name,'output_pmx':generated.name,'screen_material':target.name,
                  'screen_material_index':index,'image':ref,'dimensions':list(dimensions),
                  'vmd_files':motions,'source_screen_timing_preserved':True}
        (stage/'屏幕输入报告.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf8')
        stage.rename(output)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package',required=True,type=Path)
    parser.add_argument('--image',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    parser.add_argument('--material')
    args=parser.parse_args()
    result=bind_screen_image(args.package,args.image,args.out,material=args.material)
    print(result['output_pmx'])
