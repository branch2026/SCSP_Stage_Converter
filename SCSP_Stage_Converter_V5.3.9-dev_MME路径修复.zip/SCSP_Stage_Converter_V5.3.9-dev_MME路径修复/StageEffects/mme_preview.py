"""Export opt-in MME material previews from explicit source shader properties."""
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
from struct import pack, unpack_from

from .camera_ripples import append_camera_ripple
from .cri_movie_screen import append_cri_movie
from .external_lights import texture_transform
from .floor_shadows import split_raised_overlay
from .fountain_meshes import append_fountains
from .mesh_beams import append_beams
from .mme_reflection import convert_probe, reflection_shader
from .particles import append_particles
from .pmx_binary import Model
from .point_mask_geometry import apply_point_mask_geometry
from .scene_lighting import light_receiver_shader, lights_for_surface, timeline_atlas
from .stage_effects import check_dependencies,safe_texture_path
from .timeline_light_meshes import append_timeline_light_meshes, uses_dot_light_mask
from .unity_effect_probe import COLOR_LINE, FLOAT_LINE
from .vmd_codec import BONE_FRAME_SIZE, MORPH_FRAME_SIZE, pack_morph_frame, parse_vmd, write_vmd


BLENDS = {
    (1,0): ('opaque','ONE','ZERO'),
    (1,1): ('additive','ONE','ONE'),
    (5,1): ('alpha_additive','SRCALPHA','ONE'),
    (5,10): ('alpha','SRCALPHA','INVSRCALPHA'),
    (1,10): ('premultiplied_alpha','ONE','INVSRCALPHA'),
    (2,0): ('multiply','DESTCOLOR','ZERO'),
}

MAP_SLOTS = ('_Distortion', '_AlphaTex', '_LightTex')
NIGHTP_LIGHT_PLANES = {
    '3f29fdc9b393418488dab64c5e2f3dc4',
    'ec230506110114946be6c5589a597948',
}


def water_palette(material_text, values, declarations):
    keys = ('_ScatteringColor', '_SpecularColor', '_TextureColorInfluence')
    weight = values.get(keys[2])
    if not set(keys) <= declarations or weight is None or not 0 <= weight <= 1:
        return None
    colors = dict(COLOR_LINE.findall(material_text))
    try:
        channels = [dict((key.strip(), float(value)) for key, value in
                         (field.split(':', 1) for field in colors[name].split(',')))
                    for name in keys[:2]]
        scattering, specular = [tuple(color[key] for key in 'rgb') for color in channels]
    except (KeyError, ValueError):
        return None
    if not all(0 <= value <= 1 for value in (*scattering, *specular)) or not any(scattering):
        return None
    return dict(scattering_color=scattering, specular_color=specular, texture_color_influence=weight)


def mapped_material(shader, values, declarations, material_text, source_textures, textures, *, secondary=False):
    if shader == 'Prism/Effect/Water':
        slot = '_Distortion'
        speed = values.get('_DistortionSpeed', 0)
        strength = values.get('_DistortionStrength', 0)
        if not {'_DistortionSpeed', '_DistortionStrength'} <= declarations:
            return None
        if not (0 < abs(speed) <= 16 and 0 < strength <= 1):
            return None
        palette = water_palette(material_text, values, declarations)
        if palette is None:
            return None
        config = dict(mode='water_distortion', speed=speed, strength=strength, **palette)
    elif shader == 'Giken/3d/Texture_Cutoff':
        slot = '_AlphaTex'
        cutoff = values.get('_Cutoff')
        if '_Cutoff' not in declarations or cutoff is None or not 0 < cutoff <= 1:
            return None
        config = dict(mode='texture_cutoff', cutoff=cutoff)
    elif shader in ('Giken/3d/Texture_Add_Scroll_LightAdjust', 'Giken/3d/LightObjectAdjust'):
        slot = '_LightTex'
        if (secondary or values.get('_SpeedL',0) or values.get('_SpeedLY',0) or
                values.get('_UseMatCap') or not source_textures.get(slot)):
            return None
        config = material_mode(shader, values, True, declarations)
        if not config or config['light'] is None:
            return None
        config.update(map_intensity=config.pop('light'))
    else:
        return None

    guid = source_textures.get(slot, '')
    image = textures.get(guid)
    if (slot not in declarations or not re.fullmatch(r'[0-9a-f]{32}', guid) or
            image is None or image.suffix.lower() != '.png' or not image.is_file()):
        return None
    try:
        main_sx, main_sy, main_ox, main_oy = texture_transform(material_text, '_MainTex')
        sx, sy, ox, oy = texture_transform(material_text, slot)
    except ValueError:
        return None
    if min(abs(main_sx), abs(main_sy)) < 1e-6:
        return None

    # PMX UV already includes the main texture transform and a V flip.
    ratio_x, ratio_y = sx / main_sx, sy / main_sy
    relative = (ratio_x, ratio_y, ox - main_ox * ratio_x,
                1 - ratio_y + main_oy * ratio_y - oy)
    if any(abs(value) > 10000 for value in relative):
        return None
    config = {**dict(src='ONE', dst='ZERO', zwrite=True, light=None, cutoff=None), **config}
    return dict(config, map_slot=slot, map_guid=guid,
                map_file=f'Map_{guid}.png', map_uv=relative, source_texture=image.name,
                map_channel='rgb' if slot == '_LightTex' else 'r')


def material_mode(shader, values, secondary, declarations):
    giken = shader.startswith('Giken/')
    light_family = shader in ('Giken/3d/Texture_Add_Scroll_LightAdjust','Giken/3d/LightObjectAdjust')
    custom = shader=='Custom/AllinOne(ParticleSystem)'
    if not (giken or custom):
        return None
    if custom:
        if (values.get('_MaskSwitch') or values.get('_DistortSwitch') or
                values.get('_SubSwitch') and values.get('_SubAlpha',1)>0):
            return None
        pair = (values.get('_BlendSrc'),values.get('_BlendDst'))
        zwrite = values.get('_ZWriteMode')
        cutoff = values.get('_CutOffAmount') if values.get('_CutOffSwitch')==1 else None
    else:
        if shader == 'Giken/3d/LightObjectAdjust' and (not secondary or values.get('_UseMatCap')):
            return None
        if not light_family and not {'_SrcBlend','_DstBlend'} <= declarations:
            return None
        pair = (values.get('_SrcBlend'),values.get('_DstBlend'))
        zwrite = values.get('_ZWrite')
        cutoff = values.get('_Cutoff') if values.get('_AlphaClip')==1 else None
    if pair not in BLENDS or zwrite not in (0,1):
        return None
    if cutoff is not None and not 0<=cutoff<=1:
        return None
    light = values.get('_Intensity')
    light = light if (secondary and light_family and light is not None
                       and math.isfinite(light) and 0<light<=32) else None
    mode,src,dst = BLENDS[pair]
    if mode=='opaque' and cutoff is None and light is None:
        return None
    return dict(mode=mode,src=src,dst=dst,zwrite=bool(zwrite),cutoff=cutoff,light=light)


def lamp_overlay_mode(mode, shader, material, properties=None):
    # This atlas tile is shared by the confirmed NightP floor lamps. Verify the
    # material and both textures before using its layout on a merged PMX slot.
    if (shader != 'Giken/3d/Texture_Add_Scroll_LightAdjust' or
            material['guid'] not in ('a12762985d4003e4a889c7e0fc53c1ef','27268ef9710bcae43b243091b5a43e99') or
            material['textures'].get('_MainTex') != 'e13875a9c2439f445a0d9bf52b580ae1' or
            material['textures'].get('_LightTex') != '9a8778b1e95663949a4790fe2f201886'):
        return mode
    pulse = mode.get('light') if mode else None
    intensity = pulse or (properties or {}).get('_Intensity',0)
    if not 0 < intensity <= 32:
        return mode
    return dict(mode='lamp_atlas_falloff', src='ONE', dst='INVSRCALPHA',
                zwrite=False, halo_tile=(0.25, 0.25, 0.375, 0.375),
                cutoff=None, light=pulse, halo_intensity=intensity)


def shader_vector(values):
    return ', '.join(f'{value:.8f}' for value in values)


def pool_material_mode(mode, shader, material, properties):
    guid = material['guid']
    if (guid == '98d339e37a483474a964de2b62a33e96' and
            shader == 'Giken/3d/LightObjectAdjust' and not properties.get('_UseMatCap')):
        intensity = properties.get('_Intensity', 0)
        if 0 < intensity <= 32 and properties.get('_ZWrite') == 1:
            return dict(mode='ball_emission', intensity=intensity, src='ONE', dst='ZERO',
                        zwrite=True, light=None, cutoff=None)
    if (guid == 'd56baac5ac13d9f45971b87d8e63da13' and
            mode is not None and mode['mode'] == 'multiply'):
        return dict(mode, shadow_strength=0.45)
    return mode


def light_plane_mode(shader, material, properties):
    if (shader != 'Giken/3d/Texture_Add_Scroll_LightAdjust' or material['guid'] not in NIGHTP_LIGHT_PLANES or
            material['textures'].get('_MainTex') != '9d3430c2991b82d499e0691fac5a2503' or
            material['textures'].get('_LightTex')):
        return None
    intensity = properties.get('_Intensity', 0)
    if not 0 < intensity <= 32:
        return None
    return dict(mode='light_plane_additive', intensity=intensity, src='ONE', dst='ONE',
                zwrite=False, light=None, cutoff=None)


def shader_text(config):
    mode,src,dst = (config[key] for key in ('mode','src','dst'))
    light = config['light']
    cutoff = config['cutoff']
    fragment = []
    map_texture = ''
    base_uv = 'input.uv'
    if mode=='masked_scrolling_light':
        sx,sy,ox,oy = config['point_mask_uv']
        base_uv = f'input.uv * float2({sx:.8f}, {sy:.8f}) + float2({ox:.8f}, {1-sy-oy:.8f})'
    if 'map_file' in config:
        sx, sy, ox, oy = config['map_uv']
        fragment.append(f'float2 mapUV = input.uv * float2({sx:.8f}, {sy:.8f}) + float2({ox:.8f}, {oy:.8f});')
        map_texture = f'''
texture StageMap < string ResourceName = "{config['map_file']}"; >;
sampler2D MapSampler = sampler_state {{
    Texture = <StageMap>;
    MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
'''
        if mode == 'water_distortion':
            map_texture += 'float StageSeconds : TIME < bool SyncInEditMode = true; >;\n'
            fragment.extend([
                f'float phase = frac(StageSeconds * {config["speed"]:.8f});',
                'float rippleX = tex2D(MapSampler, mapUV + float2(phase, 0.0)).r;',
                'float rippleY = tex2D(MapSampler, mapUV + float2(0.5, phase)).r;',
                f'float2 displacement = (float2(rippleX, rippleY) - 0.5) * {config["strength"]:.8f};',
            ])
            base_uv = 'input.uv + displacement'
        elif config['map_slot'] == '_AlphaTex':
            fragment.append(f'clip(tex2D(MapSampler, mapUV).r - {cutoff:.8f});')
    special_surface = mode in ('water_distortion', 'lamp_atlas_falloff')
    if special_surface:
        fragment.extend([f'float4 surfaceTexel = tex2D(BaseSampler, {base_uv});',
                         'float4 base = surfaceTexel * ModelTint;'])
    else:
        fragment.extend([f'float4 base = tex2D(BaseSampler, {base_uv}) * ModelTint;',
                         'clip(ModelTint.a - 0.0001);' if mode=='floor_illumination' else 'clip(base.a - 0.0001);'])
    if mode == 'water_distortion':
        scattering = shader_vector(config['scattering_color'])
        specular = shader_vector(config['specular_color'])
        weight = config['texture_color_influence']
        fragment.extend([
            f'float3 waterBody = float3({scattering}) * 0.22;',
            f'float3 rippleColor = surfaceTexel.rgb * float3({specular});',
            f'base.rgb = (waterBody + rippleColor * {weight:.8f}) * ModelTint.rgb;',
        ])
    if cutoff is not None and mode != 'texture_cutoff':
        fragment.append(f'clip(base.a - {cutoff:.8f});')
    if mode == 'lamp_atlas_falloff':
        x0, y0, x1, y1 = config['halo_tile']
        fragment.extend([
            f'float2 inTile = step(float2({x0}, {y0}), input.uv) * step(input.uv, float2({x1}, {y1}));',
            'float halo = inTile.x * inTile.y;',
            'float atlasMask = dot(surfaceTexel.rgb, float3(0.2126, 0.7152, 0.0722));',
            ('float pulse = dot(tex2D(LightSampler, input.uv1).rgb, float3(0.2126, 0.7152, 0.0722));'
             if light is not None else 'float pulse = 1.0;'),
            f'base.a *= lerp(1.0, saturate(atlasMask * pulse * {config["halo_intensity"]:.8f}), halo);',
            'base.rgb = lerp(base.rgb, ModelTint.rgb, halo) * base.a;',
        ])
    elif 'map_intensity' in config:
        fragment.append(f'base.rgb += tex2D(MapSampler, mapUV).rgb * {config["map_intensity"]:.8f};')
    elif light is not None:
        fragment.append(f'base.rgb += tex2D(LightSampler, input.uv1).rgb * {light:.8f};')
    if special_surface:
        fragment.append('clip(base.a - 0.0001);')
    if mode=='ball_emission':
        fragment.extend([
            f'float3 response = base.rgb * {config["intensity"]:.8f};',
            'base.rgb = ModelTint.rgb * 0.25 + 0.75 * response / (1.0 + response);',
        ])
    elif mode in ('light_plane_additive','neon_glow'):
        fragment.append(f'base.rgb *= base.a * {config["intensity"]:.8f};')
    elif mode=='floor_illumination':
        fragment.append('base = float4(base.rgb * ModelTint.a, 0.0);')
    elif mode=='masked_scrolling_light':
        fragment.append('base = float4(base.rgb * base.a, 0.0);')
    elif mode=='premultiplied_alpha':
        fragment.append('base.rgb *= base.a;')
    elif mode=='additive':
        fragment.append('base.rgb *= ModelTint.a;')
    elif mode=='multiply':
        coverage = f'base.a * {config["shadow_strength"]:.8f}' if 'shadow_strength' in config else 'base.a'
        fragment.append(f'base.rgb = lerp(float3(1, 1, 1), base.rgb, {coverage});')
    # Hide called meshes via their animated material alpha, including opaque light surfaces.
    if mode in ('opaque', 'water_distortion', 'texture_cutoff', 'ball_emission'):
        src,dst='SRCALPHA','INVSRCALPHA'
    body = '\n    '.join([*fragment,'return base;'])
    light_texture = '' if light is None else '''
texture LightTexture : MATERIALSPHEREMAP;
sampler2D LightSampler = sampler_state {
    Texture = <LightTexture>;
    MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
};
'''
    uv1 = '' if light is None else 'float4 tex1 : TEXCOORD1;'
    uv_out = '' if light is None else 'float2 uv1 : TEXCOORD1;'
    uv_copy = '' if light is None else 'result.uv1 = input.tex1.xy;'
    techniques=[]
    for name,kind in [('Surface','object'),('SurfaceSS','object_ss')]:
        techniques.append(f'''technique {name} < string MMDPass = "{kind}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_2_0 TransformVertex();
        PixelShader = compile ps_2_0 RenderSurface();
        AlphaTestEnable = false;
        AlphaBlendEnable = true;
        SrcBlend = {src};
        DestBlend = {dst};
        BlendOp = ADD;
        ZWriteEnable = {'true' if config['zwrite'] else 'false'};
    }}
}}''')
    return f'''float4x4 Transform : WORLDVIEWPROJECTION;
float4 ModelTint : DIFFUSE < string Object = "Geometry"; >;
texture BaseTexture : MATERIALTEXTURE;
sampler2D BaseSampler = sampler_state {{
    Texture = <BaseTexture>;
    MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
{light_texture}{map_texture}
struct MeshVertex {{ float4 position : POSITION0; float2 tex : TEXCOORD0; {uv1} }};
struct SurfaceVertex {{ float4 position : POSITION0; float2 uv : TEXCOORD0; {uv_out} }};
SurfaceVertex TransformVertex(MeshVertex input) {{
    SurfaceVertex result;
    result.position = mul(input.position, Transform);
    result.uv = input.tex;
    {uv_copy}
    return result;
}}
float4 RenderSurface(SurfaceVertex input) : COLOR0 {{
    {body}
}}
'''+'\n\n'.join(techniques)+'\n'


def floor_glow_shader(intensity):
    return f'''float4x4 Transform : WORLDVIEWPROJECTION;
float4 ModelTint : DIFFUSE < string Object = "Geometry"; >;
texture BaseTexture : MATERIALTEXTURE;
texture LightTexture : MATERIALSPHEREMAP;
sampler2D BaseSampler = sampler_state {{
    Texture = <BaseTexture>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
sampler2D LightSampler = sampler_state {{
    Texture = <LightTexture>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
struct MeshVertex {{
    float4 position : POSITION0; float3 normal : NORMAL0;
    float2 uv : TEXCOORD0; float4 uv1 : TEXCOORD1;
}};
struct Surface {{
    float4 position : POSITION0; float2 uv : TEXCOORD0;
    float2 uv1 : TEXCOORD1; float isFloor : TEXCOORD2;
}};
Surface TransformVertex(MeshVertex input) {{
    Surface o;
    o.position = mul(input.position, Transform);
    o.uv = input.uv;
    o.uv1 = input.uv1.xy;
    o.isFloor = step(0.98, input.normal.y) * (1.0 - step(0.5, abs(input.position.y)));
    return o;
}}
float4 PaintedSurface(Surface input) {{
    float4 albedo = tex2D(BaseSampler, input.uv) * ModelTint;
    clip(albedo.a - 0.0001);
    albedo.rgb += tex2D(LightSampler, input.uv1).rgb * {intensity:.8f};
    return albedo;
}}
float4 RenderFloor(Surface input) : COLOR0 {{
    clip(input.isFloor - 0.5);
    float4 base = PaintedSurface(input);
    return float4(base.rgb * base.a, 0.0);
}}
float4 RenderMirror(Surface input) : COLOR0 {{
    clip(0.5 - input.isFloor);
    return PaintedSurface(input);
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{kind}"; bool UseTexture = true; > {{
    pass Mirror {{
        VertexShader = compile vs_2_0 TransformVertex();
        PixelShader = compile ps_2_0 RenderMirror();
        AlphaBlendEnable = true; SrcBlend = SRCALPHA; DestBlend = INVSRCALPHA;
        ZWriteEnable = true;
    }}
    pass Glow {{
        VertexShader = compile vs_2_0 TransformVertex();
        PixelShader = compile ps_2_0 RenderFloor();
        AlphaBlendEnable = true; SrcBlend = ONE; DestBlend = ONE;
        ZWriteEnable = false;
    }}
}}
''' for name,kind in (('FloorGlow','object'),('FloorGlowSS','object_ss')))


def build_mme_preview(package, pmx, referenced, shaders, textures, motions, *, probe=None, blender=None,
                      lights=(), light_programs=None, raised_floor_overlay=None, uv_effects=(),
                      scene=None, scale=12.5, assets=None, light_schedule=None, movie_cues=()):
    model = Model(pmx.read_bytes())
    source_floor = next((i for i,slot in enumerate(model.materials) if slot.name==raised_floor_overlay),None)
    model,floor_slot = split_raised_overlay(model,source_floor) if source_floor is not None else (model,None)
    _,missing = check_dependencies(pmx,model)
    if missing:
        raise ValueError('MME 对照包存在无效贴图')
    model,particle_textures,particles = append_particles(model,scene,scale,assets,light_schedule)
    model,beam_textures,beams = append_beams(model,scene,assets,light_schedule,scale)
    particle_textures.update(beam_textures)
    particles.extend(beams)
    model,ripple_textures,ripples = append_camera_ripple(model,scene,assets,light_schedule,scale)
    particle_textures.update(ripple_textures)
    particles.extend(ripples)
    model,fountain_textures,fountains = append_fountains(model,scene,assets,light_schedule,scale)
    particle_textures.update(fountain_textures)
    model,mesh_light_textures,mesh_lights = append_timeline_light_meshes(model,scene,assets,light_schedule,scale)
    particle_textures.update(mesh_light_textures)
    model,movie_textures,movies,movie_status = append_cri_movie(model,scene,assets,scale,movie_cues,package/'MovieTemp')
    particle_textures.update(movie_textures)
    by_name = {mat['name']:mat for mat in referenced}
    unity_counts=Counter(mat['name'] for mat in referenced)
    pmx_counts=Counter(mat.name for mat in model.materials)
    configs,bindings={},[]
    for row in [*particles,*fountains,*mesh_lights,*movies]:
        code = row.pop('fx_code')
        filename = 'Material_'+sha256(code.encode('ascii')).hexdigest()[:12]+'.fx'
        configs[filename] = code
        bindings.append(dict(row,fx=filename))
    automatic = set()
    scrolls = {}
    for effect in uv_effects:
        if effect['type']=='uv_offset' and len(effect['material_indices'])==1:
            scrolls.setdefault(effect['material_indices'][0],[]).append(effect)
    timeline, timeline_texture = timeline_atlas(light_programs)
    reflection_status = None
    reflection_file = package/'SceneReflection.dds'
    for index,slot in enumerate(model.materials):
        if not slot.faces:
            continue
        name = slot.name
        # External light slots keep the source material name after the exact exporter prefix.
        source_name = re.sub(r'^AutoExt\d+_', '',name)
        if index==floor_slot:
            source_name = raised_floor_overlay
        if unity_counts[source_name]!=1 or pmx_counts[name]!=1:
            continue
        mat = by_name[source_name]
        shader_path=shaders.get(mat['shader_guid'])
        if not shader_path:
            continue
        shader_source = shader_path.read_text('utf-8-sig',errors='replace')
        shader = re.search(r'^\s*Shader\s+"([^"]+)"',shader_source,re.M)
        if not shader:
            continue
        material_source = Path(mat['path']).read_text('utf-8-sig',errors='replace')
        props={key:float(value) for key,value in FLOAT_LINE.findall(material_source)}
        if (slot.texture_index == -1 and shader[1] == 'Giken/3d/Texture_Cubemap' and
                mat['guid'] == '4f9063b85e6f7c64f8591e2f761f73d4'):
            roughness, metallic = props.get('_Roughness', -1), props.get('_Metallic', -1)
            if (mat['textures'].get('_MainTex') or mat['textures'].get('_RoughnessMap') or
                    props.get('_UseNormalMap') or props.get('_UseAlphaClip') or
                    (props.get('_BlendSrcFactor'), props.get('_BlendDstFactor'), props.get('_ZWrite')) != (1, 0, 1)
                    or not (0 <= roughness <= 1 and 0 < metallic <= 1)):
                continue
            if reflection_status is None:
                if probe is None or blender is None:
                    reflection_status = 'SOURCE_OR_BLENDER_MISSING'
                else:
                    try:
                        convert_probe(probe[0], reflection_file, blender)
                        reflection_status = 'CONVERTED'
                    except (OSError, subprocess.SubprocessError):
                        reflection_status = 'CONVERSION_FAILED'
            if reflection_status != 'CONVERTED':
                continue
            code = reflection_shader(roughness, metallic, probe[1])
            filename='Material_'+sha256(code.encode('ascii')).hexdigest()[:12]+'.fx'
            configs[filename] = code
            bindings.append(dict(material_index=index, material=name, material_guid=mat['guid'],
                                 shader=shader[1], fx=filename, mode='reflection_probe',
                                 source_probe=probe[0].name, map_file=reflection_file.name,
                                 roughness=roughness, metallic=metallic, scene_ambient=probe[1]))
            continue
        if not 0 <= slot.texture_index < len(model.textures):
            continue
        texture = textures.get(mat['textures'].get('_MainTex'))
        pmx_texture = model.textures[slot.texture_index]
        if texture is None or not texture.is_file():
            continue
        same = re.fullmatch(re.escape(texture.stem)+r'(?:_[0-9a-f]{8})?',Path(pmx_texture).stem,re.I)
        external = name.startswith('AutoExt') and Path(pmx_texture).stem==mat['textures'].get('_MainTex')
        if not same and not external:
            continue
        secondary = (model.uv_count>0 and slot.sphere_mode==3 and
                     0<=slot.sphere_index<len(model.textures) and
                     Path(model.textures[slot.sphere_index]).stem==mat['textures'].get('_LightTex'))
        declarations=set(re.findall(r'(_[A-Za-z][\w]*)\s*\(',shader_source.split('SubShader',1)[0]))
        mode = mapped_material(shader[1], props, declarations, material_source, mat['textures'], textures,
                               secondary=secondary)
        if mode is None:
            mode=material_mode(shader[1],props,secondary,declarations)
        if (mode and mode['mode']=='opaque' and mode.get('light') is not None
                and uses_dot_light_mask(shader[1],mat['textures'])):
            mode.update(mode='masked_scrolling_light',src='ONE',dst='ONE',zwrite=False,point_mask=True,
                        point_mask_uv=texture_transform(material_source,'_MainTex'))
        mode = lamp_overlay_mode(mode, shader[1], mat, props)
        mode = pool_material_mode(mode, shader[1], mat, props)
        if model.version < 2.05:
            mode = light_plane_mode(shader[1], mat, props) or mode
            intensity = props.get('_LightScale',0)
            if shader[1]=='Giken/3d/LightEffect' and '_LightScale' in declarations and 0<intensity<=8:
                mode = dict(mode='neon_glow', intensity=intensity, src='ONE', dst='ONE',
                            zwrite=False, light=None, cutoff=None)
        influence = props.get('_LightInfluence',1)
        if (mode is None and shader[1] in ('Giken/3d/Texture','Giken/3d/GroundPlane','Giken/3d/Texture_Cubemap') and
                '_LightInfluence' in declarations and slot.diffuse[3] >= 0.999 and 0 < influence <= 1 and
                props.get('_ZWrite',1) == 1 and props.get('_BlendSrcFactor',1) == 1 and
                props.get('_BlendDstFactor',0) == 0 and not props.get('_UseAlphaClip')):
            sources = lights_for_surface(model, slot, lights)
            if sources:
                mode = dict(mode='scene_light_receiver', light_influence=influence,
                            light_source_ids=[light['file_id'] for light in sources])
                motion_lights = [light['file_id'] for light in sources if light.get('animated')]
                if motion_lights:
                    mode['animated_light_ids'] = motion_lights
                code = light_receiver_shader(sources, influence, timeline)
        if mode is None:
            continue
        if index==floor_slot and secondary and mode.get('light') is not None:
            mode.update(mode='floor_illumination',src='ONE',dst='ONE',zwrite=False)
        if (name==raised_floor_overlay and floor_slot is None and model.version<2.05 and
                secondary and mode.get('light') is not None):
            code = floor_glow_shader(mode['light'])
            mode.update(mode='separated_floor_glow', floor_zwrite=False)
        elif mode['mode'] != 'scene_light_receiver':
            code=shader_text(mode)
            lookup = source_floor if index==floor_slot else index
            if 'map_file' not in mode and mode['mode'] not in ('lamp_atlas_falloff','water_distortion','texture_cutoff'):
                code,tracks = timed_scroll(code,scrolls.get(lookup,()))
                if tracks:
                    mode['automatic_uv_tracks'] = tracks
                    automatic.update(tracks)
        filename='Material_'+sha256(code.encode('ascii')).hexdigest()[:12]+'.fx'
        configs[filename]=code
        bindings.append(dict(material_index=index,material=name,material_guid=mat['guid'],
                             shader=shader[1],fx=filename,**mode))
    if not bindings:
        return None
    model=apply_point_mask_geometry(model,bindings)
    preview=package/'MME_Preview'
    preview.mkdir()
    preview_pmx=preview/pmx.name
    overlays = {item['material_index'] for item in bindings
                if model.version < 2.05 and (item.get('point_mask') or
                    item['mode'] in ('light_plane_additive','lamp_atlas_falloff','separated_floor_glow','bubble_particles','glitter_particles','mesh_light_beams','camera_ripple','splash_particles',
                                     'floor_illumination','neon_glow','fountain_column','fountain_flow','fountain_wave','fountain_light'))}
    empty_slots = {index for index, slot in enumerate(model.materials) if not slot.faces}
    # Keep EMD indices equal to drawn subset indices when MME skips empty slots.
    # Move empty slots to the end, preserving any PMX morphs that refer to them.
    move_empty = bool(movies and model.version < 2.05 and empty_slots)
    for slots in (overlays, empty_slots if move_empty else set()):
        if not slots:
            continue
        reordered, mapping = model.materials_last(slots)
        model = Model(reordered)
        for item in bindings:
            source_index = item['material_index']
            item.setdefault('source_material_index',source_index)
            item['material_index'] = mapping[source_index]
        bindings.sort(key=lambda item: item['material_index'])
    preview_pmx.write_bytes(model.data)
    for path in (set(model.textures)|set(particle_textures))-{''}:
        relative=safe_texture_path(path)
        target=preview/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(particle_textures.get(path,pmx.parent/relative),target)
    for path in motions:
        data = path.read_bytes()
        (preview/path.name).write_bytes(without_uv_tracks(data,automatic) if automatic else data)
    for name, guid in {item['map_file']: item['map_guid'] for item in bindings if 'map_guid' in item}.items():
        shutil.copy2(textures[guid], preview/name)
    if reflection_status == 'CONVERTED':
        shutil.copy2(reflection_file, preview/reflection_file.name)
    has_timeline = timeline_texture is not None and any(item.get('animated_light_ids') for item in bindings)
    if has_timeline:
        (preview/'StageLightTimeline.dds').write_bytes(timeline_texture)
    for name,code in configs.items():
        (preview/name).write_text(code,encoding='ascii')
    content=['[Info]','Version = 3','','[Effect]','Obj = none']
    content.extend(f"Obj[{item['material_index']}] = {item['fx']}" for item in bindings)
    preview_pmx.with_suffix('.emd').write_text('\n'.join(content)+'\n',encoding='ascii')
    result=dict(folder=preview.name,pmx=preview_pmx.name,materials=bindings,
                unique_fx=len(configs),automatic_uv_tracks=sorted(automatic),
                particle_emitters=len(particles),
                status='MME_VISUAL_VALIDATION_PENDING')
    if fountains:
        result['fountain_meshes'] = dict(Counter(row['mode'] for row in fountains))
    if mesh_lights:
        result['timeline_light_meshes'] = len(mesh_lights)
    if movie_status:
        result['movie_screen'] = movie_status
    if movies and len(model.bones)==1:
        motion_name = pmx.stem+'_屏幕播放时长.vmd'
        neutral = [(model.bones[0],frame,(0,0,0),(0,0,0,1)) for frame in (0,movie_status['last_frame'])]
        (preview/motion_name).write_bytes(write_vmd(model.name,[],bone_frames=neutral))
        movie_status['timing_vmd'] = motion_name
    if reflection_status:
        result['reflection_probe_status'] = reflection_status
    if has_timeline:
        result['light_timeline'] = dict(texture='StageLightTimeline.dds', fps=30, last_frame=timeline[2],
                                        texture_size=list(timeline[:2]), light_texel_offsets=timeline[3])
    (preview/'MME_Preview_Report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
    (preview/'使用说明.txt').write_text(
        '使用已安装 MME 的 MMD932 打开本目录 PMX，拖动时间轴即可检查自动效果。\n'
        '其余表情控制使用本目录的 VMD。\n'
        '同名 EMD 指向当前目录的 FX，请在 MMEffect 的效果分配里确认已载入。\n'
        '与外层普通版使用同机位比较。水面随时间轴更新，可停在不同帧查看波纹。\n'
        '167_NightP 的水色取自 Unity 材质，地灯使用光斑贴图渐隐。\n'
        '池中浮具使用场景烘焙反射，球灯保留绿色底亮度，池畔道具阴影减弱。\n'
        '灯光片在实体之后加算混合，黑色底纹保持透明。\n'
        '存在 StageLightTimeline.dds 时，灯光随 MMD 时间轴播放或拖动。请保留同目录贴图。\n'
        '试验包按源参数近似水面纹理、镂空、材质混合和部分光照贴图。\n' +
        ('屏幕由 MME 时间轴播放。加载同目录的屏幕播放时长 VMD，也可直接跳到任意视频播放帧。\n'
         f"源视频开始帧：{', '.join(map(str,movie_status['cue_frames']))}。\n" if movies else ''),
        encoding='utf-8-sig')
    return result


def timed_scroll(code, effects):
    head, tail = code.split('float4 RenderSurface(',1)
    rates, names = {},[]
    for effect in effects:
        channel = effect['uv_channel']
        uv = 'input.uv1' if channel else 'input.uv'
        if not re.search(r'\b'+re.escape(uv)+r'\b',tail):
            continue
        pair = rates.setdefault(uv,[0.,0.])
        for axis,direction in enumerate(effect['offset']):
            if direction:
                pair[axis] = direction * abs(effect['unity_evidence']['speed'])
        names.append(effect['name'])
    for uv,pair in rates.items():
        terms = [f'{-1.0 if value<0 else 1.0:.1f} * frac(max(AutoSeconds, 0.0) * {abs(value):.8f})'
                 if value else '0.0' for value in pair]
        tail = re.sub(r'\b'+re.escape(uv)+r'\b',f'({uv} + float2({", ".join(terms)}))',tail)
    clock = 'float AutoSeconds : TIME < bool SyncInEditMode = true; >;\n' if names else ''
    return head+clock+'float4 RenderSurface('+tail,names


def without_uv_tracks(data, names):
    parsed = parse_vmd(data)
    bone_count, = unpack_from('<I',data,50)
    start = 54 + bone_count*BONE_FRAME_SIZE
    entries = parsed['morph_frames']
    kept = [data[start+4+i*MORPH_FRAME_SIZE:start+4+(i+1)*MORPH_FRAME_SIZE]
            for i,item in enumerate(entries) if item['name'] not in names]
    if entries and not kept and not bone_count:
        # Keep a loadable playback range without applying any of the UV motion.
        anchor = entries[0]['name']
        kept = [pack_morph_frame(anchor, frame, 0.0)
                for frame in sorted({0,parsed['last_morph_frame']})]
    return (data[:start]+pack('<I',len(kept))+b''.join(kept)
            +data[start+4+len(entries)*MORPH_FRAME_SIZE:])
