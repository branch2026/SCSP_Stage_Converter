"""Convert Timeline-started Unity mesh particles into additive MME stage beams."""
from math import ceil, cos, pi, radians, sin, sqrt
from random import Random
import re
from struct import pack, unpack

from SceneBuilder.rebuild_stage_blender import parse_mesh, parse_scene, vec
from .external_lights import local_matrix, material_record, mesh_records, multiply, texture_transform
from .particles import number, scalar_range, section
from .pmx_binary import Model, i32
from .timeline_visibility import array, field, reference
from .unity_effect_probe import YAML_BLOCK


LASER_MESH = '7aef5c9e35ada4d419c2334d6f8fd3de'
LASER_MATERIALS = {'22fb83e2a796d4e4dacc7863a9a185ac','56437064d87624d4ab29763e59c42b26'}
LASER_TEXTURE = '5f9303182183cec43976daa7e6f3e37b'


def emission_parameters(block):
    initial = section(block,'InitialModule',2)
    shape = section(block,'ShapeModule',2)
    emission = section(block,'EmissionModule',2)
    rate = section(emission,'rateOverTime',4)
    size = []
    for prop in ('startSize','startSizeY','startSizeZ'):
        low,high = scalar_range(initial,prop)
        if low != high or not 0<high<=1000:
            raise ValueError('光束尺寸必须为有限常量')
        size.append(high)
    lifetime,_ = scalar_range(initial,'startLifetime')
    initial_speed = scalar_range(initial,'startSpeed')
    loop = float(field(block,'lengthInSec'))
    if (number(initial,'size3D',4)!=1 or number(shape,'type',4)!=4 or
            not 0<lifetime<=2 or not 0<loop<=10 or max(abs(v) for v in initial_speed)>.01 or
            number(rate,'minMaxState',6)!=0 or float(field(block,'simulationSpeed') or '1')!=1):
        raise ValueError('光束粒子寿命、发射方向或运动模式不支持')
    rate_hz = number(rate,'scalar',6)
    bursts = number(emission,'m_BurstCount',4)
    if bursts==0 and 0<rate_hz<=60:
        count = ceil(lifetime*rate_hz)
        spacing = 1/rate_hz
        period = count*spacing
    elif bursts==1 and rate_hz==0:
        # The source contains one repeatable, certain burst at the start of the system loop.
        times = re.findall(r'(?m)^ *time: ([^\n]+)$',emission)
        counts = re.findall(r'(?m)^ *scalar: ([^\n]+)$',emission)
        repeats = re.findall(r'(?m)^ *cycleCount: ([^\n]+)$',emission)
        probabilities = re.findall(r'(?m)^ *probability: ([^\n]+)$',emission)
        if len(times)!=1 or float(times[0])!=0 or repeats!=['1'] or probabilities!=['1'] or lifetime>loop:
            raise ValueError('只支持发射循环起点的单次爆发')
        count = int(float(counts[-1]))
        period,spacing = loop,0.
    else:
        raise ValueError('仅支持恒定发射或单次爆发')
    if not 1<=count<=8:
        raise ValueError('并发光束数量超出支持范围')
    color = section(initial,'startColor',4)
    if number(color,'minMaxState',6)!=0:
        raise ValueError('仅支持源光束的固定初始颜色')
    gradient = section(section(section(block,'ColorModule',2),'gradient',4),'maxGradient',6)
    opacity = [(number(gradient,'atime'+str(i),8)/65535,
                vec(gradient,'key'+str(i),('a',),(1,))[0])
               for i in range(int(number(gradient,'m_NumAlphaKeys',8,0)))]
    if not opacity or any(not 0<=v<=1 for _,v in opacity):
        raise ValueError('源光束渐隐数据缺失')
    return dict(size=size, lifetime=lifetime, period=period, spacing=spacing, count=count,
                angle=number(shape,'angle',4), alpha=opacity,
                color=vec(color,'maxColor',tuple('rgba'),(1,1,1,1)))


def beam_shader(cue, config):
    color = ', '.join(f'{v:.8f}' for v in config['color'])
    opacity = f"    float opacity = {config['alpha'][0][1]:.8f};\n"
    for (start,a),(end,b) in zip(config['alpha'],config['alpha'][1:]):
        if end>start and a!=b:
            opacity += f'    opacity += ({b-a:.8f}) * saturate((phase - {start:.8f}) / {end-start:.8f});\n'
    return f'''float Seconds : TIME < bool SyncInEditMode = true; >;
float4x4 Transform : WORLDVIEWPROJECTION;
texture BeamTexture : MATERIALTEXTURE;
sampler2D BeamSampler = sampler_state {{
    Texture = <BeamTexture>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Clamp; AddressV = Clamp;
}};
struct Vertex {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; }};
struct Result {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; float opacity : TEXCOORD1; }};
Result PoseBeam(Vertex input) {{
    Result result;
    result.pos = mul(input.pos, Transform);
    float slot = floor(input.uv.x * 0.5);
    result.uv = float2(input.uv.x - 2.0 * slot, input.uv.y);
    float elapsed = Seconds - {cue:.8f} - slot * {config['spacing']:.8f};
    float age = frac(elapsed / {config['period']:.8f}) * {config['period']:.8f};
    float phase = age / {config['lifetime']:.8f};
{opacity}    result.opacity = saturate(opacity) * step(0.0, elapsed) * (1.0 - step(1.0, phase));
    return result;
}}
float4 PaintBeam(Result input) : COLOR0 {{
    float4 color = tex2D(BeamSampler, input.uv) * float4({color});
    color.a *= input.opacity;
    clip(color.a - 0.0001);
    return color;
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{kind}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_2_0 PoseBeam();
        PixelShader = compile ps_2_0 PaintBeam();
        AlphaBlendEnable = true; SrcBlend = SRCALPHA; DestBlend = ONE;
        CullMode = NONE; ZWriteEnable = false;
    }}
}}
''' for name,kind in (('StageBeam','object'),('StageBeamSS','object_ss')))


def append_beams(model, scene, assets, schedule, scale):
    if scene is None or schedule is None or not schedule.effect_events or not model.vertex_offsets or not model.bones:
        return model,{},[]
    text = scene.read_text('utf-8-sig',errors='replace')
    if LASER_MESH not in text:
        return model,{},[]
    objects,_,by_go,_,by_tid,_,_,_,paths = parse_scene(scene,assets or scene.parent)
    mesh = paths.get(LASER_MESH)
    texture = paths.get(LASER_TEXTURE)
    if not mesh or not texture or not mesh.is_file() or not texture.is_file():
        return model,{},[]
    geometry = parse_mesh(mesh)
    if not geometry:
        return model,{},[]
    source_materials = {}
    for guid in LASER_MATERIALS:
        path = paths.get(guid)
        if not path or not path.is_file():
            continue
        material = path.read_text('utf-8-sig',errors='replace')
        if LASER_TEXTURE not in material or not all(re.search(r'(?m)^ *'+k+r': '+v+r'\s*$',material)
                                                  for k,v in (('_BlendSrc','5'),('_BlendDst','1'),('_ZWriteMode','0'))):
            continue
        uv = texture_transform(material,'_MainTex')
        if uv == (1,1,0,0):
            source_materials[guid] = uv
    blocks = YAML_BLOCK.findall(text)
    renderers = {reference(field(b,'m_GameObject'))[0]:b
                 for k,_,b in blocks if k=='199' and field(b,'m_Enabled')=='1'}
    vertices,faces,materials,rows = [],[],[],[]
    asset_name = 'textures/AutoStageParticles/StageBeamMask.png'
    tex = len(model.textures)
    if asset_name in model.textures or tex>=2**(model.tex_width*8-1):
        return model,{},[]
    for kind,fileid,block in blocks:
        if (kind!='198' or field(block,'looping')!='1' or field(block,'playOnAwake')!='1'):
            continue
        go = reference(field(block,'m_GameObject'))[0]
        renderer = renderers.get(go,'')
        if (field(renderer,'m_RenderMode')!='4' or reference(field(renderer,'m_Mesh'))[1]!=LASER_MESH):
            continue
        refs = re.findall(r'^  - (\{[^\n]+\})',array(renderer,'m_Materials'),re.M)
        if len(refs)!=1 or reference(refs[0])[1] not in source_materials:
            continue
        try:
            chain,cues,seen = [],[],set()
            current = int(go)
            while current:
                if current in seen or not objects[current]['active']:
                    raise ValueError('光束层级未启用')
                seen.add(current)
                transform = by_go[current]
                chain.append(local_matrix(transform))
                cues.extend(schedule.effect_events.get(objects[current]['name'],()))
                current = by_tid[transform['father']] if transform['father'] else 0
            # Ambiguous launches across the same emitter are left to the original controller.
            times = {event['time'] for event in cues}
            if len(times)!=1:
                continue
            cue = next(iter(times))
            config = emission_parameters(block)
            world = chain.pop()
            while chain:
                world = multiply(world,chain.pop())
            uv = source_materials[reference(refs[0])[1]]
            moving = []
            rng = Random(int(fileid))
            for index in range(config['count']):
                angle = radians(config['angle'])*sqrt(rng.random())
                azimuth = rng.random()*2*pi
                quaternion = (-sin(azimuth)*sin(angle/2),cos(azimuth)*sin(angle/2),0,cos(angle/2))
                local = local_matrix(dict(rot=quaternion,pos=(0,0,0),scale=config['size']))
                moving.append(mesh_records(geometry,multiply(world,local),scale,uv))
        except (ValueError,KeyError,IndexError):
            continue
        total = sum(len(rows) for rows,_ in moving)
        if (model.vertex_count+len(vertices)+total>2**(8*model.vertex_width) or
                len(model.materials)+len(materials)>=2**(8*model.mat_width-1)):
            break
        start_faces = len(faces)
        for variant,(records,indices) in enumerate(moving):
            start = model.vertex_count+len(vertices)
            for record in records:
                u,v = unpack('<2f',record[24:32])
                vertices.append(record[:24]+pack('<2f',u+2*variant,v)+bytes(16*model.uv_count)
                                +b'\0'+Model.idx(0,model.bone_width)+bytes(4))
            faces.extend(Model.idx(start+i,model.vertex_width,signed=False) for i in indices)
        name = 'AutoBeam_'+fileid
        materials.append(material_record(model,name,(1,1,1,1),tex,len(faces)-start_faces))
        rows.append(dict(material_index=len(model.materials)+len(rows),material=name,mode='mesh_light_beams',
                         shader='Unity ParticleSystem',
                         source_emitter=fileid,source_object=objects[int(go)]['name'],cue_seconds=cue,
                         marker=cues[0]['asset'],beam_count=config['count'],fx_code=beam_shader(cue,config)))
    if not rows:
        return model,{},[]
    data = model.data
    vertex = model.vertex_offsets[0]
    face = model.face_index_start-4
    texture_table = model.texture_table_at
    material = model.material_table_at
    bone = model.bone_table_at
    payload = b''.join((data[:vertex-4],i32(model.vertex_count+len(vertices)),data[vertex:face],b''.join(vertices),
                        i32(model.face_index_count+len(faces)),data[face+4:texture_table],b''.join(faces),
                        i32(tex+1),data[texture_table+4:material],model.encode_str(asset_name),
                        i32(len(model.materials)+len(rows)),data[material+4:bone],b''.join(materials),data[bone:]))
    return Model(payload),{asset_name:texture},rows
