"""Read Boolean GameObject animation curves and sample Timeline clip timing."""
from bisect import bisect_right
from decimal import Decimal, InvalidOperation, ROUND_CEILING
import re


def frame_at(seconds):
    # Snap AssetRipper float timestamps within 0.001 frame to the exact frame.
    return int((seconds * 30 - Decimal('0.001')).to_integral_value(rounding=ROUND_CEILING))


def active_curves(float_curves):
    """Yield explicit AnimationClip GameObject bindings and step keys."""
    for curve in re.split(r'^  - serializedVersion:.*$',float_curves,flags=re.M)[1:]:
        if not re.search(r'^    attribute: m_IsActive\s*$',curve,re.M):
            continue
        path = re.search(r'^    path:[ \t]*(.*)$',curve,re.M)
        if not path or not re.search(r'^    classID: 1[ \t]*$',curve,re.M):
            continue
        key_count = len(re.findall(r'^        time:',curve,re.M))
        pairs = re.findall(r'^        time: ([^\n]+)\n        value: ([^\n]+)',curve,re.M)
        try:
            keys = [(Decimal(time),Decimal(value)) for time,value in pairs]
            valid = (0 < len(keys)==key_count and
                     all(t.is_finite() and t>=0 and v in (0,1) for t,v in keys) and
                     all(a[0]<b[0] for a,b in zip(keys,keys[1:])))
        except InvalidOperation:
            valid = False
        yield path[1].strip().strip('"'), keys if valid else []


def clip_visibility_keys(keys, frames, *, start, duration, clip_in, speed,
                         before_hold, after_hold, initial_active):
    """Return hidden morph weights for the source property, at 30 fps."""
    times = [key[0] for key in keys]
    first = frame_at(start)
    end = frame_at(start + duration)

    def is_active(frame):
        if frame < first and not before_hold or frame >= end and not after_hold:
            return initial_active
        elapsed = max(Decimal(0),min(duration, Decimal(frame)/30-start))
        # A timestamp close to an exact sample uses the same snap rule as frame_at.
        source_time = clip_in + (elapsed+Decimal('0.001')/30)*speed
        if frame >= end:
            source_time = clip_in+duration*speed
        index = max(0,bisect_right(times,source_time)-1)
        return bool(keys[index][1])

    samples = {0,frames}
    changes = [first,end]
    for source_time,_ in keys:
        scene_time = start + (source_time-clip_in)/speed
        if start <= scene_time < start+duration:
            changes.append(frame_at(scene_time))
    for boundary in changes:
        samples.update(f for f in (boundary-1,boundary) if 0<=f<=frames)
    return [[f,int(not is_active(f))] for f in sorted(samples)]
