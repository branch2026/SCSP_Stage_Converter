"""Restore source-bound external meshes using the scrolling light-map shader family."""
from collections import Counter
from functools import lru_cache
from math import isfinite
import re

from SceneBuilder.rebuild_stage_blender import BUILTIN_MESH_GUID, parse_builtin_mesh, parse_mesh, parse_scene, vec
from .external_lights import local_matrix, material_record, mesh_records, multiply, texture_transform
from .pmx_binary import Model, i32
from .unity_effect_probe import FLOAT_LINE, material_info


SHADER = 'Giken/3d/Texture_Add_Scroll_LightAdjust'
DOT_LIGHT_TEXTURES = ('456d0221b48eafa4585e2ec6709660ec','5bff9e4bbc47f5c419b4f4af31a8d711')


def uses_dot_light_mask(shader, textures):
    # The source white point atlas is a coverage mask for the scrolling light
    # texture. It has 948 transparent texels out of 1024.
    return shader==SHADER and (textures.get('_MainTex'),textures.get('_LightTex'))==DOT_LIGHT_TEXTURES


def light_mesh_shader(cue, layers, intensity, tint, cull, *, alpha_mask=False):
    def uv_transform(layer):
        (sx,sy,ox,oy),(u,v) = layer
        return (f'input.uv * float2({sx:.8f}, {sy:.8f}) + '
                f'float2({ox:.8f}, {1-sy-oy:.8f}) + elapsed * float2({u:.8f}, {-v:.8f})')

    color = ', '.join(f'{value:.8f}' for value in tint)
    base_uv = uv_transform(layers["main"])
    base_sample = (f'float4 base = tex2D(Base, {base_uv});\n    float3 tint = float3({color});'
                   if alpha_mask else f'float3 base = tex2D(Base, {base_uv}).rgb * float3({color});')
    output = ('clip(base.a - 0.00392157);\n'
              '    return float4((base.rgb * tint + light) * base.a, 0);' if alpha_mask else
              'return float4(base + light, 1);')
    render_state = (f'AlphaBlendEnable = true; SrcBlend = ONE; DestBlend = ONE; CullMode = {cull}; '
                    'ZEnable = true; ZWriteEnable = false;' if alpha_mask else
                    f'AlphaBlendEnable = false; CullMode = {cull}; ZEnable = true; ZWriteEnable = true;')
    return f'''float Seconds : TIME < bool SyncInEditMode = true; >;
float4x4 Transform : WORLDVIEWPROJECTION;
texture BaseTex : MATERIALTEXTURE;
texture LightTex < string ResourceName = "{layers["light_file"]}"; >;
sampler2D Base = sampler_state {{
    Texture = <BaseTex>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
sampler2D Light = sampler_state {{
    Texture = <LightTex>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
struct Vertex {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; }};
Vertex Pose(Vertex input) {{
    input.pos = mul(input.pos, Transform);
    return input;
}}
float4 Paint(Vertex input) : COLOR0 {{
    float elapsed = Seconds - {cue:.8f};
    clip(elapsed);
    {base_sample}
    float3 light = tex2D(Light, {uv_transform(layers["light"])}).rgb * {intensity:.8f};
    {output}
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{tag}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_2_0 Pose();
        PixelShader = compile ps_2_0 Paint();
        {render_state}
    }}
}}
''' for name,tag in (('StageLightMesh','object'),('StageLightMeshSS','object_ss')))


def append_timeline_light_meshes(model, scene, assets, schedule, scale):
    empty = (model,{},[])
    if (scene is None or schedule is None or not schedule.effect_events
            or not model.vertex_offsets or not model.bones):
        return empty
    objects,transforms,by_go,_,by_tid,_,filters,renderers,paths = parse_scene(scene,assets or scene.parent)
    present = {re.sub(r'^AutoExt\d+_', '',slot.name) for slot in model.materials}

    @lru_cache(maxsize=None)
    def lineage(tid):
        result = []
        while tid and tid not in result and tid in transforms:
            result.append(tid)
            tid = transforms[tid]['father']
        return tuple(reversed(result)) if not tid else ()

    player_roots = {tid for tid,t in transforms.items() if
                    objects.get(t['go'],{}).get('name')=='EffectPlayer'}
    if not player_roots:
        return empty
    names = Counter(objects[by_tid[tid]]['name'] for tid in transforms
                    if player_roots.intersection(lineage(tid)) and by_tid[tid] in objects)

    @lru_cache(maxsize=None)
    def read_shader(guid):
        path = paths[guid]
        match = re.search(r'^\s*Shader\s+"([^"]+)"',path.read_text('utf-8-sig',errors='replace'),re.M)
        return match[1] if match else None

    @lru_cache(maxsize=None)
    def material(guid):
        path = paths[guid]
        info = material_info(path)
        if info['name'] in present or read_shader(info['shader_guid']) != SHADER:
            return None
        text = path.read_text('utf-8-sig',errors='replace')
        props = {k:float(v) for k,v in FLOAT_LINE.findall(text)}
        if ((props.get('_SrcBlend'),props.get('_DstBlend'),props.get('_ZWrite'))!=(1,0,1)
                or props.get('_Surface',0)!=0 or props.get('_AlphaClip',0)
                or props.get('_UseMatCap',0) or not 0 < props.get('_Intensity',0) <= 8):
            return None
        if props.get('_Cull') not in (0,2):
            return None
        names = (('_MainTex','_SpeedM','_SpeedMY'),('_LightTex','_SpeedL','_SpeedLY'))
        layers,refs,files = {},[],{}
        for layer,(slot,x,y) in zip(('main','light'),names):
            tex_id = info['textures'][slot]
            tex = paths[tex_id]
            if tex.suffix.lower()!='.png' or not tex.is_file():
                return None
            ref = f'textures/AutoStageTimelineLight/{tex_id}.png'
            refs.append(ref)
            files[ref] = tex
            layers[layer] = texture_transform(text,slot),(props.get(x,0),props.get(y,0))
        if not all(isfinite(v) and abs(v)<=16 for _,speed in layers.values() for v in speed):
            return None
        layers['light_file'] = refs[1]
        tint = vec(text,'_Color',tuple('rgb'),(1,1,1))
        if not all(isfinite(v) and 0<=v<=32 for v in tint):
            return None
        return info,refs[0],files,layers,props['_Intensity'],tint,('NONE' if props['_Cull']==0 else 'CCW')

    @lru_cache(maxsize=None)
    def geometry(guid, file_id):
        if guid==BUILTIN_MESH_GUID:
            return parse_builtin_mesh(file_id)
        path = paths[guid]
        return parse_mesh(path) if path.suffix.lower()=='.asset' else None

    vertices,indices,slots,rows = [],[],[],[]
    textures,files = {},{}
    instances = set()
    for go, render in renderers.items():
        enabled = [r for r in render if r['enabled']]
        if len(enabled)!=1 or len(enabled[0]['materials'])!=1 or len(filters.get(go,()))!=1 or go not in by_go:
            continue
        chain = lineage(by_go[go]['id'])
        if not player_roots.intersection(chain):
            continue
        try:
            hierarchy = [objects[by_tid[tid]] for tid in chain]
            bound = [obj['name'] for obj in hierarchy if obj['name'] in schedule.effect_events]
            if len(bound)!=1 or names[bound[0]]!=1:
                continue
            cues = schedule.effect_events[bound[0]]
            if (len({event['time'] for event in cues})!=1 or any(event['grade'] is not None for event in cues)):
                continue
            # A play marker can enable its bound group. An inactive child may
            # represent another variant and still needs its own source binding.
            if any(not obj['active'] and obj['name']!=bound[0] for obj in hierarchy):
                continue
            mat_id = enabled[0]['materials'][0]['guid']
            support = material(mat_id)
            if support is None:
                continue
            info,main,maps,layers,intensity,tint,cull = support
            mesh_ref = filters[go][0]['mesh']
            mesh_id = (mesh_ref['guid'],int(mesh_ref['fileID']))
            mesh = geometry(*mesh_id)
            if not mesh:
                continue
            matrix = local_matrix(transforms[chain[0]])
            for tid in chain[1:]:
                matrix = multiply(matrix,local_matrix(transforms[tid]))
            instance = (mesh_id,mat_id,matrix)
            if instance in instances:
                continue
            records,faces = mesh_records(mesh,matrix,scale,(1,1,0,0))
        except (KeyError,TypeError,ValueError,IndexError,OSError,OverflowError):
            continue
        if (model.vertex_count+len(vertices)+len(records)>2**(8*model.vertex_width) or
                len(model.materials)+len(rows)>=2**(8*model.mat_width-1) or
                main not in textures and len(model.textures)+len(textures)>=2**(8*model.tex_width-1)
                or main in model.textures):
            continue
        instances.add(instance)
        files.update(maps)
        if main not in textures:
            textures[main] = len(model.textures)+len(textures)
        name = 'AutoTimelineLight_'+str(go)
        offset = model.vertex_count+len(vertices)
        vertices.extend(row+bytes(16*model.uv_count)+b'\0'+Model.idx(0,model.bone_width)+bytes(4) for row in records)
        indices.extend(Model.idx(offset+i,model.vertex_width,signed=False) for i in faces)
        slots.append(material_record(model,name,(1,1,1,1),textures[main],len(faces)))
        cue = cues[0]['time']
        alpha_mask = uses_dot_light_mask(SHADER,info['textures'])
        rows.append(dict(material_index=len(model.materials)+len(rows),material=name,
                         mode='timeline_light_mesh',shader=SHADER,source_material=info['name'],
                         source_object=objects[go]['name'],source_object_id=go,
                         effect_object=bound[0],cue_seconds=cue,marker=cues[0]['asset'],vertex_count=len(records),
                         **({'point_mask':True,'point_mask_uv':layers['main'][0]} if alpha_mask else {}),
                         fx_code=light_mesh_shader(cue,layers,intensity,tint,cull,alpha_mask=alpha_mask)))
    if not rows:
        return empty
    data = model.data
    vertex,face = model.vertex_offsets[0],model.face_index_start-4
    tex,mat,bone = model.texture_table_at,model.material_table_at,model.bone_table_at
    output = b''.join((data[:vertex-4],i32(model.vertex_count+len(vertices)),data[vertex:face],b''.join(vertices),
                      i32(model.face_index_count+len(indices)),data[face+4:tex],b''.join(indices),
                      i32(len(model.textures)+len(textures)),data[tex+4:mat],
                      b''.join(model.encode_str(ref) for ref in textures),i32(len(model.materials)+len(rows)),
                      data[mat+4:bone],b''.join(slots),data[bone:]))
    return Model(output),files,rows

