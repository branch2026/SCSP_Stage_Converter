"""Disable PMX floor shadows and remove explicit Unity ground shadow faces."""
from collections import defaultdict
from math import isfinite
from pathlib import Path
import re
from struct import pack_into, unpack_from

from .pmx_binary import Model, i32
from .prepare_model import floor_layout
from .unity_effect_probe import FLOAT_LINE


KARMA_OVERLAY = 'M_Stage_001910_Add_addscrl_mirrorFish'
KARMA_FLOORS = ('M_Stage_001910_op_floor_main', KARMA_OVERLAY, 'M_Stage_001910_op_floor_runwey_road')
KARMA_LAYOUT = '8bc0d09c230cb6389d1b31576074f437ae5a7b4fad793e49ab284421964c0e3c'
FLOOR_NAME = re.compile(r'floor|ground|runw[ae]y|carpet|地板|地面|床面|ステージ床', re.I)
EXCLUDED_FLOOR_NAME = re.compile(r'ceiling|celing|ceil|roof|shadow|lamp|light|scroll|skirt|天井|阴影|影$',re.I)
SHADOW_NAME = re.compile(r'shadow|陰影|阴影|影$',re.I)


def coordinates(model, vertex):
    return unpack_from('<6f',model.data,model.vertex_offsets[vertex])


def horizontal_triangles(model, slot, *, upward):
    indices = model.face_indices(slot.start,slot.faces)
    points = {v:coordinates(model,v) for v in set(indices)}
    for index in range(0,len(indices),3):
        corners = tuple(points[v] for v in indices[index:index+3])
        if not all(isfinite(n) for p in corners for n in p):
            continue
        if upward and min(p[4] for p in corners)<0.8:
            continue
        a,b,c = corners
        dx,dy,dz = (v-u for u,v in zip(a[:3],b[:3]))
        ex,ey,ez = (v-u for u,v in zip(a[:3],c[:3]))
        y = abs(dx*ez-dz*ex)
        if y>0.0001 and max(abs(dy*ez-dz*ey),abs(dx*ey-dy*ex))<=y*0.15:
            yield index,corners


def karma_floor_overlay(model, root, scene):
    if root!='180_KarmaD' or scene.stem.casefold()!='180_karmad' or model.version>=2.05:
        return {}, None
    matches = [[i for i,slot in enumerate(model.materials) if slot.name==name] for name in KARMA_FLOORS]
    if any(len(indices)!=1 for indices in matches):
        return {}, None
    slots = [indices[0] for indices in matches]
    if floor_layout(model,slots)!=KARMA_LAYOUT:
        return {}, None
    index = slots[1]
    overlay = model.materials[index]
    indices = model.face_indices(overlay.start,overlay.faces)
    floor = {indices[face+corner] for face,points in horizontal_triangles(model,overlay,upward=True)
             if max(abs(point[1]) for point in points)<0.08 for corner in range(3)}
    other_overlay = set()
    for face in range(0,len(indices),3):
        triangle = indices[face:face+3]
        if not all(vertex in floor for vertex in triangle):
            other_overlay.update(triangle)
    if floor & other_overlay:
        return {}, None
    for i,slot in enumerate(model.materials):
        if i!=index and floor.intersection(model.face_indices(slot.start,slot.faces)):
            return {}, None
    return ({i:0.20 for i in floor}, KARMA_OVERLAY) if floor else ({}, None)


def split_raised_overlay(model, index):
    """Put confirmed raised horizontal faces in their own final material slot."""
    if model.version>=2.05 or any(int.from_bytes(model.data[at:at+model.mat_width],'little',signed=True)==index
                                  for at in model.material_morph_indices):
        return model,None
    slot = model.materials[index]
    ground = {face for face,corners in horizontal_triangles(model,slot,upward=True)
              if all(0.12<=point[1]<=0.28 for point in corners)}
    if not ground or len(ground)*3==slot.faces or len(model.materials)>=2**(8*model.mat_width-1):
        return model,None
    start = model.face_index_start+slot.start*model.vertex_width
    end = start+slot.faces*model.vertex_width
    keep, overlay = [],[]
    width = model.vertex_width
    for face in range(0,slot.faces,3):
        target = overlay if face in ground else keep
        target.append(model.data[start+face*width:start+(face+3)*width])
    data = bytearray(model.data)
    record_end = (model.materials[index+1].record_at if index+1<len(model.materials) else model.bone_table_at)
    named = model.encode_str(slot.name)+model.encode_str(slot.english)
    name = slot.name+'_GroundGlow'
    clone = (model.encode_str(name)+model.encode_str(name)+data[slot.record_at+len(named):record_end-4]
             +i32(len(overlay)*3))
    data[model.bone_table_at:model.bone_table_at] = clone
    data[record_end-4:record_end] = i32(len(keep)*3)
    data[model.material_table_at:model.material_table_at+4] = i32(len(model.materials)+1)
    data[start:model.texture_table_at] = b''.join(keep)+data[end:model.texture_table_at]+b''.join(overlay)
    return Model(bytes(data)),len(model.materials)


def disable_floor_shadows(model, referenced, shaders, scale, protected=()):
    source = {}
    for mat in referenced:
        source.setdefault(mat['name'],[]).append(mat)

    def material_shader(name):
        materials = source.get(name,[])
        if len(materials)!=1:
            return '',None
        mat = materials[0]
        path = shaders.get(mat['shader_guid'])
        if not path:
            return '',None
        match = re.search(r'^\s*Shader\s+"([^"]+)"',path.read_text('utf-8-sig',errors='replace'),re.M)
        return (match[1] if match else ''),mat

    heights = {}
    floors = []
    for index,slot in enumerate(model.materials):
        if not slot.faces or EXCLUDED_FLOOR_NAME.search(slot.name):
            continue
        shader,_ = material_shader(slot.name) if not FLOOR_NAME.search(slot.name) else ('',None)
        if not FLOOR_NAME.search(slot.name) and shader!='Giken/3d/GroundPlane':
            continue
        planes = defaultdict(list)
        for _,corners in horizontal_triangles(model,slot,upward=True):
            planes[round(sum(c[1] for c in corners)/3,3)].extend(corners)
        if not planes:
            continue
        floors.append(index)
        for level,points in planes.items():
            x,_,z,*_ = zip(*points)
            heights.setdefault(level,[]).append((min(x),max(x),min(z),max(z)))

    selected = set(floors)
    data = bytearray(model.data)
    cleared,removed = [],[]
    faces = []
    for index,slot in enumerate(model.materials):
        at = slot.diffuse_at+44
        flags = data[at]
        data[at] &= ~(0x0e if index in selected else 0x02)
        if flags!=data[at]:
            cleared.append(dict(material=slot.name,material_index=index,old_flags=flags,new_flags=data[at]))
        drop = set()
        if heights and slot.faces and index not in protected and SHADOW_NAME.search(slot.name):
            shader,material = material_shader(slot.name)
            if shader=='Custom/AllinOne(ParticleSystem)':
                text = Path(material['path']).read_text('utf-8-sig',errors='replace')
                values = dict(FLOAT_LINE.findall(text))
                if float(values.get('_BlendSrc',0))==2 and float(values.get('_BlendDst',-1))==0:
                    tolerance = scale*0.06
                    for face,corners in horizontal_triangles(model,slot,upward=False):
                        x,y,z,*_ = zip(*corners)
                        height = sum(y)/3
                        if any(abs(height-level)<=tolerance and
                               any(a<=min(x)+tolerance and b>=max(x)-tolerance and
                                   d<=min(z)+tolerance and e>=max(z)-tolerance for a,b,d,e in bounds)
                               for level,bounds in heights.items()):
                            drop.add(face)
        start = model.face_index_start+slot.start*model.vertex_width
        end = start+slot.faces*model.vertex_width
        if not drop:
            faces.append(data[start:end])
            continue
        kept = [data[start+face*model.vertex_width:start+(face+3)*model.vertex_width]
                for face in range(0,slot.faces,3) if face not in drop]
        faces.extend(kept)
        record_end = (model.materials[index+1].record_at
                      if index+1<len(model.materials) else model.bone_table_at)
        pack_into('<i',data,record_end-4,slot.faces-3*len(drop))
        removed.append(dict(material=slot.name, material_index=index, faces_removed=len(drop)))
    if removed:
        indices = b''.join(faces)
        data[model.face_index_start-4:model.texture_table_at] = i32(len(indices)//model.vertex_width)+indices
    return (Model(bytes(data)) if cleared or removed else model,
            dict(status='applied' if cleared or removed else 'no_matching_surfaces',
                 floor_materials=[model.materials[i].name for i in floors],
                 shadow_flags=cleared, shadow_faces=removed))
