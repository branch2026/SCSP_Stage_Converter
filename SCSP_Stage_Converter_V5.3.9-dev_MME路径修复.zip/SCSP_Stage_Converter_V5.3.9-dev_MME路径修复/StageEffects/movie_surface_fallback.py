"""Suppress unresolved CriMana video placeholders and their coincident overlays."""
from pathlib import Path
from struct import unpack_from

from .pmx_binary import Model, i32
from .timeline_visibility import field, reference
from .unity_effect_probe import guid_of


CRI_SHADER = '6ae999b243cd0424a9b27558c90df16f'
CRI_CLIP = '5360d8694200ba2ee251b39445faf0fc'
DOT_OVERLAY = 'c383927babac23e4c8a6ab7116e9b82d'
ROSE_SOURCE = 'e688413d087f34f4ba2252495d3ed758'


def restore_movie_surfaces(model, referenced, assets, textures):
    source_movies = {name for row in referenced
                     if row['shader_guid']==CRI_SHADER and not row['textures'].get('_MainTex')
                     for name in (row['name'],Path(row['path']).stem)}
    candidates = {i for i,slot in enumerate(model.materials)
                  if slot.faces and slot.texture_index<0 and slot.name in source_movies}
    if not candidates:
        return model,{},{}
    overlays = {row['name'] for row in referenced if row['guid']==DOT_OVERLAY}

    def signature(slot):
        # The exported stages may use separate vertex IDs for identical layers.
        positions = frozenset(tuple(round(x,4) for x in unpack_from('<3f',model.data,model.vertex_offsets[index]))
                              for index in set(model.face_indices(slot.start,slot.faces)))
        return slot.faces,positions

    movie_meshes = {signature(model.materials[i]) for i in candidates}
    rose = next((row for row in referenced if row['guid']==ROSE_SOURCE),None)
    rose_guid = rose['textures'].get('_MainTex') if rose else None
    rose_texture = textures.get(rose_guid)
    keep = min(candidates) if (rose_texture and rose_texture.is_file() and len(movie_meshes)==1
                               and len(model.textures)<2**(8*model.tex_width-1)) else None
    ref = 'textures/AutoStageScreen/'+rose_guid+'.png' if keep is not None else ''
    candidates.update(i for i,slot in enumerate(model.materials)
                      if slot.faces and slot.texture_index<0 and slot.name in overlays
                      and signature(slot) in movie_meshes)
    movies = {}
    for path in assets.rglob('*.bytes'):
        guid = guid_of(path)
        if guid:
            movies[guid] = path
    clips = set()
    for path in assets.rglob('CriManaClip*.asset'):
        text = path.read_text('utf-8-sig',errors='replace')
        if reference(field(text,'m_Script'))[1]!=CRI_CLIP:
            continue
        source = movies.get(reference(field(text,'m_movieData'))[1])
        if source and source.is_file():
            with source.open('rb') as stream:
                if stream.read(4)==b'CRID':
                    clips.add(str(source.relative_to(assets)))
    data = model.data
    kept,records,removed = [],[],[]
    ends = [slot.record_at for slot in model.materials[1:]]+[model.bone_table_at]
    for index,(slot,end) in enumerate(zip(model.materials,ends)):
        if index in candidates and index!=keep:
            records.append(data[slot.record_at:end-4]+i32(0))
            removed.append(dict(material=slot.name, material_index=index, removed_faces=slot.faces//3))
        else:
            at = model.face_index_start+slot.start*model.vertex_width
            kept.append(data[at:at+slot.faces*model.vertex_width])
            if index==keep:
                at = slot.sphere_at-model.tex_width
                records.append(data[slot.record_at:at]+Model.idx(len(model.textures),model.tex_width)
                               +data[slot.sphere_at:end])
            else:
                records.append(data[slot.record_at:end])
    texture_table = data[model.texture_table_at:model.material_table_at]
    if keep is not None:
        texture_table = i32(len(model.textures)+1)+texture_table[4:]+model.encode_str(ref)
    payload = b''.join((data[:model.face_index_start-4],i32(sum(map(len,kept))//model.vertex_width),
                        b''.join(kept),texture_table,data[model.material_table_at:model.material_table_at+4],
                        b''.join(records),data[model.bone_table_at:]))
    report = dict(status='source_still' if keep is not None else 'hidden_until_video_is_bound',
                  materials=removed,cri_clip_assets=sorted(clips))
    if keep is not None:
        report.update(still_material=model.materials[keep].name,still_texture=ref)
    return Model(payload),({ref:rose_texture} if keep is not None else {}),report
