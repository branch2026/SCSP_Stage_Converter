"""Import a local video segment into a verified PMX screen animation."""
import argparse
import math
from pathlib import Path
import shutil
import subprocess

from .output_staging import staging_directory
from .screen_input import load_screen_target, read_screen_png
from .screen_atlas import bind_video_atlas
from .stage_effects import safe_texture_path


def video_canvas(original, aspect=None):
    if aspect:
        try:
            width,height = (int(value) for value in aspect.split(':'))
        except ValueError as error:
            raise ValueError('屏幕比例请填写宽:高，例如 9:16') from error
        if not 1<=width<=10000 or not 1<=height<=10000:
            raise ValueError('屏幕比例的宽与高必须为正整数')
    else:
        width,height = original
    scale = 512/max(width,height)
    return tuple(max(2,2*round(dim*scale/2)) for dim in (width,height))


def bind_screen_video(folder, video, output, *, start=0, duration=4, step=5, ffmpeg=None, material=None, aspect=None):
    folder,video,output = (Path(path).resolve() for path in (folder,video,output))
    if output.exists():
        raise FileExistsError(output)
    if video.suffix.lower() not in ('.mp4','.mov','.mkv','.avi','.webm','.m4v') or not video.is_file():
        raise ValueError('请选择本地 MP4、MOV、MKV、AVI、WebM 或 M4V 视频')
    if not math.isfinite(start) or start<0 or not math.isfinite(duration) or duration<=0:
        raise ValueError('起点和时长须为有效秒数，且时长大于零')
    if not isinstance(step,int) or not 1<=step<=120:
        raise ValueError('每张画面持续帧数必须为 1 至 120')
    fps = 30/step
    if not 2/fps<=duration<=120/fps:
        raise ValueError('按当前速度，视频片段需要生成 2 至 120 帧')
    expected = math.floor(duration*fps + 1e-8)
    executable = Path(ffmpeg).resolve() if ffmpeg else shutil.which('ffmpeg')
    if not executable or not Path(executable).is_file():
        raise ValueError('找不到 FFmpeg，请指定 ffmpeg.exe')

    source,model,_,_,index = load_screen_target(folder,material)
    chosen_material = model.materials[index]
    previous_image = source.parent/safe_texture_path(model.textures[chosen_material.texture_index])
    _, original_size = read_screen_png(previous_image)
    width,height = video_canvas(original_size,aspect)
    filt = (f'fps=30/{step},scale=trunc(iw*sar/2)*2:ih,setsar=1,'
            f'scale={width}:{height}:force_original_aspect_ratio=decrease,'
            f'pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black,format=rgb24')
    output.parent.mkdir(parents=True,exist_ok=True)
    with staging_directory(output.parent) as temp:
        frames = temp/'frames'
        frames.mkdir()
        cmd = [str(executable),'-hide_banner','-nostdin','-v','error',
               '-protocol_whitelist','file','-ss',str(start),'-i',str(video),
               '-map','0:v:0','-an','-sn','-dn','-t',str(duration),
               '-vf',filt,'-frames:v',str(expected),'-threads:v','1',
               '-start_number','1',str(frames/'frame_%03d.png')]
        try:
            run = subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',
                                 errors='replace',timeout=120,
                                 creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired as error:
            raise ValueError('视频取帧超时，请缩短片段或降低取帧数量') from error
        if run.returncode:
            detail = run.stderr.strip()
            raise ValueError('FFmpeg 无法读取该视频片段' + ('\n'+detail[-1200:] if detail else ''))
        count = len(list(frames.glob('frame_*.png')))
        if count<2:
            raise ValueError('片段内不足两帧，请检查起点与视频长度')
        video_source = dict(file=video.name,start_seconds=start,requested_seconds=duration,
                            sampled_frames=count,sampling_fps=fps,
                            loop_seconds=count/fps,fit='letterbox',display_aspect=aspect,audio_imported=False)
        return bind_video_atlas(folder,frames,output,step=step,material=chosen_material.name,
                                executable=executable,video_source=video_source)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('package','video','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--ffmpeg',type=Path)
    parser.add_argument('--start',type=float,default=0)
    parser.add_argument('--duration',type=float,default=4)
    parser.add_argument('--step',type=int,default=5)
    parser.add_argument('--material')
    parser.add_argument('--aspect',help='Screen aspect, such as 9:16')
    args=parser.parse_args()
    print(bind_screen_video(args.package,args.video,args.out,start=args.start,duration=args.duration,
                            step=args.step,ffmpeg=args.ffmpeg,material=args.material,aspect=args.aspect))
