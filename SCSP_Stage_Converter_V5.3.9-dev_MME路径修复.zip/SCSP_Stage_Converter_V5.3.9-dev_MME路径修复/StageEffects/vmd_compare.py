# -*- coding: utf-8 -*-
"""Compare two VMD files structurally to diagnose MMD-generated vs tool-generated motion."""
import argparse
import hashlib
import json
from pathlib import Path

try:
    from .vmd_codec import parse_vmd
except ImportError:
    from vmd_codec import parse_vmd


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def compare(left, right):
    a=parse_vmd(left, strict=True); b=parse_vmd(right, strict=True)
    def morph_map(parsed):
        out={}
        for item in parsed['morph_frames']:
            out.setdefault(item['name'],[]).append({'frame':item['frame'],'weight':round(item['weight'],7)})
        return out
    def bone_map(parsed):
        out={}
        for item in parsed['bone_frames']:
            out.setdefault(item['name'],[]).append({'frame':item['frame'],
                'position':[round(v,7) for v in item['position']],
                'rotation':[round(v,7) for v in item['rotation']]})
        return out
    am,bm=morph_map(a),morph_map(b); ab,bb=bone_map(a),bone_map(b)
    return {
        'schema':'scsp-vmd-structural-compare-v1',
        'left':{'file':str(Path(left)),'sha256':sha256(left),'model':a['model'],
                'bone_keys':a['bone_keys'],'morph_keys':a['morph_keys'],
                'camera_keys':a['camera_keys'],'light_keys':a['light_keys'],
                'self_shadow_keys':a['self_shadow_keys'],'model_display_keys':a['model_display_keys']},
        'right':{'file':str(Path(right)),'sha256':sha256(right),'model':b['model'],
                 'bone_keys':b['bone_keys'],'morph_keys':b['morph_keys'],
                 'camera_keys':b['camera_keys'],'light_keys':b['light_keys'],
                 'self_shadow_keys':b['self_shadow_keys'],'model_display_keys':b['model_display_keys']},
        'model_name_equal':a['model']==b['model'],
        'morph_track_names_equal':set(am)==set(bm),
        'bone_track_names_equal':set(ab)==set(bb),
        'morph_tracks':{
            'left_only':sorted(set(am)-set(bm)),
            'right_only':sorted(set(bm)-set(am)),
            'different':{name:{'left':am[name],'right':bm[name]} for name in sorted(set(am)&set(bm)) if am[name]!=bm[name]},
        },
        'bone_tracks':{
            'left_only':sorted(set(ab)-set(bb)),
            'right_only':sorted(set(bb)-set(ab)),
            'different':{name:{'left':ab[name],'right':bb[name]} for name in sorted(set(ab)&set(bb)) if ab[name]!=bb[name]},
        },
        'section_counts_equal':all(a[k]==b[k] for k in ('camera_keys','light_keys','self_shadow_keys','model_display_keys')),
        'interpretation':'Structural comparison only; MMD playback still requires in-application validation.'
    }


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('left',type=Path);p.add_argument('right',type=Path)
    p.add_argument('--out',type=Path)
    args=p.parse_args()
    report=compare(args.left,args.right)
    text=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(text,'utf-8')
        print('Comparison saved:',args.out)
    else:print(text)

if __name__=='__main__':main()
