# -*- coding: utf-8 -*-
"""Read-only Unity AssetRipper material/scene/animation evidence inventory.

Not an emulator of Unity shaders or runtime Timeline. Does not fabricate FX.
"""
import argparse
import collections
import json
import re
from pathlib import Path


GUID_LINE=re.compile(r'^guid:\s*([0-9a-fA-F]{32})\s*$',re.M)
YAML_BLOCK=re.compile(r'^--- !u!(\d+) &(-?\d+)\s*\n(.*?)(?=^--- !u!|\Z)',re.M|re.S)
FLOAT_LINE=re.compile(r'^\s*(?:-\s*)?(_[A-Za-z][\w.]*)\s*:\s*(-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*$',re.M)
COLOR_LINE=re.compile(r'^\s*(?:-\s*)?(_[A-Za-z][\w.]*)\s*:\s*\{([xyzwrgba0-9.,+\- eE:]+)\}',re.M)
TEXTURE_LINE=re.compile(r'^\s*(?:-\s*)?(_[A-Za-z][\w.]*)\s*:\s*\n\s*m_Texture:\s*\{[^\n]*guid:\s*([0-9a-fA-F]{32})',re.M)


def yaml_name(text):
    m=re.search(r'^\s*m_Name:\s*(.*?)\s*$',text,re.M)
    return m.group(1) if m else None


def guid_of(file):
    meta=Path(str(file)+'.meta')
    if not meta.is_file():return None
    m=GUID_LINE.search(meta.read_text('utf-8-sig',errors='replace'))
    return m.group(1).lower() if m else None


def material_info(path):
    text=Path(path).read_text('utf-8-sig',errors='replace')
    name=yaml_name(text) or Path(path).stem
    shader=re.search(r'^\s*m_Shader:\s*\{[^\n]*guid:\s*([0-9a-fA-F]{32})',text,re.M)
    floats={k:float(v) for k,v in FLOAT_LINE.findall(text)}
    colors={k:v.strip() for k,v in COLOR_LINE.findall(text)}
    textures={k:g.lower() for k,g in TEXTURE_LINE.findall(text)}
    interesting=['_SrcBlend','_DstBlend','_ZWrite','_SpeedL','_Intensity','_Cutoff','_Alpha','_Mode','_EmissionIntensity']
    return {'path':str(path),'guid':guid_of(path),'name':name,
            'shader_guid':shader.group(1).lower() if shader else None,
            'floats':{k:v for k,v in floats.items() if k in interesting or any(w in k.lower() for w in ('speed','emiss','blend','intensity','alpha'))},
            'colors':{k:v for k,v in colors.items() if any(w in k.lower() for w in ('emiss','color','tint'))},
            'textures':textures}


def scene_material_references(scene_path):
    text=Path(scene_path).read_text('utf-8-sig',errors='replace')
    objects={}; renderers=[]
    blocks=YAML_BLOCK.findall(text)
    for kind,fileid,block in blocks:
        if kind=='1':
            objects[fileid]=yaml_name(block) or fileid
    for kind,fileid,block in blocks:
        if kind not in ('23','137'):continue
        go=re.search(r'm_GameObject:\s*\{fileID:\s*(-?\d+)',block)
        if not go:continue
        mat_section=re.search(r'^\s*m_Materials:\s*\n((?:\s*-\s*\{[^\n]*\}\s*\n)+)',block,re.M)
        gids=re.findall(r'guid:\s*([0-9a-fA-F]{32})',mat_section.group(1)) if mat_section else []
        renderer_enabled=re.search(r'^\s*m_Enabled:\s*(\d+)',block,re.M)
        renderers.append({'game_object':objects.get(go.group(1),go.group(1)),
                          'renderer_fileid':fileid,'type':'MeshRenderer' if kind=='23' else 'SkinnedMeshRenderer',
                          'enabled':renderer_enabled.group(1)=='1' if renderer_enabled else None,
                          'material_guids':[g.lower() for g in gids]})
    return renderers


def animation_info(file):
    s=Path(file).read_text('utf-8-sig',errors='replace')
    tracks=re.findall(r'^\s*attribute:\s*(.+?)\s*\n\s*path:\s*(.*?)\s*$',s,re.M)
    return {'file':str(file),'clip':yaml_name(s) or Path(file).stem,
            'tracks':[{'attribute':a,'path':p} for a,p in tracks],
            'tracked_attributes':sorted({a for a,_ in tracks})}


def probe(project,scene,include_animations=True):
    project=Path(project).resolve()
    assets=project/'Assets'
    if not assets.is_dir():raise ValueError('Expected scene-project containing Assets')
    scene=Path(scene)
    scene_abs=(project/scene).resolve() if not scene.is_absolute() else scene.resolve()
    if not scene_abs.is_file() or not scene_abs.is_relative_to(assets):
        raise ValueError('Scene must be an existing .unity file under Assets')
    mats=[material_info(f) for f in assets.rglob('*.mat')]
    guids={m['guid']:m for m in mats if m['guid']}
    refs=scene_material_references(scene_abs)
    referenced=collections.defaultdict(list)
    for r in refs:
        for guid in r['material_guids']:
            referenced[guid].append(r['game_object'])
    result=[]
    for guid,gos in referenced.items():
        src=guids.get(guid)
        result.append({'guid':guid,'unity_material':src,'objects_using_material':sorted(set(gos)),
                       'material_file_found':src is not None})
    result.sort(key=lambda d:(d['unity_material']['name'] if d['unity_material'] else d['guid']))
    out={'schema':'scsp-unity-effect-evidence-v1','project':str(project),'scene':str(scene_abs),
         'material_files':len(mats),'renderer_count':len(refs),'referenced_materials':result,
         'unresolved_material_guids':[x['guid'] for x in result if not x['material_file_found']],
         'warning':'This is source evidence only; material properties do not prove final rendered effect or runtime animation.'}
    if include_animations:
        out['animation_clips']=[animation_info(f) for f in assets.rglob('*.anim')]
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project',required=True,type=Path)
    p.add_argument('--scene',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--no-animations',action='store_true')
    args=p.parse_args()
    result=probe(args.project,args.scene,not args.no_animations)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
    print('Unity evidence report:',args.out,'renderer:',result['renderer_count'],'materials:',len(result['referenced_materials']))

if __name__=='__main__':main()
