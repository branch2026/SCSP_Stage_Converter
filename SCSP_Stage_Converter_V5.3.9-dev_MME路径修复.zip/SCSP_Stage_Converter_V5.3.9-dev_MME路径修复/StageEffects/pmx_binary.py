# -*- coding: utf-8 -*-
"""Conservative PMX2 morph injector; preserves all original geometry and sections.

Morph insertion preserves the original mesh, materials, textures and physics.
The reader also records offsets used by the automatic effect preparation step.
"""
import struct
from dataclasses import dataclass


class PMXError(ValueError):
    pass


def i32(n):
    return struct.pack('<i', n)


class Cursor:
    def __init__(self, data):
        self.d = data
        self.p = 0

    def take(self, n):
        if not isinstance(n, int) or n < 0 or self.p + n > len(self.d):
            raise PMXError('PMX truncated or invalid size at offset %d, need %s' % (self.p, n))
        old = self.p
        self.p += n
        return self.d[old:self.p]

    def num(self, fmt):
        return struct.unpack('<'+fmt, self.take(struct.calcsize('<'+fmt)))[0]

    def count(self, label, max_items=10_000_000):
        n = self.num('i')
        if not 0 <= n <= max_items:
            raise PMXError('%s count invalid: %s' % (label, n))
        return n

    def string(self, enc):
        n = self.count('string length', 8*1024*1024)
        try:
            return self.take(n).decode(enc)
        except UnicodeError as exc:
            raise PMXError('Invalid PMX string at %d' % self.p) from exc


@dataclass
class Material:
    name: str
    english: str
    diffuse: tuple
    faces: int
    start: int
    texture_index: int = -1
    record_at: int = 0
    diffuse_at: int = 0
    sphere_at: int = 0
    sphere_index: int = -1
    sphere_mode: int = 0


class Model:
    def __init__(self, data):
        self.data = data
        c = Cursor(data)
        if c.take(4) != b'PMX ':
            raise PMXError('Not a PMX file')
        self.version = c.num('f')
        if not 1.99 <= self.version <= 2.11:
            raise PMXError('Unsupported PMX version %s' % self.version)
        hsize = c.num('B')
        if hsize != 8:
            raise PMXError('Unexpected PMX global size %s' % hsize)
        flags = c.take(8)
        if flags[0] not in (0,1) or flags[1] > 4 or any(x not in (1,2,4) for x in flags[2:]):
            raise PMXError('Invalid PMX globals')
        self.encoding = ('utf-16-le','utf-8')[flags[0]]
        self.uv_count = flags[1]
        self.vertex_width,self.tex_width,self.mat_width,self.bone_width,self.morph_width,self.rigid_width = flags[2:]
        self.name = c.string(self.encoding)
        self.english = c.string(self.encoding)
        c.string(self.encoding); c.string(self.encoding)
        self.vertex_count = c.count('vertices', 10_000_000)
        self.vertex_offsets = []
        for _ in range(self.vertex_count):
            self.vertex_offsets.append(c.p)
            c.take(32+16*self.uv_count)
            typ=c.num('B')
            if typ == 0: n=self.bone_width
            elif typ == 1: n=2*self.bone_width+4
            elif typ in (2,4): n=4*self.bone_width+16
            elif typ == 3: n=2*self.bone_width+40
            else: raise PMXError('Invalid vertex deform type')
            c.take(n+4)
        self.face_index_start = c.p + 4
        self.face_index_count = c.count('face indices', 120_000_000)
        if self.face_index_count % 3:
            raise PMXError('Face count not divisible by 3')
        c.take(self.face_index_count * self.vertex_width)
        self.texture_table_at = c.p
        self.textures = [c.string(self.encoding) for _ in range(c.count('textures'))]
        self.material_table_at = c.p
        self.materials=[]
        start=0
        for _ in range(c.count('materials')):
            record_at=c.p
            name=c.string(self.encoding); english=c.string(self.encoding)
            diffuse_at=c.p
            diffuse=struct.unpack('<4f',c.take(16))
            c.take(12+4+12+1+16+4)
            texture_index=int.from_bytes(c.take(self.tex_width),'little',signed=True)
            sphere_at = c.p
            sphere_index = int.from_bytes(c.take(self.tex_width),'little',signed=True)
            sphere_mode = c.num('B')
            toon=c.num('B'); c.take(self.tex_width if toon == 0 else 1) if toon in (0,1) else self._bad('toon')
            c.string(self.encoding)
            face_count=c.num('i')
            if face_count < 0 or face_count%3:raise PMXError('Invalid material surface count')
            self.materials.append(Material(name,english,diffuse,face_count,start,texture_index,record_at,diffuse_at,sphere_at,sphere_index,sphere_mode))
            start +=face_count
        if start!=self.face_index_count:
            raise PMXError('Material triangle counts do not cover mesh')
        self.bone_table_at = c.p
        self.bones=[]
        for _ in range(c.count('bones')):
            name=c.string(self.encoding); c.string(self.encoding)
            self.bones.append(name)
            c.take(12+self.bone_width+4)
            flag=c.num('H')
            c.take(self.bone_width if flag & 1 else 12)
            if flag & 0x300:c.take(self.bone_width+4)
            if flag & 0x400:c.take(12)
            if flag & 0x800:c.take(24)
            if flag & 0x2000:c.take(4)
            if flag & 0x20:
                c.take(self.bone_width+4+4)
                for _ in range(c.count('ik links')):
                    c.take(self.bone_width)
                    has_limit=c.num('B')
                    if has_limit not in (0,1):raise PMXError('Invalid IK limit')
                    if has_limit:c.take(24)
        self.morph_begin=c.p
        self.morph_count=c.count('morphs')
        self.morph_names=[]
        self.morph_types=[]
        self.material_morph_indices=[]
        for _ in range(self.morph_count):
            name=c.string(self.encoding); c.string(self.encoding)
            c.take(1)
            typ=c.num('B')
            self.morph_names.append(name);self.morph_types.append(typ)
            n=c.count('morph offsets')
            if typ in (0,9): width=self.morph_width+4
            elif typ==1:width=self.vertex_width+12
            elif typ==2:width=self.bone_width+28
            elif 3<=typ<=7:width=self.vertex_width+16
            elif typ==8:width=self.mat_width+1+112
            elif typ==10:width=self.rigid_width+1+24
            else:raise PMXError('Unsupported morph type %s' % typ)
            if typ==8:
                self.material_morph_indices.extend(range(c.p,c.p+width*n,width))
            c.take(width*n)
        self.morph_end=c.p
        self.display_begin=c.p
        self.display=[]
        for _ in range(c.count('display frames')):
            name=c.string(self.encoding); en=c.string(self.encoding)
            special=c.num('B'); slots=[]
            if special not in (0,1):raise PMXError('Invalid display frame')
            for _ in range(c.count('display entries')):
                kind=c.num('B')
                if kind not in (0,1):raise PMXError('Invalid display entry')
                index=int.from_bytes(c.take(self.morph_width if kind else self.bone_width),'little',signed=True)
                slots.append((kind,index))
            self.display.append((name,en,special,slots))
        self.display_end=c.p
        self.original_tail=c.d[c.p:]
        # At least rigid bodies and joints counts exist. We intentionally keep all tail bytes unchanged.
        if len(self.original_tail)<8:
            raise PMXError('PMX physics tail too short')

    @staticmethod
    def _bad(s):
        raise PMXError('Invalid '+s)

    def face_indices(self,start,count):
        if start < 0 or count<0 or start+count>self.face_index_count:
            raise PMXError('Invalid face slice')
        fmt={1:'B',2:'H',4:'I'}[self.vertex_width]
        offset=self.face_index_start+start*self.vertex_width
        values=struct.unpack_from('<'+str(count)+fmt,self.data,offset) if count else ()
        if any(v>=self.vertex_count for v in values):raise PMXError('Out of range vertex index')
        return values

    def materials_last(self, overlay_indices):
        """Move overlays and their face ranges together in a PMX 2.0 preview."""
        if self.version >= 2.05:
            raise PMXError('Material reordering requires PMX 2.0')
        count = len(self.materials)
        order = [index for index in range(count) if index not in overlay_indices]
        order.extend(index for index in range(count) if index in overlay_indices)
        mapping = {old: new for new, old in enumerate(order)}
        material_ends = [item.record_at for item in self.materials[1:]] + [self.bone_table_at]
        data = bytearray(self.data)
        for at in self.material_morph_indices:
            end = at+self.mat_width
            index = int.from_bytes(data[at:end],'little',signed=True)
            if index != -1:
                if index not in mapping:
                    raise PMXError('Invalid material morph index')
                data[at:end] = self.idx(mapping[index],self.mat_width)
        reordered_faces = []
        reordered_materials = []
        for index in order:
            material = self.materials[index]
            start = self.face_index_start + material.start * self.vertex_width
            end = start + material.faces * self.vertex_width
            reordered_faces.append(data[start:end])
            reordered_materials.append(data[material.record_at:material_ends[index]])
        data[self.face_index_start:self.texture_table_at] = b''.join(reordered_faces)
        data[self.material_table_at+4:self.bone_table_at] = b''.join(reordered_materials)
        return bytes(data), mapping

    def encode_str(self,s):
        raw=str(s).encode(self.encoding)
        return i32(len(raw))+raw

    @staticmethod
    def idx(n,width,signed=True):
        return int(n).to_bytes(width,'little',signed=signed)

    def add_morphs(self, effects):
        if not effects:raise PMXError('No effects to insert')
        if self.morph_count+len(effects)>100000:raise PMXError('Too many morphs')
        facial=next((i for i,(n,e,s,slots) in enumerate(self.display) if s and (e=='Facial' or n=='表情')),None)
        frames=[(n,e,s,list(slots)) for n,e,s,slots in self.display]
        if facial is None:
            frames.append(('表情','Facial',1,[]));facial=len(frames)-1
        new_morph_data=[]
        names=set(self.morph_names)
        for i, fx in enumerate(effects):
            name=fx['name']
            if name in names:raise PMXError('Morph already exists: '+name)
            names.add(name)
            typ=fx['type']
            if typ==8:
                offsets=[]
                for target in fx['targets']:
                    # Backward-compatible legacy form: (material_index, diffuse_delta_rgba).
                    # New material-state morphs carry all 28 PMX material coefficients and
                    # an explicit multiply/add operation.
                    if isinstance(target, dict):
                        m_index = target['index']
                        operation = target['operation']
                        values = target['values']
                        if operation not in (0, 1) or len(values) != 28:
                            raise PMXError('Invalid full material morph target')
                    else:
                        m_index, rgba = target
                        operation = 1
                        values = list(rgba) + [0.0] * 24
                    offsets.append(
                        self.idx(m_index,self.mat_width,signed=True)
                        + bytes([operation])
                        + struct.pack('<28f', *values)
                    )
            elif typ in (3,4,5,6,7):
                offsets=[self.idx(v,self.vertex_width,signed=False)+struct.pack('<4f',*vec) for v,vec in fx['targets']]
            else:raise PMXError('Invalid new morph type')
            new_morph_data.append(self.encode_str(name)+self.encode_str(fx.get('english',name))+bytes([4,typ])+i32(len(offsets))+b''.join(offsets))
            frames[facial][3].append((1,self.morph_count+i))
        blob=i32(self.morph_count+len(effects)) + self.data[self.morph_begin+4:self.morph_end]+b''.join(new_morph_data)
        packed_frames=[i32(len(frames))]
        for name,en,special,slots in frames:
            packed_frames.extend([self.encode_str(name),self.encode_str(en),bytes([special]),i32(len(slots))])
            for typ,index in slots:
                packed_frames.append(bytes([typ])+self.idx(index,self.morph_width if typ else self.bone_width))
        return (self.data[:self.morph_begin]+blob+b''.join(packed_frames)+self.original_tail)
