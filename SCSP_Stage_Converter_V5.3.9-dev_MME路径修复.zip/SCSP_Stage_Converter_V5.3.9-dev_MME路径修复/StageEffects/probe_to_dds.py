"""Run with Blender to convert a Unity six-face vertical EXR strip to an MME cubemap."""
from array import array
from pathlib import Path
from struct import pack
import sys

import bpy


def convert(source, target):
    image = bpy.data.images.load(str(source), check_existing=False)
    width, height = image.size
    if width < 1 or height != 6 * width or width > 1024 or image.channels != 4:
        raise ValueError('Expected a vertical six-face RGBA reflection probe')
    pixels = array('f', [0]) * (width * height * 4)
    image.pixels.foreach_get(pixels)
    # DDS cubemap order follows the exported +X, -X, +Y, -Y, +Z, -Z strip.
    # Blender presents the image scanlines bottom-up.
    out = bytearray(width * height * 4)
    stride = width * 4
    for y in range(height):
        source_start = (height - y - 1) * stride
        for x in range(width):
            start = source_start + x * 4
            rgb = [max(0., value) for value in pixels[start:start + 3]]
            r, g, b = (round(255 * (value / (1 + value)) ** (1 / 2.2)) for value in rgb)
            offset = y * stride + x * 4
            out[offset:offset + 4] = bytes((b,g,r,255))
    header = [124, 0x100F, width, width, stride, 0, 0] + [0] * 11
    header += [32, 0x41, 0, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000]
    header += [0x1008, 0xfe00, 0, 0, 0]
    target.write_bytes(b'DDS ' + pack('<31I', *header) + out)


if __name__ == '__main__':
    source, target = map(Path, sys.argv[sys.argv.index('--') + 1:])
    convert(source, target)
