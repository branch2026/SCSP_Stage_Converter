"""PMX effect-layer and accepted floor adjustments for generated AutoStage copies."""
from collections import defaultdict
from hashlib import sha256
import math
from struct import pack, pack_into, unpack_from

from .pmx_binary import Model, i32


FUTURE_FLOOR = {
    '01_01': 0.0, '01_03': 0.20, '01_04': 0.40, '01_05': 0.60,
    '02_01': 0.80, '02_02': 1.00, '02_03': 1.20,
}
FUTURE_PREFIX = 'M_Stage_001550_01_floor'
FLOOR_LAYOUTS = {
    ('143_Future','143_future'): (
        '143_Future_B',
        'e7a9ec7ae08140728c1c287608652e2a9f614306caca66cbeab906fd6d03c4e0',
        {FUTURE_PREFIX + suffix: dy for suffix,dy in FUTURE_FLOOR.items()},
    ),
    ('182_SuperD','182_superd'): (
        '182_SuperD_floor_decal',
        'c14ca58d7ef58130bba5d39e6f06be49cf8572912e6aec6518d4d49e3a3a9fba',
        {'M_Stage_001930_op_floor01': 0.0, 'M_Stage_001930_transparent_rogo01': 0.2},
    ),
}


def material_vertices(model):
    return [set(model.face_indices(mat.start, mat.faces)) for mat in model.materials]


def floor_layout(model, material_slots):
    """Fingerprint the floor triangles independently of their export order."""
    digest = sha256()
    for slot in material_slots:
        mat = model.materials[slot]
        indices = model.face_indices(mat.start, mat.faces)
        triangles = []
        for start in range(0, len(indices), 3):
            corners = sorted(model.data[model.vertex_offsets[i]:model.vertex_offsets[i]+12]
                             for i in indices[start:start+3])
            triangles.append(b''.join(corners))
        digest.update(i32(len(triangles)))
        for triangle in sorted(triangles):
            digest.update(triangle)
    return digest.hexdigest()


def floor_adjustment(model, scene, root, slots, vertices):
    rule = FLOOR_LAYOUTS.get((root,scene.stem.lower()))
    if rule is None:
        return {}, {'status': 'no_validated_layout'}
    method, expected, layers = rule
    if any(len(slots.get(name, ())) != 1 for name in layers):
        return {}, {'status': 'layout_not_matched', 'reason': '地板材质槽不同'}
    material_slots = {name:slots[name][0] for name in layers}
    fingerprint = floor_layout(model, material_slots.values())
    if fingerprint != expected:
        return {}, {'status': 'layout_not_matched', 'reason': '地板三角面与已验收样本不同', 'fingerprint': fingerprint}
    moves = {material_slots[name]:dy for name,dy in layers.items() if dy}
    touched = {}
    for i, points in enumerate(vertices):
        for vertex in points:
            dy = moves.get(i, 0)
            if vertex in touched and touched[vertex] != dy:
                return {}, {'status': 'layout_not_matched', 'reason': '地板层与其他材质共用顶点'}
            touched[vertex] = dy
    offsets = {vertex: dy for vertex,dy in touched.items() if dy}
    return offsets, {'status':'applied', 'method':method, 'fingerprint':fingerprint,
                     'vertices_moved':len(offsets), 'y_offsets':FUTURE_FLOOR if method=='143_Future_B' else layers,
                     'adjusted_materials':{model.materials[i].name:dy for i,dy in moves.items()}}


def floor_risks(model, vertices):
    """Find horizontal, closely stacked material bounds for inspection."""
    planes = defaultdict(list)
    for mat, points in zip(model.materials, vertices):
        if 'floor' not in mat.name.casefold() or not points:
            continue
        by_height = defaultdict(list)
        for vertex in points:
            x,y,z = unpack_from('<3f', model.data, model.vertex_offsets[vertex])
            if all(math.isfinite(value) for value in (x,y,z)):
                by_height[round(y,3)].append((x,z))
        for height, coords in by_height.items():
            if len(coords) < 3:
                continue
            x,z = zip(*coords)
            bounds = (min(x),max(x),min(z),max(z))
            if bounds[0] < bounds[1] and bounds[2] < bounds[3]:
                planes[height].append((mat.name,bounds))
    found = {}
    heights = sorted(planes)
    for left, height in enumerate(heights):
        for right in range(left, len(heights)):
            gap = round(heights[right]-height,3)
            if gap > 0.03:
                break
            for name,a in planes[height]:
                for other,b in planes[heights[right]]:
                    if name == other:
                        continue
                    pair = tuple(sorted((name,other)))
                    if min(a[1],b[1]) > max(a[0],b[0]) and min(a[3],b[3]) > max(a[2],b[2]):
                        found[pair] = min(gap,found.get(pair,gap))
    return [{'materials':list(pair),'y_gap':gap} for pair,gap in sorted(found.items(),key=lambda p:p[1])[:30]]


def prepare_model(model, layers, moves):
    """Install UV1 subtextures and optional Y offsets with original indices intact."""
    if not layers and not moves:
        return model, {}
    data = bytearray(model.data)
    for vertex,dy in moves.items():
        at = model.vertex_offsets[vertex]+4
        y, = unpack_from('<f',data,at)
        pack_into('<f',data,at,y+dy)
    if not layers:
        return Model(bytes(data)), {}

    added = {}
    uv_by_vertex = {}
    for index, layer in layers.items():
        path, ref, vertices, transform = layer
        if ref not in added:
            added[ref] = (len(model.textures)+len(added),path)
        mat = model.materials[index]
        texture_index = added[ref][0]
        data[mat.sphere_at:mat.sphere_at+model.tex_width] = Model.idx(texture_index,model.tex_width)
        data[mat.sphere_at+model.tex_width] = 3
        for vertex in vertices:
            uv_by_vertex[vertex] = transform

    data[10] = 1  # Additional UV channel count, previously verified as zero.
    chunks = [data[:model.vertex_offsets[0]]]
    neutral = bytes(16)
    for i, at in enumerate(model.vertex_offsets):
        end = model.vertex_offsets[i+1] if i+1 < model.vertex_count else model.face_index_start-4
        chunks.append(data[at:at+32])
        if i in uv_by_vertex:
            sx,sy,tx,ty = uv_by_vertex[i]
            u,v = unpack_from('<2f',data,at+24)
            chunks.append(pack('<4f',u*sx+tx,1-((1-v)*sy+ty),0,0))
        else:
            chunks.append(neutral)
        chunks.append(data[at+32:end])
    chunks.extend((data[model.face_index_start-4:model.texture_table_at],
                   i32(len(model.textures)+len(added))))
    table_end = model.texture_table_at+4+sum(len(model.encode_str(ref)) for ref in model.textures)
    chunks.append(data[model.texture_table_at+4:table_end])
    chunks.extend(model.encode_str(ref) for ref in added)
    chunks.append(data[table_end:])
    prepared = Model(b''.join(chunks))
    assert prepared.face_index_count==model.face_index_count and prepared.morph_names==model.morph_names
    return prepared, {ref:path for ref,(_,path) in added.items()}
