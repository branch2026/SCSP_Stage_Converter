"""Translate Unity Timeline activation and AnimationClip visibility to PMX."""
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from functools import lru_cache
from pathlib import Path
import re

from .activation_curves import active_curves, clip_visibility_keys, frame_at
from .unity_effect_probe import YAML_BLOCK, guid_of, yaml_name


def field(block, name):
    match = re.search(r'^  ' + name + r':[ \t]*(.*)$', block, re.M)
    return match[1].strip() if match else ''


def reference(text):
    fileid = re.search(r'fileID: (-?\d+)', text)
    guid = re.search(r'guid: ([a-fA-F0-9]{32})', text)
    return (fileid[1] if fileid else '', guid[1].lower() if guid else '')


def array(block, name):
    match = re.search(r'^  ' + name + r': *\n((?:  -[^\n]*\n| {3,}[^\n]*\n)+)', block, re.M)
    return match[1] if match else ''


def activation_keys(intervals, frames):
    ranges = [(max(0, frame_at(a)), min(frames+1, frame_at(b))) for a,b in intervals]
    ranges = [(a,b) for a,b in ranges if a < b]
    if not ranges:
        return []
    samples = {0, frames}
    for start, end in ranges:
        for boundary in (start, end):
            samples.update(f for f in (boundary-1, boundary) if 0 <= f <= frames)
    return [[f, int(not any(a <= f < b for a,b in ranges))] for f in sorted(samples)]


def track_clips(block):
    return [re.sub(r'^  ', '', clip, flags=re.M)
            for clip in re.split(r'^  - m_Version:.*$',array(block,'m_Clips'),flags=re.M)[1:]]


def visibility_timing(clip, playable, source):
    start = Decimal(field(clip,'m_Start'))
    duration = Decimal(field(clip,'m_Duration'))
    clip_in = Decimal(field(clip,'m_ClipIn') or '0')
    speed = Decimal(field(clip,'m_TimeScale') or '1')
    ease = [Decimal(field(clip,name) or '0') for name in
            ('m_EaseInDuration','m_EaseOutDuration','m_BlendInDuration','m_BlendOutDuration')]
    pre = field(clip,'m_PreExtrapolationMode') or '0'
    post = field(clip,'m_PostExtrapolationMode') or '0'
    source_loops = bool(re.search(r'^    m_LoopTime: *1[ \t]*$',source,re.M))
    mode = field(playable,'m_Loop')
    if (not all(number.is_finite() for number in (start,duration,clip_in,speed,*ease)) or
            start<0 or duration<=0 or clip_in<0 or speed<=0 or any(value>0 for value in ease) or
            pre not in ('0','1') or post not in ('0','1') or
            (mode!='2' and (mode!='0' or source_loops))):
        raise InvalidOperation
    return dict(start=start,duration=duration,clip_in=clip_in,speed=speed,
                before_hold=pre=='1',after_hold=post=='1')


def timeline_visibility(assets, scene, model, material_rows, slots, frames, root_name, *, external_pairs=None):
    @lru_cache(maxsize=None)
    def documents(path):
        return {fileid: (kind, block) for kind,fileid,block in
                YAML_BLOCK.findall(path.read_text('utf-8-sig', errors='replace'))}

    scene_docs = documents(Path(scene))
    objects = {key: block for key,(kind,block) in scene_docs.items() if kind == '1'}
    root_ids = {key for key, block in objects.items() if yaml_name(block) == root_name}
    transforms = {key: block for key,(kind,block) in scene_docs.items() if kind in ('4','224')}
    transform_go = {key: reference(field(block,'m_GameObject'))[0] for key,block in transforms.items()}
    parent = {transform_go[key]: transform_go.get(reference(field(block,'m_Father'))[0], '')
              for key,block in transforms.items()}
    materials = {row['guid']: row['unity_material'] for row in material_rows if row['unity_material']}
    material_names = Counter(Path(mat['path']).stem for mat in materials.values())
    use = defaultdict(set)
    renderer_rows = []
    for key,(kind,block) in scene_docs.items():
        if kind in ('23','137','199'):
            go,_ = reference(field(block,'m_GameObject'))
            renderer_rows.append((go,kind,block))
            for entry in re.findall(r'^  - (\{[^\n]+\})', array(block,'m_Materials'), re.M):
                _,guid = reference(entry)
                if guid:
                    use[guid].add(go)

    @lru_cache(maxsize=None)
    def ancestors(go):
        lineage = []
        while go and go not in lineage:
            lineage.append(go)
            go = parent.get(go,'')
        return frozenset(lineage)

    directors = [block for kind,block in scene_docs.values()
                 if kind == '320' and field(block,'m_Enabled') == '1']
    if not directors:
        return [], []
    asset_paths = {guid: path for suffix in ('*.asset','*.playable','*.anim') for path in assets.rglob(suffix)
                   if (guid := guid_of(path))}

    def asset(ref, local=None):
        fileid,guid = ref
        path = asset_paths.get(guid) if guid else local
        return (path, documents(path).get(fileid, ('',''))[1]) if path else (None,'')

    def belongs_to_timeline(track_path, track, timeline_path, timeline_id):
        visited = set()
        while track:
            parent_ref = reference(field(track,'m_Parent'))
            path, block = asset(parent_ref, track_path)
            identity = (path, parent_ref[0])
            if identity == (timeline_path, timeline_id):
                return bool(array(block,'m_Tracks'))
            if identity in visited or field(block,'m_Muted') != '0':
                return False
            visited.add(identity)
            track_path,track = path,block
        return False

    children = defaultdict(list)
    for go,pid in parent.items():
        children[pid,yaml_name(objects.get(go,''))].append(go)

    def find_object(go, path):
        if not path:
            return go
        for part in path.split('/'):
            matches = children[go,part]
            if len(matches)!=1:
                return None
            go = matches[0]
        return go

    candidates = []
    report = []
    for director in directors:
        timeline_ref = reference(field(director,'m_PlayableAsset'))
        timeline_path,timeline = asset(timeline_ref)
        if not timeline or field(director,'m_InitialTime') != '0':
            continue
        bindings = array(director,'m_SceneBindings')
        for track_text,object_text in re.findall(r'^  - key: (\{[^\n]+\})\n    value: (\{[^\n]+\})',bindings,re.M):
            track_ref = reference(track_text)
            track_path,track = asset(track_ref,timeline_path)
            if not track or field(track,'m_Muted') != '0':
                continue
            fileid,guid = reference(object_text)
            if guid:
                continue
            track_info = dict(track=str(track_path.relative_to(assets)),track_file_id=track_ref[0])
            bound = belongs_to_timeline(track_path,track,timeline_path,timeline_ref[0])
            clips = track_clips(track)
            if field(track,'m_PostPlaybackState') and fileid in objects:
                item = dict(track_info,source_type='activation_track')
                intervals = []
                for clip in clips:
                    _,playable = asset(reference(field(clip,'m_Asset')),track_path)
                    try:
                        start = Decimal(field(clip,'m_Start'))
                        duration = Decimal(field(clip,'m_Duration'))
                        if (yaml_name(playable) != 'ActivationPlayableAsset' or
                                not start.is_finite() or not duration.is_finite() or start < 0 or duration <= 0):
                            raise InvalidOperation
                    except InvalidOperation:
                        intervals = []
                        break
                    intervals.append((start,start+duration))
                keys = activation_keys(intervals,frames)
                item['active_intervals_seconds'] = [[float(a),float(b)] for a,b in intervals]
                candidates.append((fileid,keys,item,bound))
                continue
            kind,component = scene_docs.get(fileid,('',''))
            if kind != '95':
                continue
            bind_go,_ = reference(field(component,'m_GameObject'))
            if bind_go not in objects:
                continue
            for clip in clips:
                playable_path,playable = asset(reference(field(clip,'m_Asset')),track_path)
                if yaml_name(playable) != 'AnimationPlayableAsset':
                    continue
                clip_path,source = asset(reference(field(playable,'m_Clip')),playable_path)
                if not source:
                    continue
                for path,curve in active_curves(array(source,'m_FloatCurves')):
                    item = dict(track_info,source_type='animation_clip',
                                animation=str(clip_path.relative_to(assets)),object_path=path,
                                source_keys=[[float(time),int(value)] for time,value in curve])
                    go = find_object(bind_go,path)
                    if go is None:
                        report.append(dict(item,reason='Animator 下的物件路径缺失或不唯一'))
                        continue
                    keys = []
                    if len(clips)==1 and curve:
                        try:
                            timing = visibility_timing(clip,playable,source)
                            keys = clip_visibility_keys(curve,frames,**timing,
                                                        initial_active=field(objects[go],'m_IsActive')=='1')
                            item.update(start_seconds=float(timing['start']), duration_seconds=float(timing['duration']),
                                        clip_in_seconds=float(timing['clip_in']), time_scale=float(timing['speed']))
                        except InvalidOperation:
                            pass
                    candidates.append((go,keys,item,bound))

    if external_pairs is not None and len(root_ids)==1:
        by_parent = defaultdict(list)
        for go,keys,item,bound in candidates:
            if (bound and keys and item['source_type']=='animation_clip' and
                    len({weight for _,weight in keys})==2 and parent.get(go) and
                    not root_ids & ancestors(go) and
                    all(field(objects.get(a,''),'m_IsActive')=='1' for a in ancestors(go)-{go}) and
                    sum(1 for other,_,_,verified in candidates
                        if verified and (other in ancestors(go) or go in ancestors(other)))==1):
                changes = tuple((frame,weight) for i,(frame,weight) in enumerate(keys)
                                if i==0 or weight!=keys[i-1][1])
                group = (parent[go],item['track'],item['track_file_id'],item['animation'])
                by_parent[group].append((go,keys,item,changes))
        for siblings in by_parent.values():
            if len(siblings)==2:
                left,right = siblings
                if left[3] == tuple((frame,1-weight) for frame,weight in right[3]):
                    external_pairs.append((left[:3],right[:3]))

    effects = []
    for go,keys,item,bound in candidates:
        item.update(object=yaml_name(objects[go]),file_id=go)
        report.append(item)
        reason = None
        if len(root_ids) != 1 or not root_ids <= ancestors(go):
            reason = '绑定物件位于导出根对象之外，或根对象不唯一'
        elif any(field(objects.get(a,''),'m_IsActive') != '1' for a in ancestors(go)-{go}):
            reason = '祖先物件静态禁用'
        elif not bound:
            reason = '无法确认轨道所属 Timeline，或父轨道已静音'
        elif sum(1 for other,_,_,verified in candidates
                 if verified and (other in ancestors(go) or go in ancestors(other))) > 1:
            reason = '绑定物件及其层级存在重叠的可见性控制'
        elif not keys:
            reason = ('不支持该片段的曲线、循环、混合或多片段编排' if item['source_type']=='animation_clip'
                      else '没有可映射到预览范围的激活片段')
        elif item['source_type']=='animation_clip' and len({weight for _,weight in keys})==1:
            reason = '预览范围内没有显隐状态切换'
        if reason:
            item['reason'] = reason
            continue

        subtree_renderers = [(user,kind,block) for user,kind,block in renderer_rows if go in ancestors(user)]
        if any(kind != '23' or field(block,'m_Enabled') != '1' or
               any(field(objects.get(a,''),'m_IsActive') != '1' for a in ancestors(user)-ancestors(go))
               or not array(block,'m_Materials')
               for user,kind,block in subtree_renderers):
            item['reason'] = '子树含禁用物件、无材质或当前无法映射的渲染器'
            continue
        indices = []
        for guid, users in use.items():
            if not any(go in ancestors(user) for user in users):
                continue
            mat = materials.get(guid)
            name = Path(mat['path']).stem if mat else ''
            choices = slots.get(name, [])
            if (any(go not in ancestors(user) for user in users) or material_names[name] != 1 or
                    len(choices) != 1 or not model.materials[choices[0]].faces or
                    model.materials[choices[0]].diffuse[3] <= 0):
                indices = []
                break
            indices.append(choices[0])
        if not indices:
            item['reason'] = '找不到完整独占的 PMX 材质槽，或材质已透明'
            continue
        item.update(status='generated', material_indices=sorted(indices))
        effects.append(dict(type='material_alpha', name=f'Hide{len(effects)+1:04d}',
                            material_indices=sorted(indices), target_alpha=0, keys=keys,
                            provenance='unity-verified', unity_evidence=item))
    return effects, report
