"""Restore Timeline-linked fountain renderers outside the exported stage root."""
from functools import lru_cache
from math import cos, radians, sin
import re

from SceneBuilder.rebuild_stage_blender import parse_mesh, parse_scene, vec
from .external_lights import local_matrix, material_record, mesh_records, multiply, texture_transform
from .pmx_binary import Model, i32
from .unity_effect_probe import FLOAT_LINE, material_info


def sampler(name, resource):
    return f'''texture {name}Tex {resource};
sampler2D {name}Sampler = sampler_state {{
    Texture = <{name}Tex>; MinFilter = Linear; MagFilter = Linear; MipFilter = Linear;
    AddressU = Wrap; AddressV = Wrap;
}};
'''


def fountain_shader(kind, cue, source, props, layers, scale):
    def value(key, default=0):
        return props.get(key, default)

    def sample(name, coordinate='input.uv'):
        scales, _ = layers[name]
        sx,sy,ox,oy = scales
        angle = radians(value('_'+name+'Rotate'))
        speed = (value('_'+name+'AutoScrollX'),value('_'+name+'AutoScrollY'))
        if kind=='fountain_light':
            speed = (value('_SpeedM'),value('_SpeedMY'))
        uv = (f'LayerUV({coordinate}, float4({sx:.8f}, {sy:.8f}, {ox:.8f}, {oy:.8f}), '
              f'float2({cos(angle):.8f}, {sin(angle):.8f}), float2({speed[0]:.8f}, {speed[1]:.8f}), elapsed)')
        return f'tex2D({name}Sampler, {uv})'

    tint = vec(source,'_Color',tuple('rgba'),(1,1,1,1))
    if kind in ('fountain_flow','fountain_wave','fountain_column') and not value('_ColorSwitch'):
        tint = (1,1,1,1)
    color = ', '.join(f'{x:.8f}' for x in tint)
    extra,body,deform = '',[],''
    if 'Sub' in layers:
        body.append(f'    float4 detail = {sample("Sub")};')
        body.append(f'    float2 warped = input.uv + (detail.rg - 0.5) * {value("_DistortAmount"):.8f};')
    body.append(f'    float4 main = {sample("Main","warped" if "Sub" in layers else "input.uv")};')
    if kind=='fountain_body':
        body.append(f'    return float4(main.rgb * float3({", ".join(f"{x:.8f}" for x in tint[:3])}), 1);')
        blend = 'AlphaBlendEnable = false; ZWriteEnable = true;'
    elif kind=='fountain_light':
        body.append(f'    return float4(main.rgb * float4({color}).rgb * {value("_Intensity",1):.8f} * main.a, 0);')
        blend = 'AlphaBlendEnable = true; SrcBlend = ONE; DestBlend = ONE; ZWriteEnable = false;'
    else:
        body.append(f'    float4 color = main * float4({color});')
        if kind in ('fountain_flow','fountain_column'):
            body.append(f'    color.a = saturate(main.a * {value("_MainAlpha",1):.8f} + detail.a * {value("_SubAlpha",1):.8f});')
            body.append(f'    color.rgb = saturate((main.rgb * {value("_MainAlpha",1):.8f} + detail.rgb * {value("_SubAlpha",1):.8f}) * float4({color}).rgb);')
            if kind=='fountain_column':
                body.append(f'    float mask = lerp(1.0, {sample("Mask")}.r, {value("_MaskAlpha",1):.8f});')
                body.append(f'    float edge = pow(1.0 - saturate(abs(dot(normalize(input.normal), normalize(input.toCamera)))), {value("_Pow",1):.8f});')
                body.append('    color.a *= mask * edge;')
                wavelength = max(0.001,value('_Wlen',1)*scale)
                deform = f'''    float phase = input.pos.y * {6.283185307/wavelength:.8f} - max(0, Seconds - {cue:.8f}) * 6.28318531;
    input.pos.xz += input.normal.xz * (sin(phase) * {value('_Wstr')*scale:.8f});
'''
            src = 'SRCALPHA'
        else:
            body.append(f'    color *= lerp(float4(1,1,1,1), detail, {value("_SubAlpha",1):.8f});')
            body.append(f'    color *= {sample("Mask")}.r * {value("_MaskAlpha",1):.8f} * {value("_MainAlpha",1):.8f};')
            src = 'INVDESTCOLOR'
        body.append(f'    return color * float4(1, 1, 1, {value("_Alpha",1):.8f});')
        blend = f'AlphaBlendEnable = true; SrcBlend = {src}; DestBlend = ONE; ZWriteEnable = false;'
    for name,(_,resource) in layers.items():
        extra += sampler(name, ': MATERIALTEXTURE' if name=='Main' else
                         f'< string ResourceName = "{resource}"; >')
    return f'''float Seconds : TIME < bool SyncInEditMode = true; >;
float4x4 Transform : WORLDVIEWPROJECTION;
float4x4 World : WORLD;
float3 Eye : CAMERAPOSITION;
{extra}
struct Vertex {{ float4 pos : POSITION0; float3 normal : NORMAL0; float2 uv : TEXCOORD0; }};
struct Surface {{ float4 pos : POSITION0; float2 uv : TEXCOORD0; float3 normal : TEXCOORD1; float3 toCamera : TEXCOORD2; }};
Surface FountainVS(Vertex input) {{
    Surface result;
{deform}    result.pos = mul(input.pos, Transform);
    result.uv = input.uv;
    result.normal = mul(float4(input.normal, 0), World).xyz;
    result.toCamera = Eye - mul(input.pos, World).xyz;
    return result;
}}
float2 LayerUV(float2 uv, float4 st, float2 angle, float2 speed, float elapsed) {{
    float2 p = float2(uv.x, 1.0 - uv.y) - 0.5;
    p = float2(p.x * angle.x - p.y * angle.y, p.x * angle.y + p.y * angle.x);
    p = (p + 0.5) * st.xy + st.zw + speed * elapsed;
    return float2(p.x, 1.0 - p.y);
}}
float4 FountainPS(Surface input) : COLOR0 {{
    float elapsed = Seconds - {cue:.8f};
    clip(elapsed);
{chr(10).join(body)}
}}
''' + ''.join(f'''
technique {name} < string MMDPass = "{tag}"; bool UseTexture = true; > {{
    pass P {{
        VertexShader = compile vs_3_0 FountainVS();
        PixelShader = compile ps_3_0 FountainPS();
        {blend}
        CullMode = NONE; ZEnable = true;
    }}
}}
''' for name,tag in (('Fountain','object'),('FountainSS','object_ss')))


def append_fountains(model, scene, assets, schedule, scale):
    empty = model,{},[]
    if scene is None or schedule is None or not schedule.effect_events or not model.vertex_offsets or not model.bones:
        return empty
    source = scene.read_text('utf-8-sig',errors='replace')
    if not re.search(r'^  m_Name: (?:waterfountain|fountain)\s*$',source,re.M|re.I):
        return empty
    objects,transforms,by_go,children,by_tid,_,filters,renderers,paths = parse_scene(scene,assets or scene.parent)
    roles = {'fountain_body':0,'fountain_column':1,'fountain_flow':2,'fountain_wave':3,'fountain_light':4}
    present = {slot.name for slot in model.materials}

    @lru_cache(maxsize=None)
    def material(guid):
        path = paths[guid]
        info = material_info(path)
        shader = paths[info['shader_guid']].read_text('utf-8-sig',errors='replace')
        name = re.search(r'^\s*Shader\s+"([^"]+)"',shader,re.M)[1]
        source = path.read_text('utf-8-sig',errors='replace')
        props = {k:float(v) for k,v in FLOAT_LINE.findall(source)}
        if name=='Custom/AllinOne(ParticleSystem)' and (props.get('_BlendDst'),props.get('_ZWriteMode'),
                props.get('_UVSwitch'),props.get('_DistortSwitch'),props.get('_SubSwitch'))==(1,0,1,1,1):
            if (props.get('_BlendSrc'),props.get('_MaskSwitch'))==(5,0):
                role,channels = 'fountain_flow',('Main','Sub')
            elif (props.get('_BlendSrc'),props.get('_MaskSwitch'))==(4,1):
                role,channels = 'fountain_wave',('Main','Sub','Mask')
            elif (props.get('_BlendSrc'),props.get('_MaskSwitch'),props.get('_FresnelSwitch'),
                  props.get('_WaveSwitch'))==(5,1,1,1) and props.get('_Pow',0)>0:
                role,channels = 'fountain_column',('Main','Sub','Mask')
            else:
                raise ValueError('不支持该喷泉水面混合方式')
        elif name=='Giken/3d/Texture_Cubemap' and (props.get('_Surface'),props.get('_ZWrite'))==(0,1):
            role,channels = 'fountain_body',('Main',)
        elif name=='Giken/3d/Texture_Add_Scroll_LightAdjust' and props.get('_ZWrite')==0:
            role,channels = 'fountain_light',('Main',)
        else:
            raise ValueError('不支持该喷泉材质')
        files,layers = {},{}
        for channel in channels:
            slot = '_'+channel+'Tex'
            texture_id = info['textures'][slot]
            texture = paths[texture_id]
            if not texture.is_file() or texture.suffix.lower() not in ('.png','.jpg','.jpeg','.bmp','.tga'):
                raise ValueError('喷泉贴图缺失或格式无效')
            ref = 'textures/AutoStageFountain/'+texture_id+texture.suffix.lower()
            files[ref] = texture
            layers[channel] = texture_transform(source,slot),ref if channel!='Main' else channel
            if channel=='Main':
                main = ref
        return role,info,source,props,files,layers,main

    @lru_cache(maxsize=None)
    def geometry(guid):
        path = paths[guid]
        if path.suffix.lower()!='.asset':
            raise ValueError('喷泉网格不是独立资源')
        return parse_mesh(path)

    vertices,faces,materials,rows = [],[],[],[]
    textures,files = {},{}
    for go,obj in objects.items():
        if obj['name'].casefold() not in ('waterfountain','fountain') or go not in by_go:
            continue
        tid = by_go[go]['id']
        ancestors,cues = [],[]
        cursor = tid
        while cursor in transforms and cursor not in ancestors and objects[by_tid[cursor]]['active']:
            ancestors.append(cursor)
            cues.extend(schedule.effect_events.get(objects[by_tid[cursor]]['name'],()))
            cursor = transforms[cursor]['father']
        if cursor or len({event['time'] for event in cues})!=1:
            continue
        world = local_matrix(transforms[ancestors[-1]])
        for parent in reversed(ancestors[:-1]):
            world = multiply(world,local_matrix(transforms[parent]))
        todo,pending = [(tid,world)],[]
        visited = set()
        # Decode and validate the whole branch before changing PMX offsets.
        try:
            while todo:
                current,matrix = todo.pop()
                item = by_tid[current]
                if current in visited:
                    raise ValueError('喷泉层级循环')
                visited.add(current)
                if not objects[item]['active']:
                    continue
                todo.extend((node,multiply(matrix,local_matrix(transforms[node])))
                            for node in children.get(current,()))
                enabled = [r for r in renderers.get(item,()) if r['enabled']]
                if not enabled:
                    continue
                if len(enabled)!=1 or len(enabled[0]['materials'])!=1 or len(filters.get(item,()))!=1:
                    raise ValueError('喷泉网格与材质无法一一对应')
                guid = enabled[0]['materials'][0]['guid']
                role,info,source,props,maps,layers,main = material(guid)
                if info['name'] in present:
                    raise ValueError('舞台已含对应的喷泉材质')
                mesh = geometry(filters[item][0]['mesh']['guid'])
                records,indices = mesh_records(mesh,matrix,scale,(1,1,0,0))
                cue = cues[0]['time']
                code = fountain_shader(role,cue,source,props,layers,scale)
                pending.append((role,info,item,main,maps,records,indices,code))
        except (KeyError, IndexError, OSError, ValueError, TypeError, OverflowError):
            continue
        if not {'fountain_body','fountain_column','fountain_flow','fountain_wave'} <= {row[0] for row in pending}:
            continue
        new_textures = {row[3] for row in pending} - set(textures)
        if (new_textures & set(model.textures) or
                len(model.textures)+len(textures)+len(new_textures)>2**(8*model.tex_width-1) or
                len(model.materials)+len(materials)+len(pending)>2**(8*model.mat_width-1) or
                model.vertex_count+len(vertices)+sum(len(row[5]) for row in pending)>2**(8*model.vertex_width)):
            continue
        for role,info,item,main,maps,records,indices,code in sorted(pending,key=lambda row:(roles[row[0]],row[2])):
            files.update(maps)
            if main not in textures:
                textures[main] = len(model.textures)+len(textures)
            name = 'AutoFountain_'+str(item)
            base = model.vertex_count+len(vertices)
            vertices.extend(record+bytes(16*model.uv_count)+b'\0'+Model.idx(0,model.bone_width)+bytes(4)
                            for record in records)
            faces.extend(Model.idx(base+i,model.vertex_width,signed=False) for i in indices)
            materials.append(material_record(model,name,(1,1,1,1),textures[main],len(indices)))
            rows.append(dict(material_index=len(model.materials)+len(rows), material=name, mode=role,
                             source_object=objects[item]['name'],source_object_id=item,source_material=info['name'],
                             vertex_count=len(records), cue_seconds=cues[0]['time'], marker=cues[0]['asset'],
                             fx_code=code))
    if not rows:
        return empty
    data = model.data
    v = model.vertex_offsets[0]
    f = model.face_index_start-4
    t,m,b = model.texture_table_at,model.material_table_at,model.bone_table_at
    payload = b''.join((data[:v-4],i32(model.vertex_count+len(vertices)),data[v:f],b''.join(vertices),
                       i32(model.face_index_count+len(faces)),data[f+4:t],b''.join(faces),
                       i32(len(model.textures)+len(textures)),data[t+4:m],
                       b''.join(model.encode_str(ref) for ref in textures),i32(len(model.materials)+len(rows)),
                       data[m+4:b],b''.join(materials),data[b:]))
    return Model(payload),files,rows

