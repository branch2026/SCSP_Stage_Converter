"""Generate PMX stage effects from Unity material and animation evidence."""
import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import re

from .cri_movie_timeline import movie_timeline
from .external_lights import append_lights
from .floor_shadows import disable_floor_shadows, karma_floor_overlay
from .light_timeline import read_light_timeline
from .mme_reflection import stage_probe
from .mme_preview import MAP_SLOTS, build_mme_preview
from .movie_surface_fallback import restore_movie_surfaces
from .output_staging import staging_directory
from .pmx_binary import Model
from .prepare_model import floor_adjustment, floor_risks, material_vertices, prepare_model
from .scene_lighting import scene_lights
from .screen_sources import screen_preview, screen_sources
from .stage_effects import build_effect_package, check_dependencies
from .timeline_visibility import timeline_visibility
from .unity_effect_probe import guid_of, probe


def phase_keys(speed, frames):
    """Retain both samples across each wrap and interpolate linearly between wraps."""
    speed = abs(speed)
    keep = {0, frames}
    previous = 0
    for frame in range(1, frames + 1):
        cycle = math.floor(frame * speed / 30)
        if cycle != previous:
            keep.update((frame - 1, frame))
        previous = cycle
    return [[i, (i * speed / 30) % 1] for i in sorted(keep)]


def light_transform(material_path):
    text = Path(material_path).read_text('utf-8-sig',errors='replace')
    block = re.search(r'^([ \t]*)_LightTex:[ \t]*\n((?:\1[ \t]+[^\n]*\n)+)',text,re.M)
    if not block:
        return None
    numbers = []
    for field in ('m_Scale','m_Offset'):
        match = re.search(field+r': *\{x: ([^,]+), y: ([^}]+)\}',block[2])
        if not match:
            return None
        try:
            numbers.extend(float(value) for value in match.groups())
        except ValueError:
            return None
    return tuple(numbers) if all(math.isfinite(value) and abs(value)<=10000 for value in numbers) else None


def scroll_effects(index, speeds, frames, evidence, *, secondary=False):
    result = []
    for axis,speed in enumerate(speeds):
        if not speed:
            continue
        prefix = 'LT' if secondary else 'UV'
        offset = [0,0]
        offset[axis] = (1 if speed > 0 else -1) * (1 if axis == 0 else -1)
        result.append(dict(type='uv_offset', name=f'{prefix}{index:04d}{"XY"[axis]}',
            uv_channel=int(secondary), material_indices=[index], offset=offset, keys=phase_keys(speed,frames),
            provenance='unity-verified', unity_evidence=dict(evidence,
                parameter=(('_SpeedL','_SpeedLY') if secondary else ('_SpeedM','_SpeedMY'))[axis],speed=speed)))
    return result


def restore(project, scene, pmx, output, frames=5400, *, root_name=None, scale=12.5, mme_preview=False,
            blender=None, floor_cleanup=False, floor_only=False):
    output, pmx = Path(output), Path(pmx)
    if output.exists():
        raise FileExistsError(output)
    if not isinstance(frames, int) or not 1 <= frames <= 108000:
        raise ValueError('Preview duration must be between 1 and 108000 frames')
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('PMX export scale must be positive and finite')
    assets = Path(project).resolve() / 'Assets'
    evidence = probe(project, scene)
    exported_scene = Path(evidence['scene'])
    shaders = {guid_of(p): p for p in assets.rglob('*.shader')}
    model = Model(pmx.read_bytes())
    slots = defaultdict(list)
    for index, mat in enumerate(model.materials):
        slots[mat.name].append(index)
    referenced = [row['unity_material'] for row in evidence['referenced_materials'] if row['unity_material']]
    if floor_only:
        return restore_floor_only(model,pmx,output,exported_scene,root_name,referenced,shaders,scale)
    light_schedule = read_light_timeline(assets, exported_scene) if mme_preview else None
    light_programs = {}
    lights = scene_lights(exported_scene, scale, schedule=light_schedule, frames=frames, programs=light_programs)
    names = Counter(m['name'] for m in referenced)
    effects, light_effects, skipped, light_textures = [], [], [], []
    layers = {}
    vertices = material_vertices(model)
    # A UV morph moves every face sharing its vertices.
    owners = {}
    shared = set()
    for index, points in enumerate(vertices):
        for vertex in points:
            if owners.setdefault(vertex, index) != index:
                shared.update((index, owners[vertex]))
    textures = {}
    audited_slots = ('_MainTex','_LightTex','_EmissionMap','_MaskTex','_SubTex')
    texture_slots = audited_slots + MAP_SLOTS if mme_preview else audited_slots
    wanted = {m['textures'].get(key) for m in referenced for key in texture_slots}
    for meta in assets.rglob('*.meta'):
        if meta.suffixes[-2:-1] and meta.suffixes[-2].lower() in ('.png','.tga','.jpg','.jpeg','.dds','.psd','.tif','.bmp','.exr'):
            path = meta.with_suffix('')
            guid = guid_of(path)
            if guid in wanted:
                textures[guid] = path
    for mat in referenced:
        name = mat['name']
        props = mat['floats']
        speeds = (props.get('_SpeedM',0), props.get('_SpeedMY',0))
        light_speeds = (props.get('_SpeedL',0), props.get('_SpeedLY',0))
        if not any((*speeds,*light_speeds)):
            continue
        shader = shaders.get(mat['shader_guid'])
        shader_text = shader.read_text('utf-8-sig', errors='replace') if shader else ''
        main_guid = mat['textures'].get('_MainTex')
        source_tex = textures.get(main_guid)
        candidates = slots[name]
        reason = None
        if names[name] != 1 or len(candidates) != 1:
            reason = '舞台 PMX 中缺少唯一同名材质'
        else:
            index = candidates[0]
            tex = model.materials[index].texture_index
            if index in shared or not vertices[index]:
                reason = '材质与其他面共用顶点或没有面'
            elif (source_tex is None or not 0 <= tex < len(model.textures) or not
                  re.fullmatch(re.escape(source_tex.stem) + r'(?:_[0-9a-f]{8})?',Path(model.textures[tex]).stem,re.I)):
                reason = 'PMX 主纹理与 Unity 主纹理无法对应'
        if reason:
            if any(speeds):
                skipped.append([name,reason])
            if any(light_speeds):
                light_textures.append(dict(material=name,status='skipped',reason=reason))
            continue
        origin = dict(material_guid=mat['guid'],shader=str(shader.relative_to(assets)),
                      material=name,main_texture=str(source_tex.relative_to(assets)))
        if any(speeds):
            if any(speed and label not in shader_text for speed,label in zip(speeds, ('"UV X Speed Main"','"UV Y Speed Main"'))):
                skipped.append([name,'源着色器未声明对应的主纹理滚动参数'])
            else:
                effects.extend(scroll_effects(index,speeds,frames,origin))
        if not any(light_speeds):
            continue
        light_guid = mat['textures'].get('_LightTex')
        texture = textures.get(light_guid)
        transform = light_transform(mat['path'])
        item = dict(material=name,texture_guid=light_guid)
        light_textures.append(item)
        if any(speed and label not in shader_text for speed,label in zip(light_speeds, ('"UV X Speed Light"','"UV Y Speed Light"'))):
            reason = '源着色器未声明对应的光照纹理滚动参数'
        elif model.uv_count or model.materials[index].sphere_mode or model.materials[index].sphere_index >= 0:
            reason = 'PMX 已使用追加 UV 或球贴图'
        elif texture is None or not texture.is_file():
            reason = '光照贴图源文件缺失'
        elif texture.suffix.lower() not in ('.png','.jpg','.jpeg','.tga','.bmp'):
            reason = '光照贴图格式暂不支持'
        elif transform is None:
            reason = '无法读取光照贴图的缩放与偏移'
        else:
            ref = 'textures/AutoStageLight/'+light_guid+texture.suffix.lower()
            known = {row[1] for row in layers.values()}
            max_index = 2**(8*model.tex_width-1)-1
            if ref in model.textures or (ref not in known and len(model.textures)+len(known)>max_index):
                reason = 'PMX 纹理表索引空间不足或新增路径冲突'
        if reason:
            item.update(status='skipped',reason=reason)
            continue
        item.update(status='generated',source=str(texture.relative_to(assets)),texture_ref=ref,
                    uv_scale=list(transform[:2]),uv_offset=list(transform[2:]),
                    intensity=props.get('_Intensity',1),blend_approximation='PMX subtexture')
        layers[index] = (texture,ref,vertices[index],transform)
        light_effects.extend(scroll_effects(index,light_speeds,frames,dict(origin,light_texture=item),secondary=True))
    light_binding = {row['material']:row for row in light_textures if row['status']=='generated'}
    texture_rows = []
    for mat in referenced:
        name = mat['name']
        if names[name]!=1 or len(slots.get(name,[]))!=1:
            continue
        index = slots[name][0]
        texture_index = model.materials[index].texture_index
        pmx_ref = model.textures[texture_index] if 0<=texture_index<len(model.textures) else ''
        for prop in audited_slots:
            guid = mat['textures'].get(prop)
            if not guid:
                continue
            source = textures.get(guid)
            present = source is not None and source.is_file()
            if not present:
                status = 'source_file_missing'
            elif prop=='_MainTex':
                match = re.fullmatch(re.escape(source.stem)+r'(?:_[0-9a-f]{8})?',Path(pmx_ref).stem,re.I)
                status = 'primary_bound' if match else 'primary_different_or_unbound'
            elif prop=='_LightTex' and name in light_binding:
                status = 'secondary_bound'
            else:
                status = 'source_layer_not_converted'
            texture_rows.append(dict(material=name,property=prop,guid=guid,status=status,
                                     source=str(source.relative_to(assets)) if present else None,
                                     pmx_ref=pmx_ref if prop=='_MainTex' and pmx_ref else None))
    _, missing = check_dependencies(pmx,model)
    scene_path = Path(evidence['scene'])
    chosen_root = root_name or model.name
    screens = screen_sources(scene_path,assets,referenced,textures,chosen_root)
    external_pairs = []
    visibility, timeline_report = timeline_visibility(
        assets, scene_path, model, evidence['referenced_materials'], slots, frames, chosen_root,
        external_pairs=None if missing else external_pairs)
    moves, floor_status = floor_adjustment(model,scene_path,chosen_root,slots,vertices)
    floor_overlay = None
    if floor_cleanup and not missing:
        glow_moves,floor_overlay = karma_floor_overlay(model,chosen_root,scene_path)
        moves.update(glow_moves)
    if moves and missing:
        floor_status.update(status='blocked_missing_textures', vertices_moved=0)
    risks = floor_risks(model,vertices)
    extended, external_textures, external_visibility, external_layers, external_report = append_lights(
        model,assets,scene_path,external_pairs,scale)
    scroll_count = len(effects)
    visibility.extend(external_visibility)
    limit = 2**(8*extended.tex_width-1)
    # Keep existing compatible layers first and reserve texture indices before preparing UV1.
    secondary_refs = {layer[1] for layer in layers.values()}
    if len(extended.textures)+len(secondary_refs)>limit:
        for item in light_textures:
            if item['status']=='generated':
                item.update(status='skipped',reason='追加网格后纹理索引空间不足')
        layers.clear()
        light_effects.clear()
        secondary_refs.clear()
    for slot,(path,ref,points,transform,props,info) in external_layers.items():
        ref = ref.replace('AutoStageExternal','AutoStageLight',1)
        speeds = (props.get('_SpeedL',0),props.get('_SpeedLY',0))
        item = dict(material=info['name'], source=str(path.relative_to(assets)),texture_ref=ref,
                    external_mesh=True,intensity=props.get('_Intensity',1))
        light_textures.append(item)
        if extended.uv_count or (ref not in secondary_refs and len(extended.textures)+len(secondary_refs)>=limit):
            item.update(status='skipped',reason='PMX 追加 UV 或纹理索引空间不足')
            continue
        secondary_refs.add(ref)
        item.update(status='generated',blend_approximation='PMX subtexture')
        layers[slot] = (path,ref,points,transform)
        light_effects.extend(scroll_effects(slot,speeds,frames,dict(material=info['name'],light_texture=item),
                                            secondary=True))
    effects.extend(light_effects)
    effects.extend(visibility)
    prepared, added_textures = (model,{}) if missing else prepare_model(extended,layers,moves)
    movie_fallback = {}
    if not missing:
        prepared,movie_textures,movie_fallback = restore_movie_surfaces(prepared,referenced,assets,textures)
        added_textures.update(movie_textures)
    shadow_cleanup = dict(status='blocked_missing_textures' if floor_cleanup else 'disabled')
    future_floor_b = floor_status.get('method')=='143_Future_B' and floor_status.get('status')=='applied'
    if floor_cleanup and not missing and future_floor_b:
        shadow_cleanup = dict(status='preserved_verified_floor_separation')
    elif floor_cleanup and not missing:
        protected = {index for fx in effects for index in fx.get('material_indices',[])}
        prepared,shadow_cleanup = disable_floor_shadows(prepared,referenced,shaders,scale,protected)
        if floor_overlay:
            shadow_cleanup.update(separated_light_overlay=floor_overlay, overlay_vertices_moved=len(glow_moves))
    added_textures = {**external_textures,**added_textures}
    animation_visibility = [row for row in timeline_report if row['source_type']=='animation_clip']
    activation_tracks = [row for row in timeline_report if row['source_type']=='activation_track']
    report = dict(scene=evidence['scene'], source_pmx=str(pmx.resolve()), preview_frames=frames,
        fps=30, effects=len(effects), screen_sources=screens, scroll_controls=scroll_count, light_scroll_controls=len(light_effects),
        light_textures=light_textures, external_lights=external_report, floor_repair=floor_status,
        floor_shadow_cleanup=shadow_cleanup, possible_floor_overlap=risks,
        visibility_controls=len(visibility), timeline_activation=activation_tracks,
        animation_clip_visibility=animation_visibility, texture_audit=dict(missing_pmx_references=missing, slots=texture_rows), skipped=skipped, unresolved_materials=evidence['unresolved_material_guids'],
        animation_clips_pending=[clip['file'] for clip in evidence['animation_clips']],
        scene_lighting=dict(sources=lights, receiver_materials=0, light_map_materials=0,
                            timeline_sources=light_schedule.sources if light_schedule else [],
                            timeline_profile='normal', animated_receiver_materials=0,
                            status='MME_NOT_REQUESTED' if not mme_preview else 'NO_MME_LIGHTS'),
        limits='UV 位移按每秒纹理周期近似。光照层用 PMX 子纹理近似。Timeline 支持部分激活和灯光曲线。粒子支持已匹配的气泡和闪粉发射器。投影、其他粒子和 HDR 发光仍待转换。')
    particle_count = len(re.findall(r'(?m)^--- !u!198 &',scene_path.read_text('utf-8-sig',errors='replace')))
    report['particle_systems'] = dict(total=particle_count,converted=0,pending=particle_count)
    movie_cues = movie_timeline(assets,scene_path)
    if movie_cues:
        report['movie_timeline'] = dict(status='timeline_detected_playback_pending',cues=movie_cues)
    if movie_fallback:
        report['movie_surface_fallback'] = movie_fallback
    output.parent.mkdir(parents=True, exist_ok=True)
    with staging_directory(output.parent) as temp:
        package = Path(temp)/'package'
        if missing:
            report.update(effects=0,planned_effects=len(effects),
                          no_output_reason='基础 PMX 存在缺失或无效的贴图引用')
        elif effects or moves or shadow_cleanup['status']=='applied' or movie_fallback:
            profile = Path(temp)/'AutoStage.profile.json'
            profile.write_text(json.dumps(dict(schema_version=1,effects=effects)), 'utf-8')
            result = build_effect_package(pmx,profile,package,auto=True,prepared_model=prepared,added_textures=added_textures)
            report.update(output_pmx=result['output_pmx'], vmd_outputs=result['vmd_outputs'])
            review, screen_marks = screen_preview(model.name,screens,visibility)
            if review:
                preview_name = pmx.stem+'_屏幕切换验收.vmd'
                (package/preview_name).write_bytes(review)
                report['screen_preview'] = dict(file=preview_name, fps=30, playback_frames=120,
                                                controls=screen_marks, source_timing_modified=True)
                with (package/'使用说明.txt').open('a',encoding='utf-8') as notes:
                    notes.write('\n屏幕切换验收 VMD 将原场景的切换压缩到第 30 和 90 帧。单独加载到舞台，从第 0 帧播放。')
        elif not any((skipped, light_textures, timeline_report)):
            report['no_output_reason'] = '当前支持的自动转换规则未匹配到效果。'
        if not package.exists():
            package.mkdir()
        if mme_preview and not missing:
            try:
                with staging_directory(temp) as mme_temp:
                    export_pmx = package/report['output_pmx'] if report.get('output_pmx') else pmx
                    motions = [package/row['file'] for row in report.get('vmd_outputs',[])]
                    if report.get('screen_preview'):
                        motions.append(package/report['screen_preview']['file'])
                    probe_source = stage_probe(evidence['scene'], assets, guid_of) if blender else None
                    mme = build_mme_preview(mme_temp,export_pmx,referenced,shaders,textures,motions,
                                            probe=probe_source, blender=blender, lights=lights,
                                            light_programs=light_programs, raised_floor_overlay=floor_overlay,
                                            uv_effects=() if future_floor_b else effects,
                                            scene=scene_path,scale=scale,assets=assets,
                                            light_schedule=light_schedule,movie_cues=movie_cues)
                    if mme:
                        (mme_temp/mme['folder']).rename(package/mme['folder'])
                        report['mme_preview'] = mme
                        if mme.get('movie_screen'):
                            report['movie_timeline']['status'] = mme['movie_screen']['status']
                        count = mme['particle_emitters']
                        report['particle_systems'].update(converted=count,pending=max(0,particle_count-count))
                        receivers = [row for row in mme['materials'] if row['mode']=='scene_light_receiver']
                        bound = {file_id for row in receivers for file_id in row['light_source_ids']}
                        maps = sum(row.get('map_slot')=='_LightTex' or row.get('light') is not None or
                                   row['mode'] in ('light_plane_additive','lamp_atlas_falloff','ball_emission')
                                   for row in mme['materials'])
                        for light in lights:
                            if light['status']=='supported':
                                light['status'] = 'bound' if light['file_id'] in bound else 'no_matching_surface'
                        report['scene_lighting'].update(receiver_materials=len(receivers),light_map_materials=maps,
                                                        animated_receiver_materials=sum(bool(row.get('animated_light_ids'))
                                                                                        for row in receivers),
                                                        status='GENERATED' if receivers or maps else 'NO_MME_LIGHTS')
                    else:
                        report['mme_preview'] = {'status':'NO_MATCHED_MATERIALS'}
            except (OSError,ValueError) as error:
                report['mme_preview'] = {'status':'FAILED','reason':str(error)}
                report['scene_lighting']['status'] = 'FAILED'
        if mme_preview:
            bindings = report.get('mme_preview',{}).get('materials',[])
            marker_bindings = Counter(row['marker'] for row in bindings if row.get('marker'))
            effect_cues = [
                dict(effect=name, seconds=event['time'], grade=event['grade'], asset=event['asset'],
                     mesh_or_particle_bindings=marker_bindings[event['asset']])
                for name, events in light_schedule.effect_events.items() for event in events
            ]
            report['effect_coverage'] = dict(
                mme_material_modes=dict(Counter(row['mode'] for row in bindings)),
                effect_play_cues=sorted(effect_cues,key=lambda row:(row['seconds'],row['effect'])),
            )
            if bindings:
                report.pop('no_output_reason',None)
        (package/'AutoStage_Report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2),'utf-8')
        package.rename(output)
    return report


def restore_floor_only(model, pmx, output, scene, root_name, referenced, shaders, scale):
    _, missing = check_dependencies(pmx,model)
    report = dict(scene=str(scene),source_pmx=str(pmx.resolve()),effects=0,
                  floor_shadow_cleanup=dict(status='blocked_missing_textures',missing_textures=missing))
    output.parent.mkdir(parents=True, exist_ok=True)
    with staging_directory(output.parent) as temp:
        package = temp/'package'
        if not missing:
            slots = defaultdict(list)
            for index,slot in enumerate(model.materials):
                slots[slot.name].append(index)
            moves,_ = floor_adjustment(model,scene,root_name or model.name,slots,material_vertices(model))
            glow_moves,overlay = karma_floor_overlay(model,root_name or model.name,scene)
            moves.update(glow_moves)
            prepared,_ = prepare_model(model,{},moves)
            prepared,cleanup = disable_floor_shadows(prepared,referenced,shaders,scale)
            if overlay:
                cleanup.update(separated_light_overlay=overlay, overlay_vertices_moved=len(glow_moves))
            report['floor_shadow_cleanup'] = cleanup
            if cleanup['status']=='applied' or moves:
                profile = temp/'AutoStage.profile.json'
                profile.write_text(json.dumps(dict(schema_version=1,effects=[])),'utf8')
                result = build_effect_package(pmx,profile,package,auto=True,prepared_model=prepared)
                report.update(output_pmx=result['output_pmx'],vmd_outputs=result['vmd_outputs'])
        package.mkdir(exist_ok=True)
        (package/'AutoStage_Report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
        package.rename(output)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('project','scene','pmx','out'):
        parser.add_argument('--'+key, required=True, type=Path)
    parser.add_argument('--frames', type=int, default=5400)
    parser.add_argument('--root', help='Unity root GameObject name, defaults to PMX model name')
    parser.add_argument('--scale',type=float,default=12.5,help='Original Unity-to-PMX export scale')
    parser.add_argument('--mme-preview',action='store_true')
    parser.add_argument('--remove-floor-shadows',action='store_true')
    parser.add_argument('--blender',type=Path, help='Blender executable for converting scene reflection probes')
    args = parser.parse_args()
    print(restore(args.project,args.scene,args.pmx,args.out,args.frames,root_name=args.root,scale=args.scale,
                  mme_preview=args.mme_preview,blender=args.blender,floor_cleanup=args.remove_floor_shadows)['effects'])
