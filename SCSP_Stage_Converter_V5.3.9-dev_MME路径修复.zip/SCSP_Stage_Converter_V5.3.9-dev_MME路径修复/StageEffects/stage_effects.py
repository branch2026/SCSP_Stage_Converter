# -*- coding: utf-8 -*-
"""Opt-in Unity stage PMX effects: non-destructive material/UV morphs and VMD.

No effects are inferred from names. Input profiles explicitly list PMX material
slots and source provenance. Effects are written to a separate self-contained
folder, never into the V3.0-converted PMX folder.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import struct
from pathlib import Path

try:
    from .output_staging import staging_directory
    from .pmx_binary import Model, PMXError
    from .vmd_codec import write_vmd, encode_name as encode_vmd_name, VMDError
except ImportError:
    from output_staging import staging_directory
    from pmx_binary import Model, PMXError
    from vmd_codec import write_vmd, encode_name as encode_vmd_name, VMDError


class EffectError(ValueError):
    pass


def hash_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def validate_number(value, label):
    if isinstance(value, bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise EffectError('%s must be a finite number' % label)
    return float(value)


def resolve_materials(model, fx):
    slots = fx.get('material_indices')
    named = fx.get('materials')
    if (slots is None) == (named is None):
        raise EffectError('Specify exactly one of materials or material_indices')
    if slots is not None:
        if not isinstance(slots,list) or not slots or any(type(x) is not int or x<0 or x>=len(model.materials) for x in slots):
            raise EffectError('Invalid material_indices')
        indices=slots
    else:
        if not isinstance(named,list) or not named or any(not isinstance(s,str) or not s for s in named):
            raise EffectError('materials must be a nonempty array of exact names')
        indices=[]
        for name in named:
            matches=[i for i,m in enumerate(model.materials) if m.name==name]
            if not matches:
                raise EffectError('Material not found: '+name)
            if len(matches)>1 and not fx.get('match_all',False):
                raise EffectError('Ambiguous material %r: %d matches; use material_indices or match_all' % (name,len(matches)))
            indices.extend(matches)
    if len(set(indices))!=len(indices):raise EffectError('Repeated material slot')
    return indices


def keys_for_fx(fx, name):
    keys=fx.get('keys',[])
    if not isinstance(keys,list):raise EffectError('keys must be an array')
    seen=set(); output=[]
    for pair in keys:
        if not isinstance(pair,list) or len(pair)!=2:
            raise EffectError('Invalid VMD key pair for '+name)
        frame,weight=pair
        if type(frame) is not int or frame<0 or frame>2**32-1 or frame in seen:
            raise EffectError('VMD frame must be a unique nonnegative integer')
        val=validate_number(weight,'VMD morph weight')
        if val<0 or val>1:raise EffectError('VMD morph weight must be 0..1')
        seen.add(frame);output.append((frame,val))
    return sorted(output)


_MATERIAL_FIELDS = (
    ('diffuse', 4), ('specular', 3), ('shininess', 1), ('ambient', 3),
    ('edge_color', 4), ('edge_size', 1), ('texture_factor', 4),
    ('sphere_factor', 4), ('toon_factor', 4),
)


def _resolve_one_material(model, entry):
    if ('material' in entry) == ('material_index' in entry):
        raise EffectError('Each material offset must specify exactly one of material or material_index')
    if 'material_index' in entry:
        index = entry['material_index']
        if type(index) is not int or not 0 <= index < len(model.materials):
            raise EffectError('Invalid material_index in material_offsets')
        return index
    name = entry['material']
    if not isinstance(name, str) or not name:
        raise EffectError('material must be an exact non-empty material name')
    matches = [i for i, material in enumerate(model.materials) if material.name == name]
    if not matches:
        raise EffectError('Material not found: ' + name)
    if len(matches) != 1:
        raise EffectError('Ambiguous material name %r; use material_index' % name)
    return matches[0]


def resolve_material_state(model, fx):
    """Resolve a Phase-style type-8 morph with explicit PMX material offsets.

    PMX operation 0 is multiply (neutral coefficient 1); operation 1 is add
    (neutral coefficient 0). All 28 coefficients are emitted so omitted
    channels remain neutral and cannot accidentally alter unrelated channels.
    """
    entries = fx.get('material_offsets')
    if not isinstance(entries, list) or not entries:
        raise EffectError('material_state requires a non-empty material_offsets array')
    targets = []
    descriptions = []
    seen = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise EffectError('Each material_offsets item must be an object')
        index = _resolve_one_material(model, entry)
        if index in seen:
            raise EffectError('A material may only appear once in one Phase morph: %d' % index)
        seen.add(index)
        op_name = entry.get('operation', 'add')
        if op_name not in ('add', 'multiply'):
            raise EffectError('Material morph operation must be add or multiply')
        operation = 1 if op_name == 'add' else 0
        neutral = 0.0 if operation == 1 else 1.0
        values = []
        changed = []
        for field, width in _MATERIAL_FIELDS:
            default = [neutral] * width
            value = entry.get(field, default if width > 1 else neutral)
            if width == 1:
                value = [value]
            if not isinstance(value, (list, tuple)) or len(value) != width:
                raise EffectError('%s must contain %d value(s)' % (field, width))
            numbers = [validate_number(x, field) for x in value]
            values.extend(numbers)
            if field in entry:
                changed.append(field)
        if len(values) != 28:
            raise EffectError('Internal material coefficient layout error')
        targets.append({'index': index, 'operation': operation, 'values': values})
        descriptions.append({
            'index': index,
            'name': model.materials[index].name,
            'operation': op_name,
            'changed_channels': changed,
        })
    return targets, descriptions


def resolve_effects(model, spec):
    if not isinstance(spec,dict) or spec.get('schema_version')!=1:
        raise EffectError('Stage effect spec schema_version must be 1')
    if 'model_name' in spec and spec['model_name']!=model.name:
        raise EffectError('Model name does not match spec')
    effects=spec.get('effects')
    if not isinstance(effects,list) or not effects:
        raise EffectError('effects must be a nonempty array')
    parsed=[]; descriptions=[]; names=set(model.morph_names); vmd_names=set()
    for fx in effects:
        if not isinstance(fx,dict):raise EffectError('Invalid effect entry')
        name=fx.get('name')
        if not isinstance(name,str) or not name or len(name)>120 or name in names:
            raise EffectError('Empty/duplicate/existing PMX morph name: %r' % name)
        names.add(name)
        try:
            vmd_name = encode_vmd_name(name, 15, 'VMD morph name')[:15].rstrip(b'\0')
        except VMDError as exc:
            raise EffectError(str(exc)) from exc
        if vmd_name in vmd_names:
            raise EffectError('VMD morph name collides after CP932 encoding: '+name)
        vmd_names.add(vmd_name)
        origin=fx.get('provenance','manual-demo')
        if origin not in ('manual-demo','unity-verified'):
            raise EffectError('provenance must be manual-demo or unity-verified')
        if origin=='unity-verified' and not fx.get('unity_evidence'):
            raise EffectError('Unity-verified effect requires explicit unity_evidence')
        typ=fx.get('type')
        targets=[]
        if typ == 'material_state':
            targets, material_descriptions = resolve_material_state(model, fx)
            indices = [x['index'] for x in targets]
            ntype = 8
        elif typ in ('material_alpha','material_tint'):
            indices=resolve_materials(model,fx)
            if typ=='material_alpha':
                a=validate_number(fx.get('target_alpha'),'target_alpha')
                if not 0<=a<=1:raise EffectError('target_alpha must be 0..1')
            else:
                colors=fx.get('target_rgba')
                if not isinstance(colors,list) or len(colors)!=4:raise EffectError('target_rgba must contain 4 values')
                colors=[validate_number(x,'target_rgba') for x in colors]
                if any(not 0<=x<=1 for x in colors):raise EffectError('target_rgba must contain values 0..1')
            for i in indices:
                rgba=model.materials[i].diffuse
                dest=(rgba[:3]+(a,)) if typ=='material_alpha' else colors
                targets.append((i,tuple(float(x-y) for x,y in zip(dest,rgba))))
            ntype=8
            material_descriptions = [{'index': i, 'name': model.materials[i].name,
                                      'operation': 'add', 'changed_channels': ['diffuse']} for i in indices]
        elif typ=='uv_offset':
            indices=resolve_materials(model,fx)
            uv=fx.get('uv_channel',0)
            if type(uv) is not int or not 0<=uv<=4 or uv>model.uv_count:
                raise EffectError('Requested additional UV does not exist in source PMX')
            vector=fx.get('offset')
            if not isinstance(vector,list) or len(vector)!=2:
                raise EffectError('uv_offset requires [du,dv]')
            u,v=[validate_number(x,'uv_offset') for x in vector]
            selected=set()
            for i in indices:
                m=model.materials[i]
                selected.update(model.face_indices(m.start,m.faces))
            if not selected:raise EffectError('Selected material contains no faces')
            other=set()
            for i,m in enumerate(model.materials):
                if i not in indices:other.update(model.face_indices(m.start,m.faces))
            shared=selected & other
            if shared and not fx.get('allow_shared_vertices',False):
                raise EffectError('UV morph would affect %d vertices shared with unselected materials' % len(shared))
            targets=[(idx,(u,v,0.0,0.0)) for idx in sorted(selected)]
            ntype=3+uv
            material_descriptions = [{'index': i, 'name': model.materials[i].name} for i in indices]
        else:
            raise EffectError('Unsupported effect type: '+str(typ))
        parsed.append({'type':ntype,'name':name,'english':fx.get('english',name),'targets':targets})
        descriptions.append({'name':name,'type':typ,'materials':material_descriptions,
                             'offset_count':len(targets),'provenance':origin,'unity_evidence':fx.get('unity_evidence',None),
                             'keys':keys_for_fx(fx,name)})
    return parsed,descriptions


def make_vmd(model_name, descriptions, anchor_bone=None):
    frames=[]
    for d in descriptions:
        for frame,weight in d['keys']:
            frames.append((d['name'],frame,weight))
    if not frames:return None
    bones=[]
    if anchor_bone:
        # A neutral frame is a diagnostic compatibility variant. It must not
        # move the model: zero translation + identity quaternion.
        bones.append((anchor_bone,0,(0.0,0.0,0.0),(0.0,0.0,0.0,1.0)))
    try:
        return write_vmd(model_name, frames, bones)
    except VMDError as exc:
        raise EffectError(str(exc)) from exc


def safe_texture_path(ref):
    # PMX files use Windows paths even on other OSes; never copy outside model directory.
    if not ref or '\x00' in ref or ':' in ref or ref.startswith(('/', '\\')):
        raise EffectError('Absolute/invalid PMX texture reference: '+str(ref))
    path=Path(ref.replace('\\','/'))
    if not path.parts or '..' in path.parts or path.is_absolute():
        raise EffectError('Unsafe PMX texture reference: '+ref)
    return path


def check_dependencies(pmx_path, model):
    parent=Path(pmx_path).resolve().parent
    files=[]; missing=[]
    for ref in model.textures:
        if not ref:
            files.append({'ref':ref,'status':'empty'});continue
        try:
            rel=safe_texture_path(ref)
            source=(parent/rel).resolve()
            if not source.is_relative_to(parent):raise EffectError('Symlink escape')
            okay=source.is_file() and source.stat().st_size>0
            files.append({'ref':ref,'status':'ok' if okay else 'missing','size':source.stat().st_size if okay else 0})
            if not okay:missing.append(ref)
        except (EffectError,OSError) as exc:
            files.append({'ref':ref,'status':'unsafe','detail':str(exc)});missing.append(ref)
    return files, missing


def inspect(pmx_path):
    path=Path(pmx_path)
    model=Model(path.read_bytes())
    deps,missing=check_dependencies(path,model)
    return {'schema':'scsp-stage-effects-inspection-v1', 'model':model.name, 'pmx':str(path),
            'vertices':model.vertex_count,'triangles':model.face_index_count//3,
            'materials':[{'index':i,'name':m.name,'alpha':round(m.diffuse[3],5),'triangles':m.faces//3} for i,m in enumerate(model.materials)],
            'bones':list(model.bones),
            'morphs':list(model.morph_names),'additional_uv_count':model.uv_count,
            'textures':deps,'missing_textures':missing}


def build_effect_package(pmx_path, profile_path, out_dir, *, auto=False, prepared_model=None, added_textures=None):
    source=Path(pmx_path).resolve(); profile=Path(profile_path).resolve(); dest=Path(out_dir).resolve()
    if not source.is_file() or not profile.is_file():raise EffectError('Input PMX or effect profile does not exist')
    if dest.exists():raise FileExistsError('Output directory must not already exist: '+str(dest))
    if source.parent==dest or source.parent in dest.parents and dest.name=='textures':
        raise EffectError('Output cannot overwrite texture folder')
    spec=json.loads(profile.read_text('utf-8-sig'))
    model=Model(source.read_bytes())
    _,missing=check_dependencies(source,model)
    if missing:raise EffectError('Unresolved/unsafe PMX textures (%d): %s' % (len(missing),missing[:4]))
    if prepared_model is not None:
        model = prepared_model
    added_textures = added_textures or {}
    effects, descriptions = resolve_effects(model,spec) if spec["effects"] or not auto else ([],[])
    payload = model.add_morphs(effects) if effects else model.data
    checked=Model(payload)
    assert checked.data[:checked.morph_begin]==model.data[:model.morph_begin]
    assert checked.original_tail==model.original_tail
    assert checked.morph_names==model.morph_names+[fx['name'] for fx in effects]
    assert checked.face_index_count==model.face_index_count and len(checked.materials)==len(model.materials)
    vmd_settings = spec.get('vmd', {})
    if not isinstance(vmd_settings, dict):
        raise EffectError('vmd settings must be an object')
    anchor_bone = vmd_settings.get('neutral_anchor_bone')
    if anchor_bone is not None:
        if anchor_bone not in checked.bones:
            raise EffectError('VMD neutral_anchor_bone is not present in PMX: ' + str(anchor_bone))
        try:
            encode_vmd_name(anchor_bone, 15, 'VMD neutral anchor bone name')
        except VMDError as exc:
            raise EffectError(str(exc)) from exc
    motion=make_vmd(checked.name,descriptions)
    anchored_motion=make_vmd(checked.name,descriptions,anchor_bone=anchor_bone) if anchor_bone else None
    dest.parent.mkdir(parents=True,exist_ok=True)
    with staging_directory(dest.parent) as stage_dir:
        stage=stage_dir/'package';stage.mkdir()
        for ref in model.textures:
            if not ref:continue
            rel=safe_texture_path(ref)
            target=stage/rel
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(added_textures.get(ref, source.parent/rel),target)
        pmx_out=stage/(source.stem+('_V5.3.9_Auto.pmx' if auto else '_V3.1_FX.pmx'))
        pmx_out.write_bytes(payload)
        vmd_outputs=[]
        if motion:
            morph_only_name=source.stem+('_V5.3.9_Auto.vmd' if auto else '_效果测试.vmd')
            (stage/morph_only_name).write_bytes(motion)
            vmd_outputs.append({'file':morph_only_name,'bone_keys':0,'mode':'morph-only'})
        if anchored_motion:
            anchored_name=source.stem+'_效果测试_中性骨骼锚点.vmd'
            (stage/anchored_name).write_bytes(anchored_motion)
            vmd_outputs.append({'file':anchored_name,'bone_keys':1,'mode':'neutral-bone-anchor',
                                'anchor_bone':anchor_bone})
        validation=Model(pmx_out.read_bytes())
        _,missing=check_dependencies(pmx_out,validation)
        if missing:raise EffectError('Output texture validation failed: '+str(missing))
        result={'schema':'scsp-stage-effects-build-v1','model':model.name,'source_pmx_sha256':hash_file(source),
                'source_pmx':str(source),'profile':profile.name,'source_provenance':spec.get('notes',''),
                'output_pmx':pmx_out.name,'output_pmx_sha256':hash_file(pmx_out),
                'vertices':checked.vertex_count,'triangles':checked.face_index_count//3,
                'materials':len(checked.materials),'morph_count_before':model.morph_count,
                'morph_count_after':checked.morph_count,'texture_references':len(checked.textures),
                'missing_textures':0,'effects':descriptions, 'vmd_created':motion is not None,
                'vmd_outputs':vmd_outputs,
                'status':'BUILT_NOT_MMD_VERIFIED','conversion_core_modified':False,
                'secondary_textures_added':list(added_textures)}
        (stage/'StageEffects_Report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
        (stage/'使用说明.txt').write_text(
          'SCSP Stage Converter V3.1 效果附加包\n\n'
          '此目录是从原始 PMX 另行生成的效果版，原始 V3.0 PMX 未改动。\n'
          '先在 MMD 加载 *_V3.1_FX.pmx，在模型表情操作中查看新增形态键。\n'
          '如存在 *_效果测试.vmd：这是纯形态键动作（兼容 V3.1-dev 原文件名）。\n'
          '如存在 *_效果测试_中性骨骼锚点.vmd：这是额外含一条零位移骨骼帧的兼容性对照版本。\n'
          '两份 VMD 请分别单独导入，不要同时加载。\n'
          '材质控制与测试 VMD 不是 MME 发光渲染；不会自动恢复 Unity 原版动画。\n'
          '效果来源请查看 StageEffects_Report.json；仍需在 MMD 9.32 手动验收。\n',encoding='utf-8-sig')
        dest.parent.mkdir(parents=True,exist_ok=True)
        if auto:
            (stage/'使用说明.txt').write_text('在 MMD 加载本目录的 PMX。如附带 VMD，请选中舞台模型，导入同名 VMD 后从第 0 帧播放。效果范围与未支持项见 AutoStage_Report.json。','utf-8-sig')
        stage.rename(dest)
        return result


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    subs=ap.add_subparsers(dest='command',required=True)
    q=subs.add_parser('inspect',help='List PMX materials, morphs and missing textures');q.add_argument('pmx',type=Path)
    q.add_argument('--out',type=Path)
    b=subs.add_parser('build',help='Add effects to a separate PMX package')
    b.add_argument('--pmx',required=True,type=Path);b.add_argument('--profile',required=True,type=Path)
    b.add_argument('--out',required=True,type=Path)
    args=ap.parse_args(argv)
    try:
        report=inspect(args.pmx) if args.command=='inspect' else build_effect_package(args.pmx,args.profile,args.out)
        result=json.dumps(report,ensure_ascii=False,indent=2)
        if args.command=='inspect' and args.out:
            args.out.parent.mkdir(parents=True,exist_ok=True)
            args.out.write_text(result+'\n',encoding='utf-8')
            print('Inspection saved:',args.out)
        else:print(result)
        return 0
    except (OSError,ValueError,struct.error) as exc:
        ap.exit(2,'Stage effects failed: %s\n' % exc)


if __name__=='__main__':
    main()
