"""Clip the verified long-light dot atlas into the PMX face mesh."""
from math import ceil, floor, isfinite
from struct import pack, unpack_from

from .pmx_binary import Model, i32


# Opaque texel runs from the verified 32x32 dot atlas. Identical adjacent
# scanlines share a rectangle. Texture coordinates use PNG's top-left origin.
DOT_BANDS = ((14,18,11,12),(13,19,12,13),(12,20,13,14),(11,21,14,18),
             (12,20,18,19),(13,19,19,20),(14,18,20,21))


def clip_half_plane(polygon, axis, boundary, sign):
    result = []
    if not polygon:
        return result
    previous = polygon[-1]
    from_edge = sign * (previous[axis]-boundary)
    for vertex in polygon:
        to_edge = sign * (vertex[axis]-boundary)
        if (to_edge>=0)!=(from_edge>=0):
            weight = from_edge/(from_edge-to_edge)
            result.append(tuple(a+(b-a)*weight for a,b in zip(previous,vertex)))
        if to_edge>=0:
            result.append(vertex)
        previous,from_edge = vertex,to_edge
    return result


def covered_polygons(triangle):
    lo_u,hi_u = min(p[0] for p in triangle),max(p[0] for p in triangle)
    lo_v,hi_v = min(p[1] for p in triangle),max(p[1] for p in triangle)
    if not all(isfinite(v) and abs(v)<1024 for v in (lo_u,hi_u,lo_v,hi_v)):
        raise ValueError('点阵网格的 UV 范围无法安全裁剪')
    if (ceil(hi_u)-floor(lo_u))*(ceil(hi_v)-floor(lo_v))>128:
        raise ValueError('单个三角面跨越过多点阵贴图')
    for u in range(floor(lo_u),ceil(hi_u)):
        for v in range(floor(lo_v),ceil(hi_v)):
            for x0,x1,y0,y1 in DOT_BANDS:
                left,right,top,bottom = u+x0/32,u+x1/32,v+y0/32,v+y1/32
                if hi_u<=left or lo_u>=right or hi_v<=top or lo_v>=bottom:
                    continue
                polygon = clip_half_plane(triangle,0,left,1)
                polygon = clip_half_plane(polygon,0,right,-1)
                polygon = clip_half_plane(polygon,1,top,1)
                polygon = clip_half_plane(polygon,1,bottom,-1)
                if len(polygon)>=3:
                    yield polygon


def clip_material(model, slot, transform, base):
    sx,sy,ox,oy = transform
    values = 8+4*model.uv_count
    length = 4*values
    all_indices = model.face_indices(slot.start,slot.faces)
    samples,tails = {},set()
    for index in set(all_indices):
        at = model.vertex_offsets[index]
        tail_at = at+length
        if model.data[tail_at]!=0:
            raise ValueError('点阵灯条需要单骨骼绑定的静态网格')
        tails.add(model.data[tail_at:tail_at+1+model.bone_width+4])
        record = unpack_from('<'+str(values)+'f',model.data,at)
        samples[index] = (record[6]*sx+ox,record[7]*sy+1-sy-oy,*record)
    if len(tails)!=1:
        raise ValueError('点阵灯条材质含不同的蒙皮或边缘参数')
    tail = tails.pop()
    vertices,indices,reuse = [],[],{}
    capacity = 2**(8*model.vertex_width)
    for i in range(0,len(all_indices),3):
        triangle = tuple(samples[index] for index in all_indices[i:i+3])
        for polygon in covered_polygons(triangle):
            a = polygon[0]
            for b,c in zip(polygon[1:],polygon[2:]):
                area = (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
                if abs(area)<1e-10:
                    continue
                for p in (a,b,c):
                    record = pack('<'+str(values)+'f',*p[2:])
                    index = reuse.get(record)
                    if index is None:
                        index = base+len(vertices)
                        if index>=capacity:
                            raise ValueError('点阵灯条超过 PMX 顶点索引容量')
                        reuse[record] = index
                        vertices.append(record+tail)
                    indices.append(Model.idx(index,model.vertex_width,signed=False))
    return vertices,b''.join(indices)


def apply_point_mask_geometry(model, bindings):
    masks = {row['material_index']:row for row in bindings if row.get('point_mask_uv')}
    if not masks:
        return model
    data = model.data
    vertices,faces,material_records = [],[],[]
    ends = [slot.record_at for slot in model.materials[1:]]+[model.bone_table_at]
    for index,(slot,end) in enumerate(zip(model.materials,ends)):
        if index in masks:
            row = masks[index]
            try:
                new_vertices,face_data = clip_material(model,slot,row['point_mask_uv'],model.vertex_count+len(vertices))
                vertices.extend(new_vertices)
                row['mask_geometry'] = 'source_dot_cutout'
            except ValueError as error:
                # Keep material indices and VMD bindings stable. Omitting the
                # faces avoids exposing the original white sheet on fallback.
                face_data = b''
                row['mask_geometry'] = 'hidden'
                row['mask_geometry_reason'] = str(error)
            row['mask_face_indices'] = len(face_data)//model.vertex_width
            material_records.append(data[slot.record_at:end-4]+i32(row['mask_face_indices']))
        else:
            start = model.face_index_start+slot.start*model.vertex_width
            face_data = data[start:start+slot.faces*model.vertex_width]
            material_records.append(data[slot.record_at:end])
        faces.append(face_data)
    vertex = model.vertex_offsets[0]
    face = model.face_index_start-4
    return Model(b''.join((data[:vertex-4],i32(model.vertex_count+len(vertices)),data[vertex:face],
                           b''.join(vertices),i32(sum(map(len,faces))//model.vertex_width),b''.join(faces),
                           data[model.texture_table_at:model.material_table_at+4],b''.join(material_records),
                           data[model.bone_table_at:])))

