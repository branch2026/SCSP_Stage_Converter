"""Temporary output directories with the same inherited permissions as the result."""
from contextlib import contextmanager
import shutil
from uuid import uuid4


@contextmanager
def staging_directory(parent):
    # Windows Python 3.13+ treats mode 0o700 specially. tempfile creates
    # private directories that keep their restricted ACL on the final rename.
    path = parent / ('.scsp_fx_' + uuid4().hex)
    path.mkdir()
    try:
        yield path
    finally:
        shutil.rmtree(path)
