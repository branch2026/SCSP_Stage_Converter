# -*- coding: utf-8 -*-
"""Read-only PMX/VMD/MME/EMD/FX/APNG stage dependency inventory.

References from ITTW46 are inspected only; third-party FX never bundled.
"""
import argparse
import json
import re
import struct
from pathlib import Path

try:
    from .pmx_binary import Model
    from .stage_effects import check_dependencies
    from .vmd_codec import parse_vmd, VMDError
except ImportError:
    from pmx_binary import Model
    from stage_effects import check_dependencies
    from vmd_codec import parse_vmd, VMDError


def apng_info(path):
    path=Path(path)
    with path.open('rb') as f:
        if f.read(8)!=b'\x89PNG\r\n\x1a\n':return None
        width=height=frames=0
        while True:
            header=f.read(8)
            if len(header)<8:break
            n,chunk=struct.unpack('>I4s',header)
            if n > 64*1024*1024:break
            if chunk==b'IHDR' and n>=8:
                width,height=struct.unpack('>II',f.read(8))
                f.seek(n-8+4,1)
            elif chunk==b'acTL' and n>=8:
                frames=struct.unpack('>I',f.read(4))[0]
                f.seek(n-4+4,1)
            else:
                f.seek(n+4,1)
            if chunk==b'IEND':break
    return {'width':width,'height':height,'apng_frames':frames if frames else 1,'animated':frames>1}


def read_text(path):
    data=Path(path).read_bytes()
    for enc in ('utf-8-sig','cp932','utf-16'):
        try:return data.decode(enc)
        except UnicodeError:pass
    return data.decode('cp932','replace')


def vmd_info(path):
    try:
        return parse_vmd(Path(path), strict=True)
    except (OSError, VMDError) as exc:
        return {'error':str(exc)}


def audit_folder(folder,pmx=None):
    root=Path(folder).resolve()
    if not root.is_dir():raise FileNotFoundError(root)
    pmx_files=[Path(pmx)] if pmx else list(root.rglob('*.pmx'))
    if len(pmx_files)>50:raise ValueError('Too many PMX; specify --pmx')
    results={'schema':'scsp-stage-dependencies-v1','folder':str(root),'models':[],
             'vmd':[],'fx':[],'emd':[],'emm':[],'animated_png':[], 'warnings':[]}
    models=[]
    for f in pmx_files:
        try:
            m=Model(f.read_bytes()); deps,missing=check_dependencies(f,m)
            models.append(m)
            results['models'].append({'path':str(f),'name':m.name,'materials':len(m.materials),
                                      'bones':len(m.bones),'morphs':list(m.morph_names),
                                      'textures':deps,'missing_textures':missing})
            if missing:results['warnings'].append(f'{f.name}: {len(missing)} missing/unsafe textures')
        except (OSError,ValueError) as exc:
            results['warnings'].append(f'{f.name}: invalid PMX ({exc})')
    names={m.name:m for m in models}
    for f in root.rglob('*.vmd'):
        data=vmd_info(f);data['file']=str(f)
        if 'morph_tracks' in data and data['model'] in names:
            model=names[data['model']]
            data['unmatched_morph_tracks']=[k for k in data['morph_tracks'] if k not in model.morph_names]
            data['unmatched_bone_tracks']=[k for k in data['bone_tracks'] if k not in model.bones]
            data['matched_model']=True
        elif 'morph_tracks' in data:
            data['matched_model']=False
            data['warning']='VMD model-name field did not exactly match a PMX internal model name in this folder'
        results['vmd'].append(data)
    for f in root.rglob('*.fx'):
        txt=read_text(f)
        names=re.findall(r'^\s*#\s*define\s+AnimatedTexture\s+["<]([^">]+)',txt,re.M)
        includes=re.findall(r'^\s*#\s*include\s+["<]([^">]+)',txt,re.M)
        assets=[]
        for name in names+includes:
            relative=Path(name.replace('\\','/'))
            hit=(f.parent/relative).is_file() if not relative.is_absolute() and '..' not in relative.parts else False
            assets.append({'ref':name,'exists_relative_to_fx':hit})
        results['fx'].append({'file':str(f),'animated_textures':names,'dependencies':assets})
    for f in root.rglob('*.emd'):
        lines=re.findall(r'^\s*Obj(?:\[\d+\])?\s*=\s*(.+?)\s*$',read_text(f),re.M)
        refs=sorted({line.strip() for line in lines if line.strip().lower()!='none'})
        results['emd'].append({'file':str(f),'material_fx_entries':len(lines),
                               'unique_fx':refs,
                               'missing_relative_fx':[v for v in refs if not (f.parent / Path(v.replace('\\','/'))).is_file()]})
    for f in root.rglob('*.emm'):
        txt=read_text(f)
        lines=re.findall(r'^\s*(?:Pmd\d+\[\d+\]|Obj\[\d+\])\s*=\s*(.+?)\s*$',txt,re.M)
        refs=[v.strip() for v in lines if v.strip().lower()!='none']
        absolute=[v for v in refs if re.match(r'^[a-zA-Z]:[\\/]',v)]
        results['emm'].append({'file':str(f),'explicit_material_fx_links':len(refs),
                               'absolute_path_links':len(absolute),'portable':not absolute,
                               'note':'Absolute paths reference the author machine; report-only, not rewritten'})
    for f in root.rglob('*.png'):
        inf=apng_info(f)
        if inf and inf['animated']:
            results['animated_png'].append({'file':str(f),**inf})
    return results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('folder',type=Path)
    p.add_argument('--pmx',type=Path)
    p.add_argument('--out',type=Path)
    args=p.parse_args()
    data=audit_folder(args.folder,args.pmx)
    text=json.dumps(data,ensure_ascii=False,indent=2)+'\n'
    if args.out:
        args.out.write_text(text,'utf-8');print('Saved:',args.out)
    else:print(text)

if __name__=='__main__':main()
