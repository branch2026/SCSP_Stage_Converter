"""Collect and append complementary light meshes driven by external Timeline bindings."""
from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache
import math
from pathlib import Path
import re
from struct import pack

from SceneBuilder.rebuild_stage_blender import docs, parse_mesh, parse_scene, vec
from .pmx_binary import Model, i32
from .unity_effect_probe import material_info


@dataclass(frozen=True)
class Part:
    mesh: str
    material: str
    matrix: tuple


def multiply(a,b):
    return tuple(tuple(sum(x*y for x,y in zip(row,column)) for column in zip(*b)) for row in a)


def local_matrix(transform):
    x,y,z,w = transform['rot']
    sx,sy,sz = transform['scale']
    px,py,pz = transform['pos']
    return (((1-2*(y*y+z*z))*sx, 2*(x*y-z*w)*sy, 2*(x*z+y*w)*sz, px),
            (2*(x*y+z*w)*sx, (1-2*(x*x+z*z))*sy, 2*(y*z-x*w)*sz, py),
            (2*(x*z-y*w)*sx, 2*(y*z+x*w)*sy, (1-2*(x*x+y*y))*sz, pz),
            (0,0,0,1))


def cross(a,b):
    return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])


def mesh_records(mesh,matrix,scale,uv_transform):
    positions = [tuple(sum(x*y for x,y in zip(row,(*p,1)))*scale*sign
                       for row,sign in zip(matrix,(1,1,-1))) for p in mesh['positions']]
    indices = mesh['indices']
    subs = mesh['submeshes']
    if subs:
        if len(subs)!=1 or subs[0]['topology']!=0:
            raise ValueError('只支持单材质三角网格')
        start = subs[0]['firstByte']//(4 if mesh['indexFormat']==1 else 2)
        count = subs[0]['indexCount']
        chunk = indices[start:start+count]
        if len(chunk)!=count:
            raise ValueError('网格索引范围无效')
        indices = [index+subs[0].get('baseVertex',0) for index in chunk]
    uv = mesh['uv']
    if (not uv or len(uv)!=len(positions) or not indices or len(indices)%3 or
            min(indices)<0 or max(indices)>=len(positions) or
            any(not math.isfinite(v) for p in positions for v in p)):
        raise ValueError('网格几何或 UV 无效')
    normals = [[0.,0.,0.] for _ in positions]
    for a,b,c in zip(indices[::3],indices[1::3],indices[2::3]):
        p,q,r = positions[a],positions[b],positions[c]
        normal = cross(tuple(x-y for x,y in zip(r,p)),tuple(x-y for x,y in zip(q,p)))
        for index in (a,b,c):
            normals[index] = [x+y for x,y in zip(normals[index],normal)]
    sx,sy,ox,oy = uv_transform
    records = []
    for (u,v),p,n in zip(uv,positions,normals):
        length = math.hypot(*n)
        unit = tuple(x/length for x in n) if length else (0.,1.,0.)
        records.append(pack('<8f',*p,*unit,u*sx+ox,1-(v*sy+oy)))
    return records,indices


def texture_transform(block, name):
    section = re.search(r'^([ \t]*)'+re.escape(name)+r':[ \t]*\n((?:\1[ \t]+[^\n]*\n)+)',block,re.M)
    if not section:
        raise ValueError('找不到贴图缩放和偏移 '+name)
    scale = vec(section[2],'m_Scale',('x','y'),(1.,1.))
    offset = vec(section[2],'m_Offset',('x','y'),(0.,0.))
    if not all(math.isfinite(v) and abs(v)<=10000 for v in (*scale,*offset)):
        raise ValueError('贴图缩放和偏移无效')
    return (*scale,*offset)


def material_record(model,name,rgba,texture,face_count):
    return b''.join((model.encode_str(name),model.encode_str(name),pack('<4f',*rgba),
                     pack('<3ff3fB4ff',0,0,0,0,1,1,1,1,0,0,0,0,0),
                     Model.idx(texture,model.tex_width),Model.idx(-1,model.tex_width),
                     b'\0\1\0',model.encode_str(''),i32(face_count)))


def append_lights(model, assets, scene, pairs, scale):
    if not pairs:
        return model,{},[],{},[]
    if not model.bones:
        return model,{},[],{},[{'status':'skipped','reason':'基础 PMX 缺少可绑定的舞台骨骼'}]
    objects,transforms,by_go,children,by_tid,_,filters,renderers,guid = parse_scene(scene,assets)

    @lru_cache(maxsize=None)
    def world(go):
        chain = []
        visited = set()
        while go:
            if go in visited or go not in by_go:
                raise ValueError('物件变换层级不完整')
            visited.add(go)
            transform = by_go[go]
            chain.append(local_matrix(transform))
            parent = transform['father']
            if parent and parent not in by_tid:
                raise ValueError('物件父变换缺失')
            go = by_tid[parent] if parent else 0
        matrix = chain.pop()
        while chain:
            matrix = multiply(matrix,chain.pop())
        return matrix

    @lru_cache(maxsize=None)
    def read_material(g):
        path = guid.get(g)
        if path is None or not path.is_file():
            raise ValueError('外部物件材质文件缺失')
        info = material_info(path)
        text = path.read_text('utf-8-sig',errors='replace')
        main = next((p for p in ('_MainTex','_BaseMap') if p in info['textures']),None)
        if main is None:
            raise ValueError('外部物件主贴图未绑定')
        color = info['colors'].get('_Color') or info['colors'].get('_BaseColor') or ''
        components = dict(re.findall(r'([rgba]):\s*([^, }]+)',color))
        rgba = tuple(float(components.get(key,1)) for key in 'rgba')
        if not all(math.isfinite(x) for x in rgba) or rgba[3]<=0:
            raise ValueError('不支持透明或无效的源灯面材质')
        return info,text,main,tuple(max(0.,min(1.,x)) for x in rgba)

    def texture_ref(g):
        path = guid.get(g)
        if path is None or not path.is_file() or path.suffix.lower() not in ('.png','.jpg','.jpeg','.tga','.bmp'):
            raise ValueError('外部贴图缺失或格式不支持 '+g)
        return 'textures/AutoStageExternal/'+g+path.suffix.lower(),path

    @lru_cache(maxsize=None)
    def read_mesh(mesh_guid):
        path = guid.get(mesh_guid)
        if not path or path.suffix.lower()!='.asset':
            raise ValueError('外部网格资源无法解析')
        mesh = parse_mesh(path)
        if not mesh:
            raise ValueError('外部网格为空')
        return mesh

    def branch(fileid):
        go = int(fileid)
        if go not in by_go:
            raise ValueError('外部物件没有变换')
        queue = [by_go[go]['id']]
        parts = []
        visited = set()
        while queue:
            tid = queue.pop()
            if tid in visited:
                raise ValueError('外部物件层级存在循环')
            visited.add(tid)
            item = by_tid[tid]
            if item!=go and not objects[item]['active']:
                continue
            queue.extend(children.get(tid,()))
            extra_components = set(objects[item]['components'])-allowed_components
            if extra_components:
                raise ValueError('外部支路含非 MeshRenderer 组件')
            mesh = filters.get(item,())
            renderer = [r for r in renderers.get(item,()) if r['enabled']]
            if not renderer:
                continue
            if len(mesh)!=1 or len(renderer)!=1 or len(renderer[0]['materials'])!=1:
                raise ValueError('外部支路的网格与材质无法一一对应')
            mg = (mesh[0]['mesh'] or {}).get('guid','').lower()
            mat = renderer[0]['materials'][0].get('guid','').lower()
            if not mg or not mat:
                raise ValueError('外部网格或材质 GUID 缺失')
            parts.append(Part(mg,mat,world(item)))
        if not parts:
            raise ValueError('外部物件没有可转换的灯面')
        return parts

    # Read component ownership using the same source-scene docs as the rebuilder.
    allowed_components = {fileid for kind,fileid,_ in docs(scene.read_text('utf-8-sig',errors='replace'))
                          if kind in (4,23,33,224)}

    vertices = []
    faces = []
    materials = []
    main_textures = {}
    light_layers = {}
    effects = []
    report = []
    for left,right in pairs:
        pair_info = {'objects':[left[2]['object'],right[2]['object']], 'status':'skipped'}
        report.append(pair_info)
        try:
            groups = [branch(left[0]),branch(right[0])]
            if not all(any(read_material(part.material)[0]['textures'].get('_LightTex') for part in group)
                       for group in groups):
                raise ValueError('两个状态都需要有独立光照贴图的灯面')
            common = set(groups[0]) & set(groups[1])
            if len(set(groups[0]))!=len(groups[0]) or len(set(groups[1]))!=len(groups[1]):
                raise ValueError('外部支路存在重叠的网格实例')
            unique = [[part for part in group if part not in common] for group in groups]
            if not all(unique):
                raise ValueError('其中一个状态没有独立的灯面')
            pending = []
            for group_number,group in enumerate([*unique,sorted(common,key=lambda p:(p.material,p.mesh,p.matrix))]):
                by_material = defaultdict(list)
                for part in group:
                    by_material[part.material].append(part)
                for material_guid,parts in by_material.items():
                    info,text,main,rgba = read_material(material_guid)
                    tex,path = texture_ref(info['textures'][main])
                    transform = texture_transform(text,main)
                    mesh_data = [mesh_records(read_mesh(part.mesh),part.matrix,scale,transform) for part in parts]
                    light = None
                    light_guid = info['textures'].get('_LightTex')
                    if light_guid:
                        light_ref,light_path = texture_ref(light_guid)
                        light_transform = texture_transform(text,'_LightTex')
                        # Convert from the baked main UV back to the source mesh UV
                        # before applying the independent light texture transform.
                        sx,sy,x,y = transform
                        if not sx or not sy:
                            raise ValueError('主贴图缩放为零，无法恢复独立光照 UV')
                        lx,ly,ox,oy = light_transform
                        independent = (lx/sx,ly/sy,ox-x*lx/sx,oy-y*ly/sy)
                        light = (light_path,light_ref,independent,info['floats'])
                    pending.append((group_number,rgba,tex,path,mesh_data,light,info))
            count = sum(len(rows) for _,_,_,_,meshes,_,_ in pending for rows,_ in meshes)
            candidate_refs = set(main_textures) | {row[2] for row in pending}
            if (model.vertex_count+len(vertices)+count > 2**(8*model.vertex_width) or
                    len(model.materials)+len(materials)+len(pending)>2**(8*model.mat_width-1) or
                    len(model.textures)+len(candidate_refs)>2**(8*model.tex_width-1) or
                    any(ref in model.textures for ref in candidate_refs)):
                raise ValueError('超出 PMX 原有索引容量或贴图路径冲突')
        except (ValueError, OSError, OverflowError) as error:
            pair_info['reason'] = str(error)
            continue

        slot_groups = [[],[]]
        visible_alpha = {}
        for group,rgba,ref,path,meshes,light,info in pending:
            slot = len(model.materials)+len(materials)
            if ref not in main_textures:
                main_textures[ref] = (len(model.textures)+len(main_textures),path)
            texture_index = main_textures[ref][0]
            name = 'AutoExt' + str(slot) + '_' + info['name']
            if group<2:
                slot_groups[group].append(slot)
                visible_alpha[slot] = rgba[3]
            first_vertex = model.vertex_count+len(vertices)
            face_count = 0
            for rows,indices in meshes:
                start = model.vertex_count+len(vertices)
                vertices.extend(row+bytes(16*model.uv_count)+b'\0'+Model.idx(0,model.bone_width)+bytes(4)
                                for row in rows)
                faces.extend(Model.idx(start+i,model.vertex_width,signed=False) for i in indices)
                face_count += len(indices)
            alpha = rgba[3] if group==2 or (left,right)[group][1][0][1]==0 else 0.0
            materials.append(material_record(model,name,(*rgba[:3],alpha),texture_index,face_count))
            if light is not None:
                light_path,light_ref,transform,properties = light
                light_layers[slot] = (light_path,light_ref,range(first_vertex,model.vertex_count+len(vertices)),
                                      transform,properties,info)
        pair_info.update(status='generated',added_vertices=count,common_meshes=len(common),
                         state_meshes=[len(g) for g in unique],material_groups=slot_groups)
        for branch_info,slots in zip((left,right),slot_groups):
            _,keys,item = branch_info
            # The inactive state is already transparent in standalone PMX.
            initial_hidden = bool(keys[0][1])
            item.pop('reason',None)
            item.update(status='generated',material_indices=slots,external_meshes=True)
            if initial_hidden:
                for slot in slots:
                    effects.append(dict(type='material_alpha',name=f'Ext{slot:05d}',material_indices=[slot],
                                        target_alpha=visible_alpha[slot],keys=[[f,1-w] for f,w in keys],
                                        provenance='unity-verified',unity_evidence=item))
            else:
                effects.append(dict(type='material_alpha',name=f'Ext{slots[0]:05d}',material_indices=slots,
                                    target_alpha=0,keys=keys,provenance='unity-verified',unity_evidence=item))

    if not vertices:
        return model,{},effects,light_layers,report
    first = model.vertex_offsets[0]
    face_count_at = model.face_index_start-4
    texture_at = model.texture_table_at
    material_at = model.material_table_at
    bone_at = model.bone_table_at
    data = model.data
    payload = b''.join((data[:first-4],i32(model.vertex_count+len(vertices)),data[first:face_count_at],
                       b''.join(vertices),i32(model.face_index_count+len(faces)),
                       data[model.face_index_start:texture_at],b''.join(faces),
                       i32(len(model.textures)+len(main_textures)),data[texture_at+4:material_at],
                       b''.join(model.encode_str(ref) for ref in main_textures),
                       i32(len(model.materials)+len(materials)),data[material_at+4:bone_at],
                       b''.join(materials),data[bone_at:]))
    prepared = Model(payload)
    assert prepared.original_tail==model.original_tail
    assert prepared.morph_names==model.morph_names
    return prepared,{ref:path for ref,(_,path) in main_textures.items()},effects,light_layers,report
