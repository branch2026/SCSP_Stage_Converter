from pathlib import Path
import json,re,collections,csv,argparse,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from mesh_decode_probe import probe
ap=argparse.ArgumentParser()
ap.add_argument('project', help='Unity project root containing Assets/')
ap.add_argument('--scene', default='Assets/182_superd.unity')
ap.add_argument('--out', default='StageAnalyzer_Output')
args=ap.parse_args()
proj=Path(args.project).resolve(); assets=proj/'Assets'; scene_path=proj/args.scene; out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
scene=scene_path.read_text(errors='replace')
docs=re.split(r'(?=^--- !u!\d+ &)',scene,flags=re.M)
objects={}; transforms={}; mf=collections.defaultdict(list); mr=collections.defaultdict(list)
for d in docs:
 h=re.match(r'--- !u!(\d+) &(\d+)',d)
 if not h: continue
 c=int(h.group(1)); oid=int(h.group(2))
 def refid(key):
  m=re.search(r'^\s*'+key+r':\s*\{fileID:\s*(-?\d+)',d,re.M); return int(m.group(1)) if m else 0
 if c==1:
  m=re.search(r'^  m_Name: (.*)$',d,re.M); objects[oid]={'name':m.group(1).strip('"') if m else str(oid)}
 elif c==4: transforms[oid]={'go':refid('m_GameObject'),'father':refid('m_Father')}
 elif c==33:
  g=re.search(r'm_Mesh:\s*\{[^}]*guid:\s*([0-9a-f]{32})',d); mf[refid('m_GameObject')].append(g.group(1) if g else None)
 elif c==23:
  mm=re.search(r'm_Materials:\s*\n(.*?)(?=\n\s*m_StaticBatchInfo:)',d,re.S)
  mr[refid('m_GameObject')].extend(re.findall(r'guid:\s*([0-9a-f]{32})',mm.group(1)) if mm else [])
go_to_transform={t['go']:tid for tid,t in transforms.items()}; children=collections.defaultdict(list)
for tid,t in transforms.items(): children[t['father']].append(tid)
name_to_go=collections.defaultdict(list)
for _go,_obj in objects.items(): name_to_go[_obj['name']].append(_go)
def descendant_ids(go):
 tid=go_to_transform.get(go); ids={go}; stack=[tid] if tid else []
 while stack:
  t=stack.pop()
  for child_t in children.get(t,[]):
   child_go=transforms[child_t]['go']; ids.add(child_go); stack.append(child_t)
 return ids
# GUID path index
idx={}
for mp in assets.rglob('*.meta'):
 m=re.search(r'guid: ([0-9a-f]{32})',mp.read_text(errors='replace'))
 if m: idx[m.group(1)]=Path(str(mp)[:-5])
main_go=name_to_go['182_SuperD'][0]
# Resolve the stage root by its actual parent relationship, not by a duplicate object name.
main_tid=go_to_transform[main_go]
nested_go=next((transforms[t]['go'] for t in children[main_tid] if objects[transforms[t]['go']]['name']=='Stage_001930'), None)
effect_go=next((go for go in name_to_go.get('EffectPlayer',[]) if transforms[go_to_transform.get(go,0)]['father']==0), None)
summary={}
for label,go in [('182_SuperD',main_go),('Stage_001930',nested_go),('EffectPlayer',effect_go)]:
 if go is None: continue
 ids=descendant_ids(go); meshrefs=[g for i in ids for g in mf.get(i,[])]; matrefs=[g for i in ids for g in mr.get(i,[])]
 summary[label]={'rootGameObjectFileID':go,'gameObjectCount':len(ids),'meshFilterCount':len(meshrefs),'uniqueMeshGuidCount':len(set(g for g in meshrefs if g)),'resolvedMeshGuidCount':len(set(g for g in meshrefs if g and g in idx)),'materialReferenceCount':len(matrefs),'uniqueMaterialGuidCount':len(set(matrefs)),'resolvedMaterialGuidCount':len(set(g for g in matrefs if g in idx)),'meshGuids':sorted(set(g for g in meshrefs if g)),'materialGuids':sorted(set(matrefs))}
# Main stage's material and texture references
main_mat_guids=summary['182_SuperD']['materialGuids']; material_records=[]; texture_guids=collections.Counter()
for g in main_mat_guids:
 p=idx.get(g)
 if not p or not p.exists(): continue
 s=p.read_text(errors='replace')
 shader=re.search(r'm_Shader:\s*\{[^}]*guid:\s*([0-9a-f]{32})',s)
 tex_refs=[]
 for block in re.findall(r'\w+:\s*\n\s*m_Texture:\s*\{([^}]+)\}',s):
  gm=re.search(r'guid:\s*([0-9a-f]{32})',block)
  if gm: tex_refs.append(gm.group(1)); texture_guids[gm.group(1)]+=1
 material_records.append({'guid':g,'path':str(p.relative_to(proj)),'name':(re.search(r'^  m_Name: (.*)$',s,re.M).group(1) if re.search(r'^  m_Name: (.*)$',s,re.M) else p.stem),'shaderGuid':shader.group(1) if shader else None,'textureGuids':tex_refs})
texture_records=[]
for g,count in texture_guids.items():
 p=idx.get(g); texture_records.append({'guid':g,'references':count,'path':str(p.relative_to(proj)) if p else None,'exists':bool(p and p.exists())})
# mesh inventory from referenced GUIDs
mesh_inventory=[]
for g in summary['182_SuperD']['meshGuids']:
 p=idx.get(g); rec={'guid':g,'path':str(p.relative_to(proj)) if p else None,'exists':bool(p and p.exists())}
 if p and p.exists():
  s=p.read_text(errors='replace'); m=re.search(r'm_VertexCount:\s*(\d+)',s); rec['vertexCount']=int(m.group(1)) if m else 0
  ib=re.search(r'm_IndexBuffer:\s*([0-9a-fA-F]+)',s); rec['indexBufferBytes']=len(ib.group(1))//2 if ib else 0
  rec['meshName']=re.search(r'^  m_Name: (.*)$',s,re.M).group(1) if re.search(r'^  m_Name: (.*)$',s,re.M) else p.stem
 mesh_inventory.append(rec)
# Validate each referenced Mesh vertex/index buffer directly from AssetRipper YAML.
mesh_probe_records=[probe(proj / rec['path']) for rec in mesh_inventory if rec.get('path') and rec.get('exists')]
mesh_validation={'meshCount':len(mesh_probe_records),'totalVertices':sum(x['vertexCount'] for x in mesh_probe_records),'totalSubmeshIndices':sum(x['submeshIndexCount'] for x in mesh_probe_records),'allLayoutsValid':all(x['layoutValid'] for x in mesh_probe_records),'allSubmeshRangesValid':all(x['submeshRangesValid'] for x in mesh_probe_records),'allAttributesFinite':all(x['nonFiniteAttributeRows']==0 for x in mesh_probe_records),'invalidLayoutCount':sum(not x['layoutValid'] for x in mesh_probe_records),'invalidSubmeshCount':sum(not x['submeshRangesValid'] for x in mesh_probe_records)}
(out/'mesh_decode_report.json').write_text(json.dumps({'summary':mesh_validation,'meshes':mesh_probe_records},ensure_ascii=False,indent=2),encoding='utf-8')
# CSV
with (out/'stage_mesh_inventory.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['meshName','guid','path','vertexCount','indexBufferBytes','exists']); w.writeheader(); w.writerows(mesh_inventory)
with (out/'stage_material_inventory.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['name','guid','path','shaderGuid','textureCount']); w.writeheader(); w.writerows([{'name':x['name'],'guid':x['guid'],'path':x['path'],'shaderGuid':x['shaderGuid'],'textureCount':len(x['textureGuids'])} for x in material_records])
with (out/'stage_texture_inventory.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['guid','references','path','exists']); w.writeheader(); w.writerows(texture_records)
result={'mainStageRoot':'182_SuperD','nestedStageRoot':'Stage_001930','subtrees':summary,'mainStageMaterials':material_records,'mainStageTextures':texture_records,'mainStageMeshInventory':mesh_inventory,'mainStageUniqueMaterialCount':len(main_mat_guids),'mainStageTextureGuidCount':len(texture_guids),'mainStageResolvedTextureCount':sum(1 for g in texture_guids if g in idx),'meshDecodeValidation':mesh_validation}
(out/'stage_resource_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
md=['# SCSP 舞台资源分析（182_superd）','',f'- 场景：`{args.scene}`','- 主舞台根节点：`182_SuperD`','- 舞台主体节点：`Stage_001930`','', '## 主要统计','', '| 项目 | 数量 |','|---|---:|',f"| 主舞台 GameObject | {summary['182_SuperD']['gameObjectCount']} |",f"| 舞台主体 GameObject | {summary['Stage_001930']['gameObjectCount']} |",f"| 舞台 MeshFilter | {summary['182_SuperD']['meshFilterCount']} |",f"| 唯一 Mesh GUID | {summary['182_SuperD']['uniqueMeshGuidCount']} |",f"| 已解析 Mesh 资源 | {summary['182_SuperD']['resolvedMeshGuidCount']} |",f"| 材质种类 | {summary['182_SuperD']['uniqueMaterialGuidCount']} |",f"| 已解析材质 | {summary['182_SuperD']['resolvedMaterialGuidCount']} |",f"| 贴图 GUID | {result['mainStageTextureGuidCount']} |",f"| 已解析贴图 | {result['mainStageResolvedTextureCount']} |",f"| Mesh 顶点总数 | {mesh_validation['totalVertices']:,} |",f"| 子网格索引总数 | {mesh_validation['totalSubmeshIndices']:,} |",f"| Mesh 数据布局有效 | {'是' if mesh_validation['allLayoutsValid'] else '否'} |",f"| 索引范围全部有效 | {'是' if mesh_validation['allSubmeshRangesValid'] else '否'} |",f"| 顶点属性无非数值 | {'是' if mesh_validation['allAttributesFinite'] else '否'} |",'', '## 另一个独立根节点','',f"`EffectPlayer`：{summary['EffectPlayer']['gameObjectCount']} 个 GameObject、{summary['EffectPlayer']['meshFilterCount']} 个 MeshFilter、{summary['EffectPlayer']['uniqueMeshGuidCount']} 个唯一 Mesh GUID。它包含特效相关对象，V1 默认不并入静态舞台。",'', '## 重要说明','', '- 本阶段已完成场景层级与 GUID 资源索引。','- 已验证主舞台 789 个 Mesh 的 VertexData 布局、索引范围和顶点属性数值。','- 尚未生成 FBX 或 PMX；材质 Shader 到 MMD 材质的映射仍需单独实现。','']
(out/'stage_resource_report.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['mainStageMaterials','mainStageTextures','mainStageMeshInventory']},ensure_ascii=False,indent=2))
