#!/usr/bin/env python3
"""Probe and validate AssetRipper Unity YAML Mesh vertex/index buffers.
Uses only Python standard library. It does not export a model yet.
"""
from pathlib import Path
import argparse, collections, json, math, re, struct

FMT = {0:('f',4),1:('e',2),2:('B',1),3:('b',1),4:('H',2),5:('h',2),6:('B',1),7:('b',1),8:('H',2),9:('h',2),10:('I',4),11:('i',4)}

def scalar(s,key,default=None):
 m=re.search(r'^\s*'+re.escape(key)+r':\s*([^\n]+)',s,re.M)
 return m.group(1).strip() if m else default

def parse_channels(s):
 m=re.search(r'm_Channels:\s*\n(.*?)(?=\n\s*m_DataSize:)',s,re.S)
 if not m:return []
 out=[]
 for a,b,c,d in re.findall(r'- stream: (\d+)\n\s+offset: (\d+)\n\s+format: (\d+)\n\s+dimension: (\d+)',m.group(1)):
  # AssetRipper 2.0 bug: dimension is serialized as a byte; keep only low nibble.
  out.append({'stream':int(a),'offset':int(b),'format':int(c),'dimension':int(d)&0x0F,'rawDimension':int(d)})
 return out

def parse_submeshes(s):
 m=re.search(r'm_SubMeshes:\s*\n(.*?)(?=\n\s*m_Shapes:)',s,re.S)
 if not m:return []
 blocks=re.split(r'(?=\n\s*- serializedVersion:)', '\n'+m.group(1))
 out=[]
 for b in blocks:
  if 'indexCount:' not in b:continue
  d={}
  for k in ['firstByte','indexCount','topology','baseVertex','firstVertex','vertexCount']:
   mm=re.search(r'^\s*'+k+r':\s*(-?\d+)',b,re.M)
   if mm:d[k]=int(mm.group(1))
  out.append(d)
 return out

def decode_values(buf,offset,fmt,dim):
 code,size=FMT[fmt]
 try:return struct.unpack_from('<'+code*dim,buf,offset)
 except struct.error:return None

def probe(path):
 s=path.read_text(encoding='utf-8-sig',errors='replace')
 if not re.search(r'^Mesh:\s*$',s,re.M):return None
 name=(re.search(r'^  m_Name: (.*)$',s,re.M) or [None,path.stem])[1]
 vc=int(scalar(s,'m_VertexCount','0') or 0)
 data_match=re.search(r'_typelessdata:\s*([0-9a-fA-F]*)',s)
 raw=bytes.fromhex(data_match.group(1)) if data_match else b''
 idx_match=re.search(r'm_IndexBuffer:\s*([0-9a-fA-F]*)',s)
 idxraw=bytes.fromhex(idx_match.group(1)) if idx_match else b''
 channels=parse_channels(s); submeshes=parse_submeshes(s)
 active=[c for c in channels if c['dimension']>0]
 strides=collections.defaultdict(int)
 for c in active:strides[c['stream']]=max(strides[c['stream']],c['offset']+c['dimension']*FMT[c['format']][1])
 # Unity 2018+ stream packing: each stream starts at 16-byte aligned offset.
 stream_offsets={}; cur=0
 ordered_streams=sorted(strides)
 for si,st in enumerate(ordered_streams):
  stream_offsets[st]=cur; cur += vc*strides[st]
  if si < len(ordered_streams)-1: cur=(cur+15)&~15
 expected=cur if strides else 0
 # Most meshes here use one stream. Validate buffer dimensions without silently decoding a bad layout.
 layout_ok=(len(raw)>=expected and all(c['format'] in FMT for c in active))
 attrs={}; bad_values=0; nonfinite_values=0
 if layout_ok and len(strides)==1:
  st=next(iter(strides)); stride=strides[st]; base=stream_offsets[st]
  for c in active:
   if c['stream']!=st:continue
   vals=[]
   for vi in range(vc):
    v=decode_values(raw,base+vi*stride+c['offset'],c['format'],c['dimension'])
    if v is None:bad_values+=1;continue
    if not all(math.isfinite(float(x)) for x in v): nonfinite_values+=1
    vals.append(v)
   attrs[c['stream']*16+active.index(c)]={'channel':active.index(c),'dimension':c['dimension'],'format':c['format'],'count':len(vals),'sample':list(vals[0]) if vals else None}
 # index decoding
 index_format=int(scalar(s,'m_IndexFormat','0') or 0); index_size=2 if index_format==0 else 4
 index_count=len(idxraw)//index_size
 if index_size==2: indices=struct.unpack('<'+'H'*index_count,idxraw) if index_count else ()
 else: indices=struct.unpack('<'+'I'*index_count,idxraw) if index_count else ()
 max_index=max(indices) if indices else -1
 sub_ok=True; sub_index_count=0
 for sub in submeshes:
  count=sub.get('indexCount',0); first=sub.get('firstByte',0)//index_size; basev=sub.get('baseVertex',0)
  sub_index_count+=count
  if first+count>index_count:sub_ok=False;continue
  if count and max((indices[i]+basev for i in range(first,first+count)),default=-1)>=vc:sub_ok=False
 # Positions range
 pos_range=None
 pos_channel=next((c for c in active if channels.index(c)==0),None)
 if pos_channel and layout_ok and len(strides)==1:
  st=pos_channel['stream']; stride=strides[st]; vals=[]
  for vi in range(vc):
   v=decode_values(raw,stream_offsets[st]+vi*stride+pos_channel['offset'],pos_channel['format'],pos_channel['dimension'])
   if v: vals.append(v[:3])
  if vals:pos_range=[[min(v[i] for v in vals) for i in range(3)],[max(v[i] for v in vals) for i in range(3)]]
 return {'name':name,'path':str(path),'vertexCount':vc,'vertexDataBytes':len(raw),'expectedVertexDataBytes':expected,'strideByStream':dict(strides),'channels':channels,'layoutValid':layout_ok,'attributeDecodeBadValues':bad_values,'nonFiniteAttributeRows':nonfinite_values,'indexFormat':index_format,'indexBytes':len(idxraw),'indexCount':index_count,'maxIndex':max_index,'submeshCount':len(submeshes),'submeshIndexCount':sub_index_count,'submeshRangesValid':sub_ok,'positionRange':pos_range,'submeshes':submeshes}

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('--guids-json'); ap.add_argument('--out',default='mesh_decode_report.json'); a=ap.parse_args()
 proj=Path(a.project).resolve(); assets=proj/'Assets'
 if a.guids_json:
  data=json.loads(Path(a.guids_json).read_text(encoding='utf-8')); guids=data['subtrees']['182_SuperD']['meshGuids']
  idx={}
  for mp in assets.rglob('*.meta'):
   m=re.search(r'guid: ([0-9a-f]{32})',mp.read_text(errors='replace'))
   if m:idx[m.group(1)]=Path(str(mp)[:-5])
  files=[idx[g] for g in guids if g in idx]
 else:files=list(assets.rglob('*.asset'))
 records=[]
 for p in files:
  r=probe(p)
  if r:records.append(r)
 sigs=collections.Counter(tuple((c['stream'],c['offset'],c['format'],c['dimension']) for c in r['channels'] if c['dimension']) for r in records)
 report={'meshCount':len(records),'totalVertices':sum(r['vertexCount'] for r in records),'allLayoutsValid':all(r['layoutValid'] for r in records),'allSubmeshRangesValid':all(r['submeshRangesValid'] for r in records),'allAttributesFinite':all(r['nonFiniteAttributeRows']==0 for r in records),'totalSubmeshIndices':sum(r['submeshIndexCount'] for r in records),'invalidLayoutCount':sum(not r['layoutValid'] for r in records),'invalidSubmeshCount':sum(not r['submeshRangesValid'] for r in records),'nonFiniteAttributeRows':sum(r['nonFiniteAttributeRows'] for r in records),'layoutSignatures':[{'count':n,'channels':sig} for sig,n in sigs.most_common()],'meshes':records}
 out=Path(a.out).resolve();out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in report.items() if k!='meshes'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
