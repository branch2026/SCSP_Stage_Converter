#!/usr/bin/env python3
# SCSP_Stage_To_PMX - Stage resource analyzer (V1.0-dev)
# Python 3.10+; standard library only.
from __future__ import annotations
import argparse, collections, json, re, sys
from pathlib import Path

DOC_RE = re.compile(r'(?=^--- !u!\d+ &)', re.M)
HEADER_RE = re.compile(r'^--- !u!(\d+) &(\d+)', re.M)
GUID_RE = re.compile(r'guid: ([0-9a-fA-F]{32})')
FILEID_RE = re.compile(r'fileID:\s*(-?\d+)')


def parse_scalar(text, key, default=None):
    m = re.search(r'^\s*'+re.escape(key)+r':\s*(.*?)\s*$', text, re.M)
    return m.group(1).strip(' "') if m else default


def parse_fileid(text, key, default=0):
    m = re.search(r'^\s*'+re.escape(key)+r':\s*\{fileID:\s*(-?\d+)', text, re.M)
    if m: return int(m.group(1))
    v = parse_scalar(text, key, None)
    try: return int(v) if v is not None else default
    except ValueError: return default


def parse_vec(text, key, default=None):
    m = re.search(r'^\s*'+re.escape(key)+r':\s*\{([^}]+)\}', text, re.M)
    if not m: return default
    vals = {}
    for k,v in re.findall(r'([A-Za-z]+):\s*([^,]+)', m.group(1)):
        try: vals[k] = float(v.strip())
        except ValueError: pass
    return vals or default


def split_docs(text):
    out=[]
    for d in DOC_RE.split(text):
        h=HEADER_RE.match(d)
        if h: out.append((int(h.group(1)), int(h.group(2)), d))
    return out


def main():
    ap=argparse.ArgumentParser(description='Analyze an AssetRipper Unity scene project for SCSP stage conversion.')
    ap.add_argument('project', help='Unity project root containing Assets/')
    ap.add_argument('--scene', default='Assets/182_superd.unity')
    ap.add_argument('--out', default='StageAnalyzer_Output')
    args=ap.parse_args()
    project=Path(args.project).resolve(); assets=project/'Assets'; scene_path=project/args.scene
    if not assets.is_dir(): raise SystemExit(f'Assets folder not found: {assets}')
    if not scene_path.is_file(): raise SystemExit(f'Scene file not found: {scene_path}')
    out=Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)

    # GUID -> source asset path index
    guid_index={}; meta_count=0; duplicate_guids=[]
    for mp in assets.rglob('*.meta'):
        meta_count += 1
        try: s=mp.read_text(encoding='utf-8-sig', errors='replace')
        except OSError: continue
        m=GUID_RE.search(s)
        if m:
            g=m.group(1).lower(); target=Path(str(mp)[:-5])
            if g in guid_index: duplicate_guids.append({'guid':g,'first':str(guid_index[g].relative_to(project)),'duplicate':str(target.relative_to(project))})
            else: guid_index[g]=target

    # Parse scene objects
    scene_text=scene_path.read_text(encoding='utf-8-sig', errors='replace')
    docs=split_docs(scene_text); class_counts=collections.Counter(x[0] for x in docs)
    objects={}; transforms={}; meshfilters={}; renderers={}; component_to_go={}
    for cls,fid,d in docs:
        if cls==1:
            name=parse_scalar(d,'m_Name',f'GameObject_{fid}')
            comps=[int(x) for x in re.findall(r'- component: \{fileID: (-?\d+)\}',d)]
            objects[fid]={'fileID':fid,'name':name,'active':parse_scalar(d,'m_IsActive','1')!='0','components':comps,'transform':None}
            for c in comps: component_to_go[c]=fid
        elif cls==4:
            go=parse_fileid(d,'m_GameObject',0)
            children=[int(x) for x in re.findall(r'- \{fileID: (-?\d+)\}', re.search(r'm_Children:\s*\n(.*?)(?=\n\s*m_Father:)',d,re.S).group(1))] if re.search(r'm_Children:\s*\n(.*?)(?=\n\s*m_Father:)',d,re.S) else []
            transforms[fid]={'fileID':fid,'gameObject':go,'position':parse_vec(d,'m_LocalPosition',{}),'rotation':parse_vec(d,'m_LocalRotation',{}),'scale':parse_vec(d,'m_LocalScale',{}),'children':children,'father':parse_fileid(d,'m_Father',0)}
        elif cls==33:
            go=parse_fileid(d,'m_GameObject',0)
            m=re.search(r'm_Mesh:\s*\{([^}]+)\}',d)
            ref={}
            if m:
                ref={k:v for k,v in re.findall(r'(fileID|guid|type):\s*([^, }]+)',m.group(1))}
                if 'guid' in ref: ref['guid']=ref['guid'].lower()
            meshfilters[fid]={'fileID':fid,'gameObject':go,'mesh':ref}
        elif cls==23:
            go=parse_fileid(d,'m_GameObject',0)
            mats=[]
            mm=re.search(r'm_Materials:\s*\n(.*?)(?=\n\s*m_StaticBatchInfo:)',d,re.S)
            if mm:
                for entry in re.findall(r'- \{([^}]+)\}',mm.group(1)):
                    mats.append({k:v for k,v in re.findall(r'(fileID|guid|type):\s*([^, }]+)',entry)})
            renderers[fid]={'fileID':fid,'gameObject':go,'materials':mats,'enabled':parse_scalar(d,'m_Enabled','1')!='0'}

    # Link transforms to objects
    transform_by_go={}
    for tid,t in transforms.items():
        transform_by_go[t['gameObject']]=tid
        if t['gameObject'] in objects: objects[t['gameObject']]['transform']=tid
    # Build child lists using father links (more reliable than serialized children)
    child_by_parent=collections.defaultdict(list)
    for tid,t in transforms.items():
        if t['father'] in transforms: child_by_parent[t['father']].append(tid)
    go_by_transform={t['fileID']:t['gameObject'] for t in transforms.values()}
    def tree_for_go(go_id, depth=0, seen=None):
        if seen is None: seen=set()
        if go_id in seen: return {'name':objects.get(go_id,{}).get('name','?'),'cycle':True}
        seen.add(go_id)
        o=objects.get(go_id,{'name':f'GameObject_{go_id}','active':True,'components':[],'transform':None})
        node={'fileID':go_id,'name':o['name'],'active':o['active'],'components':o['components'],'children':[]}
        tid=o.get('transform')
        if tid in transforms:
            t=transforms[tid]; node.update({'localPosition':t['position'],'localRotation':t['rotation'],'localScale':t['scale']})
            for ctid in child_by_parent.get(tid,[]):
                cgo=go_by_transform.get(ctid)
                if cgo is not None: node['children'].append(tree_for_go(cgo,depth+1,seen.copy()))
        return node
    roots=[]
    for tid,t in transforms.items():
        if t['father']==0 and t['gameObject'] in objects: roots.append(t['gameObject'])
    # Mesh/material references per renderer GO
    mf_by_go=collections.defaultdict(list); mr_by_go=collections.defaultdict(list)
    for x in meshfilters.values(): mf_by_go[x['gameObject']].append(x)
    for x in renderers.values(): mr_by_go[x['gameObject']].append(x)
    mesh_guids=collections.Counter(); material_guids=collections.Counter(); unresolved_mesh=[]; unresolved_mat=[]; mesh_objects=[]
    for go_id,o in objects.items():
        for mf in mf_by_go.get(go_id,[]):
            ref=mf['mesh']; g=ref.get('guid')
            if g:
                mesh_guids[g]+=1
                mesh_objects.append({'gameObject':o['name'],'gameObjectFileID':go_id,'meshFileID':mf['fileID'],'guid':g,'path':str(guid_index[g].relative_to(project)) if g in guid_index else None})
                if g not in guid_index: unresolved_mesh.append(g)
        for mr in mr_by_go.get(go_id,[]):
            for mat in mr['materials']:
                g=mat.get('guid')
                if g:
                    material_guids[g]+=1
                    if g not in guid_index: unresolved_mat.append(g)
    # Scan asset Mesh YAML names, vertex/index counts, data presence
    mesh_asset_records=[]
    for p in assets.rglob('*.asset'):
        try: s=p.read_text(encoding='utf-8-sig',errors='replace')
        except OSError: continue
        if not re.search(r'^Mesh:\s*$',s,re.M): continue
        name=parse_scalar(s,'m_Name',p.stem)
        vc=int(parse_scalar(s,'m_VertexCount','0') or 0)
        ib=re.search(r'm_IndexBuffer:\s*([0-9a-fA-F]+)',s)
        ds=int(parse_scalar(s,'m_DataSize','0') or 0)
        submeshes=[]
        for block in re.findall(r'- serializedVersion: 2\n(.*?)(?=\n\s*- serializedVersion: 2|\n\s*m_Shapes:)',s,re.S):
            submeshes.append({'indexCount':int(parse_scalar(block,'indexCount','0') or 0),'topology':int(parse_scalar(block,'topology','0') or 0),'firstByte':int(parse_scalar(block,'firstByte','0') or 0)})
        mesh_asset_records.append({'name':name,'path':str(p.relative_to(project)),'vertexCount':vc,'indexBufferBytes':len(ib.group(1))//2 if ib else 0,'vertexDataBytes':ds,'submeshes':submeshes})
    # Outputs
    hierarchy={'scene':str(scene_path.relative_to(project)),'roots':[tree_for_go(g) for g in roots], 'objectCount':len(objects),'transformCount':len(transforms)}
    (out/'scene_hierarchy.json').write_text(json.dumps(hierarchy,ensure_ascii=False,indent=2),encoding='utf-8')
    report={'project':str(project),'scene':str(scene_path.relative_to(project)),'sceneBytes':scene_path.stat().st_size,'yamlDocuments':len(docs),'classCounts':dict(class_counts),'gameObjects':len(objects),'transforms':len(transforms),'meshFilters':len(meshfilters),'meshRenderers':len(renderers),'metaFiles':meta_count,'guidIndexEntries':len(guid_index),'duplicateGuids':duplicate_guids,'uniqueMeshGuids':len(mesh_guids),'meshGuidReferences':sum(mesh_guids.values()),'resolvedMeshGuids':sum(1 for g in mesh_guids if g in guid_index),'unresolvedMeshGuids':sorted(set(unresolved_mesh)),'uniqueMaterialGuids':len(material_guids),'materialGuidReferences':sum(material_guids.values()),'resolvedMaterialGuids':sum(1 for g in material_guids if g in guid_index),'unresolvedMaterialGuids':sorted(set(unresolved_mat)),'meshAssetFiles':len(mesh_asset_records),'meshAssetsReferenced':sum(1 for x in mesh_objects if x['path']),'meshAssetSamples':mesh_asset_records[:30]}
    (out/'analysis_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'mesh_references.json').write_text(json.dumps(mesh_objects,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# SCSP Stage Resource Analyzer Report','',f"- Scene: `{report['scene']}`",f"- Scene size: {report['sceneBytes']:,} bytes",f"- YAML documents: {report['yamlDocuments']:,}",'', '## Scene structure','',f"- GameObjects: {len(objects):,}",f"- Transforms: {len(transforms):,}",f"- MeshFilters: {len(meshfilters):,}",f"- MeshRenderers: {len(renderers):,}",'', '## Resource references','',f"- META files: {meta_count:,}",f"- GUID index entries: {len(guid_index):,}",f"- Unique Mesh GUIDs: {len(mesh_guids):,}",f"- Mesh GUIDs resolved: {report['resolvedMeshGuids']:,}",f"- Unique Material GUIDs: {len(material_guids):,}",f"- Material GUIDs resolved: {report['resolvedMaterialGuids']:,}",f"- Mesh `.asset` files found: {len(mesh_asset_records):,}",'', '## Class ID counts','']
    for k,v in sorted(class_counts.items()): lines.append(f'- Class ID {k}: {v:,}')
    lines += ['', '## Important limitations','', '- This analyzer indexes references and scene hierarchy; it does not yet decode all Unity vertex buffer formats or write PMX.', '- Some scene objects may reference built-in Unity resources or prefab-linked objects outside this scene file.', '- Material shader conversion will require a separate mapping to MMD material properties.', '']
    (out/'analysis_report.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['yamlDocuments','gameObjects','transforms','meshFilters','meshRenderers','metaFiles','guidIndexEntries','uniqueMeshGuids','resolvedMeshGuids','uniqueMaterialGuids','resolvedMaterialGuids','meshAssetFiles']},indent=2))
    print('Output:',out)

if __name__=='__main__': main()
