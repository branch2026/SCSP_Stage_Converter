# -*- coding: utf-8 -*-
"""Discover AssetRipper scene-project folders inside stage folders.

The batch workflow selects one or more stage folders, not individual .unity files.
Each stage folder may contain either:
  <stage folder>/scene-project/Assets
or already be a scene-project root:
  <stage folder>/Assets
A small bounded fallback search supports one or two extra wrapper directories.
"""
from __future__ import annotations

import os
from pathlib import Path

_IGNORED_DIRS = {
    ".git", "__pycache__", "library", "temp", "obj", "logs",
    "packagescache", "user settings", "pmx_output_gui",
}
_MAX_SEARCH_DEPTH = 4


def is_scene_project(path: Path) -> bool:
    return path.is_dir() and (path / "Assets").is_dir()


def find_scene_project(stage_folder: str | Path) -> Path:
    """Return the unique AssetRipper project root contained in stage_folder.

    Prefer the conventional direct child named ``scene-project``. If no direct
    match exists, search only a few wrapper levels and fail clearly on ambiguity.
    """
    stage_folder = Path(stage_folder).expanduser().resolve()
    if not stage_folder.is_dir():
        raise FileNotFoundError(f"舞台文件夹不存在：{stage_folder}")

    # The selected folder itself may already be an AssetRipper scene-project.
    if is_scene_project(stage_folder):
        return stage_folder

    preferred = stage_folder / "scene-project"
    if is_scene_project(preferred):
        return preferred.resolve()

    found: list[Path] = []
    base_depth = len(stage_folder.parts)
    for current, dirnames, _filenames in os.walk(stage_folder):
        current_path = Path(current)
        depth = len(current_path.parts) - base_depth
        if depth >= _MAX_SEARCH_DEPTH:
            dirnames[:] = []
        else:
            dirnames[:] = [
                name for name in dirnames
                if name.casefold() not in _IGNORED_DIRS
                and not name.startswith(".")
            ]

        if current_path == stage_folder:
            continue
        if is_scene_project(current_path):
            found.append(current_path.resolve())
            # Do not descend into a discovered project; continue only with its
            # siblings so genuinely ambiguous project roots can still be found.
            dirnames[:] = []

    # De-duplicate paths (case-insensitively for Windows paths).
    unique: dict[str, Path] = {}
    for item in found:
        unique[str(item).casefold()] = item

    if not unique:
        raise FileNotFoundError(
            f"没有找到 AssetRipper scene-project（需要包含 Assets 文件夹）：{stage_folder}"
        )
    if len(unique) > 1:
        paths = "\n".join(str(x) for x in unique.values())
        raise RuntimeError(
            "该舞台文件夹中发现多个 scene-project，无法自动判断应使用哪一个：\n" + paths
        )
    return next(iter(unique.values()))


def find_unity_scenes(project_root: str | Path) -> list[Path]:
    """Find all Unity scene files below the project's Assets directory."""
    project_root = Path(project_root).expanduser().resolve()
    assets = project_root / "Assets"
    if not assets.is_dir():
        raise FileNotFoundError(f"项目根目录下找不到 Assets：{project_root}")
    scenes = [
        path.resolve()
        for path in assets.rglob("*")
        if path.is_file() and path.suffix.lower() == ".unity"
    ]
    return sorted(scenes, key=lambda p: str(p).casefold())


def discover_stage_folders(common_root: str | Path) -> list[dict]:
    """Inspect the selected common parent and return valid child stage folders.

    If the selected directory is itself a stage folder/project, it is returned as
    a single entry. Otherwise only its immediate child folders are considered,
    matching the user's requested multi-folder selection workflow.
    """
    common_root = Path(common_root).expanduser().resolve()
    if not common_root.is_dir():
        raise FileNotFoundError(f"共同父目录不存在：{common_root}")

    try:
        project = find_scene_project(common_root)
    except (FileNotFoundError, RuntimeError):
        project = None

    if project is not None:
        folders = [common_root]
    else:
        folders = sorted(
            (p for p in common_root.iterdir() if p.is_dir() and not p.name.startswith(".")),
            key=lambda p: p.name.casefold(),
        )

    results: list[dict] = []
    for folder in folders:
        entry = {
            "stage_folder": folder.resolve(),
            "project_root": None,
            "scenes": [],
            "error": "",
        }
        try:
            project_root = project if folder == common_root and project is not None else find_scene_project(folder)
            scenes = find_unity_scenes(project_root)
            entry["project_root"] = project_root
            entry["scenes"] = scenes
            if not scenes:
                entry["error"] = "Assets 中没有找到 .unity 场景文件"
        except Exception as exc:
            entry["error"] = str(exc)
        results.append(entry)
    return results
