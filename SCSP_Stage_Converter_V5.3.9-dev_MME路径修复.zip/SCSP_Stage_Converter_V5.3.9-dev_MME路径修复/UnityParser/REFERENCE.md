# 技术参考

- `scsp_mmd_tools` README：<https://github.com/patchouliwxy/scsp_mmd_tools>
  - 参考其 Blender 后台批处理、分阶段日志、纯 Python PMX IO、贴图相对路径、坐标/UV/面绕序转换与回读验证。
  - 其输入是 SCSP 角色 FBX；本项目输入是 AssetRipper Unity Scene/Assets，因此不能直接套用角色预处理逻辑。
- `scsp_mmd_tools/Tools/pmx_io.py`：<https://raw.githubusercontent.com/patchouliwxy/scsp_mmd_tools/main/Tools/pmx_io.py>
  - 参考 PMX 2.0/2.1 的数据结构与二进制字段布局；本项目的静态舞台 writer 独立实现，没有复制该文件源码。
- `scsp_mmd_tools/Tools/ufbx_importer.py`：<https://raw.githubusercontent.com/patchouliwxy/scsp_mmd_tools/main/Tools/ufbx_importer.py>
  - 参考 ufbx bridge 与 Blender Mesh/材质/层级构建方式。舞台原始 Mesh 不经过 FBX 时，不需要使用该导入器。
- AssetRipper Issue #1706：<https://github.com/AssetRipper/AssetRipper/issues/1706>
  - 记录 Mesh `ChannelInfo.dimension` 被序列化成 52 而不是 4 的问题。本项目按 byte 低四位解析。
- Unity Mesh Vertex Data 文档：<https://docs.unity.com/en-us/engine/6000.0/manual/assets-and-media/asset-types/mesh/get-started-with-meshes/anatomyofa/vertex-data>
  - 参考 Position、Normal、Tangent、Color 与 UV 等顶点属性概念。

许可证说明：本项目当前仅参考该仓库的公开架构与 PMX 格式实现思路，没有复制其 GPL-3.0 的 PMX IO 源码；若未来直接复用其代码，发布或分发时必须遵守 GPL-3.0。
