# SCSP Stage Converter V5.3.9-dev · Auto Stage Restoration

MME 路径修复包启用自动还原与 MME 预览时，用场景编号和舞台根名称替代输出目录中的日文标签。例如 `過純性ブリーチ__032_kjunbl__032_KjunBL` 会输出为 `032_kjunbl__032_KjunBL`。任务队列仍显示原名。为便于 MMD/MME 读取，输出根目录可使用 `G:/STAGE/PMX` 这类 ASCII 路径。

MME 材质修复包将替换重复屏幕后留下的零面材质移到末尾，并同步更新 EMD 的材质索引。打开 `AutoStage/MME_Preview` 中的 PMX，载入同目录的「屏幕播放时长」VMD。保留同目录的 EMD、FX 和 `textures`。

V5.3.9 按 Unity 实际绑定识别兼容的 A/B 屏幕。实测新增 019_FuySOS，使用 SOS 自己的 4 段视频，按 Timeline 还原 6 次播放；原演出空档保留。032_KjunBL 的转换和播放方式见随包说明。

V5.3.8 修正 MME 屏幕图集换行和循环接缝的取样，避免误采到黑色填充。批量转换、FFmpeg 设置和 MMD 播放步骤见《032_KjunBL_屏幕动画使用说明.txt》。

V5.3.7 自动从 032_KjunBL 的三段 CRI 视频提取嵌入的 VP9 图像流，恢复游戏原屏幕网格并按原 Timeline 播放。FFmpeg 从 PATH 查找，也可通过 SCSP_FFMPEG 指定 exe。此版的动态图集每帧为 256×156，保留 30 fps，退场最后一帧延续至源播放区间结束。

V5.3.6 在 AutoStage_Report.json 中记录 Unity 实际绑定的 CriMana 视频片段、对应屏幕、原始时间、帧率和循环标记。该版不生成 CRI 视频播放，保留已经验收的静态画面。

V5.3.5 撤销 032_KjunBL 的 SOS 临时画面。032_KjunBL 对应《過純性ブリーチ》，使用 KjunBL_in、KjunBL_loop 和 KjunBL_out 三段 CRI 视频。当前尚未转换这三段视频。

V5.3.4 为 121_ForbiP 补回原厂玫瑰静态屏幕画面。143_Future 恢复 B 地板分层策略，保留滚动 VMD。

V5.3.3 在 121_ForbiP 的 AutoStage PMX 和 MME_Preview PMX 隐藏未绑定的 CriMana 视频面和重合点阵层。报告列出该工程的 CRI 视频源。此版未导出视频播放。

V5.3.2 将 121_ForbiP 长灯条的原点阵遮罩应用到 MME_Preview 的 PMX 网格，整块矩形从模型几何中去掉。输出继续携带滚动光照 FX。

V5.3.1 修复 121_ForbiP 的长灯条白板。MME 使用源点阵贴图的透明度限制滚动光照的可见范围，透明处不写深度。这两张源 PNG 均为静态贴图，光照通过 MME 时间轴滚动。

V5.3 批量按场景名与网格层级识别舞台根对象，证据不足的场景列为待确认，其他舞台继续加入队列。MME 预览自动读取 EffectPlayer 的普通演出启动标记，并为支持的滚动光照网格恢复原贴图、UV 速度和亮度。批量报告可直接打开效果 PMX 和效果报告。启动标记的覆盖数是实际写进 MME 的绑定数，画面仍需验收。

V5.2 自动还原 172_SleepN 的独立喷泉网格。工具按 Timeline 启动绑定恢复喷泉主体、透明水柱、三层流动水面、三圈涟漪和三片照明网格，并使用对应的源贴图。进入 MME_Preview 后从第 0 帧播放即可检查。滚动叠色、水柱变形与扰动采用 MME 近似，喷泉主体暂使用源底色贴图。

V5.1 新增 Sleepless Nights 的喷泉水花。匹配相同源材质和支持的圆锥粒子发射器，再读取 Timeline 启动标记。效果分为池面飞沫、底部水花、中央喷溅，使用源贴图、寿命、发射速率、大小、透明度和重力。圆锥内随机分布采用近似。打开 MME_Preview 中的舞台 PMX，从第 0 帧开始播放即可检查。

V5.0 新增 Summer Night Paradise 的镜头环形水纹。源粒子跟随 LiveCamera，在约 23.73 秒触发。生成包保留原环形网格、六格水纹图集、扰动贴图、0.6 秒寿命和扩散曲线。MMD 中的镜头前摆放和纹理叠合采用近似。打开 MME_Preview，跳到第 716 或 719 帧可查看效果。它由 MME 时间轴触发。

V5.1 新增以 Unity 网格粒子呈现的舞台光束。Summer Night Paradise 的普通演出轨道在约 52.18 秒和 96.70 秒启动两组光束。打开 167_NightP 的 MME_Preview，播放或跳到第 1568、2902 帧即可检查。使用源光束网格、原遮罩、初始颜色和发射间隔。扇形随机方向采用确定性近似，独立的光束停止控制仍待支持。

V4.8 新增 Fading Stars 的循环闪粉。工具根据源材质、圆锥发射形状、发射速率、色彩范围和生命周期匹配。闪粉自动随 MMD 时间轴播放，圆锥内的随机分布和漂移为近似。粒子数量写入 AutoStage_Report.json，匹配结果和适用材质写入 MME_Preview_Report.json。

V5.1 新增池边气泡，以 172_SleepN 作为验收样本。匹配由源材质和粒子组件参数决定。在批量转换生成的 MME_Preview 打开 PMX 并播放时间轴，气泡会按 Unity 的发射曲线循环出现、上升和消失。预览使用源气泡图集、寿命、大小、速度和透明度，随机分布和粒子运动采用近似。AutoStage_Report.json 的 particle_systems 记录每个场景的粒子组件总数、转换数和待处理数。

当滚动轨道全部由 MME 驱动时，配套 VMD 使用零权重关键帧保留播放长度。灯光和滚动继续由同目录 FX 随时间轴执行。

V5.1 的 MME_Preview 支持打开同目录 PMX 后直接播放或拖动时间轴。已经绑定到 FX 的灯面滚动、灯光时序及水面波纹随时间自动更新。其他显隐表情使用本目录的 VMD。灯光版 PMX、同名 EMD、FX 和贴图应整目录保留。

新增匹配 Unity 的 Giken/3d/LightEffect 发光材质，按源 LightScale 近似亮度。Karma 的水平波纹拆成独立材质并在地板之后叠加，镜面继续使用原材质。

V5.1 将已解析的舞台灯光时序导出到 MME_Preview。打开配套 PMX 后可播放已有舞台 VMD，也可直接拖动 MMD 时间轴检查点光。

批量设置中的「自动去除地板黑影」默认开启。处理后的模型在 AutoStage，使用 MME 时打开 AutoStage/MME_Preview。工具根据地板材质和网格检测关闭相关投影标志，并移除可确认的贴地乘算阴影面。Karma 中已匹配的波纹地板层会微量抬高，并在 MME 中按加算光纹绘制。贴图自带的阴影与外部 MME 效果取决于对应的贴图或效果设置。处理明细写入 AutoStage_Report.json 的 floor_shadow_cleanup。

本开发版给批量转换增加基于 Unity 光源和灯面材质的 MME 舞台照明。屏幕视频仍用单张图集与 UV 表情切换。182_SuperD 与 143_Future 的已验收地板分层随批量转换自动应用。双击 RUN_GUI.bat，确认「自动还原舞台效果」和「另存 MME 效果试验包」已勾选。两项首次启动默认开启，批量照明输出到每个舞台的 AutoStage/MME_Preview。用 MMD932 打开此目录的 PMX，选中舞台后载入已有的同目录 VMD。

本版本对照场景材质 GUID、着色器参数声明、PMX 材质槽和主贴图，自动生成主贴图 UV 位移表情。动作默认长 180 秒，以 30 fps 采样，Y 方向按 Unity 到 PMX 的 UV 翻转处理。速度单位按每秒纹理周期近似。导出的占位 shader 无法还原原游戏的逐像素计算。

独立光照贴图滚动读取 Unity _LightTex、缩放、偏移与速度，将源贴图复制到效果包，并使用 PMX 第一组追加 UV 与子纹理坐标。已有主贴图和原 UV 保留。子纹理是普通 MMD 的渲染近似，Unity 加算、强度、遮罩和 HDR 发光仍需其他渲染支持。报告中的 light_textures 列出每个滚动光照贴图的来源和跳过原因。

工具会检查地板材质的高度和覆盖范围，在 possible_floor_overlap 中列出可能相互重叠的面。这个检查基于水平投影范围，只能提示风险。143_Future 的地板几何与已经用 MMD932 和 VMD 验收的 B 版输入匹配时，效果 PMX 自动应用相同的地板层间距。182_SuperD 的地砖和徽标三角面匹配已验收布局时，工具仅将徽标面沿 Y 轴上移 0.2 PMX 单位。新版本的地板分层会写入 floor_repair 和 GUI 日志。

Timeline 激活轨道按单次从零播放生成材质透明度表情。转换器从 Playable Director 找到绑定的物件，并核对该物件的渲染材质是否由这部分几何独占。片段内显示，片段之间隐藏。切换点在 30 fps 下使用相邻两帧，避免整段渐变。报告中的 timeline_activation 记录绑定和跳过原因。

AnimationClip 显隐通过 Playable Director 的 Animator 绑定查找相对物件路径。当前支持单个有限动画片段、片段内偏移及播速、None 和 Hold 外推。目标物件需位于导出舞台根内，并具备可独立控制的 PMX 材质槽。animation_clip_visibility 记录原曲线和跳过原因。多片段混合、循环和自定义脚本待支持。

当单片段绑定了同一父物件下的两组互补灯面时，转换器会检查两组静态网格的材质与贴图，并把它们追加到效果 PMX。两组完全相同的底座只添加一次。主贴图保留，独立 _LightTex 使用追加 UV 滚动。AutoStage_Report.json 的 external_lights 记录新增网格、材料槽和跳过原因。普通 MMD 的子纹理用于近似光照层，Unity 加算、强度和 HDR 着色待还原。

screen_sources 会报告屏幕或捕获物件的材质、源图、APNG 帧数、相机目标贴图，以及只能追到脚本的捕获连接。发现捕获组件不等于追到了视频源。当屏幕已有经 Timeline 校验的显隐控制时，会额外生成屏幕切换验收 VMD，把前两次切换压缩到第 30 和 90 帧。常规舞台 VMD 保留原时间。动态画面仍需要实际输入与 MME 播放方案。

在 GUI 点击「替换屏幕画面…」，依次选择对应的 AutoStage_Report.json、静态 PNG 和输出目录。必须能确认唯一的捕获屏幕材质，生成独立效果包，保留原动作与屏幕显隐。PNG 作为静态输入，视频、APNG 动画和副相机信号仍待支持。
命令行也可使用 py -3 -m StageEffects.screen_input --package AutoStage --image input.png --out ScreenTest。多个已验证材质时可用 --material 指定。
        
在 GUI 点击「屏幕序列动画…」，选择 AutoStage_Report.json 和连续编号的同尺寸静态 PNG 文件夹，例如 frame_001.png、frame_002.png。每张画面默认停 5 个 MMD 帧。序列从舞台第 0 帧开始循环计时，屏幕按原关键帧隐藏时露出下层画面。输入 2 至 120 张图，实际容量还取决于原 PMX 剩余贴图和材质索引。输出是独立 PMX 和配套 VMD，正式和验收动作请分别单独加载。支持 PNG 帧序列，实时副相机及原 MV 视频源待接入。

命令行用法为 py -3 -m StageEffects.screen_sequence --package AutoStage --frames PNG目录 --out ScreenSequence --step 5。

「导入屏幕视频…」读取本地视频、起点秒数、时长和每张画面对应的 MMD 帧数。使用已安装的 ffmpeg.exe，默认 5 帧一张即每秒 6 张。画面默认按原屏幕贴图比例缩放，也可指定 9:16 等实际屏幕比例。比例不同处以黑边填充。视频取出的画面循环播放，原显隐曲线决定可见时段。视频导入在一个屏幕材质内切换 UV，保留原来的透明度控制。图集上限 4096×4096，过长时可缩短片段或降低取帧数量。输出包含 PMX、正式 VMD 和可用时的验收 VMD。视频音轨、实时副相机和 Unity 原画面追踪不在此输入功能内。

命令行用法为 py -3 -m StageEffects.screen_video --package AutoStage --video clip.mp4 --out ScreenVideo --start 0 --duration 4 --step 5 --aspect 9:16 --ffmpeg ffmpeg.exe。

勾选「另存 MME 效果试验包」，在 AutoStage/MME_Preview 打开 PMX。配套 EMD 指向工具按源参数生成的 FX，需要安装 MikuMikuEffect。包括加算、按 Alpha 的加算、透明、预乘透明、乘算、镂空和部分独立光照贴图加亮。主图与材质对应不明时，工具跳过相关材质。新增效果使用同目录的 PNG，匹配结果和材质槽写入 MME_Preview_Report.json。

- `Prism/Effect/Water` 读取 `_Distortion`、`_DistortionSpeed` 和 `_DistortionStrength`，在播放或拖动时间轴时扰动水面主纹理。用材质的 `_ScatteringColor`、`_SpecularColor` 和 `_TextureColorInfluence` 近似水体底色和高光。游戏运行时的反射、折射和波面形变仍待比对。
- `167_NightP` 的地灯光斑读取源图集中的渐隐区，按亮度控制混合透明度。预览仍使用源光照纹理的滚动。
- `167_NightP` 的绿色球灯保留光图变化，并用材质色补足暗面。池畔道具的乘算阴影采用较低强度，原阴影轮廓跟随贴图。
- `167_NightP` 的浮具读取 Unity 全局反射设置指向的 EXR 烘焙探针，由批量转换中选定的 Blender 转为 MME 使用的 DDS。粗糙度使用近似混合。命令行另加 `--mme-preview --blender <Blender.exe>` 可导出。探针无法转换时仍可生成其余命中的效果。
- `167_NightP` 匹配到灯光专用贴图的两个光片材质在 MME 预览 PMX 中排到实体之后，用加算混合。场景环境色用于抬升浮具反射暗部。普通 PMX 的材质顺序沿用原导出。
- 批量照明读取 Unity 的方向光、点光和聚光灯。可确认的 Timeline 普通镜头轨道和 Effect Play Marker 用于启动灯组，再应用 AnimationClip 的显隐、强度、颜色、范围和本地位置曲线。没有匹配曲线的灯采用源场景初始值。灯光旋转、Focus 镜头分支、实时阴影和光束体积待支持。
- 已转换的时序按 30 FPS 写入同目录的 StageLightTimeline.dds，由 MME 跟随 MMD 时间轴采样。时序贴图需与 FX 保存在一起。报告记录源标记、动画片段、受光材质和开关帧。
- `121_ForbiP` 可对照约 108 秒至 122.45 秒的烛光淡出，`180_KarmaD` 可对照第 100、101、141、142 帧的 A、B 灯组切换。
- 已匹配的独立静态光照贴图可直接生成 MME 灯面，已有滚动灯面的 UV 动作继续通过同目录 VMD 播放。每个舞台的 AutoStage_Report.json 记录光源、命中的受光与发光材质数量，以及跳过原因。
- `Giken/3d/Texture_Cutoff` 读取 `_AlphaTex` 红色通道，按照 `_Cutoff` 阈值镂空。可在 Summer Night Paradise 的树叶、遮罩道具和泳池同机位对照。
命令行可在 StageEffects.auto_restore 加 --mme-preview。

texture_audit 区分 PMX 贴图路径不可用、Unity 主贴图与当前绑定的文件不同、源贴图文件缺失，以及存在但尚未转换的发光层、子贴图和遮罩。一份效果包有可能因缺失基础贴图而只输出报告。

处理已有 PMX 时，可在本目录运行以下命令，输出目录应为新目录。

```
py -3 -m StageEffects.auto_restore --project "源工程/scene-project" --scene "Assets/场景.unity" --pmx "导出的舞台.pmx" --out "AutoStage" --frames 5400 --scale 12.5
```

已有 PMX 的 --scale 必须与原导出比例一致。GUI 直接使用该次导出比例。

旧版手工配置仍可在 GUI 中单独启用。
