# -*- coding: utf-8 -*-
"""Resolve and normalize PMX texture references without rebuilding model data.

The native MMD Tools exporter can write absolute Windows paths into the PMX
texture table. This module resolves every reference against the stage output,
then rewrites only that PMX string table to portable relative paths.
"""
from __future__ import annotations

from pathlib import Path

from pmx_texture_table import read_texture_table_bytes, rewrite_texture_table
from texture_path_repair import repair_texture_references


class PMXTexturePipelineError(RuntimeError):
    pass


def normalize_pmx_texture_paths(pmx_path, texture_dir=None):
    """Return a detailed report after resolving and, if needed, rewriting refs.

    This function does not rewrite any vertex, index, material, bone, morph,
    rigid-body, or joint data. The PMX table writer preserves all bytes outside
    the texture string table.
    """
    pmx_path = Path(pmx_path).resolve()
    texture_dir = Path(texture_dir or (pmx_path.parent / "textures")).resolve()
    original_bytes = pmx_path.read_bytes()
    before = read_texture_table_bytes(original_bytes)
    original_refs = list(before["textures"])

    resolution = repair_texture_references(pmx_path, original_refs, texture_dir)
    report = {
        "status": resolution["status"],
        "pmx": str(pmx_path),
        "texture_dir": str(texture_dir),
        "texture_count": len(original_refs),
        "original_references": original_refs,
        "resolution": resolution,
        "rewrite": {"status": "NOT_NEEDED", "rewritten_count": 0},
        "final_validation": None,
        "normalized_references": list(resolution.get("normalized_references", original_refs)),
        "changed": False,
        "original_pmx_bytes": len(original_bytes),
    }

    if resolution["status"] != "PASSED":
        report["status"] = "FAILED"
        report["failure_stage"] = "resolve"
        return report

    normalized_refs = list(resolution["normalized_references"])
    rewrite_attempted = False
    try:
        if normalized_refs != original_refs:
            rewrite_attempted = True
            rewrite_report = rewrite_texture_table(
                pmx_path, original_refs, normalized_refs
            )
            report["rewrite"] = rewrite_report
            report["changed"] = True

        after = read_texture_table_bytes(pmx_path.read_bytes())
        if after["textures"] != normalized_refs:
            raise PMXTexturePipelineError(
                "PMX texture table read-back differs from the normalized references."
            )

        final_validation = repair_texture_references(
            pmx_path, after["textures"], texture_dir
        )
        report["final_validation"] = final_validation
        report["normalized_references"] = after["textures"]
        report["final_pmx_bytes"] = pmx_path.stat().st_size

        if final_validation["status"] != "PASSED":
            raise PMXTexturePipelineError(
                "Final PMX texture references did not resolve: {} unresolved, {} ambiguous.".format(
                    final_validation["unresolved_count"],
                    final_validation["ambiguous_count"],
                )
            )

        report["status"] = "PASSED"
        report["failure_stage"] = None
        return report

    except Exception:
        # A failed post-write verification must not leave a partially changed
        # PMX. Restore the exact native-exported bytes before propagating.
        if rewrite_attempted:
            rollback_path = pmx_path.with_name(pmx_path.name + ".rollback.tmp")
            try:
                rollback_path.write_bytes(original_bytes)
                rollback_path.replace(pmx_path)
                report["rolled_back"] = True
            finally:
                try:
                    if rollback_path.exists():
                        rollback_path.unlink()
                except OSError:
                    pass
        raise
