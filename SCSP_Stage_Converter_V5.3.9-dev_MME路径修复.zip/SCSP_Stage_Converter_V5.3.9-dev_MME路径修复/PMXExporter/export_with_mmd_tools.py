# -*- coding: utf-8 -*-
"""
SCSP Stage Converter V2.2.2-dev — MMD Tools native PMX exporter.

Run by Blender after opening a rebuilt .blend:
  blender --background --disable-autoexec <stage_rebuilt.blend> ^
    --python-exit-code 1 --python export_with_mmd_tools.py -- ^
    --input <stage_rebuilt.blend> --output <stage.pmx> --name <GameObject> ^
    --scale 12.5 --report <report.json> --log <native_export.log>

This script deliberately uses MMD Tools' own PMX writer. The old SCSP custom
binary writer is retained only as a legacy reference and is not called.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import traceback
from pathlib import Path

import bpy

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from mmd_tools_bridge import load_mmd_tools
from pmx_texture_pipeline import normalize_pmx_texture_paths


def safe_filename(value):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(value)).strip(" .")
    return value[:100] or "SCSP_Stage"


def restore_file_bytes(path, payload):
    """Atomically restore a file from an in-memory byte-exact snapshot."""
    path = Path(path)
    temp_path = path.with_name(path.name + ".restore.tmp")
    try:
        temp_path.write_bytes(payload)
        temp_path.replace(path)
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except OSError:
            pass


def parse_args():
    import argparse
    parser = argparse.ArgumentParser(description="SCSP MMD Tools native PMX exporter")
    parser.add_argument("--input", required=True, help="Rebuilt Blender .blend file")
    parser.add_argument("--output", required=True, help="Output PMX path")
    parser.add_argument("--name", default="", help="PMX model name / Unity root name")
    parser.add_argument("--scale", type=float, default=12.5, help="MMD Tools export scale")
    parser.add_argument("--report", required=True, help="JSON report path")
    parser.add_argument("--log", required=True, help="Internal exporter log path")
    parser.add_argument("--prepared-blend", default="", help="Optional prepared .blend path")
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    return parser.parse_args(argv)


def image_extension(image, source_path=None):
    if source_path:
        ext = source_path.suffix.lower()
        if ext:
            return ext
    ext = Path(str(getattr(image, "filepath", "") or "")).suffix.lower()
    if ext:
        return ext
    formats = {
        "PNG": ".png",
        "JPEG": ".jpg",
        "JPG": ".jpg",
        "TARGA": ".tga",
        "BMP": ".bmp",
        "TIFF": ".tif",
        "OPEN_EXR": ".exr",
        "WEBP": ".webp",
    }
    return formats.get(str(getattr(image, "file_format", "PNG")).upper(), ".png")


def copy_or_save_image(image, texture_dir, image_cache, used_names, warnings):
    """Copy external or packed image and return its exact PMX-relative path."""
    if image is None:
        return None

    pointer = int(image.as_pointer())
    if pointer in image_cache:
        return image_cache[pointer]

    raw_path = str(getattr(image, "filepath", "") or "")
    source = None
    if raw_path:
        try:
            resolved = Path(bpy.path.abspath(raw_path)).expanduser()
            if resolved.is_file():
                source = resolved.resolve()
        except Exception:
            source = None

    ext = image_extension(image, source)
    if source is not None:
        identity = str(source).lower()
        stem = safe_filename(source.stem or image.name)
    else:
        identity = "packed:{}:{}".format(image.name, pointer)
        stem = safe_filename(Path(image.name).stem or image.name)

    digest = hashlib.sha1(identity.encode("utf-8", "replace")).hexdigest()[:8]
    filename = "{}_{}{}".format(stem, digest, ext)
    if filename in used_names:
        # Keep a hash-looking tail so the name remains unique and deterministic
        # for this export even if two image datablocks point to the same source.
        second_digest = hashlib.sha1(
            (identity + ":" + str(pointer)).encode("utf-8", "replace")
        ).hexdigest()[:8]
        filename = "{}_{}{}".format(stem, second_digest, ext)
    used_names.add(filename)

    destination = texture_dir / filename
    texture_dir.mkdir(parents=True, exist_ok=True)

    try:
        if source is not None:
            if source.resolve() != destination.resolve():
                shutil.copy2(str(source), str(destination))
            # Important: point the Blender image at the exported copy, not the
            # original AssetRipper path. MMD Tools can then keep a portable path.
            image.filepath = str(destination)
        elif getattr(image, "packed_file", None) is not None:
            image.filepath_raw = str(destination)
            image.file_format = {
                ".jpg": "JPEG", ".jpeg": "JPEG", ".tga": "TARGA",
                ".bmp": "BMP", ".tif": "TIFF", ".tiff": "TIFF",
                ".exr": "OPEN_EXR", ".webp": "WEBP",
            }.get(ext, "PNG")
            image.save()
            image.filepath = str(destination)
            if not destination.is_file() or destination.stat().st_size <= 0:
                raise RuntimeError("Blender 未能写出打包贴图")
        else:
            warnings.append(
                "贴图无法定位且未打包，无法导出：{} ({})".format(image.name, raw_path)
            )
            return None

        rel = "textures/" + filename
        image_cache[pointer] = rel
        return rel
    except Exception as exc:
        warnings.append("贴图复制失败：{}: {}".format(image.name, exc))
        return None


def set_mmd_material(material, texture_dir, image_cache, used_names, warnings, fn_material):
    if material is None:
        return

    if not hasattr(material, "mmd_material"):
        raise RuntimeError("MMD Tools 材质属性未注册，请检查 MMD Tools 是否启用。")

    try:
        fn_material.convert_to_mmd_material(material, bpy.context)
    except Exception as exc:
        warnings.append("材质转换警告（{}）：{}".format(material.name, exc))

    mmd_mat = material.mmd_material
    mmd_mat.name_j = material.name
    mmd_mat.name_e = material.name

    rgba = tuple(float(x) for x in material.diffuse_color)
    if len(rgba) < 4:
        rgba = rgba[:3] + (1.0,)
    rgba = tuple(max(0.0, min(1.0, x)) for x in rgba)

    mmd_mat.diffuse_color = rgba[:3]
    mmd_mat.alpha = rgba[3]
    mmd_mat.ambient_color = tuple(max(0.0, min(1.0, x * 0.5)) for x in rgba[:3])
    mmd_mat.specular_color = (0.0, 0.0, 0.0)
    mmd_mat.shininess = 1.0
    mmd_mat.is_double_sided = not bool(getattr(material, "use_backface_culling", False))
    mmd_mat.enabled_drop_shadow = True
    mmd_mat.enabled_self_shadow_map = True
    mmd_mat.enabled_self_shadow = True
    mmd_mat.enabled_toon_edge = False
    mmd_mat.edge_weight = 0.0
    mmd_mat.sphere_texture_type = "0"
    mmd_mat.is_shared_toon_texture = False
    mmd_mat.toon_texture = ""
    mmd_mat.sphere_texture_rel_path = ""
    mmd_mat.toon_texture_rel_path = ""

    base_node = None
    if material.use_nodes and material.node_tree:
        base_node = material.node_tree.nodes.get("mmd_base_tex")

    if base_node is not None and getattr(base_node, "image", None) is not None:
        rel_path = copy_or_save_image(
            base_node.image, texture_dir, image_cache, used_names, warnings
        )
        mmd_mat.texture_rel_path = rel_path or ""
    else:
        mmd_mat.texture_rel_path = ""


def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def parsed_texture_strings(parsed):
    values = []
    for item in getattr(parsed, "textures", []):
        if isinstance(item, str):
            value = item
        else:
            value = str(getattr(item, "path", getattr(item, "name", item)))
        if value and value not in values:
            values.append(value)
    return values


def main():
    args = parse_args()
    source_blend = Path(bpy.data.filepath).resolve() if bpy.data.filepath else None
    requested_input = Path(args.input).resolve()
    output_pmx = Path(args.output).resolve()
    report_path = Path(args.report).resolve()
    log_path = Path(args.log).resolve()
    texture_dir = output_pmx.parent / "textures"
    prepared_blend = Path(args.prepared_blend).resolve() if args.prepared_blend else None

    report = {
        "status": "started",
        "source_blend": str(source_blend) if source_blend else "",
        "requested_input": str(requested_input),
        "output_pmx": str(output_pmx),
        "stage_name": safe_filename(args.name or requested_input.stem),
        "blender_version": bpy.app.version_string,
        "export_backend": "MMD Tools native bpy.ops.mmd_tools.export_pmx",
        "scale": float(args.scale),
        "warnings": [],
    }

    try:
        if source_blend is None or not source_blend.is_file():
            raise RuntimeError("Blender 当前没有打开有效的 rebuilt.blend 文件。")
        if source_blend != requested_input:
            raise RuntimeError(
                "当前 Blender 打开的文件与 --input 不一致：{} != {}".format(
                    source_blend, requested_input
                )
            )
        if not output_pmx.parent.is_dir():
            output_pmx.parent.mkdir(parents=True, exist_ok=True)
        if float(args.scale) <= 0:
            raise RuntimeError("PMX 比例必须大于 0。")

        tools = load_mmd_tools()
        package = tools["package"]
        Model = tools["model"]
        FnModel = tools["fn_model"]
        FnMaterial = tools["fn_material"]
        mmd_pmx = tools["pmx"]
        report["mmd_tools_package"] = tools["package_name"]
        report["mmd_tools_version"] = tools["version"]
        report["mmd_tools_operator_properties"] = tools["operator_properties"]

        scene = bpy.context.scene
        mesh_objects = [obj for obj in scene.objects if obj.type == "MESH"]
        if not mesh_objects:
            raise RuntimeError("当前 rebuilt.blend 中没有 Mesh 对象。")

        root_object_name = "SCSP_{}_MMD_Root".format(report["stage_name"])
        existing_roots = [
            obj for obj in bpy.data.objects
            if getattr(obj, "mmd_type", "") == "ROOT" and obj.name == root_object_name
        ]
        if existing_roots:
            raise RuntimeError(
                "当前 BLEND 已经包含同名 MMD Root。请使用原始 rebuilt.blend 重新运行。"
            )

        original_world_matrices = {
            obj.name: obj.matrix_world.copy() for obj in mesh_objects
        }
        materials = []
        seen_materials = set()
        for obj in mesh_objects:
            for slot in obj.material_slots:
                material = slot.material
                if material is not None and int(material.as_pointer()) not in seen_materials:
                    seen_materials.add(int(material.as_pointer()))
                    materials.append(material)

        report.update({
            "mesh_objects": len(mesh_objects),
            "unique_materials": len(materials),
            "source_mesh_vertices": sum(len(obj.data.vertices) for obj in mesh_objects),
            "source_mesh_polygons": sum(len(obj.data.polygons) for obj in mesh_objects),
        })

        rig = Model.create(
            report["stage_name"],
            report["stage_name"] + " Stage",
            scale=0.08,
            obj_name=root_object_name,
            add_root_bone=True,
        )
        root_obj = rig.rootObject()
        armature_obj = rig.armature()
        rig.initialDisplayFrames()

        for obj in mesh_objects:
            world_matrix = original_world_matrices[obj.name]
            if hasattr(obj, "mmd_type"):
                obj.mmd_type = "NONE"
            obj.parent = armature_obj
            obj.parent_type = "OBJECT"
            obj.matrix_world = world_matrix

        bpy.context.view_layer.update()

        texture_dir.mkdir(parents=True, exist_ok=True)
        image_cache = {}
        used_texture_names = set()
        for material in materials:
            set_mmd_material(
                material, texture_dir, image_cache, used_texture_names,
                report["warnings"], FnMaterial
            )

        texture_source_errors = [
            warning for warning in report["warnings"]
            if warning.startswith(("贴图无法定位", "贴图复制失败"))
        ]
        report["texture_source_errors"] = texture_source_errors
        if texture_source_errors:
            raise RuntimeError(
                "有贴图源文件无法复制到舞台输出目录，已停止导出以免生成缺贴图 PMX：\n"
                + "\n".join(texture_source_errors)
            )

        attached_meshes = list(FnModel.iterate_mesh_objects(root_obj))
        if len(attached_meshes) != len(mesh_objects):
            raise RuntimeError(
                "MMD Root 下可识别的 Mesh 数量不匹配：场景 {}，MMD Tools 识别 {}。".format(
                    len(mesh_objects), len(attached_meshes)
                )
            )
        if FnModel.find_armature_object(root_obj) != armature_obj:
            raise RuntimeError("MMD Tools 无法从 Root 找到 Armature。")

        bpy.ops.object.select_all(action="DESELECT")
        root_obj.select_set(True)
        bpy.context.view_layer.objects.active = root_obj

        if prepared_blend:
            prepared_blend.parent.mkdir(parents=True, exist_ok=True)
            bpy.ops.wm.save_as_mainfile(
                filepath=str(prepared_blend),
                check_existing=False,
                compress=True,
            )
            report["prepared_blend"] = str(prepared_blend)

        desired_options = {
            "filepath": str(output_pmx),
            "scale": float(args.scale),
            "copy_textures_mode": "NONE",
            "auto_texture_rel_path_depth": 0,
            "sort_materials": False,
            "disable_specular": False,
            "visible_meshes_only": False,
            "export_vertex_colors_as_adduv2": False,
            "fix_bone_order": True,
            "overwrite_bone_morphs_from_action_pose": False,
            "translate_in_presets": False,
            "normal_handling": "PRESERVE_ALL_NORMALS",
            "sort_vertices": "NONE",
            "ik_angle_limits": "IGNORE_ALL",
            "log_level": "INFO",
            "save_log": True,
        }
        operator = bpy.ops.mmd_tools.export_pmx
        operator_properties = {
            prop.identifier for prop in operator.get_rna_type().properties
        }
        export_options = {
            key: value for key, value in desired_options.items()
            if key in operator_properties
        }
        result = operator("EXEC_DEFAULT", **export_options)
        report["native_export_options"] = export_options
        report["native_export_result"] = sorted(result)

        if "CANCELLED" in result:
            raise RuntimeError("MMD Tools 原生 PMX 导出操作返回 CANCELLED。")
        if not output_pmx.is_file() or output_pmx.stat().st_size <= 0:
            raise RuntimeError("MMD Tools 没有生成有效 PMX 文件。")

        # Keep a byte-exact copy in memory so a parser rejection after the
        # texture-table rewrite can restore the original native-exported PMX.
        original_pmx_bytes = output_pmx.read_bytes()
        parsed_before = mmd_pmx.load(str(output_pmx))
        parser_counts_before = {
            "vertices": len(parsed_before.vertices),
            "faces": len(parsed_before.faces),
            "materials": len(parsed_before.materials),
            "textures": len(parsed_before.textures),
            "bones": len(parsed_before.bones),
            "morphs": len(parsed_before.morphs),
            "rigid_bodies": len(parsed_before.rigids),
            "joints": len(parsed_before.joints),
        }
        report["mmd_tools_parser_check_before_texture_rewrite"] = {
            "status": "PASSED",
            **parser_counts_before,
        }

        texture_pipeline = normalize_pmx_texture_paths(output_pmx, texture_dir)
        report["texture_path_pipeline"] = texture_pipeline
        report["texture_validation_before_rewrite"] = texture_pipeline.get("resolution", {})
        report["texture_path_rewrite"] = texture_pipeline.get("rewrite", {})
        report["texture_references_before_rewrite"] = texture_pipeline.get("original_references", [])
        report["texture_references"] = texture_pipeline.get("normalized_references", [])
        report["texture_validation"] = texture_pipeline.get("final_validation") or texture_pipeline.get("resolution", {})

        if texture_pipeline.get("status") != "PASSED":
            report["status"] = "texture_validation_failed"
            resolution = texture_pipeline.get("resolution", {})
            raise RuntimeError(
                "PMX 已导出，但贴图无法全部解析：缺失 {} 项，歧义 {} 项。".format(
                    resolution.get("unresolved_count", resolution.get("missing_count", 0)),
                    resolution.get("ambiguous_count", 0),
                )
            )

        # Confirm that MMD Tools itself can parse the PMX after the surgical
        # texture-path rewrite. If not, restore the exact original PMX bytes.
        try:
            parsed = mmd_pmx.load(str(output_pmx))
        except Exception as parse_exc:
            if texture_pipeline.get("changed"):
                restore_file_bytes(output_pmx, original_pmx_bytes)
                texture_pipeline["rolled_back_after_parser_failure"] = True
                report["texture_path_rewrite"]["status"] = "ROLLED_BACK_PARSER_FAILURE"
            texture_pipeline["status"] = "FAILED_PARSER_CHECK"
            report["texture_path_pipeline"] = texture_pipeline
            report["texture_validation"] = {
                "status": "FAILED",
                "reason": "MMD Tools parser rejected the PMX after texture-path normalization; the original PMX bytes were retained/restored.",
            }
            report["status"] = "post_rewrite_parser_failed"
            report["mmd_tools_parser_check"] = {
                "status": "FAILED",
                "error": str(parse_exc),
                "traceback": traceback.format_exc(),
            }
            raise RuntimeError(
                "MMD Tools 无法回读路径修复后的 PMX；已恢复原始导出文件。"
            ) from parse_exc

        parser_counts_after = {
            "vertices": len(parsed.vertices),
            "faces": len(parsed.faces),
            "materials": len(parsed.materials),
            "textures": len(parsed.textures),
            "bones": len(parsed.bones),
            "morphs": len(parsed.morphs),
            "rigid_bodies": len(parsed.rigids),
            "joints": len(parsed.joints),
        }
        if parser_counts_after != parser_counts_before:
            if texture_pipeline.get("changed"):
                restore_file_bytes(output_pmx, original_pmx_bytes)
                texture_pipeline["rolled_back_after_structure_mismatch"] = True
                report["texture_path_rewrite"]["status"] = "ROLLED_BACK_STRUCTURE_MISMATCH"
            texture_pipeline["status"] = "FAILED_STRUCTURE_CHECK"
            report["texture_path_pipeline"] = texture_pipeline
            report["texture_validation"] = {
                "status": "FAILED",
                "reason": "MMD Tools parser counts changed after texture-table rewrite; original PMX bytes were retained/restored.",
            }
            report["status"] = "post_rewrite_structure_mismatch"
            report["mmd_tools_parser_check"] = {
                "status": "FAILED",
                "before": parser_counts_before,
                "after": parser_counts_after,
            }
            raise RuntimeError(
                "PMX 贴图表改写前后，MMD Tools 解析到的模型结构计数发生变化；"
                "已恢复原始导出文件。"
            )

        report["mmd_tools_parser_check"] = {
            "status": "PASSED",
            **parser_counts_after,
        }
        report["mmd_tools_parser_check_after_texture_rewrite"] = {
            "status": "PASSED",
            **parser_counts_after,
        }
        report["texture_source_files"] = sorted(p.name for p in texture_dir.iterdir() if p.is_file())
        report["texture_files_total"] = len(report["texture_source_files"])
        report["output_pmx_bytes"] = output_pmx.stat().st_size

        texture_validation = report["texture_validation"]
        report["status"] = "completed"
        write_json(report_path, report)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(
            "SCSP V2.2.2 MMD Tools native export completed.\n"
            "Blender: {}\nMMD Tools: {} ({})\nSource BLEND: {}\nPMX: {}\n"
            "Mesh objects: {}\nMaterials: {}\nTextures referenced: {}\n"
            "Absolute references normalized: {}\nTexture aliases created: {}\n"
            "Texture validation: {}\n".format(
                bpy.app.version_string, tools["version"], tools["package_name"],
                source_blend, output_pmx, len(mesh_objects), len(materials),
                texture_validation.get("reference_count", 0),
                texture_pipeline.get("resolution", {}).get("normalized_absolute_count", 0),
                texture_pipeline.get("resolution", {}).get("alias_count", 0),
                texture_validation.get("status", "FAILED"),
            ),
            encoding="utf-8",
        )
        print("[SCSP V2.2.2] MMD Tools 原生 PMX 导出成功：{}".format(output_pmx))
        print("[SCSP V2.2.2] 贴图引用检查：{} / {}；绝对路径规范化 {} 项；补齐文件名 {} 项".format(
            texture_validation.get("resolved_count", 0),
            texture_validation.get("reference_count", 0),
            texture_pipeline.get("resolution", {}).get("normalized_absolute_count", 0),
            texture_pipeline.get("resolution", {}).get("alias_count", 0),
        ))
        print("[SCSP V2.2.2] 报告：{}".format(report_path))
        return 0

    except Exception:
        report["status"] = report.get("status", "failed")
        if report["status"] == "started":
            report["status"] = "failed"
        report["error"] = traceback.format_exc()
        try:
            write_json(report_path, report)
        except Exception:
            pass
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text(report["error"], encoding="utf-8")
        except Exception:
            pass
        print("[SCSP V2.2.2] PMX 导出失败：")
        print(report["error"])
        raise


if __name__ == "__main__":
    main()
