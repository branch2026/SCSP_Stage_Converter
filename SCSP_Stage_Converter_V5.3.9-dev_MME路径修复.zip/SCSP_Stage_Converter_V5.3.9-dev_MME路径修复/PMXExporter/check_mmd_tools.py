# -*- coding: utf-8 -*-
"""Preflight check for MMD Tools in the selected Blender installation."""
from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path

import bpy

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from mmd_tools_bridge import load_mmd_tools


def main():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args(argv)
    report_path = Path(args.report).resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)

    report = {
        "status": "started",
        "blender_version": bpy.app.version_string,
    }
    try:
        tools = load_mmd_tools()
        report.update({
            "status": "passed",
            "mmd_tools_package": tools["package_name"],
            "mmd_tools_version": tools["version"],
            "export_operator_registered": True,
            "operator_properties": tools["operator_properties"],
        })
        print("[SCSP V2.2.2] MMD Tools 环境检查通过：{} {}".format(
            tools["package_name"], tools["version"]
        ))
    except Exception:
        report["status"] = "failed"
        report["error"] = traceback.format_exc()
        print("[SCSP V2.2.2] MMD Tools 环境检查失败")
        print(report["error"])
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        raise
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    main()
