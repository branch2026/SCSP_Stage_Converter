# -*- coding: utf-8 -*-
"""Surgical PMX texture-string table reader/rewriter.

Only the PMX texture path strings are changed. All other PMX bytes are preserved.
"""
from __future__ import annotations

import os
import struct
from pathlib import Path


class PMXTextureTableError(RuntimeError):
    pass


def _i32(data: bytes, offset: int, label: str):
    if offset < 0 or offset + 4 > len(data):
        raise PMXTextureTableError("PMX truncated while reading " + label)
    return struct.unpack_from("<i", data, offset)[0], offset + 4


def _skip(data: bytes, offset: int, size: int, label: str):
    end = offset + size
    if size < 0 or end > len(data):
        raise PMXTextureTableError("PMX truncated while skipping " + label)
    return end


def _read_string(data: bytes, offset: int, encoding: str, label: str):
    length, offset = _i32(data, offset, label + " length")
    if length < 0 or length > 64 * 1024 * 1024:
        raise PMXTextureTableError("Invalid PMX string length for " + label)
    end = _skip(data, offset, length, label)
    raw = data[offset:end]
    try:
        value = raw.decode(encoding)
    except UnicodeDecodeError as exc:
        raise PMXTextureTableError("Cannot decode PMX " + label) from exc
    return value, end


def read_texture_table_bytes(data: bytes):
    if len(data) < 9 or data[:4] != b"PMX ":
        raise PMXTextureTableError("File is not a PMX file (missing 'PMX ' header)")

    version = struct.unpack_from("<f", data, 4)[0]
    if not (1.9 <= version <= 2.1):
        raise PMXTextureTableError("Unsupported PMX version: {}".format(version))

    header_size = data[8]
    if header_size < 8:
        raise PMXTextureTableError("Invalid PMX global header size: {}".format(header_size))
    settings_start = 9
    settings_end = _skip(data, settings_start, header_size, "global settings")
    settings = data[settings_start:settings_end]
    encoding_flag = settings[0]
    additional_uv_count = settings[1]
    vertex_index_size = settings[2]
    texture_index_size = settings[3]
    bone_index_size = settings[5]

    if encoding_flag == 0:
        encoding = "utf-16-le"
    elif encoding_flag == 1:
        encoding = "utf-8"
    else:
        raise PMXTextureTableError("Unknown PMX text encoding flag: {}".format(encoding_flag))

    if additional_uv_count > 4:
        raise PMXTextureTableError("Invalid PMX additional UV count: {}".format(additional_uv_count))
    if vertex_index_size not in (1, 2, 4) or texture_index_size not in (1, 2, 4):
        raise PMXTextureTableError("Invalid PMX index size")
    if bone_index_size not in (1, 2, 4):
        raise PMXTextureTableError("Invalid PMX bone index size")

    offset = settings_end
    for label in ("model name", "model name English", "comment", "comment English"):
        _, offset = _read_string(data, offset, encoding, label)

    vertex_count, offset = _i32(data, offset, "vertex count")
    if vertex_count < 0 or vertex_count > 100_000_000:
        raise PMXTextureTableError("Invalid PMX vertex count: {}".format(vertex_count))

    # PMX 2.0 vertex layout:
    # position(3f), normal(3f), UV(2f), additional UV(4f each),
    # deform type + deform payload, edge scale(1f).
    base_vertex_bytes = 12 + 12 + 8 + additional_uv_count * 16
    for vertex_index in range(vertex_count):
        offset = _skip(data, offset, base_vertex_bytes, "vertex {} attributes".format(vertex_index))
        if offset >= len(data):
            raise PMXTextureTableError("PMX truncated before vertex deform type")
        deform_type = data[offset]
        offset += 1
        if deform_type == 0:       # BDEF1
            deform_bytes = bone_index_size
        elif deform_type == 1:     # BDEF2
            deform_bytes = bone_index_size * 2 + 4
        elif deform_type in (2, 4):  # BDEF4 / QDEF
            deform_bytes = bone_index_size * 4 + 16
        elif deform_type == 3:     # SDEF
            deform_bytes = bone_index_size * 2 + 4 + 9 * 4
        else:
            raise PMXTextureTableError(
                "Unknown PMX vertex deform type {} at vertex {}".format(deform_type, vertex_index)
            )
        offset = _skip(data, offset, deform_bytes + 4, "vertex {} deform/edge".format(vertex_index))

    index_count, offset = _i32(data, offset, "surface index count")
    if index_count < 0 or index_count > 500_000_000:
        raise PMXTextureTableError("Invalid PMX surface index count: {}".format(index_count))
    offset = _skip(data, offset, index_count * vertex_index_size, "surface indices")

    texture_table_start = offset
    texture_count, offset = _i32(data, offset, "texture count")
    if texture_count < 0 or texture_count > 10_000_000:
        raise PMXTextureTableError("Invalid PMX texture count: {}".format(texture_count))

    textures = []
    for texture_index in range(texture_count):
        value, offset = _read_string(
            data, offset, encoding, "texture {}".format(texture_index)
        )
        textures.append(value)

    return {
        "version": version,
        "encoding": encoding,
        "texture_count": texture_count,
        "textures": textures,
        "table_start": texture_table_start,
        "table_end": offset,
        "tail_bytes": len(data) - offset,
    }


def _encode_string(value: str, encoding: str):
    raw = str(value).encode(encoding)
    return struct.pack("<i", len(raw)) + raw


def rewrite_texture_table(pmx_path, expected_old_refs, new_refs):
    """Atomically rewrite only the PMX texture string table."""
    path = Path(pmx_path)
    data = path.read_bytes()
    table = read_texture_table_bytes(data)
    old_refs = list(expected_old_refs)
    new_refs = list(new_refs)

    if table["textures"] != old_refs:
        raise PMXTextureTableError(
            "PMX texture table differs from MMD Tools parser output; refusing to rewrite."
        )
    if len(old_refs) != len(new_refs) or len(new_refs) != table["texture_count"]:
        raise PMXTextureTableError(
            "Texture reference count mismatch; refusing to rewrite PMX."
        )

    encoded_table = struct.pack("<i", len(new_refs))
    for value in new_refs:
        encoded_table += _encode_string(value, table["encoding"])

    rewritten = (
        data[:table["table_start"]]
        + encoded_table
        + data[table["table_end"]:]
    )

    temp_path = path.with_name(path.name + ".texture-path.tmp")
    try:
        temp_path.write_bytes(rewritten)
        # Validate the new table before replacing the original.
        check = read_texture_table_bytes(temp_path.read_bytes())
        if check["textures"] != new_refs:
            raise PMXTextureTableError("Post-write PMX texture table verification failed.")
        os.replace(str(temp_path), str(path))
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except OSError:
            pass

    return {
        "status": "PASSED",
        "rewritten_count": len(new_refs),
        "old_table_bytes": table["table_end"] - table["table_start"],
        "new_table_bytes": len(encoded_table),
        "preserved_tail_bytes": table["tail_bytes"],
        "encoding": table["encoding"],
        "references": new_refs,
    }
