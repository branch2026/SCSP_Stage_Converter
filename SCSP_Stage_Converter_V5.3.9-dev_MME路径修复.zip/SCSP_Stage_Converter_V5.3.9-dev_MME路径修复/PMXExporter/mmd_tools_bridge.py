﻿# -*- coding: utf-8 -*-
"""Load and validate the installed MMD Tools Blender extension."""
from __future__ import annotations

import importlib
import bpy


CANDIDATE_PACKAGES = (
    "bl_ext.blender_org.mmd_tools",
    "bl_ext.user_default.mmd_tools",
    "mmd_tools",
)


def load_mmd_tools():
    errors = []
    for package_name in CANDIDATE_PACKAGES:
        try:
            # If installed but not yet loaded in this Blender process, ask Blender
            # to enable it using the current user's saved preferences.
            try:
                bpy.ops.preferences.addon_enable(module=package_name)
            except Exception:
                # It may already be enabled, or this Blender build may expose
                # the extension without requiring addon_enable.
                pass

            package = importlib.import_module(package_name)
            model_module = importlib.import_module(package_name + ".core.model")
            material_module = importlib.import_module(package_name + ".core.material")
            pmx_module = importlib.import_module(package_name + ".core.pmx")

            operator = bpy.ops.mmd_tools.export_pmx
            operator.get_rna_type()

            return {
                "package": package,
                "model": model_module.Model,
                "fn_model": model_module.FnModel,
                "fn_material": material_module.FnMaterial,
                "pmx": pmx_module,
                "package_name": package_name,
                "version": str(getattr(package, "MMD_TOOLS_VERSION", "unknown")),
                "operator_properties": [
                    prop.identifier for prop in operator.get_rna_type().properties
                ],
            }
        except Exception as exc:
            errors.append("{}: {}: {}".format(package_name, type(exc).__name__, exc))

    raise RuntimeError(
        "无法加载 MMD Tools 原生 PMX 导出器。\n"
        "请在此 Blender 4.4.3 中安装并启用 MMD Tools 4.x，保存偏好设置后重试。\n"
        + "\n".join(errors)
    )
