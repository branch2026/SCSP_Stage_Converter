﻿# Legacy Custom PMX Writer

此目录仅保留 V2.1 及更早版本的自定义 PMX 二进制写入器，供历史对照和故障分析。

SCSP Stage Converter V2.2 GUI 不会调用这里的代码。V2.2 的 PMX 输出后端是 `../export_with_mmd_tools.py`，由 Blender 中已启用的 MMD Tools 原生导出器完成。

请勿将旧写入器复制回 V2.2 主流程。
