#!/usr/bin/env python3
"""Export one reconstructed Blender stage scene to one complete static PMX."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Vector

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pmx_stage_writer import StaticStage, StageMaterial, StageVertex, save_pmx, validate_pmx


def safe_name(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(value)).strip(" .")
    return value[:80] or "SCSP_Stage"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _image_extension(image) -> str:
    suffix = Path(str(getattr(image, "filepath", "") or "")).suffix.lower()
    if suffix:
        return suffix
    return {
        "PNG": ".png", "JPEG": ".jpg", "TARGA": ".tga", "BMP": ".bmp",
        "TIFF": ".tif", "WEBP": ".webp", "OPEN_EXR": ".exr",
    }.get(str(getattr(image, "file_format", "PNG")).upper(), ".png")


def _copy_image(image, texture_dir: Path, cache: dict, used_names: set[str], warnings: list[str]) -> str | None:
    if image is None:
        return None
    key = int(image.as_pointer())
    if key in cache:
        return cache[key]
    packed = getattr(image, "packed_file", None)
    if packed is not None:
        data = bytes(packed.data)
        digest = sha256_bytes(data)
        source = None
    else:
        raw = bpy.path.abspath(str(image.filepath or ""))
        source = Path(raw) if raw else None
        if source is None or not source.is_file():
            warnings.append(f"贴图缺失或未落盘：{image.name} ({raw})")
            return None
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        data = None
    base = safe_name(Path(str(image.filepath or image.name)).stem or image.name)
    ext = _image_extension(image)
    filename = f"{base}_{digest[:8]}{ext}"
    dest = texture_dir / filename
    if filename in used_names and not dest.exists():
        filename = f"{base}_{digest[:12]}_{len(used_names)}{ext}"
        dest = texture_dir / filename
    used_names.add(filename)
    texture_dir.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        if data is not None:
            dest.write_bytes(data)
        else:
            shutil.copy2(source, dest)
    rel = "textures/" + filename
    cache[key] = rel
    return rel


def _trace_image_and_mapping(material):
    """Find the image feeding Principled Base Color and its simple UV Mapping node."""
    if not material or not material.use_nodes or not material.node_tree:
        return None, (1.0, 1.0), (0.0, 0.0), []
    nodes = material.node_tree.nodes
    bsdf = next((n for n in nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is None:
        return None, (1.0, 1.0), (0.0, 0.0), []
    base = bsdf.inputs.get("Base Color")
    if base is None or not base.links:
        return None, (1.0, 1.0), (0.0, 0.0), []
    warnings = []
    source = base.links[0].from_node
    if source.type != "TEX_IMAGE" or source.image is None:
        # Handle one simple reroute/mix-free image path; do not guess complex graphs.
        warnings.append(f"材质 {material.name} 的 Base Color 不是直接图像纹理，按纯色导出")
        return None, (1.0, 1.0), (0.0, 0.0), warnings
    image = source.image
    scale = (1.0, 1.0)
    offset = (0.0, 0.0)
    vec_input = source.inputs.get("Vector")
    if vec_input and vec_input.links:
        vector_source = vec_input.links[0].from_node
        if vector_source.type == "MAPPING":
            sc = vector_source.inputs.get("Scale")
            loc = vector_source.inputs.get("Location")
            rot = vector_source.inputs.get("Rotation")
            if sc:
                scale = (float(sc.default_value[0]), float(sc.default_value[1]))
            if loc:
                offset = (float(loc.default_value[0]), float(loc.default_value[1]))
            if rot and any(abs(float(x)) > 1e-6 for x in rot.default_value):
                warnings.append(f"材质 {material.name} 使用了 UV 旋转，当前仅导出 Scale/Offset")
        elif vector_source.type not in ("TEX_COORD", "UV_MAP"):
            warnings.append(f"材质 {material.name} 使用复杂 UV 节点，当前按原始 UV 导出")
    return image, scale, offset, warnings


def _material_properties(material, texture_dir, texture_cache, used_names, warnings):
    if material is None:
        return ("Stage_Default", (0.65, 0.65, 0.65, 1.0), -1, (1.0, 1.0), (0.0, 0.0), True)
    color = tuple(float(x) for x in material.diffuse_color)
    image, uv_scale, uv_offset, node_warnings = _trace_image_and_mapping(material)
    warnings.extend(node_warnings)
    texture_rel = _copy_image(image, texture_dir, texture_cache, used_names, warnings)
    texture_index = -1
    return (material.name, color, texture_rel, uv_scale, uv_offset, not bool(material.use_backface_culling))


def _normal_for_loop(mesh, loop_index, normal_matrix, mirrored=False):
    try:
        n = mesh.corner_normals[loop_index].vector
    except Exception:
        n = mesh.loops[loop_index].normal
    n = normal_matrix @ Vector(n)
    if mirrored:
        n.negate()
    if n.length > 1e-12:
        n.normalize()
    else:
        n = Vector((0.0, 0.0, 1.0))
    # Blender Z-up -> MMD Y-up, same axis permutation used by the referenced exporter.
    return (float(n.x), float(n.z), float(n.y))


def export_scene(input_blend: Path, output_pmx: Path, model_name: str, scale: float) -> dict:
    bpy.ops.wm.open_mainfile(filepath=str(input_blend))
    output_pmx.parent.mkdir(parents=True, exist_ok=True)
    texture_dir = output_pmx.parent / "textures"
    texture_cache: dict[int, str] = {}
    used_names: set[str] = set()
    warnings: list[str] = []
    model = StaticStage(name=model_name, comment="Static SCSP Unity stage; one complete PMX, no physics")

    # Materials are deduplicated by Blender datablock identity.
    mat_lookup: dict[int, int] = {}
    material_properties_cache: dict[int, tuple] = {}
    mat_face_lists: list[list[tuple[int, int, int]]] = []
    texture_index_lookup: dict[str, int] = {}
    vertex_cache: dict[tuple, int] = {}
    depsgraph = bpy.context.evaluated_depsgraph_get()
    mesh_objects = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    if not mesh_objects:
        raise ValueError("Blend 场景中没有 Mesh 对象")

    source_stats = []
    for obj in mesh_objects:
        obj_eval = obj.evaluated_get(depsgraph)
        mesh = obj_eval.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
        if mesh is None:
            warnings.append(f"无法取得求值网格：{obj.name}")
            continue
        try:
            mesh.calc_loop_triangles()
            if not mesh.loop_triangles:
                warnings.append(f"没有三角面的网格已跳过：{obj.name}")
                continue
            world = obj_eval.matrix_world
            normal_matrix = world.to_3x3().inverted_safe().transposed()
            mirrored = world.to_3x3().determinant() < 0.0
            uv_layer = mesh.uv_layers.active.data if mesh.uv_layers.active else None
            object_vertex_cache = {}
            face_count = 0
            for tri in mesh.loop_triangles:
                slot = int(tri.material_index)
                material = mesh.materials[slot] if 0 <= slot < len(mesh.materials) else None
                mat_key = int(material.as_pointer()) if material is not None else -1
                if mat_key not in mat_lookup:
                    name, rgba, tex_rel, uv_scale, uv_offset, double_sided = _material_properties(
                        material, texture_dir, texture_cache, used_names, warnings
                    )
                    if tex_rel:
                        if tex_rel not in texture_index_lookup:
                            texture_index_lookup[tex_rel] = len(model.textures)
                            model.textures.append(tex_rel)
                        tex_index = texture_index_lookup[tex_rel]
                    else:
                        tex_index = -1
                    # Keep names unique for PMX Editor and MMD material lists.
                    used = {m.name for m in model.materials}
                    final_name = name
                    suffix = 2
                    while final_name in used:
                        final_name = f"{name}_{suffix}"
                        suffix += 1
                    mat_lookup[mat_key] = len(model.materials)
                    material_properties_cache[mat_key] = (uv_scale, uv_offset)
                    model.materials.append(StageMaterial(
                        name=final_name,
                        diffuse=tuple(max(0.0, min(1.0, x)) for x in rgba),
                        texture_index=tex_index,
                        double_sided=double_sided,
                    ))
                    mat_face_lists.append([])
                mat_idx = mat_lookup[mat_key]
                mat = model.materials[mat_idx]
                # Resolve the same UV transform that the reconstruction material graph applied.
                if material is not None:
                    uv_scale, uv_offset = material_properties_cache[mat_key]
                else:
                    uv_scale, uv_offset = (1.0, 1.0), (0.0, 0.0)

                loop_order = (2, 1, 0) if not mirrored else (0, 1, 2)
                face_indices = []
                for corner in loop_order:
                    loop_index = tri.loops[corner]
                    loop = mesh.loops[loop_index]
                    vertex_index = int(loop.vertex_index)
                    co = world @ mesh.vertices[vertex_index].co
                    pmx_co = (float(co.x * scale), float(co.z * scale), float(co.y * scale))
                    normal = _normal_for_loop(mesh, loop_index, normal_matrix, mirrored=mirrored)
                    if uv_layer:
                        uv = uv_layer[loop_index].uv
                        u = float(uv.x) * uv_scale[0] + uv_offset[0]
                        v = float(uv.y) * uv_scale[1] + uv_offset[1]
                    else:
                        u, v = 0.0, 0.0
                    pmx_uv = (u, 1.0 - v)
                    key = (obj.as_pointer(), vertex_index,
                           round(pmx_uv[0], 6), round(pmx_uv[1], 6),
                           round(normal[0], 6), round(normal[1], 6), round(normal[2], 6))
                    pmx_vi = vertex_cache.get(key)
                    if pmx_vi is None:
                        pmx_vi = len(model.vertices)
                        vertex_cache[key] = pmx_vi
                        model.vertices.append(StageVertex(co=pmx_co, normal=normal, uv=pmx_uv))
                    face_indices.append(pmx_vi)
                if len(set(face_indices)) == 3:
                    mat_face_lists[mat_idx].append(tuple(face_indices))
                    face_count += 1
            source_stats.append({"object": obj.name, "triangles": face_count, "source_vertices": len(mesh.vertices)})
        finally:
            obj_eval.to_mesh_clear()

    # Rebuild material records in insertion order; PMX materials consume contiguous index ranges.
    for mat, faces in zip(model.materials, mat_face_lists):
        mat.index_count = len(faces) * 3
        model.faces.extend(faces)
    model.materials = [m for m in model.materials if m.index_count > 0]
    if not model.faces:
        raise ValueError("场景中没有可导出的三角面")

    report = save_pmx(output_pmx, model)
    readback = validate_pmx(output_pmx)
    # Verify every referenced texture resolves from the PMX folder.
    texture_checks = []
    for rel in model.textures:
        resolved = output_pmx.parent / Path(rel.replace("/", os.sep))
        exists = resolved.is_file()
        texture_checks.append({"pmx_path": rel, "exists": exists, "path": str(resolved)})
        if not exists:
            raise FileNotFoundError(f"PMX 贴图不存在：{resolved}")

    result = {
        "status": "completed",
        "input_blend": str(input_blend),
        "output_pmx": str(output_pmx),
        "model_name": model_name,
        "scale": scale,
        "output_mode": "one_complete_pmx_per_stage",
        "source_mesh_objects": len(mesh_objects),
        "objects": source_stats,
        "counts": report,
        "readback_validation": readback,
        "texture_checks": texture_checks,
        "warnings": sorted(set(warnings)),
        "physics": "none",
        "vertex_weighting": "all vertices BDEF1 -> 全ての親 (Root)",
    }
    return result


def parse_args():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True, help="Rebuilt .blend")
    ap.add_argument("--output", required=True, help="Output .pmx")
    ap.add_argument("--name", default="SCSP Stage")
    ap.add_argument("--scale", type=float, default=12.5)
    ap.add_argument("--report", default="")
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    return ap.parse_args(argv)


def main():
    args = parse_args()
    source = Path(args.input).resolve(strict=True)
    output = Path(args.output).resolve()
    report_path = Path(args.report).resolve() if args.report else output.with_suffix(".report.json")
    if source.suffix.lower() != ".blend":
        raise ValueError("--input 必须是 .blend 文件")
    if output.suffix.lower() != ".pmx":
        raise ValueError("--output 必须是 .pmx 文件")
    if not math.isfinite(args.scale) or args.scale <= 0:
        raise ValueError("--scale 必须是正数")
    try:
        result = export_scene(source, output, safe_name(args.name), args.scale)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print("STAGE_PMX_OK " + json.dumps(result["counts"], ensure_ascii=False))
    except Exception as exc:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps({
            "status": "failed", "input_blend": str(source), "output_pmx": str(output),
            "error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        raise


if __name__ == "__main__":
    main()
