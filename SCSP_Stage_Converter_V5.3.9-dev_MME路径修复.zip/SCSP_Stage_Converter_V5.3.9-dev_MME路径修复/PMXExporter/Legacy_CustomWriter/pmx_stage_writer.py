#!/usr/bin/env python3
"""Minimal independent PMX 2.0 writer for static MMD stages.

This module writes static meshes with one movable root bone. It intentionally
contains no character rigging, morph, rigid-body or joint generation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import struct
from typing import BinaryIO

PMX_MAGIC = b"PMX "


def _vertex_index_size(count: int) -> int:
    if count <= 0xFF:
        return 1
    if count <= 0xFFFF:
        return 2
    return 4


def _signed_index_size(count: int) -> int:
    if count < 0x80:
        return 1
    if count < 0x8000:
        return 2
    return 4


_UNSIGNED_FMT = {1: "<B", 2: "<H", 4: "<i"}
_SIGNED_FMT = {1: "<b", 2: "<h", 4: "<i"}


def _pack_text(value: str) -> bytes:
    raw = str(value or "").encode("utf-16-le")
    return struct.pack("<i", len(raw)) + raw


def _finite(values, label: str) -> tuple[float, ...]:
    out = tuple(float(v) for v in values)
    if not all(math.isfinite(v) for v in out):
        raise ValueError(f"Non-finite value in {label}")
    return out


@dataclass
class StageVertex:
    co: tuple[float, float, float]
    normal: tuple[float, float, float]
    uv: tuple[float, float]
    bone_index: int = 0
    edge_scale: float = 1.0


@dataclass
class StageMaterial:
    name: str
    diffuse: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    texture_index: int = -1
    double_sided: bool = True
    cast_shadow: bool = True
    receive_shadow: bool = True
    edge_enabled: bool = False
    index_count: int = 0


@dataclass
class StaticStage:
    name: str
    comment: str = "Static SCSP stage exported by SCSP Stage Converter"
    vertices: list[StageVertex] = field(default_factory=list)
    faces: list[tuple[int, int, int]] = field(default_factory=list)
    textures: list[str] = field(default_factory=list)
    materials: list[StageMaterial] = field(default_factory=list)


def save_pmx(path: str | Path, model: StaticStage) -> dict:
    """Write PMX 2.0 and return structural counts."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not model.vertices:
        raise ValueError("PMX stage has no vertices")
    if not model.faces:
        raise ValueError("PMX stage has no triangle faces")
    if not model.materials:
        raise ValueError("PMX stage has no materials")
    if sum(m.index_count for m in model.materials) != len(model.faces) * 3:
        raise ValueError("Material index counts do not match total face indices")
    for face in model.faces:
        if len(face) != 3 or any(i < 0 or i >= len(model.vertices) for i in face):
            raise ValueError(f"Invalid face indices: {face}")
    for v in model.vertices:
        _finite(v.co, "vertex position")
        _finite(v.normal, "vertex normal")
        _finite(v.uv, "vertex UV")
        if v.bone_index != 0:
            raise ValueError("Static stage vertices must use root bone index 0")

    v_size = _vertex_index_size(len(model.vertices))
    t_size = _signed_index_size(len(model.textures))
    m_size = _signed_index_size(len(model.materials))
    b_size = 1  # exactly one root bone
    v_fmt = _UNSIGNED_FMT[v_size]
    t_fmt = _SIGNED_FMT[t_size]
    m_fmt = _SIGNED_FMT[m_size]
    b_fmt = _SIGNED_FMT[b_size]

    with path.open("wb") as f:
        f.write(PMX_MAGIC)
        f.write(struct.pack("<fB", 2.0, 8))
        # UTF-16LE, no additional UVs, then index widths.
        f.write(bytes((0, 0, v_size, t_size, m_size, b_size, 1, 1)))
        f.write(_pack_text(model.name))
        f.write(_pack_text(model.name))
        f.write(_pack_text(model.comment))
        f.write(_pack_text(model.comment))

        # Vertices: all are BDEF1 bound to the single movable stage root.
        f.write(struct.pack("<i", len(model.vertices)))
        vertex_head = struct.Struct("<3f3f2fB")
        bone_pack = struct.Struct(b_fmt)
        f32_pack = struct.Struct("<f")
        for v in model.vertices:
            f.write(vertex_head.pack(*v.co, *v.normal, *v.uv, 0))
            f.write(bone_pack.pack(0))
            f.write(f32_pack.pack(float(v.edge_scale)))

        # Faces / vertex indices.
        f.write(struct.pack("<i", len(model.faces) * 3))
        face_pack = struct.Struct(v_fmt[0] + v_fmt[1:] * 3)
        for face in model.faces:
            f.write(face_pack.pack(*face))

        # Relative texture paths (normally textures\\filename.ext).
        f.write(struct.pack("<i", len(model.textures)))
        for texture in model.textures:
            f.write(_pack_text(texture.replace("/", "\\")))

        # Materials.
        f.write(struct.pack("<i", len(model.materials)))
        for mat in model.materials:
            f.write(_pack_text(mat.name))
            f.write(_pack_text(mat.name))
            diffuse = _finite(mat.diffuse, f"material {mat.name} diffuse")
            if len(diffuse) != 4:
                raise ValueError(f"Material {mat.name} diffuse must have 4 components")
            specular = (0.0, 0.0, 0.0)
            ambient = (0.25, 0.25, 0.25)
            shininess = 1.0
            flags = (
                (0x01 if mat.double_sided else 0)
                | (0x02 if mat.cast_shadow else 0)
                | (0x04 if mat.receive_shadow else 0)
                | (0x08 if mat.receive_shadow else 0)
                | (0x10 if mat.edge_enabled else 0)
            )
            f.write(struct.pack("<4f3ff3fB", *diffuse, *specular, shininess, *ambient, flags))
            f.write(struct.pack("<4ff", 0.0, 0.0, 0.0, 1.0, 1.0))
            f.write(struct.pack(t_fmt, int(mat.texture_index)))
            f.write(struct.pack(t_fmt, -1))  # no sphere texture
            f.write(struct.pack("<BB", 0, 0))  # sphere mode off; non-shared toon
            f.write(struct.pack(t_fmt, -1))  # no toon texture
            f.write(_pack_text(""))
            f.write(struct.pack("<i", int(mat.index_count)))

        # One movable root bone. Every stage vertex is BDEF1 weighted to it.
        f.write(struct.pack("<i", 1))
        f.write(_pack_text("全ての親"))
        f.write(_pack_text("Root"))
        f.write(struct.pack("<3f", 0.0, 0.0, 0.0))
        f.write(struct.pack(b_fmt, -1))
        f.write(struct.pack("<iH", 0, 0x001E))
        f.write(struct.pack("<3f", 0.0, 1.0, 0.0))

        # No morphs. One display frame containing the root bone.
        f.write(struct.pack("<i", 0))
        f.write(struct.pack("<i", 1))
        f.write(_pack_text("ルート"))
        f.write(_pack_text("Root"))
        f.write(struct.pack("<Bi", 0, 1))
        f.write(struct.pack("<Bb", 0, 0))

        # Static stage: no physics bodies or joints.
        f.write(struct.pack("<i", 0))
        f.write(struct.pack("<i", 0))

    if not path.is_file() or path.stat().st_size <= 64:
        raise IOError("PMX writer did not produce a valid non-empty file")
    return {
        "pmx_version": 2.0,
        "vertices": len(model.vertices),
        "faces": len(model.faces),
        "indices": len(model.faces) * 3,
        "materials": len(model.materials),
        "textures": len(model.textures),
        "bones": 1,
        "morphs": 0,
        "rigid_bodies": 0,
        "joints": 0,
        "bytes": path.stat().st_size,
    }


def validate_pmx(path: str | Path) -> dict:
    """Read back the emitted static-stage PMX structure and validate its ranges."""
    path = Path(path)
    data = path.read_bytes()
    pos = 0

    def take(n: int) -> bytes:
        nonlocal pos
        if n < 0 or pos + n > len(data):
            raise ValueError(f"PMX truncated at byte {pos}; requested {n}")
        chunk = data[pos:pos + n]
        pos += n
        return chunk

    def unpack(fmt: str):
        st = struct.Struct(fmt)
        return st.unpack(take(st.size))

    def text() -> str:
        length = unpack("<i")[0]
        if length < 0 or length % 2:
            raise ValueError("Invalid UTF-16 PMX string length")
        return take(length).decode("utf-16-le")

    if take(4) != PMX_MAGIC:
        raise ValueError("Invalid PMX signature")
    version, globals_len = unpack("<fB")
    if abs(version - 2.0) > 1e-5 or globals_len != 8:
        raise ValueError("Unexpected PMX header")
    globals_data = take(globals_len)
    if globals_data[0] != 0 or globals_data[1] != 0:
        raise ValueError("Unexpected PMX encoding or additional UV count")
    v_size, t_size, m_size, b_size, _mo_size, _rb_size = globals_data[2:8]
    if v_size not in (1, 2, 4) or t_size not in (1, 2, 4) or m_size not in (1, 2, 4) or b_size not in (1, 2, 4):
        raise ValueError("Invalid PMX index width")
    v_fmt, t_fmt, m_fmt, b_fmt = _UNSIGNED_FMT[v_size], _SIGNED_FMT[t_size], _SIGNED_FMT[m_size], _SIGNED_FMT[b_size]
    name, name_e, comment, comment_e = text(), text(), text(), text()

    vertex_count = unpack("<i")[0]
    if vertex_count <= 0:
        raise ValueError("PMX has no vertices")
    vertex_bones = []
    for _ in range(vertex_count):
        unpack("<3f3f2f")
        weight_type = unpack("<B")[0]
        if weight_type != 0:
            raise ValueError("Static-stage PMX must use BDEF1")
        vertex_bones.append(unpack(b_fmt)[0])
        unpack("<f")

    index_count = unpack("<i")[0]
    if index_count <= 0 or index_count % 3:
        raise ValueError("Invalid PMX face index count")
    face_data = take(index_count * v_size)
    face_unpack = struct.Struct(v_fmt)
    face_indices = [face_unpack.unpack_from(face_data, i * v_size)[0] for i in range(index_count)]
    if any(i < 0 or i >= vertex_count for i in face_indices):
        raise ValueError("PMX face references an invalid vertex")

    texture_count = unpack("<i")[0]
    textures = [text() for _ in range(texture_count)]
    material_count = unpack("<i")[0]
    material_index_total = 0
    for _ in range(material_count):
        text(); text()
        unpack("<4f3ff3fB")
        unpack("<4ff")
        tex_idx = unpack(t_fmt)[0]
        unpack(t_fmt)
        unpack("<BB")
        toon_shared = data[pos - 1]
        if toon_shared:
            unpack("<B")
        else:
            unpack(t_fmt)
        text()
        material_index_total += unpack("<i")[0]
        if tex_idx >= texture_count:
            raise ValueError("PMX material texture index is out of range")

    bone_count = unpack("<i")[0]
    if bone_count != 1:
        raise ValueError("Static-stage PMX must contain exactly one root bone")
    text(); text()
    unpack("<3f")
    parent = unpack(b_fmt)[0]
    unpack("<iH")
    unpack("<3f")
    if parent != -1:
        raise ValueError("Stage root bone must not have a parent")
    if any(index != 0 for index in vertex_bones):
        raise ValueError("A stage vertex is not bound to the root bone")

    morph_count = unpack("<i")[0]
    if morph_count != 0:
        raise ValueError("Static stage unexpectedly contains morphs")
    display_count = unpack("<i")[0]
    for _ in range(display_count):
        text(); text()
        unpack("<B")
        item_count = unpack("<i")[0]
        for _ in range(item_count):
            item_type = unpack("<B")[0]
            unpack(_SIGNED_FMT[_mo_size if item_type == 1 else b_size])
    rigid_count = unpack("<i")[0]
    joint_count = unpack("<i")[0]
    if rigid_count or joint_count:
        raise ValueError("Static stage unexpectedly contains physics")
    if pos != len(data):
        raise ValueError(f"Unexpected trailing PMX data: {len(data) - pos} bytes")
    if material_index_total != index_count:
        raise ValueError("PMX material index counts do not equal total face indices")
    return {
        "name": name,
        "name_e": name_e,
        "vertices": vertex_count,
        "faces": index_count // 3,
        "materials": material_count,
        "textures": textures,
        "bones": bone_count,
        "morphs": morph_count,
        "rigid_bodies": rigid_count,
        "joints": joint_count,
        "bytes": len(data),
    }
