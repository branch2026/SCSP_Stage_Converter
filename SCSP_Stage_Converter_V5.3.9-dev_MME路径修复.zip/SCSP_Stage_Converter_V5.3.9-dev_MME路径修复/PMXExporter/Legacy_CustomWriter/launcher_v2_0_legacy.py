#!/usr/bin/env python3
"""Stable explicit-input launcher for SCSP Stage Converter.

This recovery build intentionally does NOT use automatic scene/root inference.
The user selects the exact .unity scene and stage root, avoiding ambiguous
scene discovery while the conversion core is being revalidated.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
VALIDATOR = APP / "Validator" / "validate_source.py"
REBUILDER = APP / "SceneBuilder" / "rebuild_stage_blender.py"
PMX_EXPORTER = APP / "PMXExporter" / "export_stage_pmx.py"
DEFAULT_BLENDER = Path(r"C:\Dpan\MMD\Blender\blender-4.4.3-windows-x64\blender.exe")


def configure_console() -> None:
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, OSError):
            pass


def clean(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
        value = value[1:-1]
    return value.strip()


def ask_blender() -> Path:
    default = DEFAULT_BLENDER if DEFAULT_BLENDER.is_file() else None
    while True:
        prompt = "请输入 Blender 4.4.3 的 blender.exe 完整路径"
        if default:
            raw = clean(input(f"{prompt}\n直接回车使用默认路径：{default}\n> "))
            candidate = Path(raw).expanduser() if raw else default
        else:
            raw = clean(input(f"{prompt}\n> "))
            candidate = Path(raw).expanduser() if raw else None
        if candidate is not None:
            candidate = candidate.resolve()
            if candidate.is_file() and candidate.name.lower() == "blender.exe":
                return candidate
            print(f"[错误] 不是有效的 blender.exe：{candidate}")


def ask_project() -> Path:
    while True:
        raw = clean(input("\n请输入 AssetRipper scene-project 根目录（里面必须有 Assets 文件夹）：\n> "))
        if not raw:
            print("[错误] 项目目录不能为空。")
            continue
        project = Path(raw).expanduser().resolve()
        if (project / "Assets").is_dir():
            return project
        print(f"[错误] 找不到 Assets 文件夹：{project / 'Assets'}")


def ask_scene(project: Path) -> tuple[Path, str]:
    while True:
        raw = clean(input(
            "\n请输入场景相对路径（例如 Assets/185_sankaf.unity）：\n> "
        )).replace("/", os.sep).replace("\\", os.sep)
        if not raw:
            print("[错误] 场景路径不能为空；本版本不再默认使用 182_SuperD。")
            continue
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = project / candidate
        candidate = candidate.resolve()
        if candidate.suffix.lower() != ".unity":
            print("[错误] 场景文件必须以 .unity 结尾。")
            continue
        if not candidate.is_file():
            print(f"[错误] 找不到场景文件：{candidate}")
            continue
        try:
            rel = candidate.relative_to(project).as_posix()
        except ValueError:
            print("[错误] 场景文件必须位于 scene-project 目录内部。")
            continue
        return candidate, rel


def ask_root() -> str:
    while True:
        root = clean(input("\n请输入该场景中舞台根 GameObject 的准确名称：\n> "))
        if root:
            return root
        print("[错误] 根对象名称不能为空。")


def safe_name(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return value[:80] or "SCSP_Stage"


def run_logged(command: list[str], log_path: Path, cwd: Path) -> int:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    with log_path.open("w", encoding="utf-8", newline="\n") as log:
        log.write("COMMAND:\n" + subprocess.list2cmdline(command) + "\n\n")
        log.flush()
        result = subprocess.run(
            command, cwd=str(cwd), stdout=log, stderr=subprocess.STDOUT,
            env=env, check=False
        )
    return result.returncode


def show_log(path: Path) -> None:
    print(f"\n----- 日志：{path} -----")
    try:
        print(path.read_text(encoding="utf-8", errors="replace"))
    except OSError as exc:
        print(f"日志读取失败：{exc}")
    print("----- 日志结束 -----")


def wait_exit() -> None:
    try:
        input("\n按回车退出...")
    except EOFError:
        pass


def main() -> int:
    configure_console()
    print("=" * 68)
    print("SCSP Stage Converter V2.0-dev - Recovery Rebuild 1")
    print("=" * 68)
    print("稳定恢复版：使用已验证的 Milestone B 场景重建器和 PMX 写入器。")
    print("本版暂时关闭自动场景/根对象推断，要求明确输入，避免选错场景。")
    print("当前为单舞台回归测试入口；批量任务队列将在回归通过后加入。")

    blender = ask_blender()
    project = ask_project()
    scene_path, scene_rel = ask_scene(project)
    root_name = ask_root()

    output_name = safe_name(root_name)
    out_dir = project / "PMX_Output_RecoveryRebuild1" / output_name
    out_dir.mkdir(parents=True, exist_ok=True)

    out_blend = out_dir / f"{output_name}_rebuilt.blend"
    validation = out_dir / f"{output_name}_source_validation.json"
    validation_log = out_dir / f"{output_name}_source_validation.log"
    blend_log = out_dir / f"{output_name}_rebuild.log"
    pmx_path = out_dir / f"{output_name}.pmx"
    pmx_report = out_dir / f"{output_name}_pmx_report.json"
    pmx_log = out_dir / f"{output_name}_pmx_export.log"

    print("\n[输入确认]")
    print(f"Blender：{blender}")
    print(f"项目：  {project}")
    print(f"场景：  {scene_rel}")
    print(f"根对象：{root_name}")
    print(f"输出：  {out_dir}")

    print("\n[1/3] 验证 Unity 场景和资源...")
    validate_cmd = [
        sys.executable, str(VALIDATOR),
        "--project", str(project),
        "--scene", scene_rel,
        "--root", root_name,
        "--out", str(validation),
    ]
    rc = run_logged(validate_cmd, validation_log, project)
    if rc != 0:
        show_log(validation_log)
        print("[失败] Unity 源资源验证未通过；尚未启动 Blender。")
        wait_exit()
        return rc or 4
    if not validation.is_file():
        print("[失败] 验证器没有生成报告，不能继续。")
        wait_exit()
        return 4
    print(f"[通过] {validation}")

    print("\n[2/3] Blender 后台重建舞台...")
    rebuild_cmd = [
        str(blender), "--background", "--factory-startup", "--disable-autoexec",
        "--python-exit-code", "1", "--python", str(REBUILDER), "--",
        "--project", str(project), "--scene", scene_rel, "--root", root_name,
        "--out", str(out_blend), "--include-inactive",
    ]
    rc = run_logged(rebuild_cmd, blend_log, project)
    if rc != 0 or not out_blend.is_file() or out_blend.stat().st_size == 0:
        show_log(blend_log)
        print("[失败] Blender 舞台重建失败。")
        wait_exit()
        return rc or 5
    print(f"[通过] {out_blend}")

    print("\n[3/3] 导出一个完整 PMX...")
    export_cmd = [
        str(blender), "--background", "--factory-startup", "--disable-autoexec",
        "--python-exit-code", "1", "--python", str(PMX_EXPORTER), "--",
        "--input", str(out_blend), "--output", str(pmx_path),
        "--name", root_name, "--scale", "12.5", "--report", str(pmx_report),
    ]
    rc = run_logged(export_cmd, pmx_log, project)
    if rc != 0 or not pmx_path.is_file() or pmx_path.stat().st_size == 0:
        show_log(pmx_log)
        print("[失败] PMX 导出失败。")
        wait_exit()
        return rc or 6

    try:
        report = json.loads(pmx_report.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[失败] PMX 报告无法读取：{exc}")
        wait_exit()
        return 6
    if report.get("status") != "completed":
        print("[失败] PMX 报告未标记 completed；不能报告成功。")
        print(json.dumps(report, ensure_ascii=False, indent=2))
        wait_exit()
        return 6

    print("\n" + "=" * 68)
    print("[完成] 已生成一个完整舞台 PMX。")
    print(f"PMX：{pmx_path}")
    print(f"贴图：{out_dir / 'textures'}")
    print(f"报告：{pmx_report}")
    print("移动 PMX 时必须同时移动 textures 文件夹。")
    print("=" * 68)
    wait_exit()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n用户取消。")
        raise SystemExit(130)
