import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "PMXExporter"))
from pmx_stage_writer import StaticStage, StageMaterial, StageVertex, save_pmx, validate_pmx


class StaticStageWriterTests(unittest.TestCase):
    def make_vertices(self, count=4):
        base = [
            (0.0, 0.0, 0.0),
            (1.0, 0.0, 0.0),
            (1.0, 0.0, 1.0),
            (0.0, 0.0, 1.0),
        ]
        return [StageVertex(base[i] if i < 4 else (float(i), 0.0, 0.0),
                            (0.0, 1.0, 0.0), (0.0, 0.0)) for i in range(count)]

    def test_basic_static_stage_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "stage.pmx"
            model = StaticStage("Test Stage")
            model.vertices = self.make_vertices()
            model.faces = [(0, 1, 2), (0, 2, 3)]
            model.materials = [StageMaterial("Default", index_count=6)]
            save_pmx(out, model)
            check = validate_pmx(out)
            self.assertEqual(check["vertices"], 4)
            self.assertEqual(check["faces"], 2)
            self.assertEqual(check["materials"], 1)
            self.assertEqual(check["bones"], 1)
            self.assertEqual(check["rigid_bodies"], 0)

    def test_large_vertex_index_width(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "large.pmx"
            model = StaticStage("Large Stage")
            model.vertices = self.make_vertices(300)
            model.faces = [(0, 1, 2)]
            model.materials = [StageMaterial("Mat", index_count=3)]
            save_pmx(out, model)
            check = validate_pmx(out)
            self.assertEqual(check["vertices"], 300)
            self.assertEqual(check["faces"], 1)

    def test_material_index_count_must_match_faces(self):
        model = StaticStage("Bad Stage")
        model.vertices = self.make_vertices()
        model.faces = [(0, 1, 2)]
        model.materials = [StageMaterial("Mat", index_count=6)]
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                save_pmx(Path(tmp) / "bad.pmx", model)


if __name__ == "__main__":
    unittest.main()
