# -*- coding: utf-8 -*-
"""Normalize and verify MMD Tools PMX texture references.

MMD Tools 4.5.14 may write absolute Windows texture paths even when the
material's texture_rel_path is set. This module resolves those paths against the
actual exported texture files and returns portable PMX-relative paths.
"""
from __future__ import annotations

import hashlib
import re
import shutil
from pathlib import Path, PurePosixPath, PureWindowsPath


class TextureRepairError(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_absolute_reference(ref: str) -> bool:
    return Path(ref).is_absolute() or PureWindowsPath(ref).is_absolute() or bool(
        re.match(r"^[A-Za-z]:[/\\\\]", ref)
    )


def _safe_relative_path(ref: str, pmx_dir: Path):
    normalized = ref.replace("\\", "/")
    posix = PurePosixPath(normalized)
    if posix.is_absolute() or re.match(r"^[A-Za-z]:", normalized):
        return None
    target = (pmx_dir / Path(*posix.parts)).resolve()
    try:
        target.relative_to(pmx_dir.resolve())
    except ValueError:
        return None
    return posix.as_posix(), target


def _absolute_to_relative(ref: str, pmx_dir: Path, texture_dir: Path):
    """Return (relative_path, target_path, reason)."""
    source = Path(ref)
    try:
        source_resolved = source.resolve()
    except Exception:
        source_resolved = source

    # Preferred case: the absolute PMX reference points into this stage's
    # output folder. Keep the exact relative subpath and file name.
    try:
        relative = source_resolved.relative_to(pmx_dir.resolve())
        target = (pmx_dir / relative).resolve()
        if target.is_file() and target.stat().st_size > 0:
            return relative.as_posix(), target, None
    except (ValueError, OSError):
        pass

    # If an absolute reference points elsewhere but its image was already
    # copied to this stage's textures directory, compare content before reuse.
    basename = PureWindowsPath(ref).name or Path(ref).name
    local_candidate = texture_dir / basename
    if source_resolved.is_file() and local_candidate.is_file():
        if _sha256(source_resolved) == _sha256(local_candidate):
            return "textures/" + basename, local_candidate, None

    # Otherwise, copy the absolute source into the package so the PMX remains
    # portable. Never overwrite a different image with the same filename.
    if source_resolved.is_file():
        texture_dir.mkdir(parents=True, exist_ok=True)
        destination = local_candidate
        if destination.exists() and _sha256(destination) != _sha256(source_resolved):
            digest = _sha256(source_resolved)[:8]
            destination = texture_dir / (
                source_resolved.stem + "_" + digest + source_resolved.suffix
            )
        if not destination.exists():
            shutil.copy2(source_resolved, destination)
        return "textures/" + destination.name, destination, None

    return None, None, "绝对贴图路径指向的文件不存在，且输出 textures 中没有可验证的副本"


def repair_texture_references(pmx_path, texture_refs, texture_dir=None):
    """Resolve every PMX texture reference and return portable relative refs.

    Does not modify PMX bytes. The caller must pass normalized_references to
    pmx_texture_table.rewrite_texture_table, then run this function again to
    verify the rewritten relative references.
    """
    pmx_path = Path(pmx_path).resolve()
    pmx_dir = pmx_path.parent
    texture_dir = Path(texture_dir or (pmx_dir / "textures")).resolve()
    texture_dir.mkdir(parents=True, exist_ok=True)

    normalized_refs = []
    missing = []
    ambiguous = []
    aliases = []
    items = []

    for index, raw_value in enumerate(texture_refs or []):
        ref = str(raw_value or "").strip()
        if not ref:
            missing.append({"index": index, "reference": ref, "reason": "空贴图引用"})
            normalized_refs.append(ref)
            items.append({"index": index, "reference": ref, "status": "empty"})
            continue

        if _is_absolute_reference(ref):
            relative, target, reason = _absolute_to_relative(ref, pmx_dir, texture_dir)
            if relative is None:
                missing.append({"index": index, "reference": ref, "reason": reason})
                normalized_refs.append(ref)
                items.append({"index": index, "reference": ref, "status": "missing_absolute"})
                continue
            normalized_refs.append(relative)
            items.append({
                "index": index,
                "reference": ref,
                "normalized_reference": relative,
                "status": "absolute_path_normalized",
                "resolved_path": str(target),
                "bytes": target.stat().st_size,
                "sha256": _sha256(target),
            })
            continue

        safe = _safe_relative_path(ref, pmx_dir)
        if safe is None:
            missing.append({"index": index, "reference": ref, "reason": "相对路径越出 PMX 输出目录"})
            normalized_refs.append(ref)
            items.append({"index": index, "reference": ref, "status": "unsafe_path"})
            continue

        normalized_ref, target = safe
        if target.is_file() and target.stat().st_size > 0:
            normalized_refs.append(normalized_ref)
            items.append({
                "index": index,
                "reference": ref,
                "normalized_reference": normalized_ref,
                "status": "already_present",
                "resolved_path": str(target),
                "bytes": target.stat().st_size,
                "sha256": _sha256(target),
            })
            continue

        target_name = PurePosixPath(normalized_ref).name
        target_stem = Path(target_name).stem
        target_ext = Path(target_name).suffix
        hashed_pattern = re.compile(
            r"^" + re.escape(target_stem) + r"_[0-9a-fA-F]{8}(?:_\d+)?" +
            re.escape(target_ext) + r"$",
            re.IGNORECASE,
        )
        candidates = sorted(
            p for p in texture_dir.iterdir()
            if p.is_file() and hashed_pattern.match(p.name)
        )

        if len(candidates) == 1:
            source = candidates[0]
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            normalized_refs.append(normalized_ref)
            record = {
                "index": index,
                "reference": ref,
                "normalized_reference": normalized_ref,
                "status": "alias_created",
                "source_file": str(source),
                "resolved_path": str(target),
                "bytes": target.stat().st_size,
                "sha256": _sha256(target),
            }
            aliases.append(record)
            items.append(record)
        elif len(candidates) > 1:
            candidate_names = [p.name for p in candidates]
            ambiguous.append({"index": index, "reference": ref, "candidates": candidate_names})
            normalized_refs.append(normalized_ref)
            items.append({
                "index": index,
                "reference": ref,
                "status": "ambiguous_source",
                "candidates": candidate_names,
            })
        else:
            missing.append({"index": index, "reference": ref, "reason": "找不到贴图文件或唯一哈希候选"})
            normalized_refs.append(normalized_ref)
            items.append({"index": index, "reference": ref, "status": "missing"})

    unresolved = []
    for index, ref in enumerate(normalized_refs):
        safe = _safe_relative_path(ref, pmx_dir)
        if safe is None:
            unresolved.append({"index": index, "reference": ref, "reason": "无法规范化为安全相对路径"})
            continue
        _, target = safe
        if not target.is_file() or target.stat().st_size <= 0:
            unresolved.append({"index": index, "reference": ref, "reason": "规范化后的目标文件不存在"})

    result = {
        "status": "PASSED" if not missing and not ambiguous and not unresolved else "FAILED",
        "reference_count": len(normalized_refs),
        "resolved_count": len(normalized_refs) - len(unresolved),
        "normalized_references": normalized_refs,
        "absolute_reference_count": sum(1 for x in texture_refs or [] if _is_absolute_reference(str(x))),
        "normalized_absolute_count": sum(
            1 for item in items if item.get("status") == "absolute_path_normalized"
        ),
        "alias_count": len(aliases),
        "missing_count": len(missing),
        "ambiguous_count": len(ambiguous),
        "unresolved_count": len(unresolved),
        "missing": missing,
        "ambiguous": ambiguous,
        "unresolved": unresolved,
        "items": items,
    }
    return result
