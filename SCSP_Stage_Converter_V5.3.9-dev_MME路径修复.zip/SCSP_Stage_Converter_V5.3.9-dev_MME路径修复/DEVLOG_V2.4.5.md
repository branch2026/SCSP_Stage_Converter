# V2.4.5-dev 开发记录

## 开发依据
V2.4.4-dev 的 `185_SankaF` include / exclude 双模式实机报告已经证明 Mesh Scope、inactive 决策、MeshFilter component fileID 和 PMX 输出统计可以正确对应。本版不重复开发这些能力。

## 本版发现与目标
V2.4.4 对缺少法线的 Mesh 已经能列出资源、对象路径和材质，但 `SRC-005` 主要呈现总数。仅凭“缺少法线”不能判断对象是否有 Renderer、是否能看到材质引用，也不能把数据缺失直接等同于 MMD 中出现可见阴影问题。

V2.4.5 增加只读的 Renderer / 材质证据分类，让人工检查更有顺序，同时明确这不是视觉效果结论。

## 分类定义
- `RENDERER_WITH_TEXTURED_MATERIAL`：至少一个引用该 Mesh 的纳入范围对象有 Renderer，且检测到 MainTex 已分配材质。
- `RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL`：有 Renderer，材质使用信息可读，未检测到 MainTex。
- `RENDERER_MATERIAL_USAGE_UNKNOWN`：有 Renderer，但材质使用情况未知或证据不完整。
- `NO_RENDERER_DETECTED`：引用该 Mesh 的对象上没有检测到 Renderer。

优先级：检测到纹理材质 > 材质用途未知 > 已知非纹理材质。无 Renderer 仅在没有任何 Renderer occurrence 时使用。

## 保护原则
- 仅修改 Validator/quality_check.py、GUI 版本显示、测试和文档。
- SceneBuilder、PMXExporter、UnityParser 批量发现、Validator/validate_source.py、RUN_GUI.bat 均保持原字节。
- 不自动重算法线、不生成 UV、不改材质，不调整转换范围或输出几何。

## 测试记录
- V2.4.4 原始源码在当前构建环境重新运行：55 tests passed（其旧测试记录写 58；本次以实际发现数为准）。
- V2.4.5 新增 3 个分类单元测试和 1 个端到端 JSON/TXT 测试。
- 最终测试：59 tests passed。
- Windows 185_SankaF 新转换与 MMD 9.32 视觉验收仍待用户运行。
