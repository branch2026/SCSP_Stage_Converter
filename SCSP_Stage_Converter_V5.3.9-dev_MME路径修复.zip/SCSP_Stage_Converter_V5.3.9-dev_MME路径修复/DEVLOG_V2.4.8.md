# V2.4.8-dev 开发记录

## 目标

将质量报告中的 WARNING 从汇总数字提升为可追溯到 Unity 资源和 Hierarchy 的证据清单。只增加只读诊断，不修改转换逻辑。

## 数据依据

直接使用用户此前已上传的两份 V2.4.7-dev 原始报告：

- Include：`185_SankaF_quality_report(20261120-100332).json`，生成时间 18:01:48。
- Exclude：`185_SankaF_quality_report(20261120-100925).json`，生成时间 18:05:54。

不要求用户重新上传，也不重新运行舞台转换。

## 实现

1. 新增 `Validator/diagnose_warnings.py`，验证同一舞台、版本、schema 和 include/exclude 策略。
2. `SRC-005` 直接从完整 `conversionMissingNormals` / Mesh Inventory 定位 Mesh；输出 GUID/fileID、Assets 路径、GameObject / MeshFilter IDs、Hierarchy、材质/MainTex 线索。
3. `BLD-004` 使用 `objects.inactiveInHierarchyObjects` 和 `meshInventory(scope=excludedOnly)` 交叉关联全部 inactive GameObject 与 Excluded-only Mesh。
4. 按 Mesh GUID + fileID 对比两种模式的缺法线集合。
5. 未支持的 Warning ID 保留原始 details 并标记 mappingComplete=false，不猜测。
6. 增加 GUI 按钮与独立 BAT 入口；不改转换运行流程。
7. 生成 JSON/TXT，记录输入文件 SHA-256。

## 185_SankaF 回归

- Include：SRC-005 = 217/217 条目定位完整。
- Exclude：SRC-005 = 210/210 条目定位完整；BLD-004 = 311/311 inactive GameObject、133/133 Excluded-only Mesh 对应，MeshFilter component fileID = 133。
- 缺法线 Mesh 跨模式：210 共有、7 Include 独有、0 Exclude 独有。
- UV0 的 118 条为 INFO，不混入 WARNING。

## 不变更

- Unity → Blender 重建逻辑未修改。
- Blender → PMX 导出逻辑未修改。
- inactive GameObject 策略未修改。
- 不自动补法线、UV 或材质。
- 15 个 V2.4.7 受保护转换文件 SHA-256 保持不变。
