# V2.4.5-dev — Mesh Channel Risk Diagnostics 通道风险诊断增强版

## 新增
- 为缺少法线的 Mesh 增加只读证据分类：
  - `RENDERER_WITH_TEXTURED_MATERIAL`
  - `RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL`
  - `RENDERER_MATERIAL_USAGE_UNKNOWN`
  - `NO_RENDERER_DETECTED`
- 分类依据是场景中的 Renderer / 材质引用可见性；不等同于实际 MMD 阴影结果，也不代表已证明法线缺失一定造成可见错误。
- Source、Included、Excluded-only、Shared 四个范围分别统计缺少法线的证据类别。
- `SRC-005` JSON 详情增加 `normalEvidenceCounts`、`normalEvidenceNote` 和分类样本。
- TXT 报告增加法线证据分类汇总，并在每个缺失法线 Mesh 条目中标注 `normalEvidence`。
- 增加四个范围的法线证据分类数量核对，确保分类计数之和等于该范围的缺失法线数量。
- 诊断 schema 更新为 `scsp-mesh-channel-diagnostics-v5`。

## 不变
- 不修改 Unity → Blender → PMX 转换逻辑。
- 不改变 inactive GameObject 默认选项或 include / exclude 决策。
- 不修改法线、UV、材质、贴图或模型数据。
- 不改变现有 WARNING / INFO 判定阈值。
- 保留 V2.4.4 的 MeshFilter component fileID、Hierarchy / inactive 原因定位。

## 验证
- 自动化测试：59/59 通过。
- Python 源码编译检查通过。
- 15 个转换保护文件与 V2.4.4-dev SHA-256 完全一致。
- 185_SankaF 的两组 V2.4.4 Windows 报告作为历史数量基准；当前构建环境未重新执行完整 Windows 场景转换。
