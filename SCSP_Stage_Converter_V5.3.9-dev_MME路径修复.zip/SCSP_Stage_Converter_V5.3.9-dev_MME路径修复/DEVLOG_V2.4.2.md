# V2.4.2-dev 开发记录

## 问题根因
V2.4.1 对对象级诊断遍历整个舞台根层级，但 GameObject 只记录 `activeSelf`。当父 GameObject inactive、子 GameObject activeSelf=true 时，子对象实际 `activeInHierarchy=false`，诊断却可能把它误当成活动对象。与此同时，SRC-005 / SRC-006 原先依据源验证的全场景计数形成 WARNING，可能把被转换器排除的 Mesh 缺失通道问题计入转换质量。

## 解决方案
- 从舞台根对象开始沿 Transform 层级递归计算 `activeInHierarchy = parent_active AND activeSelf`。
- 以 rebuild report 的 `inactivePolicy` 作为实际转换策略：`exclude` 时仅 activeInHierarchy=true 的对象参与；`include` 时根层级内所有对象参与。
- 每个唯一 Mesh 仍只解码一次；按 GameObject 引用分配 conversionIncluded 标记。
- 一个 Mesh 只要至少被一个纳入转换的对象引用，就计入转换范围；若同时被排除对象引用，额外标记 Shared Mesh，不重复计数。
- 全场景清单和旧的源验证交叉核对保留；SRC-005 / SRC-006 改用转换范围内唯一 Mesh 的缺失数量。

## 风险控制
只修改只读质量检查器、GUI 版本标签、测试和文档。没有触碰 SceneBuilder、PMXExporter、UnityParser、源验证器或批处理启动器。

## 测试结果
- 51 项自动化测试通过。
- 新增父级 inactive / 子级 activeSelf 的层级继承测试。
- 新增共享 Mesh 跨转换纳入/排除对象的范围去重测试。
- Python 编译检查通过。

## 待用户实机验收
185_SankaF 完整工程重跑、Windows GUI 批量回归和 MMD 9.32 外观验收尚未执行。
