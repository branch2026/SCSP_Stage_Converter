# V2.4.8-dev — WARNING 精准定位增强版

## 新增

- 新增只读 `Validator/diagnose_warnings.py`，读取同一舞台 Include / Exclude 两份 V2.4.7-dev 质量报告。
- 新增 `RUN_WARNING_DIAGNOSTICS.bat`，可独立启动 WARNING 诊断窗口；主 GUI 同时增加「WARNING 精准定位…」入口。
- 对 `SRC-005 法线覆盖率`：从 `meshDiagnostics.conversionMissingNormals` 取得参与转换范围内的全部缺法线 Mesh，逐条输出 Mesh GUID/fileID、Assets 路径、顶点数、UV0 状态、normalEvidence、GameObject fileID、MeshFilter component fileID、Hierarchy 路径、材质和 MainTex 线索。
- 对 `BLD-004 inactive 对象排除`：列出全部被排除的 inactive GameObject，并关联 Excluded-only Mesh、Mesh GUID/fileID、MeshFilter component fileID、Hierarchy 路径、材质和 MainTex 线索。
- 跨模式比较 SRC-005 的 Mesh 身份集合，区分两模式共有、Include 独有和 Exclude 独有的缺法线 Mesh。
- 对尚无可靠映射的其他 WARNING，保留原始 details 并标记为未定位；不推测对象归属。
- JSON / TXT 报告记录输入文件 SHA-256、质量检查原始状态及定位完整性。

## 185_SankaF 已有报告回归结果

使用用户已上传的两份 V2.4.7-dev 报告（Include 18:01:48、Exclude 18:05:54）进行只读回归：

- Include：1 项 WARNING（SRC-005），217 个缺法线 Mesh 全部可定位。
- Exclude：2 项 WARNING（SRC-005、BLD-004）。SRC-005 定位 210 个纳入转换的缺法线 Mesh；BLD-004 定位 311 个 inactive GameObject、133 个 Excluded-only Mesh。
- SRC-005 跨模式身份对比：210 个共有、7 个 Include 独有、0 个 Exclude 独有。
- 133 个 Excluded-only Mesh 的 GUID/fileID 均可识别；MeshFilter component fileID 计数与 BLD-004 的 133 一致。
- UV0 缺失在这两份输入报告中为 INFO，不计入 WARNING。

## 安全边界

- 只读取已有 JSON；不启动 Unity、Blender 或 MMD Tools。
- 不读取、重写或修改 PMX / BLEND / Unity 场景 / 贴图。
- 不修改 Unity → Blender → PMX 转换核心、inactive 规则、Mesh、法线、UV 或材质。
- 诊断 COMPLETE 仅表示当前支持的 WARNING 已完成证据映射，不代表原始质量 WARNING 已消失或视觉效果验收通过。

## 验证

- 全套自动化回归：94/94 PASS。
- Python 编译检查：GUI 与新增诊断模块通过。
- V2.4.7 受保护转换文件：15/15 SHA-256 一致。
