# ITTW46 参考解析（只读）

`ITTW46_404_Phase_Reference_READONLY.json` 是从用户上传的 `(404)Blender.7z` 内原始 PMX/VMD 解析得到的只读数据摘录，包含 Phase1～Phase5、HeliLight、SpotX、SpotY、Rise 的材质/顶点/UV 偏移和 VMD 时间点。

它用于理解 PMX MaterialMorph 与 VMD 的配合，不是可直接应用到其他舞台的 profile。原始 ITTW46 的 PMX、VMD、贴图和第三方 FX 不包含在本工具包中。
