# V2.4.0-dev 开发记录

## 设计约束

V2.3.2-dev 已经通过用户实测实现多舞台文件夹批量添加和转换。本版不重新设计批量入口，也不触碰核心 Mesh 重建、MMD Tools PMX 导出和贴图修复代码。

## 实现方式

采用旁路式质量检查：复用 V2.3.2 转换流程已经生成的 Unity 源验证、Blender 重建和 MMD Tools 导出报告，并只读扫描 Unity Hierarchy 与 PMX 实际贴图表。这样可以在不改变 PMX 输出过程的前提下，给每个舞台生成一致的质量报告。

## 结果等级

- PASS：本次自动检查项通过。
- WARNING：存在可能影响外观或需要人工确认的内容。
- FAIL：存在结构或资源完整性问题。

质量等级与转换状态分开保存。即使质量报告为 WARNING / FAIL，已经生成的 PMX 仍会保留，批量队列继续处理下一舞台。如果转换在输出目录建立后失败，也会尽可能根据已有阶段报告生成部分质量报告。

## 本轮验证

- 在 121_ForbiP 实际 Unity 场景上运行现有 Unity 源验证：`ok=true`，152 个唯一 Mesh 引用均解码。
- 在同一场景上运行新增 Hierarchy 检查：747 个 GameObject、285 个 MeshFilter 对象、285 个 MeshRenderer 对象；没有发现 MeshFilter / MeshRenderer 配对异常、缺失材质资源、缺失 MainTex 资源或 Transform 循环。重复名称 101 组作为 INFO 提示，不判失败；空层级节点 462 个作为正常 Unity 组织节点，不判失败。
- 质量检查单元测试覆盖完整通过、缺失贴图、inactive 几何排除、ParticleSystem、源 Mesh 错误、越界贴图路径和报告写出。
- 全部 46 项自动化测试通过后再打包。

## 未完成的验收

- 尚未在用户 Windows 10 / Blender 4.4.3 / MMD Tools 4.5.14 环境完成 V2.4 GUI 端到端实机验收。
- 新增报告需要用户用真实舞台转换后确认 GUI 状态、报告内容和 MMD 9.32 打开效果。
