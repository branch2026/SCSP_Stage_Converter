# 多材质 Phase 形态键配置模板

这是一个**可编辑的演示模板**，参考了用户提供的 ITTW46 `(404) Blender` 中 Phase1～Phase5 的结构设计。它不是 ITTW46 原始舞台的可直接套用配置，也不代表任何 SCSP 原版演出时序。

## 使用

1. 复制 JSON 文件。
2. `model_name` 改成目标 PMX 的内部模型名。
3. 将两个占位材质名替换为目标 PMX 中准确的材质名；也可改用 `material_index`。
4. 修改每个材质的 `operation` 与参数。
5. 把 `keys` 改成你希望的演示/已验证时间点。
6. 将 `neutral_anchor_bone` 改成目标 PMX 中实际存在、CP932 编码不超过 15 字节的骨骼名。
7. 运行：

```bat
py -3 StageEffects\stage_effects.py build --pmx "stage.pmx" --profile "Phase_MultiMaterial_Template.json" --out "StageEffects_Phase1"
```

## PMX 材质形态键字段

- `operation: "multiply"` 对应 PMX MaterialMorph 的乘算（operation 0），未填写的通道使用乘法单位值 1。
- `operation: "add"` 对应加算（operation 1），未填写的通道使用加法单位值 0。
- `diffuse`：RGBA 四值。
- `specular`：RGB 三值。
- `shininess`：单值。
- `ambient`：RGB 三值。
- `edge_color`：RGBA 四值。
- `edge_size`：单值。
- `texture_factor`、`sphere_factor`、`toon_factor`：各 RGBA 四值。

一个 Phase morph 可同时包含多个材质槽的偏移；VMD 只需控制这一个 morph 名称。

## VMD 兼容性对照输出

若设置 `vmd.neutral_anchor_bone`，程序会同时生成：

- `*_效果测试.vmd`：仅包含 morph 帧。
- `*_效果测试_中性骨骼锚点.vmd`：在第 0 帧额外包含一条零位移、单位四元数的中性骨骼帧。

两份文件是 A/B 诊断变体，**不是已证明的 MMD 兼容性修复**。请分别导入，不要同时加载。若要彻底定位 MMD 的差异，请再用 MMD 对同一 PMX 手动注册 morph 并保存 VMD，再用 `StageEffects/vmd_compare.py` 比较。
