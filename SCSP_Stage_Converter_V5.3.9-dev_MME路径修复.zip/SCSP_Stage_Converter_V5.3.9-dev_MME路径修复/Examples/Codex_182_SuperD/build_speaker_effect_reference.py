"""Build the 182 SuperD speaker light layer from its AssetRipper scene and Timeline."""
import argparse
import copy
import math
import os
import re
import runpy
import shutil
import struct
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
unity = runpy.run_path(str(WORK / 'SCSP_Stage_Converter_V3.0/SceneBuilder/rebuild_stage_blender.py'))
demo = runpy.run_path(str(WORK / 'V3.1舞台效果样板/build_light_demo.py'))
LIB = Path(os.environ['APPDATA']) / 'Blender Foundation/Blender/4.4/extensions/blender_org/mmd_tools/core/pmx/__init__.py'
pmx = runpy.run_path(str(LIB))
SWITCH, SCROLL = '音箱橙色', '光帯移動'
BRANCH = 'ef_Lv_182_Bg/mainspeaker_light/mainspeaker_light_'


def matrix(t):
    x, y, z, w = t['rot']
    rot = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                    [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                    [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
    m = np.eye(4)
    m[:3,:3] = rot @ np.diag(t['scale'])
    m[:3,3] = t['pos']
    return m


def track_keys(clip, path):
    for block in clip.split('  m_FloatCurves:\n')[1].split('  m_PPtrCurves:')[0].split('  - serializedVersion: 2\n    curve:'):
        if f'    path: {path}\n' in block and '    attribute: m_IsActive\n' in block:
            return [(math.ceil(float(t)*30-0.001), int(v)) for t,v in re.findall(r'        time: ([\d.]+)\n        value: ([01])\n',block)]
    raise ValueError(path)


def make_motion(name, changes, end, speed):
    frames = []
    old = None
    for at,value in changes:
        if old is not None:
            frames.append((SWITCH, at-1, old))
        frames.append((SWITCH, at, value))
        old = value
    # Keep the secondary sampler within the texture, even with clamp addressing.
    # Retain both sides of each wrap so every MMD frame samples the Unity phase.
    keep = {0, end}
    for frame in range(1, end+1):
        if math.floor(frame*speed/30) != math.floor((frame-1)*speed/30):
            keep.update((frame-1,frame))
    frames.extend((SCROLL, frame, (speed*frame/30)%1) for frame in sorted(keep))
    field = demo['fixed_name']
    payload = b''.join(field(k,15)+struct.pack('<If', f, v) for k,f,v in frames)
    return b'Vocaloid Motion Data 0002'.ljust(30,b'\0') + field(name,20) + struct.pack('<II',0,len(frames)) + payload + bytes(16)


def build(assets, base, out):
    scene = assets/'182_superd.unity'
    objects, transforms, by_go, _, _, _, filters, renderers, guid = unity['parse_scene'](scene, assets)
    model = pmx['load'](str(base.resolve()))
    assert model.name == '182_SuperD' and model.morphs[0].name == '灯面消去'
    clip = next(assets.rglob('an_Lv_182_Bg_AddObject.anim'))
    clip_guid = unity['GUID_RE'].search(Path(str(clip)+'.meta').read_text())[1]
    track = next(assets.rglob('Animation Track (1)_0.asset')).read_text('utf-8')
    playable = guid[re.search(r'm_Asset: \{fileID: 11400000, guid: (\w+)',track)[1]].read_text('utf-8')
    assert clip_guid in playable and all(field in track for field in ('m_Start: 0\n','m_ClipIn: 0\n','m_TimeScale: 1\n','m_Muted: 0\n'))
    end = round(float(re.search(r'm_Duration: ([\d.]+)',track)[1])*30)
    orange = track_keys(clip.read_text('utf-8'),BRANCH+'Orange')
    green = track_keys(clip.read_text('utf-8'),BRANCH+'green')
    assert green == [(t,1-v) for t,v in orange] and orange[0] == (0,0)

    @lru_cache(None)
    def hierarchy(go):
        t = by_go[go]
        if not t['father']:
            return objects[go]['name'], matrix(t)
        parent, transform = hierarchy(transforms[t['father']]['go'])
        return parent+'/'+objects[go]['name'], transform @ matrix(t)

    groups = {'base':[], 'green':[], 'Orange':[]}
    for go, mesh in filters.items():
        path, world = hierarchy(go)
        for layer in ('green','Orange'):
            if not path.startswith('EffectPlayer/Effects_182/BG/'+BRANCH+layer+'/'):
                continue
            renderer, = renderers[go]
            assert renderer['enabled'] and len(mesh)==1 and len(renderer['materials'])==1
            if path.endswith('/light_base') and layer=='Orange':
                continue
            group = 'base' if path.endswith('/light_base') else layer
            groups[group].append((mesh[0]['mesh']['guid'],world,renderer['materials'][0]['guid']))
    assert list(map(len,groups.values())) == [2,36,36]

    out.mkdir(parents=True)
    speeds = set()
    for tex in model.textures:
        path = Path(tex.path)
        dst = out/path.relative_to(base.parent.resolve())
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,dst)
        tex.path = str(dst.resolve())
    def texture(path, gain=1):
        dest = out/'textures'/path.name
        if not dest.exists():
            if gain==1:
                shutil.copyfile(path,dest)
            else:
                im=np.asarray(Image.open(path).convert('RGBA')).copy()
                # LDR approximation of Unity's light intensity, applied in linear space.
                rgb=im[:,:,:3]/255.
                linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)*gain
                im[:,:,:3]=np.rint(255*np.clip(np.where(linear<=.0031308,12.92*linear,1.055*linear**(1/2.4)-.055),0,1)).astype('uint8')
                Image.fromarray(np.tile(im, (1,2,1))).save(dest)
        for i,t in enumerate(model.textures):
            if t.path==str(dest.resolve()):return i
        t=pmx['Texture']()
        t.path=str(dest.resolve())
        model.textures.append(t)
        return len(model.textures)-1

    switch = pmx['MaterialMorph'](SWITCH,'Speaker amber',4)
    scroll = pmx['UVMorph'](SCROLL,'Speaker light scroll',4,type_index=4)
    for layer, items in groups.items():
        material_guid, = {m for _,_,m in items}
        text=guid[material_guid].read_text('utf-8')
        def texslot(key):
            return guid[re.search(key+r':\n\s+m_Texture: \{fileID: 2800000, guid: (\w+)',text)[1]]
        mat=copy.deepcopy(model.materials[8])
        mat.name=mat.name_e='Speaker_'+layer
        mat.texture=texture(texslot('_MainTex'))
        mat.diffuse=(1,1,1,0 if layer=='Orange' else 1)
        mat.ambient=(1,1,1)
        mat.specular=(0,0,0)
        mat.is_double_sided=True
        mat.enabled_toon_edge=mat.enabled_self_shadow=mat.enabled_drop_shadow=mat.enabled_self_shadow_map=False
        mat.vertex_count=0
        mat.sphere_texture=-1
        mat.sphere_texture_mode=0
        if layer!='base':
            mat.sphere_texture=texture(texslot('_LightTex'),float(re.search(r'_Intensity: (.*)',text)[1]))
            mat.sphere_texture_mode=3
            speed=float(re.search(r'_SpeedL: (.*)',text)[1])
            speeds.add(speed)
            light_scale=unity['vec'](text.split('_LightTex:')[1],'m_Scale',('x','y'),(1,1))
            off=copy.deepcopy(model.morphs[0].offsets[0])
            off.index=len(model.materials)
            off.diffuse_offset=(0,0,0,-1 if layer=='green' else 1)
            switch.offsets.append(off)
        model.materials.append(mat)
        for mesh_guid, world, _ in items:
            mesh=unity['parse_mesh'](guid[mesh_guid])
            coords=np.asarray(mesh['positions'])
            # Same Unity -> Blender -> PMX axes and export scale as the accepted stage.
            coords=(coords@world[:3,:3].T+world[:3,3])*[12.5,12.5,-12.5]
            start=len(model.vertices)
            tri=np.array(mesh['indices']).reshape(-1,3)
            normals=np.zeros_like(coords)
            for a,b,c in tri:
                normal=np.cross(coords[c]-coords[a],coords[b]-coords[a])
                normals[[a,b,c]]+=normal
            for i,(co,uv) in enumerate(zip(coords,mesh['uv'])):
                v=pmx['Vertex']()
                v.co=tuple(co)
                v.normal=tuple(normals[i]/max(np.linalg.norm(normals[i]),1e-10))
                v.uv=(uv[0],1-uv[1])
                v.edge_scale=0
                v.weight=model.vertices[0].weight
                if layer!='base':
                    v.additional_uvs=[(uv[0]*light_scale[0]/2,1-uv[1]*light_scale[1],0,0)]
                    off=pmx['UVMorphOffset']()
                    off.index=len(model.vertices)
                    off.offset=(0.5,0,0,0)
                    scroll.offsets.append(off)
                model.vertices.append(v)
            model.faces.extend(tuple(start+int(k) for k in face) for face in tri)
            mat.vertex_count+=tri.size
    facial=next(d for d in model.display if d.isSpecial and d.name_e=='Facial')
    for morph in (switch,scroll):
        facial.data.append((1,len(model.morphs)))
        model.morphs.append(morph)
    pmx['save'](str((out/'182_SuperD_音箱灯.pmx').resolve()),model,add_uv_count=1)
    speed, = speeds
    (out/'182_SuperD_音箱灯.vmd').write_bytes(make_motion(model.name,orange,end,speed))
    camera_header = b'Vocaloid Motion Data 0002'.ljust(30,bytes(1)) + demo['fixed_name']('カメラ・照明',20)
    camera_key = struct.pack('<If3f3f',0,-80,437,28,-114,0,math.radians(-135),0)
    camera_key += bytes([20,107,20,107])*6 + struct.pack('<IB',30,0)
    (out/'验收用_主音箱近景.vmd').write_bytes(camera_header + struct.pack('<III',0,0,1) + camera_key + bytes(12))
    print('Timeline:', orange, 'end:',end,'mesh counts:',{k:len(v) for k,v in groups.items()})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets',type=Path)
    parser.add_argument('base',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    build(args.assets,args.base,args.output)
