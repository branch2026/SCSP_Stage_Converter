"""Add one controllable light layer to the static V3.0 182_SuperD export."""
import argparse
import os
from pathlib import Path
import runpy
import shutil
import struct
import uuid


MATERIAL = "M_comon_spotlights_light_multi"
CONTROL = "灯面消去"
KEYS = [(0, 0.0), (30, 0.0), (60, 0.5), (90, 1.0), (120, 1.0), (150, 0.5), (180, 0.0)]


def integer(value):
    return struct.pack("<i", value)


def fixed_name(text, width):
    data = text.encode("cp932")
    if len(data) > width:
        raise ValueError(f"VMD name exceeds {width} bytes: {text}")
    return data.ljust(width, b"\0")


def make_vmd(model_name):
    header = b"Vocaloid Motion Data 0002".ljust(30, b"\0")
    frames = b"".join(fixed_name(CONTROL, 15) + struct.pack("<If", frame, weight)
                      for frame, weight in KEYS)
    return header + fixed_name(model_name, 20) + integer(0) + integer(len(KEYS)) + frames + bytes(16)


def build(source, destination, reader):
    source = source.resolve()
    model = reader(str(source))
    data = source.read_bytes()
    if model.morphs or model.rigids or model.joints or data[:4] != b"PMX " or struct.unpack_from("<f", data, 4)[0] != 2:
        raise ValueError("Expected a static PMX 2.0 stage exported by V3.0")
    indices = [i for i, m in enumerate(model.materials) if m.name == MATERIAL]
    if len(indices) != 1 or model.materials[indices[0]].diffuse[3] != 1:
        raise ValueError("Expected one opaque spotlight plane material")
    encoding = ("utf-16-le", "utf-8")[data[9]]
    mat_size, bone_size, morph_size = data[13], data[14], data[15]

    def string(value):
        raw = value.encode(encoding)
        return integer(len(raw)) + raw

    def display(add_control):
        parts = [integer(len(model.display))]
        for d in model.display:
            slots = list(d.data)
            if add_control and d.isSpecial and d.name_e == "Facial":
                slots.append((1, 0))
            parts.extend([string(d.name), string(d.name_e), bytes([int(d.isSpecial)]), integer(len(slots))])
            for kind, index in slots:
                size = morph_size if kind else bone_size
                parts.append(bytes([kind]) + index.to_bytes(size, "little", signed=True))
        return b"".join(parts)

    old_tail = integer(0) + display(False) + bytes(8)
    if not data.endswith(old_tail) or not any(d.isSpecial and d.name_e == "Facial" for d in model.display):
        raise ValueError("Unexpected PMX display layout")
    # Additive material morph. Only diffuse alpha changes, by minus one.
    offset = indices[0].to_bytes(mat_size, "little", signed=True) + bytes([1])
    offset += struct.pack("<28f", 0, 0, 0, -1, *([0] * 24))
    morph = string(CONTROL) + string("Spotlight layer fade") + bytes([4, 8]) + integer(1) + offset
    result = data[:-len(old_tail)] + integer(1) + morph + display(True) + bytes(8)
    destination = destination.resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = destination.parent / (".build-" + uuid.uuid4().hex)
    stage.mkdir()
    try:
        for tex in model.textures:
            path = Path(tex.path).resolve()
            target = stage / path.relative_to(source.parent)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        pmx = stage / "182_SuperD_灯面控制.pmx"
        pmx.write_bytes(result)
        (stage / "灯面消去_测试.vmd").write_bytes(make_vmd(model.name))
        check = reader(str(pmx))
        assert check.morphs[0].name == CONTROL and check.morphs[0].offsets[0].index == indices[0]
        assert check.morphs[0].offsets[0].diffuse_offset == (0, 0, 0, -1)
        assert all(Path(t.path).is_file() for t in check.textures)
        stage.rename(destination)
    finally:
        if stage.exists():
            shutil.rmtree(stage)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--reader", type=Path, default=Path(os.environ["APPDATA"]) /
                        "Blender Foundation/Blender/4.4/extensions/blender_org/mmd_tools/core/pmx/__init__.py")
    args = parser.parse_args()
    build(args.source, args.destination, runpy.run_path(str(args.reader))["load"])
