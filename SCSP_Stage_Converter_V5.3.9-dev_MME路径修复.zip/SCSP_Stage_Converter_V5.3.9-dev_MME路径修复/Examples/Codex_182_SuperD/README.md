# Codex V3.1 原始样板源码留档

这两个脚本来自用户提供的 `V3.1.7z`。它们是之前在本机 Windows、Blender/MMD Tools 环境中使用的 **研究与样板**，不是 V3.1 的通用模块，也不会被 GUI 自动运行。

`build_light_demo_reference.py`：为原始静态 `182_SuperD` 生成「灯面消去」材质形态键与 180 帧测试 VMD。此前用户已在 MMD 中验收该控制项。

`build_speaker_effect_reference.py`：需要 AssetRipper 的 Unity `.unity/.mat/.anim/.playable` 和特定 MMD Tools Python 模块，追踪 `mainspeaker_light` 组并追加几何/材质、音箱橙色以及追加 UV1 动画。原脚本使用对用户电脑目录的硬编码依赖；若直接执行可能失败。保留是为了明确效果还原的来源和可复现思路。

这两个旧样板并未作为 V3.1 当前**通用**转换过程的一部分。未来移植时，应逐项提取原始 Unity 依据并通过 Windows MMD 真实验收，不应未经验证自动套用到其他舞台。

ITTW46 两份第三方参考舞台未被复制到软件交付包。
