# V2.4.2-dev — Active Mesh Diagnostics

## 开发基线
- 基于 V2.4.1-dev MeshDiagnostics。
- V2.3.2-dev 继续作为批量转换回退基线；V2.4.0-dev 质量检查包保留。

## 诊断增强
- 新增 `activeInHierarchy` 计算，父级 inactive 会正确传递到所有后代。
- 读取 Blender 重建报告中的 `inactivePolicy`，以实际转换选项作为诊断范围依据。
- 分开统计参与转换、仅被排除对象引用、以及同时被参与/排除对象引用的 Shared Mesh。
- SRC-005 法线与 SRC-006 UV0 WARNING 只按至少存在一个参与转换引用的唯一 Mesh 计算。
- 全场景原始诊断清单和 SRC-009 源验证数量交叉核对继续保留，避免丢失追溯信息。
- JSON / TXT 报告增加转换纳入状态、activeSelf、activeInHierarchy、共享引用和转换范围计数。

## 严格保护
- 不修改 SceneBuilder、PMXExporter、UnityParser/batch_folder_discovery.py、Validator/validate_source.py、RUN_GUI.bat。
- 不修改转换、重建、导出、贴图修复逻辑。
- 不自动修复法线、UV 或材质。
- 质量检查不会改变 PMX 转换成功/失败状态。

## 测试
- 保留 V2.4.1 的 48 项测试。
- 新增父级 inactive 对 active 子对象的继承测试，并覆盖 include 策略。
- 新增 Included / Excluded 对象共享同一 Mesh 的去重与范围测试。
- 当前 51 项自动化测试全部通过。

## 尚待验收
- Windows 10 GUI 与完整批量转换实机回归。
- 185_SankaF 使用 V2.4.2-dev 重跑，检查 918 个 Mesh 的转换范围与 WARNING 定位。
- MMD 9.32 最终外观验收。
