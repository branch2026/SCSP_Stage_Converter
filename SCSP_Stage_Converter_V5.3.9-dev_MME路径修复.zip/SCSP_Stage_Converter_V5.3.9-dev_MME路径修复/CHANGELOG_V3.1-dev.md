# V3.1-dev · Stage Effects

2026-11-21

### 新增
- 舞台效果工具 GUI：材质槽列表、多选、Alpha / 基础 UV 控制，独立附加 PMX 和 VMD。
- `StageEffects/pmx_binary.py`：保守修改 PMX 形态键和显示枠；所有源几何/材质/骨骼/物理记录保持字节级不变。
- 通过 JSON 配置材料索引或精确名称，支持透明度、颜色变化、UV0 和已有追加 UV1～UV4；检查共享顶点避免波及旁边材质。
- 非破坏性批量后处理；默认关闭；按舞台根名匹配 profile。效果模块失败不影响 V3.0 PMX 成功状态。
- 独立生成测试 VMD、贴图完整性检查、构建追踪 JSON。严格检查 CP932 / VMD 15 字节名称限制。
- 源 Unity `.mat/.anim` / 场景 MeshRenderer 引用只读采样工具。
- PMX / VMD / EMD / EMM / FX / APNG 依赖只读审核。
- 保留 Codex 的 182_SuperD 旧样板源码作为参考；不自动运行和不重发 ITTW46 资产。

### 保留不动
- V3.0 的 `_convert_one` 核心导出方法。
- 15 个受保护转换文件逐字节一致。
- V3.0 既有的默认转换行为，除用户显式启用效果后处理外无改变。

### 尚待实机验收 / 不包含
- 当前环境无法运行用户 Windows Blender/MMD GUI；需要在汉化 MMD932 手动验收新增形态键和新 VMD。
- 未自动生成 MME EMD/EMM/FX、未恢复 LED APNG 实时播放与 Unity Runtime 光照。
