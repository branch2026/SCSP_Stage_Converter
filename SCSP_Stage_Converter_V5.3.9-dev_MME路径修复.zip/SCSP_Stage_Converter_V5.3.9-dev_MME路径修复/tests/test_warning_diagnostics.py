"""V2.4.8 WARNING diagnostic tests; no Unity/Blender/PMX required."""
from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "scsp_warning_diagnostics_test", ROOT / "Validator" / "diagnose_warnings.py"
)
DIAG = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DIAG)


def _mesh(name, guid, file_id, scope, normals, go_id, go_name):
    go = {
        "gameObjectName": go_name,
        "gameObjectFileID": go_id,
        "hierarchyPath": f"StageRoot/{go_name}",
        "activeSelf": scope != "excludedOnly",
        "activeInHierarchy": scope != "excludedOnly",
        "conversionIncluded": scope != "excludedOnly",
        "meshFilterComponentFileIDs": [go_id + 1000],
        "materials": [],
    }
    return {
        "meshName": name, "meshGUID": guid * 32, "meshFileID": str(file_id),
        "assetPath": f"Assets/{name}.asset", "vertexCount": 3,
        "hasNormals": normals, "hasUV0": True, "decodeStatus": "decoded",
        "scope": scope, "conversionIncluded": scope != "excludedOnly",
        "occurrenceCount": 1, "uniqueGameObjectCount": 1, "gameObjects": [go],
        "normalEvidence": "RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL",
    }


def _report(policy):
    included = _mesh("active_mesh", "a", 4300000, "included", True, 10, "active_mesh")
    missing = _mesh("missing_normal", "b", 4300000, "included", False, 11, "missing_normal")
    excluded = _mesh("hidden_mesh", "c", 4300000, "excludedOnly", False, 12, "hidden_mesh")
    if policy == "include":
        included_hidden = _mesh("hidden_mesh", "c", 4300000, "included", True, 12, "hidden_mesh")
        included_hidden["gameObjects"][0]["hierarchyPath"] = "StageRoot/HiddenRoot/hidden_mesh"
        included_hidden["gameObjects"][0]["meshFilterComponentFileIDs"] = [1012]
        inventory = [included, missing, included_hidden]
    else:
        inventory = [included, missing, excluded]
    inactive = ([
        {
            "name": "HiddenRoot", "gameObjectFileID": 20,
            "hierarchyPath": "StageRoot/HiddenRoot", "activeSelf": False,
            "conversionIncluded": False, "conversionDecision": "excluded_self_inactive",
        },
        {
            "name": "hidden_mesh", "gameObjectFileID": 12,
            "hierarchyPath": "StageRoot/HiddenRoot/hidden_mesh", "activeSelf": True,
            "conversionIncluded": False,
            "conversionDecision": "excluded_by_inactive_ancestor",
        },
    ] if policy == "exclude" else [
        {
            "name": "HiddenRoot", "gameObjectFileID": 20,
            "hierarchyPath": "StageRoot/HiddenRoot", "activeSelf": False,
            "conversionIncluded": True, "conversionDecision": "included_by_inactive_policy_override",
        },
        {
            "name": "hidden_mesh", "gameObjectFileID": 12,
            "hierarchyPath": "StageRoot/HiddenRoot/hidden_mesh", "activeSelf": True,
            "conversionIncluded": True,
            "conversionDecision": "included_by_inactive_policy_override",
        },
    ])
    # Inventory occurrence follows the actual nested inactive object path.
    excluded["gameObjects"][0]["hierarchyPath"] = "StageRoot/HiddenRoot/hidden_mesh"
    excluded["gameObjects"][0]["meshFilterComponentFileIDs"] = [1012]
    checks = [{
        "id": "SRC-005", "category": "Mesh", "name": "法线覆盖率",
        "status": "WARNING", "message": "缺少法线",
        "details": {"missingMeshCount": 1},
    }]
    if policy == "exclude":
        checks.append({
            "id": "BLD-004", "category": "场景对象", "name": "inactive 对象排除",
            "status": "WARNING", "message": "inactive 被排除",
            "details": {"skippedInactiveGameObjects": 2, "skippedInactiveMeshFilters": 1},
        })
    return {
        "schema": DIAG.SUPPORTED_QUALITY_SCHEMA, "version": "2.4.7-dev",
        "generatedAt": "2026-11-20T18:00:00+08:00",
        "stage": {"root": "StageRoot", "scene": "Assets/Stage.unity", "project": "C:/Stage/scene-project"},
        "summary": {"status": "WARNING", "passed": 10, "warnings": len(checks), "failures": 0, "info": 0},
        "objects": {"inactivePolicy": policy, "inactiveInHierarchyObjects": inactive},
        "meshDiagnostics": {
            "schema": DIAG.SUPPORTED_MESH_SCHEMA, "conversionPolicy": policy,
            "meshInventory": inventory,
            "meshInventorySummary": {
                "complete": True, "identityComplete": True, "scopeCountsMatch": True,
                "scopeUniqueMeshReferences": {"included": 2 if policy == "include" else 2, "excludedOnly": 0 if policy == "include" else 1, "shared": 0},
            },
            "conversionMissingNormals": [missing],
        },
        "checks": checks,
    }


class WarningDiagnosticsTests(unittest.TestCase):
    def test_normal_warning_maps_to_mesh_guid_and_hierarchy(self):
        result = DIAG.build_warning_diagnostics(_report("include"), _report("exclude"))
        warning = result["modes"]["include"]["warnings"][0]
        self.assertTrue(warning["diagnosis"]["mappingComplete"])
        self.assertEqual(warning["diagnosis"]["affectedMeshes"][0]["meshName"], "missing_normal")
        self.assertEqual(warning["diagnosis"]["affectedMeshes"][0]["gameObjects"][0]["hierarchyPath"], "StageRoot/missing_normal")

    def test_inactive_warning_maps_objects_and_excluded_meshes(self):
        result = DIAG.build_warning_diagnostics(_report("include"), _report("exclude"))
        warning = next(w for w in result["modes"]["exclude"]["warnings"] if w["checkId"] == "BLD-004")
        diagnosis = warning["diagnosis"]
        self.assertTrue(diagnosis["mappingComplete"])
        self.assertEqual(diagnosis["locatedGameObjectCount"], 2)
        self.assertEqual(diagnosis["excludedOnlyUniqueMeshCount"], 1)

    def test_old_report_infers_false_with_provenance_and_groups_under_root(self):
        result = DIAG.build_warning_diagnostics(_report("include"), _report("exclude"))
        include_summary = result["modes"]["include"]["inactiveHierarchySummary"]
        exclude_summary = result["modes"]["exclude"]["inactiveHierarchySummary"]
        self.assertEqual(include_summary["inactiveRootObjectCount"], 1)
        self.assertEqual(exclude_summary["inactiveRootObjectCount"], 1)
        root = exclude_summary["rootObjects"][0]
        self.assertEqual(root["rootGameObjectName"], "HiddenRoot")
        self.assertEqual(root["affectedGameObjectCount"], 2)
        self.assertEqual(root["meshBearingGameObjectCount"], 1)
        self.assertEqual(root["affectedMeshFilterComponentCount"], 1)
        self.assertEqual(root["affectedUniqueMeshCount"], 1)
        self.assertEqual(root["uniqueMeshCountByScope"]["excludedOnly"], 1)
        child = next(row for row in root["affectedGameObjects"] if row["gameObjectName"] == "hidden_mesh")
        self.assertIs(child["activeInHierarchy"], False)
        self.assertIs(child["activeInHierarchyInferred"], True)
        self.assertEqual(child["activeInHierarchySource"], "inferred_from_inactiveInHierarchyObjects_membership")
        self.assertTrue(exclude_summary["groupingComplete"])

    def test_root_summary_deduplicates_shared_mesh_and_counts_components(self):
        exclude = _report("exclude")
        exclude["objects"]["inactiveInHierarchyObjects"].append({
            "name": "hidden_mesh_copy", "gameObjectFileID": 13,
            "hierarchyPath": "StageRoot/HiddenRoot/hidden_mesh_copy", "activeSelf": True,
            "conversionIncluded": False, "conversionDecision": "excluded_by_inactive_ancestor",
        })
        mesh = next(row for row in exclude["meshDiagnostics"]["meshInventory"] if row.get("scope") == "excludedOnly")
        mesh["gameObjects"].append({
            "gameObjectName": "hidden_mesh_copy", "gameObjectFileID": 13,
            "hierarchyPath": "StageRoot/HiddenRoot/hidden_mesh_copy",
            "activeSelf": True, "activeInHierarchy": False, "conversionIncluded": False,
            "meshFilterComponents": 1, "meshFilterComponentFileIDs": [1013],
        })
        exclude["checks"][-1]["details"]["skippedInactiveGameObjects"] = 3
        exclude["checks"][-1]["details"]["skippedInactiveMeshFilters"] = 2
        summary = DIAG._inactive_hierarchy_summary(exclude)
        root = summary["rootObjects"][0]
        self.assertEqual(summary["inactiveRootObjectCount"], 1)
        self.assertEqual(root["affectedGameObjectCount"], 3)
        self.assertEqual(root["meshBearingGameObjectCount"], 2)
        self.assertEqual(root["affectedMeshFilterComponentCount"], 2)
        self.assertEqual(root["affectedUniqueMeshCount"], 1)
        self.assertTrue(summary["groupingComplete"])

    def test_explicit_active_in_hierarchy_is_preserved_not_inferred(self):
        report = _report("exclude")
        report["objects"]["inactiveInHierarchyObjects"][0]["activeInHierarchy"] = False
        report["objects"]["inactiveInHierarchyObjects"][0]["activeInHierarchySource"] = "computed_by_unity_hierarchy_walk"
        result = DIAG._inactive_hierarchy_summary(report)
        root = result["rootObjects"][0]
        self.assertIs(root["activeInHierarchy"], False)
        self.assertIs(root["activeInHierarchyInferred"], False)
        self.assertEqual(root["activeInHierarchySource"], "computed_by_unity_hierarchy_walk")


    def test_normal_inactive_association_classifies_common_and_inactive_only_meshes(self):
        include = _report("include")
        exclude = _report("exclude")

        def attach_inactive_cause(go):
            go["activeSelf"] = True
            go["activeInHierarchy"] = False
            go["conversionIncluded"] = go.get("conversionIncluded", True)
            go["conversionDecision"] = "included_by_inactive_policy_override" if go["conversionIncluded"] else "excluded_by_inactive_ancestor"
            go["hierarchyInactiveCause"] = {
                "gameObjectFileID": 20, "name": "HiddenRoot",
                "hierarchyPath": "StageRoot/HiddenRoot", "isSelf": True,
            }
            go["conversionBlockingInactiveObject"] = dict(go["hierarchyInactiveCause"])

        # The same Mesh identity is converted in Include but excluded in Exclude.
        include_hidden = _mesh("inactive_missing_normal", "d", 4300000, "included", False, 13, "inactive_missing_normal")
        exclude_hidden = _mesh("inactive_missing_normal", "d", 4300000, "excludedOnly", False, 13, "inactive_missing_normal")
        for row in (include_hidden, exclude_hidden):
            go = row["gameObjects"][0]
            go["hierarchyPath"] = "StageRoot/HiddenRoot/inactive_missing_normal"
            attach_inactive_cause(go)
        include["meshDiagnostics"]["meshInventory"].append(include_hidden)
        exclude["meshDiagnostics"]["meshInventory"].append(exclude_hidden)
        include["meshDiagnostics"]["conversionMissingNormals"].append(include_hidden)
        include["checks"][0]["details"]["missingMeshCount"] = 2
        include["objects"]["inactiveInHierarchyObjects"].append({
            "name": "inactive_missing_normal", "gameObjectFileID": 13,
            "hierarchyPath": "StageRoot/HiddenRoot/inactive_missing_normal",
            "activeSelf": True, "conversionIncluded": True,
            "conversionDecision": "included_by_inactive_policy_override",
        })
        exclude["objects"]["inactiveInHierarchyObjects"].append({
            "name": "inactive_missing_normal", "gameObjectFileID": 13,
            "hierarchyPath": "StageRoot/HiddenRoot/inactive_missing_normal",
            "activeSelf": True, "conversionIncluded": False,
            "conversionDecision": "excluded_by_inactive_ancestor",
        })
        exclude["checks"][-1]["details"]["skippedInactiveGameObjects"] = 3
        exclude["checks"][-1]["details"]["skippedInactiveMeshFilters"] = 2
        include["meshDiagnostics"]["meshInventorySummary"]["scopeUniqueMeshReferences"]["included"] = 4
        exclude["meshDiagnostics"]["meshInventorySummary"]["scopeUniqueMeshReferences"]["excludedOnly"] = 2

        result = DIAG.build_warning_diagnostics(include, exclude)
        association = result["normalInactiveAssociation"]
        self.assertTrue(association["mappingComplete"])
        self.assertEqual(association["commonMissingNormalUniqueMeshCount"], 1)
        self.assertEqual(association["includeOnlyMissingNormalUniqueMeshCount"], 1)
        self.assertEqual(association["includeOnlyInactiveExcludedMeshVerifiedCount"], 1)
        mesh = next(row for row in association["meshes"] if row["meshName"] == "inactive_missing_normal")
        self.assertEqual(mesh["classification"], "include_only")
        go = mesh["include"]["gameObjects"][0]
        self.assertIs(go["activeInHierarchy"], False)
        self.assertIs(go["activeInHierarchyInferred"], False)
        self.assertEqual(go["inactiveRoot"]["rootGameObjectName"], "HiddenRoot")
        self.assertEqual(mesh["exclude"]["inventoryScope"], "excludedOnly")
        self.assertIs(mesh["exclude"]["conversionIncluded"], False)
        self.assertEqual(association["inactiveRootAssociationCount"], 1)

    def test_inactive_state_cross_mode_conflict_is_reported(self):
        include = _report("include")
        exclude = _report("exclude")
        # The same GO fileID reports contradictory raw state in the two modes.
        inc_mesh = next(row for row in include["meshDiagnostics"]["meshInventory"] if row["meshName"] == "active_mesh")
        exc_mesh = next(row for row in exclude["meshDiagnostics"]["meshInventory"] if row["meshName"] == "active_mesh")
        inc_mesh["gameObjects"][0]["activeInHierarchy"] = True
        exc_mesh["gameObjects"][0]["activeInHierarchy"] = False
        result = DIAG.build_warning_diagnostics(include, exclude)
        cross = result["inactiveStateValidation"]["crossMode"]
        self.assertEqual(cross["status"], "CONFLICT")
        self.assertGreater(cross["crossModeStateMismatchCount"], 0)

    def test_unknown_normal_occurrence_state_is_not_guessed(self):
        include = _report("include")
        exclude = _report("exclude")
        row = include["meshDiagnostics"]["conversionMissingNormals"][0]
        row["gameObjects"][0].pop("activeInHierarchy", None)
        row["gameObjects"][0].pop("hierarchyInactiveCause", None)
        row["gameObjects"][0].pop("conversionBlockingInactiveObject", None)
        inventory_row = next(
            row for row in include["meshDiagnostics"]["meshInventory"]
            if row["meshName"] == "missing_normal"
        )
        inventory_row["gameObjects"][0].pop("activeInHierarchy", None)
        inventory_row["gameObjects"][0].pop("hierarchyInactiveCause", None)
        inventory_row["gameObjects"][0].pop("conversionBlockingInactiveObject", None)
        result = DIAG.build_warning_diagnostics(include, exclude)
        association = result["normalInactiveAssociation"]
        self.assertFalse(association["mappingComplete"])
        self.assertGreater(association["unknownStateOccurrenceCount"], 0)


    def test_unknown_warning_is_not_guessed(self):
        include = _report("include")
        include["checks"].append({"id": "NEW-001", "status": "WARNING", "name": "unknown", "details": {"x": 1}})
        result = DIAG.build_warning_diagnostics(include, _report("exclude"))
        unknown = next(w for w in result["modes"]["include"]["warnings"] if w["checkId"] == "NEW-001")
        self.assertFalse(unknown["diagnosis"]["mappingComplete"])
        self.assertEqual(unknown["diagnosis"]["rawDetails"], {"x": 1})

    def test_accepts_new_v249_quality_report_version(self):
        include = _report("include")
        exclude = _report("exclude")
        include["version"] = "2.4.9-dev"
        exclude["version"] = "2.4.9-dev"
        result = DIAG.build_warning_diagnostics(include, exclude)
        self.assertEqual(result["toolVersion"], "2.4.10-dev")
        self.assertEqual(result["schema"], "scsp-warning-diagnostics-v2")

    def test_rejects_wrong_policy(self):
        with self.assertRaises(DIAG.DiagnosticError):
            DIAG.build_warning_diagnostics(_report("exclude"), _report("exclude"))

    def test_rejects_different_stage(self):
        exclude = _report("exclude")
        exclude["stage"]["root"] = "OtherStage"
        with self.assertRaises(DIAG.DiagnosticError):
            DIAG.build_warning_diagnostics(_report("include"), exclude)

    def test_refuses_to_overwrite_input_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            inc = Path(tmp) / "inc.json"
            exc = Path(tmp) / "exc.json"
            inc.write_text(json.dumps(_report("include")), encoding="utf-8")
            exc.write_text(json.dumps(_report("exclude")), encoding="utf-8")
            before = inc.read_bytes()
            with self.assertRaises(DIAG.DiagnosticError):
                DIAG.diagnose_warning_files(inc, exc, inc, Path(tmp) / "out.txt")
            self.assertEqual(inc.read_bytes(), before)

    def test_writes_json_and_txt(self):
        with tempfile.TemporaryDirectory() as tmp:
            inc = Path(tmp) / "inc.json"
            exc = Path(tmp) / "exc.json"
            out = Path(tmp) / "out.json"
            txt = Path(tmp) / "out.txt"
            inc.write_text(json.dumps(_report("include")), encoding="utf-8")
            exc.write_text(json.dumps(_report("exclude")), encoding="utf-8")
            result = DIAG.diagnose_warning_files(inc, exc, out, txt)
            self.assertTrue(out.is_file())
            self.assertTrue(txt.is_file())
            self.assertEqual(json.loads(out.read_text(encoding="utf-8"))["summary"], result["summary"])
            rendered = txt.read_text(encoding="utf-8-sig")
            self.assertIn("WARNING", rendered)
            self.assertIn("缺法线 Mesh × inactive 关联分析", rendered)


if __name__ == "__main__":
    unittest.main()
