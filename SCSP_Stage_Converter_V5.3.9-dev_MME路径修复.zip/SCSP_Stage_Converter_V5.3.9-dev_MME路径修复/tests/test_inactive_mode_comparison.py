"""V2.4.7 independent comparison tests. No Blender, Unity, or scene-project needed."""
from __future__ import annotations

import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / 'Validator' / 'compare_inactive_modes.py'
SPEC = importlib.util.spec_from_file_location('scsp_v246_compare_test', MODULE_PATH)
CMP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CMP)


def _fixture():
    """2 GameObjects / 2 MeshFilter; exclude removes 1 inactive child and 1 Mesh."""
    source = {'gameObjects': 2, 'meshFilterComponents': 2, 'uniqueMeshReferences': 2}
    original = {
        'schema': 'scsp-stage-quality-report-v1',
        'tool': 'SCSP Stage Converter',
        'version': '2.4.4-dev',
        'generatedAt': '2026-11-20T14:00:00+08:00',
        'stage': {'root': 'StageRoot', 'scene': 'Assets/Stage.unity', 'project': r'C:\Stage\scene-project', 'pmx': r'C:\Output\StageRoot.pmx'},
        'source': source,
        'summary': {'status': 'WARNING', 'passed': 2, 'warnings': 1, 'failures': 0},
        'meshDiagnostics': {
            'schema': 'scsp-mesh-channel-diagnostics-v5',
            'conversionPolicy': 'include',
            'conversionMeshFilterComponents': 2,
            'excludedMeshFilterComponents': 0,
            'conversionUniqueMeshReferences': 2,
            'excludedOnlyUniqueMeshReferences': 0,
            'conversionMissingNormalsCount': 1,
            'conversionMissingUV0Count': 0,
            'conversionMissingEitherCount': 1,
            'excludedOnlyMissingNormalsCount': 0,
            'excludedOnlyMissingUV0Count': 0,
            'excludedOnlyMissingEitherCount': 0,
            'scopes': {'source': {'uniqueMeshReferences': 2}, 'included': {'uniqueMeshReferences': 2}},
            'scopeAccounting': {'countsMatch': True},
            'excludedOnlyMissingEither': [],
            'excludedOnlyMissingNormals': [],
            'excludedOnlyMissingUV0': [],
        },
        'objects': {
            'inactivePolicy': 'include',
            'conversionIncludedGameObjects': 2,
            'conversionExcludedGameObjects': 0,
            'inactiveInHierarchyObjects': [{
                'name': 'Hidden', 'gameObjectFileID': 123,
                'hierarchyPath': 'StageRoot/Hidden', 'activeSelf': False,
                'conversionIncluded': True,
                'conversionDecision': 'included_by_inactive_policy_override',
            }],
        },
        'rebuild': {'skippedInactive': [], 'meshObjects': 2, 'triangles': 2},
        'pmx': {
            'status': 'completed',
            'parser': {'status': 'PASSED', 'vertices': 6, 'faces': 2, 'materials': 2, 'textures': 2},
            'textureValidation': {'status': 'PASSED', 'unresolved_count': 0, 'ambiguous_count': 0,
                'reference_count': 2, 'normalized_references': ['textures/a.png', 'textures/b.png']},
        },
    }
    exclude = copy.deepcopy(original)
    exclude['meshDiagnostics'].update({
        'conversionPolicy': 'exclude',
        'conversionMeshFilterComponents': 1, 'excludedMeshFilterComponents': 1,
        'conversionUniqueMeshReferences': 1, 'excludedOnlyUniqueMeshReferences': 1,
        'conversionMissingNormalsCount': 0, 'excludedOnlyMissingNormalsCount': 1,
        'conversionMissingEitherCount': 0, 'excludedOnlyMissingEitherCount': 1,
    })
    excluded_mesh = {
        'meshName': 'HiddenMesh', 'meshGUID': 'a' * 32, 'meshFileID': '4300000',
        'assetPath': 'Assets/Hidden.asset', 'hasNormals': False, 'hasUV0': True,
        'gameObjects': [{'gameObjectFileID': 123, 'conversionIncluded': False,
            'meshFilterComponentFileIDs': [678]}],
    }
    exclude['meshDiagnostics']['excludedOnlyMissingEither'] = [excluded_mesh]
    exclude['meshDiagnostics']['excludedOnlyMissingNormals'] = [excluded_mesh]
    exclude['objects']['inactivePolicy'] = 'exclude'
    exclude['objects']['conversionIncludedGameObjects'] = 1
    exclude['objects']['conversionExcludedGameObjects'] = 1
    exclude['objects']['inactiveInHierarchyObjects'][0].update({
        'conversionIncluded': False, 'conversionDecision': 'excluded_self_inactive',
        'conversionBlockingInactiveObject': {'gameObjectFileID': 123, 'name': 'Hidden',
            'hierarchyPath': 'StageRoot/Hidden', 'isSelf': True},
    })
    exclude['rebuild'] = {'skippedInactive': [{'name': 'Hidden', 'gameObjectFileID': 123, 'meshFilters': 1}],
                          'meshObjects': 1, 'triangles': 1}
    exclude['pmx']['parser'].update({'vertices': 3, 'faces': 1, 'materials': 1, 'textures': 1})
    exclude['pmx']['textureValidation'].update({'reference_count': 1, 'normalized_references': ['textures/a.png']})
    return original, exclude


def _attach_v6_inventory(include, exclude):
    """Add a tiny complete source inventory: one hidden-only and one visible Mesh."""
    hidden_material = {
        'name': 'HiddenMaterial', 'materialGUID': 'c' * 32,
        'materialFileID': '2100000', 'assetPath': 'Assets/Hidden.mat',
        'mainTextureGUID': 'd' * 32, 'mainTextureFileID': 2800000,
        'mainTextureAssetPath': 'Assets/Hidden.png',
        'mainTextureAssigned': True, 'mainTextureResolved': True,
    }
    include_rows = [
        {
            'meshName': 'HiddenMesh', 'meshGUID': 'a' * 32, 'meshFileID': '4300000',
            'assetPath': 'Assets/Hidden.asset', 'vertexCount': 3,
            'hasNormals': True, 'hasUV0': True, 'decodeStatus': 'decoded',
            'scope': 'included', 'gameObjects': [{
                'gameObjectName': 'Hidden', 'gameObjectFileID': 123,
                'hierarchyPath': 'StageRoot/Hidden', 'conversionIncluded': True,
                'meshFilterComponentFileIDs': [678], 'materials': [hidden_material],
            }],
        },
        {
            'meshName': 'VisibleMesh', 'meshGUID': 'b' * 32, 'meshFileID': '4300000',
            'assetPath': 'Assets/Visible.asset', 'vertexCount': 6,
            'hasNormals': True, 'hasUV0': True, 'decodeStatus': 'decoded',
            'scope': 'included', 'gameObjects': [{
                'gameObjectName': 'StageRoot', 'gameObjectFileID': 1,
                'hierarchyPath': 'StageRoot', 'conversionIncluded': True,
                'meshFilterComponentFileIDs': [679], 'materials': [],
            }],
        },
    ]
    exclude_rows = copy.deepcopy(include_rows)
    exclude_rows[0]['scope'] = 'excludedOnly'
    exclude_rows[0]['gameObjects'][0]['conversionIncluded'] = False
    exclude_rows[1]['scope'] = 'included'
    for report, policy, rows in ((include, 'include', include_rows), (exclude, 'exclude', exclude_rows)):
        diag = report['meshDiagnostics']
        diag['schema'] = 'scsp-mesh-channel-diagnostics-v6'
        diag['uniqueMeshReferences'] = 2
        diag['sharedMeshReferencesAcrossIncludedAndExcludedObjects'] = 0
        diag['meshInventorySchema'] = 'scsp-mesh-resource-inventory-v1'
        diag['meshInventory'] = copy.deepcopy(rows)
        diag['meshInventorySummary'] = {
            'schema': 'scsp-mesh-resource-inventory-v1',
            'totalUniqueMeshReferences': 2,
            'recordedUniqueMeshReferences': 2,
            'identifiedUniqueMeshReferences': 2,
            'unidentifiedUniqueMeshReferences': 0,
            'complete': True,
            'identityComplete': True,
            'scopeCountsMatch': True,
            'scopeUniqueMeshReferences': (
                {'included': 2, 'excludedOnly': 0, 'shared': 0}
                if policy == 'include' else
                {'included': 1, 'excludedOnly': 1, 'shared': 0}
            ),
        }
    return include, exclude


class ComparisonTests(unittest.TestCase):
    def test_basic(self):
        a, b = _fixture()
        report = CMP.compare_reports(a, b)
        self.assertEqual(report['summary']['status'], 'PASS')
        self.assertEqual(report['summary']['checks'], 14)
        self.assertEqual(report['summary']['excludedGameObjects'], 1)
        self.assertEqual(report['summary']['identifiedExcludedMeshGUIDCount'], 1)
        self.assertEqual(report['differences']['pmxFaces']['removedByExclude'], 1)
        self.assertEqual(report['pmxTextureDifferences']['removedFromExclude'], ['textures/b.png'])
        self.assertEqual(report['excludedMeshFilterObjects'][0]['identifiedMeshReferences'][0]['meshGUID'], 'a' * 32)

    def test_v6_inventory_identifies_all_excluded_meshes_and_unity_materials(self):
        a, b = _attach_v6_inventory(*_fixture())
        report = CMP.compare_reports(a, b)
        self.assertEqual(report['summary']['status'], 'PASS')
        self.assertTrue(report['summary']['meshInventoryAvailable'])
        self.assertEqual(report['summary']['identifiedExcludedMeshGUIDCount'], 1)
        self.assertEqual(report['summary']['unidentifiedExcludedMeshGUIDCount'], 0)
        self.assertTrue(report['meshInventoryCoverage']['inventoryComplete'])
        self.assertTrue(report['meshInventoryCoverage']['scopeCountsMatch'])
        self.assertTrue(report['meshInventoryCoverage']['crossReportIdentityMatch'])
        self.assertTrue(report['meshInventoryCoverage']['crossReportOccurrenceMatch'])
        self.assertTrue(report['meshInventoryCoverage']['reportSummaryScopeMatch'])
        self.assertEqual(report['identifiedExcludedOnlyMeshes'][0]['meshGUID'], 'a' * 32)
        self.assertEqual(report['excludedMeshFilterObjects'][0]['identifiedMeshReferences'][0]['meshGUID'], 'a' * 32)
        self.assertEqual(report['summary']['excludedMaterialIdentityCount'], 1)
        material = report['excludedMaterialInventory'][0]
        self.assertEqual(material['name'], 'HiddenMaterial')
        self.assertEqual(material['materialGUID'], 'c' * 32)
        self.assertEqual(material['mainTextureGUID'], 'd' * 32)
        text_report = CMP.render_text(report)
        self.assertIn('Mesh 完整资源清单状态', text_report)
        self.assertIn('HiddenMaterial', text_report)

    def test_v6_inventory_can_be_read_from_exclude_report_alone(self):
        a, b = _attach_v6_inventory(*_fixture())
        a['meshDiagnostics']['schema'] = 'scsp-mesh-channel-diagnostics-v5'
        a['meshDiagnostics'].pop('meshInventory', None)
        a['meshDiagnostics'].pop('meshInventorySummary', None)
        report = CMP.compare_reports(a, b)
        self.assertTrue(report['meshInventoryCoverage']['available'])
        self.assertEqual(report['summary']['identifiedExcludedMeshGUIDCount'], 1)
        self.assertTrue(report['meshInventoryCoverage']['scopeCountsMatch'])

    def test_v6_occurrence_mismatch_is_auditable_warning(self):
        a, b = _attach_v6_inventory(*_fixture())
        b['meshDiagnostics']['meshInventory'][0]['gameObjects'][0]['meshFilterComponentFileIDs'] = [999]
        report = CMP.compare_reports(a, b)
        self.assertTrue(report['meshInventoryCoverage']['crossReportIdentityMatch'])
        self.assertFalse(report['meshInventoryCoverage']['crossReportOccurrenceMatch'])
        self.assertEqual(report['summary']['status'], 'WARNING')

    def test_v6_inventory_mismatch_is_auditable_warning(self):
        a, b = _attach_v6_inventory(*_fixture())
        b['meshDiagnostics']['meshInventory'][0]['meshGUID'] = 'f' * 32
        b['meshDiagnostics']['meshInventorySummary']['complete'] = True
        report = CMP.compare_reports(a, b)
        self.assertEqual(report['meshInventoryCoverage']['crossReportIdentityMatch'], False)
        self.assertEqual(report['summary']['status'], 'WARNING')
        self.assertTrue(any(item['name'] == 'Mesh 完整资源身份清单' and item['status'] == 'WARNING' for item in report['checks']))

    def test_source_inputs_unchanged(self):
        a, b = _fixture()
        old = copy.deepcopy((a,b))
        CMP.compare_reports(a,b)
        self.assertEqual((a,b),old)

    def test_swapped_policies_rejected(self):
        a,b = _fixture()
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(b,a)

    def test_same_policies_rejected(self):
        a,b = _fixture()
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,a)

    def test_wrong_stage_rejected(self):
        a,b = _fixture()
        b['stage']['root'] = 'OtherStage'
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,b)

    def test_wrong_project_rejected(self):
        a,b = _fixture()
        b['stage']['project'] = r'D:\Other\scene-project'
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,b)

    def test_scene_windows_slashes_case_insensitive(self):
        a,b = _fixture()
        b['stage']['scene'] = r'assets\stage.unity'
        b['stage']['project'] = r'c:/stage/scene-project/'
        self.assertEqual(CMP.compare_reports(a,b)['summary']['status'], 'PASS')

    def test_source_mismatch_rejected(self):
        a,b = _fixture()
        b['source']['uniqueMeshReferences'] = 10
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,b)

    def test_internal_policy_mismatch_rejected(self):
        a,b = _fixture()
        b['meshDiagnostics']['conversionPolicy'] = 'include'
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,b)

    def test_report_schema_rejected(self):
        a,b = _fixture()
        b['schema'] = 'unknown'
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,b)

    def test_missing_mesh_diagnostics_rejected(self):
        a,b = _fixture()
        b['meshDiagnostics'] = {}
        with self.assertRaises(CMP.ComparisonError):
            CMP.compare_reports(a,b)

    def test_blender_triangle_inconsistency_warning(self):
        a,b = _fixture()
        b['pmx']['parser']['faces'] = 0
        report = CMP.compare_reports(a,b)
        self.assertEqual(report['summary']['status'], 'WARNING')
        self.assertTrue(any(c['status']=='WARNING' and '面数' in c['name'] for c in report['checks']))

    def test_unexpected_texture_warning(self):
        a,b = _fixture()
        b['pmx']['textureValidation']['normalized_references'] = ['textures/unknown.png']
        report = CMP.compare_reports(a,b)
        self.assertEqual(report['summary']['status'], 'WARNING')
        self.assertEqual(report['pmxTextureDifferences']['unexpectedlyAddedInExclude'],['textures/unknown.png'])

    def test_missing_guid_provenance_not_invented(self):
        a,b = _fixture()
        b['meshDiagnostics']['excludedOnlyMissingEither'] = []
        b['meshDiagnostics']['excludedOnlyMissingNormals'] = []
        report = CMP.compare_reports(a,b)
        self.assertEqual(report['summary']['identifiedExcludedMeshGUIDCount'], 0)
        self.assertEqual(report['summary']['unidentifiedExcludedMeshGUIDCount'], 1)
        self.assertFalse(report['summary']['meshInventoryAvailable'])
        self.assertEqual(report['summary']['info'], 1)

    def test_shared_mesh_is_not_double_counted(self):
        a,b = _fixture()
        # Excluded child shares its unique Mesh with an included object.
        b['meshDiagnostics']['excludedOnlyUniqueMeshReferences'] = 0
        b['meshDiagnostics']['conversionUniqueMeshReferences'] = 2
        b['meshDiagnostics']['excludedOnlyMissingNormalsCount'] = 0
        b['meshDiagnostics']['excludedOnlyMissingEitherCount'] = 0
        b['meshDiagnostics']['conversionMissingNormalsCount'] = 1
        b['meshDiagnostics']['conversionMissingEitherCount'] = 1
        b['meshDiagnostics']['excludedOnlyMissingEither'] = []
        b['meshDiagnostics']['excludedOnlyMissingNormals'] = []
        self.assertEqual(CMP.compare_reports(a,b)['summary']['status'], 'PASS')
        self.assertEqual(CMP.compare_reports(a,b)['summary']['excludedOnlyUniqueMeshes'], 0)

    def test_files_written_and_preserve_inputs(self):
        a,b = _fixture()
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            inc, exc = root/'include.json', root/'exclude.json'
            inc.write_text(json.dumps(a),encoding='utf-8')
            exc.write_text(json.dumps(b),encoding='utf-8')
            inc_data,exc_data=inc.read_bytes(),exc.read_bytes()
            out_json,out_txt=root/'generated'/'result.json',root/'generated'/'result.txt'
            report=CMP.compare_report_files(inc,exc,out_json,out_txt)
            self.assertEqual(report['summary']['status'],'PASS')
            self.assertEqual((inc.read_bytes(),exc.read_bytes()),(inc_data,exc_data))
            self.assertEqual(json.loads(out_json.read_text(encoding='utf-8'))['schema'],CMP.REPORT_SCHEMA)
            self.assertIn('StageRoot',out_txt.read_text(encoding='utf-8-sig'))

    def test_reject_output_suffix_that_can_overwrite_pmx(self):
        a, b = _fixture()
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            inc, exc = root/'include.json', root/'exclude.json'
            inc.write_text(json.dumps(a), encoding='utf8')
            exc.write_text(json.dumps(b), encoding='utf8')
            protected=root/'stage.pmx'
            protected.write_bytes(b'PMX ORIGINAL')
            with self.assertRaises(CMP.ComparisonError):
                CMP.compare_report_files(inc, exc, protected, root/'result.txt')
            self.assertEqual(protected.read_bytes(), b'PMX ORIGINAL')

    def test_refuse_overwrite_input(self):
        a,b = _fixture()
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            inc,exc=root/'include.json',root/'exclude.json'
            inc.write_text(json.dumps(a),encoding='utf-8')
            exc.write_text(json.dumps(b),encoding='utf-8')
            with self.assertRaises(CMP.ComparisonError):
                CMP.compare_report_files(inc,exc,inc,root/'result.txt')
            self.assertEqual(json.loads(inc.read_text(encoding='utf8')),a)

    def test_cli_arguments_and_output(self):
        a,b=_fixture()
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            inc,exc=root/'a.json',root/'b.json'
            inc.write_text(json.dumps(a),encoding='utf8')
            exc.write_text(json.dumps(b),encoding='utf8')
            result=subprocess.run([sys.executable,str(MODULE_PATH),'--include',str(inc),'--exclude',str(exc),
                '--json-out',str(root/'result.json'),'--text-out',str(root/'result.txt')],
                capture_output=True,text=True,encoding='utf8')
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertTrue((root/'result.json').exists())
            self.assertTrue((root/'result.txt').exists())

    def test_cli_reject_corrupt_json(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            inc,exc=root/'a.json',root/'b.json'
            inc.write_text('{bad',encoding='utf8')
            exc.write_text('{}',encoding='utf8')
            result=subprocess.run([sys.executable,str(MODULE_PATH),'--include',str(inc),'--exclude',str(exc),
                '--json-out',str(root/'result.json'),'--text-out',str(root/'result.txt')],capture_output=True,text=True,encoding='utf8')
            self.assertEqual(result.returncode,2)
            self.assertFalse((root/'result.json').exists())


if __name__ == '__main__':
    unittest.main()
