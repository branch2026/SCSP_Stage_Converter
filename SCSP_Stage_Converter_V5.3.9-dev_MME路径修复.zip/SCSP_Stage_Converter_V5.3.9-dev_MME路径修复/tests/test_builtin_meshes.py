from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REBUILD_PATH = ROOT / "SceneBuilder" / "rebuild_stage_blender.py"
SPEC = importlib.util.spec_from_file_location("scsp_rebuild_builtin_test", REBUILD_PATH)
REBUILD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REBUILD)


def _cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


class BuiltinMeshTests(unittest.TestCase):
    def test_unity_plane_builtin_has_expected_grid_and_upward_winding(self):
        mesh = REBUILD.parse_builtin_mesh(10209)
        self.assertEqual(mesh["name"], "UnityBuiltin_Plane")
        self.assertEqual(mesh["vertexCount"], 121)
        self.assertEqual(len(mesh["indices"]), 600)
        self.assertEqual(len(mesh["submeshes"]), 1)
        self.assertEqual(len(mesh["uv"]), 121)
        self.assertEqual(mesh["indexFormat"], 0)

        i0, i1, i2 = mesh["indices"][:3]
        a, b, c = (mesh["positions"][i] for i in (i0, i1, i2))
        ab = tuple(b[k] - a[k] for k in range(3))
        ac = tuple(c[k] - a[k] for k in range(3))
        normal = _cross(ab, ac)
        self.assertGreater(normal[1], 0)
        self.assertEqual(mesh["normals"][0], (0.0, 1.0, 0.0))

    def test_unity_quad_builtin_has_negative_z_normal(self):
        mesh = REBUILD.parse_builtin_mesh(10210)
        self.assertEqual(mesh["name"], "UnityBuiltin_Quad")
        self.assertEqual(mesh["vertexCount"], 4)
        self.assertEqual(mesh["indices"], [0, 2, 1, 2, 3, 1])
        self.assertEqual(mesh["normals"], [(0.0, 0.0, -1.0)] * 4)
        self.assertEqual(len(mesh["uv"]), 4)

        i0, i1, i2 = mesh["indices"][:3]
        a, b, c = (mesh["positions"][i] for i in (i0, i1, i2))
        ab = tuple(b[k] - a[k] for k in range(3))
        ac = tuple(c[k] - a[k] for k in range(3))
        normal = _cross(ab, ac)
        self.assertLess(normal[2], 0)

    def test_unsupported_builtin_fileid_fails_explicitly(self):
        with self.assertRaisesRegex(ValueError, "Unsupported Unity built-in mesh"):
            REBUILD.parse_builtin_mesh(99999)

    def test_validator_resolves_two_meshes_sharing_one_builtin_guid(self):
        scene_text = """%YAML 1.1
--- !u!1 &1
GameObject:
  m_Component:
  - component: {fileID: 2}
  - component: {fileID: 3}
  m_Name: StageRoot
  m_IsActive: 1
--- !u!4 &2
Transform:
  m_GameObject: {fileID: 1}
  m_Children:
  - {fileID: 5}
  m_Father: {fileID: 0}
--- !u!33 &3
MeshFilter:
  m_GameObject: {fileID: 1}
  m_Mesh: {fileID: 10209, guid: 0000000000000000e000000000000000, type: 0}
--- !u!1 &4
GameObject:
  m_Component:
  - component: {fileID: 5}
  - component: {fileID: 6}
  m_Name: QuadChild
  m_IsActive: 1
--- !u!4 &5
Transform:
  m_GameObject: {fileID: 4}
  m_Father: {fileID: 2}
--- !u!33 &6
MeshFilter:
  m_GameObject: {fileID: 4}
  m_Mesh: {fileID: 10210, guid: 0000000000000000e000000000000000, type: 0}
"""
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "scene-project"
            assets = project / "Assets"
            assets.mkdir(parents=True)
            scene = assets / "Test.unity"
            scene.write_text(scene_text, encoding="utf-8")

            report_path = Path(temp) / "validation.json"
            command = [
                sys.executable,
                str(ROOT / "Validator" / "validate_source.py"),
                "--project", str(project),
                "--scene", "Assets/Test.unity",
                "--root", "StageRoot",
                "--out", str(report_path),
            ]
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertTrue(report["ok"])
            self.assertEqual(report["uniqueMeshGUIDs"], 1)
            self.assertEqual(report["uniqueMeshReferences"], 2)
            self.assertEqual(report["decodedMeshes"], 2)
            self.assertEqual(report["builtinMeshesResolved"], 2)
            self.assertEqual(report["builtinMeshTypes"], {"Plane": 1, "Quad": 1})
            self.assertEqual(report["resolvedMeshFilterComponents"], 2)


if __name__ == "__main__":
    unittest.main()
