from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]


class PipelineWiringTests(unittest.TestCase):
    def test_gui_uses_native_exporter(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        ast.parse(source)
        self.assertIn('PMXExporter" / "export_with_mmd_tools.py', source)
        self.assertIn("MMD_TOOLS_CHECKER", source)
        self.assertIn("texture_validation.get", source)
        self.assertIn("texture_path_rewrite", source)
        self.assertNotIn('PMXExporter" / "export_stage_pmx.py"', source)

    def test_batch_queue_is_project_isolated_per_task(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        self.assertIn('command=self._add_stage_folders', source)
        self.assertIn('"project": str(project_root)', source)
        self.assertIn('task.get("project", "")', source)
        self.assertIn('"source_folder": str(stage_folder)', source)
        self.assertIn('"version": 3', source)

    def test_batch_discovery_module_is_included(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        self.assertIn('"batch_folder_discovery.py"', source)
        module = ROOT / "UnityParser" / "batch_folder_discovery.py"
        self.assertTrue(module.is_file())
        module_source = module.read_text(encoding="utf-8-sig")
        self.assertIn('project_root / "Assets"', module_source)
        self.assertIn('path.suffix.lower() == ".unity"', module_source)

    def test_exporter_uses_texture_table_only_pipeline(self):
        source = (ROOT / "PMXExporter" / "export_with_mmd_tools.py").read_text(encoding="utf-8-sig")
        self.assertIn("normalize_pmx_texture_paths", source)
        self.assertIn("mmd_pmx.load(str(output_pmx))", source)
        self.assertIn("original_pmx_bytes", source)
        self.assertNotIn("pmx_stage_writer", source)

    def test_main_gui_launcher_is_preserved(self):
        launcher = (ROOT / "RUN_GUI.bat").read_text(encoding="ascii")
        self.assertIn('py -3 "%~dp0gui.py"', launcher)
        self.assertNotIn("repair_existing_pmx_texture_paths", launcher)

    def test_native_export_command_preserves_user_addon_preferences(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        tree = ast.parse(source)
        convert = next(
            node for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef) and node.name == "_convert_one"
        )
        export_assignment = next(
            node for node in ast.walk(convert)
            if isinstance(node, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == "export_cmd" for t in node.targets)
        )
        string_values = {
            node.value for node in ast.walk(export_assignment.value)
            if isinstance(node, ast.Constant) and isinstance(node.value, str)
        }
        self.assertIn("--background", string_values)
        self.assertIn("--disable-autoexec", string_values)
        self.assertIn("--python", string_values)
        self.assertNotIn("--factory-startup", string_values)
        self.assertIn("str(blend_path)", source)

    def test_rebuild_still_uses_factory_startup(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        self.assertIn('"--background", "--factory-startup", "--disable-autoexec"', source)


    def test_v24_quality_inspection_is_wired_after_native_export(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        self.assertIn('QUALITY_CHECKER = APP / "Validator" / "quality_check.py"', source)
        self.assertIn("run_quality_check", source)
        self.assertIn('"task_quality"', source)
        self.assertIn('"quality"', source)
        convert = source[source.index("    def _convert_one("):source.index("    def _poll_events(")]
        self.assertLess(convert.index('"MMD Tools 原生 PMX 导出"'), convert.index("run_quality_check"))

    def test_v24_quality_checker_is_separate_and_non_mutating(self):
        module = ROOT / "Validator" / "quality_check.py"
        self.assertTrue(module.is_file())
        source = module.read_text(encoding="utf-8-sig")
        ast.parse(source)
        self.assertIn("read_texture_table_bytes", source)
        self.assertIn("_safe_texture_target", source)
        self.assertIn("inspect_scene_objects", source)
        self.assertIn("does not modify Unity assets", source)

    def test_v24_attempts_partial_quality_report_when_conversion_fails(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8-sig")
        self.assertIn("def _write_partial_quality_report", source)
        worker = source[source.index("    def _worker_main("):source.index("    def _preflight_mmd_tools(")]
        self.assertIn("self._write_partial_quality_report(task)", worker)
        self.assertIn('task["_output_dir"] = str(out_dir)', source)

    def test_v24_keeps_existing_conversion_modules_present(self):
        for relative in (
            "SceneBuilder/rebuild_stage_blender.py",
            "PMXExporter/export_with_mmd_tools.py",
            "PMXExporter/pmx_texture_pipeline.py",
            "PMXExporter/texture_path_repair.py",
            "UnityParser/batch_folder_discovery.py",
            "Validator/validate_source.py",
        ):
            self.assertTrue((ROOT / relative).is_file(), relative)

    def test_python_sources_parse(self):
        for path in ROOT.rglob("*.py"):
            if "__pycache__" in path.parts:
                continue
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))


    def test_v2410_normal_inactive_diagnostics_is_read_only_and_wired_to_gui(self):
        gui = (ROOT / "gui.py").read_text(encoding="utf-8")
        module = (ROOT / "Validator" / "diagnose_warnings.py").read_text(encoding="utf-8")
        self.assertIn('text="WARNING / 法线关联诊断…"', gui)
        self.assertIn('normalInactiveAssociation', module)
        self.assertIn('scsp-warning-diagnostics-v2', module)
        self.assertIn("diagnose_warning_files", gui)
        self.assertIn("conversionWasExecuted\": False", module)
        self.assertIn("conversionFilesWereModified\": False", module)
        self.assertTrue((ROOT / "RUN_WARNING_DIAGNOSTICS.bat").is_file())



if __name__ == "__main__":
    unittest.main()
