from struct import unpack_from
import unittest

from StageEffects.light_timeline import Clip, Curve, LightTimeline
from StageEffects.scene_lighting import light_receiver_shader, timeline_atlas


def constant_clip(start, duration, after=0, blend_in=0, blend_out=0):
    increasing = Curve((0.,1.), ((0.,0.,0.),(1.,0.,0.))) if blend_in else None
    decreasing = Curve((0.,1.), ((1.,0.,0.),(0.,0.,0.))) if blend_out else None
    return Clip(start,duration,0,1,10,False,0,after,blend_in,blend_out,increasing,decreasing)


class LightTimelineTests(unittest.TestCase):
    def test_step_curves_and_marker_wait_for_the_source_frame(self):
        schedule = LightTimeline()
        schedule.markers['7'] = 1.0
        self.assertFalse(schedule.value('7','m_IsActive',29/30,False))
        self.assertTrue(schedule.value('7','m_IsActive',30/30,False))
        keys = Curve((0.,3.3500001,4.733333), ((1.,0.,float('inf')),(0.,0.,float('inf')),(1.,0.,0.)))
        schedule.channels['12','m_IsActive'] = [(constant_clip(0,130,100),keys)]
        expected = [True, False, False, True]
        self.assertEqual([schedule.value('12','m_IsActive',frame/30,False) for frame in (100,101,141,142)],expected)

    def test_crossfade_and_fractional_clip_hold_have_no_relight_frame(self):
        schedule = LightTimeline()
        lit = Curve((0.,),((10.,0.,0.),))
        dark = Curve((0.,),((0.,0.,0.),))
        a = constant_clip(0., 12., blend_out=4.)
        b = constant_clip(8., 6.0000001, after=float('inf'), blend_in=4.)
        schedule.channels['4','m_Intensity'] = [(a,lit),(b,dark)]
        self.assertEqual(schedule.value('4','m_Intensity',8.,10),10)
        self.assertEqual(schedule.value('4','m_Intensity',10.,10),5)
        for time in (12,14,14+1/30):
            self.assertEqual(schedule.value('4','m_Intensity',time,10),0)

    def test_dds_texel_layout_and_paired_shader_profiles(self):
        samples = [(2.,3.,4.,1.,5.,6.,7.,8.),(0.,0.,0.,0.,5.,6.,7.,8.)]
        layout, dds = timeline_atlas({10:samples,12:samples})
        self.assertEqual(dds[:4],b'DDS ')
        self.assertEqual(unpack_from('<I',dds,84)[0],116)
        self.assertEqual(unpack_from('<8f',dds,128+layout[3][12]*16),samples[0])
        code = light_receiver_shader([dict(file_id=12,type='point',position=(5,6,7),
                                           color=(1,1,1),intensity=1,range=8)],1,layout)
        self.assertIn('StageLightTimeline.dds',code)
        self.assertIn('ReadLightFrame(cell0 + 1.0)',code)
        for shader_pass in code.split('pass P {')[1:]:
            self.assertIn('compile vs_3_0',shader_pass)
            self.assertIn('compile ps_3_0',shader_pass)
