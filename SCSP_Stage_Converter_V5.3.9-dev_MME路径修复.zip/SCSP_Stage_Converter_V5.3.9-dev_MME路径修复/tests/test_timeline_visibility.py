from decimal import Decimal
from pathlib import Path
import tempfile
import unittest

from StageEffects.auto_restore import restore
from StageEffects.timeline_visibility import activation_keys
from StageEffects.vmd_codec import parse_vmd
from test_stage_effects_v31 import pmx_fixture, read_material_morph_offsets


class TimelineActivationTests(unittest.TestCase):
    def test_half_open_and_overlapping_clip_intervals(self):
        intervals = [(Decimal(a), Decimal(b)) for a, b in [('1','2'), ('1.5','3')]]
        weights = dict(activation_keys(intervals, 100))
        self.assertEqual([weights[i] for i in (0,29,30,89,90,100)], [1,1,0,0,1,1])

    def test_serialized_timeline_generates_visibility_only_for_exclusive_material(self):
        with tempfile.TemporaryDirectory() as workspace:
            project = Path(workspace)
            assets = project / 'Assets'
            assets.mkdir()
            mat_guid, timeline_guid = '1'*32, '2'*32
            (assets / 'MatA.mat').write_text('Material:\n  m_Name: MatA\n','utf8')
            (assets / 'MatA.mat.meta').write_text(f'guid: {mat_guid}\n','utf8')
            (assets / 'timeline.playable.meta').write_text(f'guid: {timeline_guid}\n','utf8')
            (assets / 'timeline.playable').write_text('''--- !u!114 &11400000
MonoBehaviour:
  m_Tracks:
  - {fileID: 2}
--- !u!114 &2
MonoBehaviour:
  m_PostPlaybackState: 3
  m_Muted: 0
  m_Parent: {fileID: 11400000}
  m_Clips:
  - m_Version: 1
    m_Start: 1
    m_Asset: {fileID: 3}
    m_Duration: 1
--- !u!114 &3
MonoBehaviour:
  m_Name: ActivationPlayableAsset
''','utf8')
            scene = assets / 'test.unity'
            scene.write_text(f'''--- !u!1 &1
GameObject:
  m_Name: UnitStage
  m_IsActive: 1
--- !u!1 &2
GameObject:
  m_Name: LightPanel
  m_IsActive: 1
--- !u!4 &3
Transform:
  m_GameObject: {{fileID: 1}}
  m_Father: {{fileID: 0}}
--- !u!4 &4
Transform:
  m_GameObject: {{fileID: 2}}
  m_Father: {{fileID: 3}}
--- !u!23 &5
MeshRenderer:
  m_GameObject: {{fileID: 2}}
  m_Enabled: 1
  m_Materials:
  - {{fileID: 2100000, guid: {mat_guid}, type: 2}}
--- !u!320 &6
PlayableDirector:
  m_Enabled: 1
  m_InitialTime: 0
  m_PlayableAsset: {{fileID: 11400000, guid: {timeline_guid}, type: 2}}
  m_SceneBindings:
  - key: {{fileID: 2, guid: {timeline_guid}, type: 2}}
    value: {{fileID: 2}}
''','utf8')
            pmx = project / 'stage.pmx'
            pmx.write_bytes(pmx_fixture())
            texture = project / 'textures/test.png'
            texture.parent.mkdir()
            texture.write_bytes(b'fixture')
            output = project / 'AutoStage'
            report = restore(project,scene,pmx,output,90)
            self.assertEqual(report['visibility_controls'], 1)
            morph = read_material_morph_offsets(next(output.glob('*.pmx')).read_bytes())['Hide0001']
            self.assertEqual(morph['offsets'][0]['values'][3], -1)
            motion = parse_vmd(next(output.glob('*.vmd')).read_bytes())
            self.assertEqual({k['frame']: k['weight'] for k in motion['morph_frames']},
                             {0:1,29:1,30:0,59:0,60:1,90:1})

            with scene.open('a',encoding='utf8') as text:
                text.write(f'''--- !u!23 &7
MeshRenderer:
  m_GameObject: {{fileID: 1}}
  m_Enabled: 1
  m_Materials:
  - {{fileID: 2100000, guid: {mat_guid}, type: 2}}
''')
            report = restore(project,scene,pmx,project/'Shared',90)
            self.assertEqual(report['visibility_controls'], 0)
            self.assertIn('独占',report['timeline_activation'][0]['reason'])
