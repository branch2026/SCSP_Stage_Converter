import unittest

from StageEffects.mesh_beams import beam_shader


class MeshBeamTests(unittest.TestCase):
    def test_light_beams_follow_cue_and_slot_lifetime(self):
        fx = beam_shader(52.18309783935547,dict(color=(1,.5,.8,1),alpha=[(0,0),(.1,1),(1,0)],
                         lifetime=.15,period=.2,spacing=.1))
        self.assertIn('Seconds - 52.18309784 - slot * 0.10000000',fx)
        self.assertIn('step(0.0, elapsed) * (1.0 - step(1.0, phase))',fx)
        self.assertIn('SrcBlend = SRCALPHA; DestBlend = ONE;',fx)
        self.assertIn('ZWriteEnable = false;',fx)
