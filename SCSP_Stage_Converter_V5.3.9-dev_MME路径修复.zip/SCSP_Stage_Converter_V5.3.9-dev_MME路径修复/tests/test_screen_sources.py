from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from StageEffects.screen_sources import screen_preview, screen_sources
from StageEffects.vmd_codec import parse_vmd


class ScreenSourceTests(unittest.TestCase):
    def test_matches_camera_target_to_material_reference(self):
        with TemporaryDirectory() as tmp:
            assets = Path(tmp)
            mat = assets/'Panel.mat'
            mat.write_text('  _MainTex:\n    m_Texture: {fileID: 12}\n','utf-8')
            guid = '1'*32
            scene = assets/'demo.unity'
            scene.write_text(f'''--- !u!1 &1
GameObject:
  m_Name: Stage
--- !u!23 &3
MeshRenderer:
  m_GameObject: {{fileID: 1}}
  m_Materials:
  - {{fileID: 2100000, guid: {guid}}}
--- !u!20 &7
Camera:
  m_GameObject: {{fileID: 4}}
  m_TargetTexture: {{fileID: 12}}
--- !u!84 &12
RenderTexture:
  m_Name: ScreenInput
''','utf-8')
            actual, = screen_sources(scene,assets,[dict(name='Panel',path=str(mat),guid=guid)],{},'Stage')
            self.assertTrue(actual['inside_export_root'])
            layer, = actual['materials']
            self.assertEqual(layer['source_type'],'camera_render_texture')
            self.assertEqual(layer['cameras'][0]['camera_file_id'],'7')

    def test_preview_compresses_verified_screen_switches(self):
        visibility = [dict(name='Hide0001',keys=[[0,0],[109,0],[110,1],[3479,1],[3480,0]],
                           unity_evidence=dict(source_type='animation_clip',file_id='624',object='CaptureDisplay'))]
        screen = dict(object_file_id='624',inside_export_root=True)
        motion, (report,) = screen_preview('Stage',[screen],visibility)
        self.assertEqual([x['source_frame'] for x in report['switches']],[110,3480])
        keys = {f['frame']:f['weight'] for f in parse_vmd(motion)['morph_frames']}
        self.assertEqual([keys[k] for k in (29,30,89,90)],[0,1,1,0])
        self.assertEqual(screen_preview('Stage',[],visibility),(None,[]))
