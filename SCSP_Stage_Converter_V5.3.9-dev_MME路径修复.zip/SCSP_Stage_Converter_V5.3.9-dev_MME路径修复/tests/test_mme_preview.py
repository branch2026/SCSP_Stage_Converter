from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from StageEffects.mme_preview import (lamp_overlay_mode, light_plane_mode, mapped_material,
                                     material_mode, pool_material_mode, shader_text)
from StageEffects.mme_reflection import reflection_shader, stage_probe
from StageEffects.mme_preview import timed_scroll, without_uv_tracks
from StageEffects.vmd_codec import parse_vmd, write_vmd
from StageEffects.pmx_binary import Model
from StageEffects.scene_lighting import light_receiver_shader, scene_lights
from test_stage_effects_v31 import pmx_fixture_multi_material


class MMEPreviewTests(unittest.TestCase):
    def test_fully_automatic_motion_keeps_neutral_playback_frames(self):
        motion = write_vmd('Stage',[('UV0100X',0,0.0),('UV0100X',5400,0.8)])
        result = parse_vmd(without_uv_tracks(motion,{'UV0100X'}))
        self.assertEqual([(row['frame'],row['weight']) for row in result['morph_frames']],
                         [(0,0.0),(5400,0.0)])

    def test_direct_scroll_removes_only_the_converted_uv_track(self):
        code = shader_text(dict(mode='opaque',src='ONE',dst='ZERO',zwrite=True,light=None,cutoff=None))
        effect = dict(name='UV0100X',uv_channel=0,offset=(-1,0),unity_evidence={'speed':-0.25})
        ignored = dict(effect,name='LT0100X',uv_channel=1)
        code, tracks = timed_scroll(code,[effect,ignored])
        self.assertIn('frac(max(AutoSeconds, 0.0) * 0.25000000)',code)
        self.assertEqual(tracks,['UV0100X'])
        motion = write_vmd('Stage',[('UV0100X',0,0.0),('Hide0001',5,1.0)])
        result = parse_vmd(without_uv_tracks(motion,set(tracks)))
        self.assertEqual([row['name'] for row in result['morph_frames']],['Hide0001'])

    def test_scene_lights_preserve_parent_transform_range_and_disabled_state(self):
        scene = """--- !u!1 &1
GameObject:
  m_Name: Parent
  m_IsActive: 1
--- !u!1 &2
GameObject:
  m_Name: Lamp
  m_IsActive: 1
--- !u!4 &3
Transform:
  m_GameObject: {fileID: 1}
  m_LocalPosition: {x: 1, y: 0, z: 2}
  m_Father: {fileID: 0}
--- !u!4 &4
Transform:
  m_GameObject: {fileID: 2}
  m_LocalPosition: {x: 0, y: 1, z: 1}
  m_Father: {fileID: 3}
--- !u!108 &5
Light:
  m_GameObject: {fileID: 2}
  m_Enabled: 1
  m_Type: 0
  m_Color: {r: 0.5, g: 0.25, b: 1, a: 1}
  m_Intensity: 2
  m_Range: 5
  m_SpotAngle: 60
  m_InnerSpotAngle: 35
--- !u!108 &6
Light:
  m_GameObject: {fileID: 2}
  m_Enabled: 0
  m_Type: 1
"""
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'Scene.unity'
            path.write_text(scene, encoding='utf8')
            spot, disabled = scene_lights(path, 10)
        self.assertEqual(spot['status'], 'supported')
        self.assertEqual(spot['position'], (10, 10, -30))
        self.assertEqual(spot['range'], 50)
        self.assertEqual(spot['direction'], (0, 0, -1))
        self.assertEqual(disabled['status'], 'skipped')
        code = light_receiver_shader([spot], 1)
        self.assertIn('smoothstep(', code)
        self.assertIn('distance0 / 50.00000000', code)
        self.assertIn('float3(1.00000000, 0.50000000, 2.00000000)', code)
        for shader_pass in code.split('pass P {')[1:]:
            self.assertIn('VertexShader = compile vs_3_0', shader_pass)
            self.assertIn('PixelShader = compile ps_3_0', shader_pass)

    def test_static_light_map_does_not_depend_on_vmd_uv1(self):
        guid = 'a' * 32
        material = '''      _MainTex:
        m_Scale: {x: 1, y: 1}
      _LightTex:
        m_Scale: {x: 0, y: 0.5}
'''
        values = dict(_Intensity=0.115, _SrcBlend=1, _DstBlend=10, _ZWrite=0)
        shader = 'Giken/3d/Texture_Add_Scroll_LightAdjust'
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'light.png'
            path.touch()
            config = mapped_material(shader,values,{'_LightTex'},material,{'_LightTex':guid},{guid:path})
            self.assertEqual(config['map_uv'], (0, 0.5, 0, 0.5))
            self.assertIn('tex2D(MapSampler, mapUV).rgb * 0.11500000',shader_text(config))
            self.assertIsNone(mapped_material(shader,dict(values,_SpeedL=0.5),{'_LightTex'},
                                              material,{'_LightTex':guid},{guid:path}))

    def test_light_planes_draw_after_surfaces_with_additive_blending(self):
        material = dict(guid='3f29fdc9b393418488dab64c5e2f3dc4',
                        textures=dict(_MainTex='9d3430c2991b82d499e0691fac5a2503'))
        mode = light_plane_mode('Giken/3d/Texture_Add_Scroll_LightAdjust', material, {'_Intensity': 1.2})
        code = shader_text(mode)
        self.assertIn('DestBlend = ONE;', code)
        self.assertIn('ZWriteEnable = false;', code)
        pmx = Model(pmx_fixture_multi_material())
        pmx = Model(pmx.add_morphs([dict(type=8, name='Light', targets=[(0, (0, 0, 0, -1)),
                                                                       (-1, (0, 0, 0, 0))])]))
        result, mapping = pmx.materials_last({0})
        new = Model(result)
        self.assertEqual(mapping, {0: 1, 1: 0})
        self.assertEqual([m.name for m in new.materials], ['MatB', 'MatA'])
        self.assertEqual(new.face_indices(0, 6), pmx.face_indices(3, 3) + pmx.face_indices(0, 3))
        references = [int.from_bytes(new.data[at:at+new.mat_width], 'little', signed=True)
                      for at in new.material_morph_indices]
        self.assertEqual(references, [1, -1])

    def test_nightp_ball_has_green_floor_and_shadow_keeps_multiply(self):
        ball = pool_material_mode(None, 'Giken/3d/LightObjectAdjust',
                                  {'guid': '98d339e37a483474a964de2b62a33e96'},
                                  {'_Intensity': 3, '_ZWrite': 1})
        self.assertIn('ModelTint.rgb * 0.25', shader_text(ball))
        shadow = material_mode('Custom/AllinOne(ParticleSystem)',
                               dict(_BlendSrc=2, _BlendDst=0, _ZWriteMode=0), False, set())
        softened = pool_material_mode(shadow, 'Custom/AllinOne(ParticleSystem)',
                                      {'guid': 'd56baac5ac13d9f45971b87d8e63da13'}, {})
        self.assertIn('base.a * 0.45000000', shader_text(softened))
        self.assertIn('SrcBlend = DESTCOLOR;', shader_text(softened))

    def test_reflection_requires_the_probe_assigned_in_render_settings(self):
        guid = 'a' * 32
        with TemporaryDirectory() as temporary:
            assets = Path(temporary)
            scene = assets / 'Stage.unity'
            probe = assets / 'Baked.exr'
            probe.touch()
            scene.write_text(f'  m_CustomReflection: {{fileID: 8900000, guid: {guid}, type: 3}}', 'utf8')
            self.assertEqual(stage_probe(scene, assets, lambda _: guid), (probe, (0, 0, 0)))
            self.assertIsNone(stage_probe(scene, assets, lambda _: 'b' * 32))
        effect = reflection_shader(0.76, 1, (0.8, 0.9, 1))
        self.assertIn('ResourceType = "CUBE"', effect)
        self.assertIn('lerp(sharp, diffuse, 0.76000000)', effect)
        self.assertIn('env += (1.0 - env) * float3(0.80000000, 0.90000000, 1.00000000) * hemiFill', effect)

    def test_multiply_and_explicit_mask_gate(self):
        properties = dict(_BlendSrc=2,_BlendDst=0,_ZWriteMode=0)
        config = material_mode('Custom/AllinOne(ParticleSystem)',properties,False,set())
        self.assertEqual(config['mode'],'multiply')
        self.assertIn('SrcBlend = DESTCOLOR;',shader_text(config))
        self.assertIsNone(material_mode('Custom/AllinOne(ParticleSystem)',
                                       dict(properties,_MaskSwitch=1),False,set()))

    def test_mme_does_not_infer_unrelated_giken_blend_properties(self):
        self.assertIsNone(material_mode('Giken/Other',
                                        dict(_SrcBlend=1,_DstBlend=10,_ZWrite=0),False,set()))
        props=dict(_SrcBlend=1,_DstBlend=0,_ZWrite=1,_Intensity=4)
        config=material_mode('Giken/3d/Texture_Add_Scroll_LightAdjust',props,True,set())
        self.assertEqual(config['light'],4)
        self.assertIn('MATERIALSPHEREMAP',shader_text(config))

    def test_water_uses_source_map_and_timeline(self):
        guid = 'a' * 32
        material = '''      _MainTex:
        m_Scale: {x: 2, y: 2}
        m_Offset: {x: 0.25, y: 0.25}
      _Distortion:
        m_Scale: {x: 4, y: 4}
        m_Offset: {x: 0.5, y: 0.25}
      _ScatteringColor: {r: 0.24, g: 0.74, b: 1, a: 1}
      _SpecularColor: {r: 0.22, g: 0.33, b: 0.47, a: 1}
'''
        props = dict(_DistortionSpeed=0.3, _DistortionStrength=0.1, _TextureColorInfluence=0.5)
        declarations = {*props, '_Distortion', '_ScatteringColor', '_SpecularColor'}
        with TemporaryDirectory() as temporary:
            texture = Path(temporary) / 'ripple.png'
            texture.touch()
            config = mapped_material('Prism/Effect/Water', props, declarations,
                                     material, {'_Distortion': guid}, {guid: texture})
            self.assertEqual(config['map_uv'], (2, 2, 0, -0.75))
            shader = shader_text(config)
            self.assertIn('TIME < bool SyncInEditMode = true;', shader)
            self.assertIn(f'"Map_{guid}.png"', shader)
            self.assertIn('StageSeconds * 0.30000000', shader)
            self.assertIn('float3(0.24000000, 0.74000000, 1.00000000) * 0.22', shader)
            self.assertIn('rippleColor * 0.50000000', shader)
            self.assertIsNone(mapped_material('Prism/Effect/Water', props, set(props),
                                              material, {'_Distortion': guid}, {guid: texture}))
            self.assertIsNone(mapped_material('Prism/Effect/Water', props, declarations,
                                              material, {'_Distortion': guid}, {}))
            self.assertIsNone(mapped_material('Prism/Effect/Water', props, declarations,
                                              material.split('_ScatteringColor:')[0],
                                              {'_Distortion': guid}, {guid: texture}))

    def test_floor_lamp_uses_its_atlas_falloff_only_on_the_matched_material(self):
        shader = 'Giken/3d/Texture_Add_Scroll_LightAdjust'
        base = material_mode(shader, dict(_SrcBlend=1, _DstBlend=0, _ZWrite=1, _Intensity=3), True, set())
        material = dict(guid='a12762985d4003e4a889c7e0fc53c1ef',
                        textures=dict(_MainTex='e13875a9c2439f445a0d9bf52b580ae1',
                                      _LightTex='9a8778b1e95663949a4790fe2f201886'))
        code = shader_text(lamp_overlay_mode(base, shader, material))
        self.assertIn('atlasMask * pulse * 3.00000000', code)
        self.assertIn('ZWriteEnable = false;', code)
        self.assertIn('DestBlend = INVSRCALPHA;', code)
        self.assertIs(lamp_overlay_mode(base, shader, dict(material, textures={})), base)

    def test_separate_cutoff_map_clips_at_the_source_threshold(self):
        guid = 'b' * 32
        material = '''      _MainTex:
        m_Scale: {x: 1, y: 1}
      _AlphaTex:
        m_Scale: {x: 1, y: 1}
'''
        with TemporaryDirectory() as temporary:
            texture = Path(temporary) / 'leaf_cutoff.png'
            texture.touch()
            config = mapped_material('Giken/3d/Texture_Cutoff', dict(_Cutoff=0.5, _AlphaClip=0),
                                     {'_Cutoff', '_AlphaTex'}, material, {'_AlphaTex': guid}, {guid: texture})
            shader = shader_text(config)
            self.assertIn('clip(tex2D(MapSampler, mapUV).r - 0.50000000);', shader)
            self.assertNotIn('clip(base.a - 0.50000000);', shader)
