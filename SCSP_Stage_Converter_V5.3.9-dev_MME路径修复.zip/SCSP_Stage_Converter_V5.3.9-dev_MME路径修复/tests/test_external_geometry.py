from pathlib import Path
from struct import unpack_from
import unittest

from StageEffects.external_lights import local_matrix, mesh_records, material_record
from StageEffects.pmx_binary import Cursor, Model
from test_stage_effects_v31 import pmx_fixture


class ExternalGeometryTests(unittest.TestCase):
    def test_world_axis_scale_and_single_material_submesh(self):
        mesh = dict(positions=[(0,0,0),(1,0,0),(0,1,0)],uv=[(0,0),(1,0),(0,1)],
                    indices=[2,2,2,0,1,2],indexFormat=0,
                    submeshes=[dict(firstByte=6,indexCount=3,topology=0,baseVertex=0)])
        transform = local_matrix(dict(rot=(0,0,0,1),scale=(2,1,1),pos=(1,2,3)))
        rows, faces = mesh_records(mesh,transform,12.5,(2,1,.25,0))
        self.assertEqual(faces,[0,1,2])
        self.assertEqual(unpack_from('<3f',rows[0]),(12.5,25.,-37.5))
        self.assertEqual(unpack_from('<3f',rows[1]),(37.5,25.,-37.5))
        self.assertEqual(unpack_from('<2f',rows[1],24),(2.25,1.))

    def test_generated_material_has_explicit_alpha_and_primary_texture(self):
        model = Model(pmx_fixture())
        record = material_record(model,'Lamp',(1,0,1,0),0,3)
        checked = Model(model.data[:model.material_table_at+4]+record+model.data[model.bone_table_at:])
        material, = checked.materials
        self.assertEqual(material.name,'Lamp')
        self.assertEqual(material.diffuse,(1,0,1,0))
        self.assertEqual(material.texture_index,0)
        self.assertEqual(material.faces,3)
