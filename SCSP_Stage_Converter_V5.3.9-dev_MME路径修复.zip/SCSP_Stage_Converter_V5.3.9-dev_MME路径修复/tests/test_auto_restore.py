import math
import unittest

from StageEffects.auto_restore import phase_keys


class ScrollTimingTests(unittest.TestCase):
    def test_interpolated_frames_follow_source_including_wraps(self):
        for speed in (0.2, -0.7166, 1, 32):
            keys = phase_keys(speed, 400)
            self.assertEqual((keys[0][0], keys[-1][0]), (0, 400))
            for (start, a), (end, b) in zip(keys, keys[1:]):
                for frame in range(start, end + 1):
                    weight = a + (b - a) * (frame - start) / (end - start)
                    self.assertTrue(math.isclose(weight, abs(speed)*frame/30 % 1, abs_tol=1e-12))
