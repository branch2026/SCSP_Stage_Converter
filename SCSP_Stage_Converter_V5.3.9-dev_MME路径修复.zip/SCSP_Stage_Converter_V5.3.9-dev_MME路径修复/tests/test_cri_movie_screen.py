import unittest
from math import floor
from pathlib import Path
from struct import pack, unpack

from StageEffects.cri_movie_screen import PAGE_FRAMES, COLUMNS, movie_shader, unpack_cri_ivf


def chunk(tag, payload, kind=0, padding=0):
    head = pack('>HHB',24,padding,0)+bytes((0,0,kind))+bytes(16)
    return pack('>4sI',tag,len(head)+len(payload)+padding)+head+payload+bytes(padding)


class CriMovieScreenTests(unittest.TestCase):
    def test_extracts_embedded_ivf_headers_and_removes_only_usm_padding(self):
        header = pack('<4sHH4sHHIIII',b'DKIF',0,32,b'VP90',1536,936,30000,1000,2,0)
        first = pack('<IQ',3,0)+b'abc'
        second = pack('<IQ',2,1)+b'de'
        data = (chunk(b'CRID',b'info',kind=1)+chunk(b'@SFV',b'header',kind=1)
                +chunk(b'@SFV',header+first,padding=5)+chunk(b'@SFV',second,padding=3))
        result,metadata = unpack_cri_ivf(data)
        self.assertEqual(result,header+first+second)
        self.assertEqual(metadata,(1536,936,30000,1000,2))
        with self.assertRaises(ValueError):
            unpack_cri_ivf(data[:-1])

    def test_shader_chooses_exact_cells_on_float32_row_page_and_loop_boundaries(self):
        def f32(value):
            return unpack('<f',pack('<f',value))[0]

        def remainder(index, divisor):
            quotient = floor(f32(f32(index+0.5)*f32(1/divisor)))
            return index-quotient*divisor

        for elapsed in range(3307):
            frame = remainder(elapsed,255)
            tile = remainder(frame,PAGE_FRAMES)
            self.assertEqual(frame,elapsed%255)
            self.assertEqual(remainder(tile,COLUMNS),tile%COLUMNS)
        cue = dict(start_seconds=16.9666666667,end_seconds=127.2,loop_within_clip=True)
        shader = movie_shader([(cue,255,[('a.png',Path('a.png'),16),('b.png',Path('b.png'),4)])])
        self.assertNotIn('fmod',shader)
        self.assertIn('tile - row * 13.0',shader)
        self.assertIn('elapsed - floor((elapsed + 0.5) / 255.0) * 255.0',shader)

    def test_repeated_movie_cues_share_one_texture_and_keep_the_gap(self):
        first = dict(start_seconds=18.2666666667,end_seconds=22.2666666667,loop_within_clip=False)
        repeat = dict(start_seconds=77,end_seconds=81,loop_within_clip=False)
        pages = [('movie.png',Path('movie.png'),10)]
        shader = movie_shader([(first,120,pages),(repeat,120,pages)])
        self.assertEqual(shader.count('ResourceName = "movie.png"'),1)
        self.assertIn('frame >= 548.0 && frame < 668.0',shader)
        self.assertIn('frame >= 2310.0 && frame < 2430.0',shader)

