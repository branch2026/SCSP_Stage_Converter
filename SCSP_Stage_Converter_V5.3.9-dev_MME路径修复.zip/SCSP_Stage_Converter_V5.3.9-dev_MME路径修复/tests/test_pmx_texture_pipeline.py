from __future__ import annotations

import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "PMXExporter"))

from pmx_texture_pipeline import normalize_pmx_texture_paths
from pmx_texture_pipeline import PMXTexturePipelineError
from pmx_texture_table import read_texture_table_bytes


def _pmx_string(value):
    raw = value.encode("utf-16-le")
    return struct.pack("<i", len(raw)) + raw


def _make_pmx(path: Path, textures):
    # Minimal PMX 2.0 header and two BDEF1 vertices; enough structure to locate
    # the texture table. A trailing sentinel checks that table rewrites do not
    # touch any bytes after the table.
    data = bytearray(b"PMX ")
    data += struct.pack("<f", 2.0)
    data += bytes([8, 0, 0, 4, 1, 1, 1, 1, 1])
    for value in ("stage", "stage", "", ""):
        data += _pmx_string(value)
    data += struct.pack("<i", 2)
    for _ in range(2):
        data += struct.pack("<6f", *([0.0] * 6))  # position + normal
        data += struct.pack("<2f", 0.0, 0.0)      # UV0
        data += b"\x00"                            # BDEF1
        data += b"\x00"                            # bone index
        data += struct.pack("<f", 1.0)             # edge scale
    data += struct.pack("<i", 3)                    # index count
    data += struct.pack("<3I", 0, 1, 0)             # surface indices
    data += struct.pack("<i", len(textures))
    for texture in textures:
        data += _pmx_string(texture)
    data += b"SCSP_NON_TEXTURE_DATA_SENTINEL"
    path.write_bytes(data)


class PMXTexturePipelineTests(unittest.TestCase):
    def test_absolute_paths_are_rewritten_to_relative_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            image_a = texture_dir / "wall_a1b2c3d4.png"
            image_b = texture_dir / "floor_b2c3d4e5.png"
            image_a.write_bytes(b"wall-image")
            image_b.write_bytes(b"floor-image")
            pmx = out / "stage.pmx"
            original_refs = [str(image_a.resolve()), str(image_b.resolve())]
            _make_pmx(pmx, original_refs)
            before_bytes = pmx.read_bytes()
            before_table = read_texture_table_bytes(before_bytes)

            result = normalize_pmx_texture_paths(pmx, texture_dir)

            self.assertEqual(result["status"], "PASSED")
            self.assertEqual(result["resolution"]["normalized_absolute_count"], 2)
            self.assertEqual(result["rewrite"]["rewritten_count"], 2)
            self.assertEqual(
                result["normalized_references"],
                ["textures/wall_a1b2c3d4.png", "textures/floor_b2c3d4e5.png"],
            )
            after_bytes = pmx.read_bytes()
            after_table = read_texture_table_bytes(after_bytes)
            self.assertEqual(after_table["textures"], result["normalized_references"])
            self.assertEqual(
                before_bytes[:before_table["table_start"]],
                after_bytes[:after_table["table_start"]],
            )
            self.assertEqual(
                before_bytes[before_table["table_end"]:],
                after_bytes[after_table["table_end"]:],
            )
            self.assertTrue(after_bytes.endswith(b"SCSP_NON_TEXTURE_DATA_SENTINEL"))

    def test_relative_paths_do_not_trigger_binary_rewrite(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            (texture_dir / "wall.png").write_bytes(b"wall")
            pmx = out / "stage.pmx"
            refs = ["textures/wall.png"]
            _make_pmx(pmx, refs)
            original = pmx.read_bytes()

            result = normalize_pmx_texture_paths(pmx, texture_dir)

            self.assertEqual(result["status"], "PASSED")
            self.assertFalse(result["changed"])
            self.assertEqual(result["rewrite"]["status"], "NOT_NEEDED")
            self.assertEqual(pmx.read_bytes(), original)

    def test_missing_absolute_path_leaves_original_pmx_unchanged(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            missing = texture_dir / "not_found.png"
            pmx = out / "stage.pmx"
            _make_pmx(pmx, [str(missing.resolve())])
            original = pmx.read_bytes()

            result = normalize_pmx_texture_paths(pmx, texture_dir)

            self.assertEqual(result["status"], "FAILED")
            self.assertEqual(result["failure_stage"], "resolve")
            self.assertEqual(pmx.read_bytes(), original)

    def test_duplicate_texture_references_keep_order(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            image = texture_dir / "shared.png"
            image.write_bytes(b"shared")
            pmx = out / "stage.pmx"
            refs = [str(image.resolve()), str(image.resolve()), "textures/shared.png"]
            _make_pmx(pmx, refs)

            result = normalize_pmx_texture_paths(pmx, texture_dir)

            self.assertEqual(result["status"], "PASSED")
            self.assertEqual(
                result["normalized_references"],
                ["textures/shared.png", "textures/shared.png", "textures/shared.png"],
            )
            self.assertEqual(
                read_texture_table_bytes(pmx.read_bytes())["textures"],
                result["normalized_references"],
            )


    def test_post_rewrite_validation_failure_rolls_back_original_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            image = texture_dir / "wall_hash1234.png"
            image.write_bytes(b"wall")
            pmx = out / "stage.pmx"
            original_ref = str(image.resolve())
            _make_pmx(pmx, [original_ref])
            original = pmx.read_bytes()

            first_pass = {
                "status": "PASSED",
                "reference_count": 1,
                "resolved_count": 1,
                "normalized_references": ["textures/wall_hash1234.png"],
                "normalized_absolute_count": 1,
                "alias_count": 0,
                "missing_count": 0,
                "ambiguous_count": 0,
                "unresolved_count": 0,
                "missing": [],
                "ambiguous": [],
                "unresolved": [],
                "items": [],
            }
            failed_final = {
                "status": "FAILED",
                "reference_count": 1,
                "resolved_count": 0,
                "normalized_references": ["textures/wall_hash1234.png"],
                "normalized_absolute_count": 0,
                "alias_count": 0,
                "missing_count": 1,
                "ambiguous_count": 0,
                "unresolved_count": 1,
                "missing": [{"reference": "textures/wall_hash1234.png"}],
                "ambiguous": [],
                "unresolved": ["textures/wall_hash1234.png"],
                "items": [],
            }

            with patch(
                "pmx_texture_pipeline.repair_texture_references",
                side_effect=[first_pass, failed_final],
            ):
                with self.assertRaises(PMXTexturePipelineError):
                    normalize_pmx_texture_paths(pmx, texture_dir)

            self.assertEqual(pmx.read_bytes(), original)

    def test_unsafe_relative_path_is_rejected_without_rewrite(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            pmx = out / "stage.pmx"
            _make_pmx(pmx, ["../outside.png"])
            original = pmx.read_bytes()

            result = normalize_pmx_texture_paths(pmx, texture_dir)

            self.assertEqual(result["status"], "FAILED")
            self.assertEqual(pmx.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
