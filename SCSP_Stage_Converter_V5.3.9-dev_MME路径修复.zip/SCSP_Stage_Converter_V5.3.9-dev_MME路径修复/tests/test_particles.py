import unittest

from StageEffects.particles import bubble_births, bubble_shader


class BubbleParticleTests(unittest.TestCase):
    def test_splash_differs_from_additive_bubble_and_has_gravity(self):
        config = dict(lifetime=(.3,.6),size=(.05,.25),rise=(0,0),duration=.6,births=[.04,.08],
                      start_color=[(1,1,1,.2),(1,1,1,.5)],material_color=(1,1,1),
                      alpha=[(0,0),(1,0)],size_keys=[(0,0),(1,1)],
                      splash=True,alignment=2,cue=0,gravity=6.867,angle=.87,speed=[.5,1.2],
                      splash_axes=[(1,0,0),(0,1,0),(0,0,-1)])
        code = bubble_shader(config,12.5)
        self.assertIn('3.43350000 * age * age',code)
        self.assertIn('DestBlend = INVSRCALPHA',code)
        self.assertIn('float2 offset = (corner - 0.5)',code)
        self.assertIn('Seconds - 0.00000000 - Starts[index]',code)

    def test_constant_source_emission_defines_birth_schedule(self):
        births = bubble_births('      minMaxState: 0\n      scalar: 4\n',2)
        self.assertEqual(len(births),8)
        self.assertAlmostEqual(births[0],0.25)
        self.assertAlmostEqual(births[-1],2)

    def test_bubble_shader_uses_timeline_atlas_and_compatible_profiles(self):
        config = dict(lifetime=(1,2),size=(.08,.13),rise=(1,2),duration=3,births=[.3,.8],
                      start_color=[(1,1,1,.5),(1,1,1,1)],material_color=(2,2,2),
                      alpha=[(0,0),(.2,1),(1,1)],size_keys=[(0,0),(1,1)])
        code = bubble_shader(config,12.5)
        self.assertIn('Seconds : TIME',code)
        self.assertIn('MATERIALTEXTURE',code)
        self.assertIn('Starts[2]',code)
        self.assertIn('SrcBlend = SRCALPHA; DestBlend = ONE;',code)
        self.assertEqual(code.count('compile vs_3_0'),code.count('compile ps_3_0'))

    def test_glitter_samples_full_texture_and_uses_source_velocity_axes(self):
        births = bubble_births('      minMaxState: 0\n      scalar: 30\n',5,180)
        self.assertEqual(len(births),150)
        config = dict(lifetime=(2,4),size=(.1,.6),rise=(0,0),duration=5,births=births,
                      start_color=[(1,.47,.77,1),(1,.53,.29,1)],material_color=(4,4,4),
                      alpha=[(0,1),(1,1)],size_keys=[(0,0),(1,0)],
                      motion_axes=[(1,0,0),(0,1,0),(0,0,-1)],drift=[(-.5,0),(0,0),(.2,.3)],rate_hz=30)
        code = bubble_shader(config,12.5)
        self.assertIn('result.uv = lerp(0.002, 0.998, corner)',code)
        self.assertIn('(index + 1.0) / 30.00000000',code)
        self.assertIn('float3(0.00000000, 0.00000000, -1.00000000)',code)
