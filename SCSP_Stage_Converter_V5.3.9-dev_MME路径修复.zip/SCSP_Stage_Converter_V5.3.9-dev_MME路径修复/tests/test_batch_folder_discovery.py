# -*- coding: utf-8 -*-
import tempfile
import unittest
from pathlib import Path

from UnityParser.batch_folder_discovery import (
    discover_stage_folders,
    find_scene_project,
    find_unity_scenes,
)


class BatchFolderDiscoveryTests(unittest.TestCase):
    def make_project(self, folder: Path, *scenes: str) -> Path:
        project = folder / "scene-project"
        assets = project / "Assets"
        assets.mkdir(parents=True)
        for name in scenes:
            target = assets / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("%YAML 1.1\n", encoding="utf-8")
        return project

    def test_discovers_multiple_stage_folders_and_scenes(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp)
            self.make_project(parent / "Forbidden Paradise", "121_forbip.unity")
            self.make_project(parent / "Another Stage", "AssetsSub/second.unity", "main.unity")
            (parent / "not a stage").mkdir()

            entries = discover_stage_folders(parent)
            self.assertEqual([e["stage_folder"].name for e in entries], [
                "Another Stage", "Forbidden Paradise", "not a stage"
            ])
            valid = [e for e in entries if e["project_root"]]
            self.assertEqual(len(valid), 2)
            self.assertEqual(len(valid[0]["scenes"]), 2)
            self.assertEqual(valid[1]["scenes"][0].name, "121_forbip.unity")

    def test_selected_folder_can_itself_be_scene_project(self):
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "scene-project"
            (project / "Assets").mkdir(parents=True)
            (project / "Assets" / "stage.unity").write_text("", encoding="utf-8")
            self.assertEqual(find_scene_project(project), project.resolve())
            self.assertEqual(len(find_unity_scenes(project)), 1)
            entries = discover_stage_folders(project)
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["project_root"], project.resolve())

    def test_finds_project_below_one_extra_wrapper_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            stage = Path(temp) / "stage"
            assets = stage / "export" / "asset-ripper-output" / "scene-project" / "Assets"
            assets.mkdir(parents=True)
            (assets / "nested_stage.unity").write_text("", encoding="utf-8")
            entries = discover_stage_folders(stage.parent)
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["project_root"], assets.parent.resolve())
            self.assertEqual(len(entries[0]["scenes"]), 1)

    def test_ambiguous_nested_projects_are_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            stage = Path(temp) / "stage"
            (stage / "export_a" / "scene-project" / "Assets").mkdir(parents=True)
            (stage / "export_b" / "scene-project" / "Assets").mkdir(parents=True)
            with self.assertRaisesRegex(RuntimeError, "多个 scene-project"):
                find_scene_project(stage)


if __name__ == "__main__":
    unittest.main()
