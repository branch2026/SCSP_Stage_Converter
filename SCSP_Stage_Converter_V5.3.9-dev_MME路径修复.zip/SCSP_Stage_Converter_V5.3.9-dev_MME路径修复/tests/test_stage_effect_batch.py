# -*- coding: utf-8 -*-
"""Batch sidecar must never change successful V3.0 stage task state."""
import queue
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import gui


class StubBatch:
    def __init__(self, folder):
        self.folder=folder
        self.rows=[]
        self.message=''
    def record(self,*args):
        self.rows.append(args)


class StageEffectsBatchTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.addCleanup(self.t.cleanup)
        self.folder=Path(self.t.name)
        self.app=gui.StageConverterGUI.__new__(gui.StageConverterGUI)
        self.app.events=queue.Queue(); self.app.stop_after_current=threading.Event()
        self.app._preflight_mmd_tools=lambda settings: None
        self.app._convert_one=lambda task,settings: self.folder
        self.task={'id':'one','root':'182_SuperD','scene':'Assets/182_superd.unity',
                   'project':'G:/mock-scene-project','_output_dir':str(self.folder)}
        self.settings={'include_inactive':False,'output':str(self.folder),'blender':'blender.exe',
                       'enable_stage_effects':True,'effect_profile_dir':str(self.folder)}
        self.report=StubBatch(self.folder)

    def events(self):
        return list(self.app.events.queue)

    def test_no_profile_skips_and_does_not_fail_conversion(self):
        with patch.object(gui,'build_effect_package') as build:
            self.app._process_batch([dict(self.task)],self.settings,self.report)
            build.assert_not_called()
        self.assertIn(('worker_done',1,1,0),self.events())
        self.assertEqual(len(self.report.rows),1)

    def test_profile_created_in_separate_stageeffects_folder(self):
        p=self.folder/'182_SuperD.json';p.write_text('{}','utf-8')
        with patch.object(gui,'build_effect_package',return_value={'effects':[{'name':'灯面消去'}]}) as build:
            self.app._process_batch([dict(self.task)],self.settings,self.report)
            build.assert_called_once()
            args=build.call_args.args
            self.assertEqual(args[0],self.folder/'182_SuperD.pmx')
            self.assertEqual(args[1],p)
            self.assertEqual(args[2],self.folder/'StageEffects')
        self.assertIn(('worker_done',1,1,0),self.events())

    def test_invalid_profile_is_warning_not_batch_failure(self):
        (self.folder/'182_SuperD.json').write_text('{}','utf-8')
        with patch.object(gui,'build_effect_package',side_effect=RuntimeError('broken effect profile')):
            self.app._process_batch([dict(self.task)],self.settings,self.report)
        self.assertIn(('worker_done',1,1,0),self.events())
        self.assertTrue(any(e[0]=='log' and 'broken effect profile' in e[1] for e in self.events()))

    def test_effects_disabled_never_attempts_build(self):
        (self.folder/'182_SuperD.json').write_text('{}','utf-8')
        self.settings['enable_stage_effects']=False
        with patch.object(gui,'build_effect_package') as build:
            self.app._process_batch([dict(self.task)],self.settings,self.report)
            build.assert_not_called()
        self.assertIn(('worker_done',1,1,0),self.events())

if __name__=='__main__':unittest.main()
