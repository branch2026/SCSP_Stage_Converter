from pathlib import Path
import importlib.util
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("scsp_v23_gui", ROOT / "gui.py")
GUI = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUI)


SAMPLE = """%YAML 1.1
--- !u!1 &100
GameObject:
  m_Component:
  - component: {fileID: 101}
  m_Name: StageRoot
--- !u!4 &101
Transform:
  m_GameObject: {fileID: 100}
  m_Father: {fileID: 0}
--- !u!1 &200
GameObject:
  m_Component:
  - component: {fileID: 201}
  - component: {fileID: 202}
  - component: {fileID: 203}
  m_Name: StageMesh
--- !u!4 &201
Transform:
  m_GameObject: {fileID: 200}
  m_Father: {fileID: 101}
--- !u!33 &202
MeshFilter:
  m_GameObject: {fileID: 200}
--- !u!23 &203
MeshRenderer:
  m_GameObject: {fileID: 200}
--- !u!1 &300
GameObject:
  m_Component:
  - component: {fileID: 301}
  m_Name: EffectPlayer
--- !u!4 &301
Transform:
  m_GameObject: {fileID: 300}
  m_Father: {fileID: 101}
--- !u!1 &400
GameObject:
  m_Component:
  - component: {fileID: 401}
  - component: {fileID: 402}
  - component: {fileID: 403}
  m_Name: 121_Effects
--- !u!4 &401
Transform:
  m_GameObject: {fileID: 400}
  m_Father: {fileID: 301}
--- !u!198 &402
ParticleSystem:
  m_GameObject: {fileID: 400}
--- !u!199 &403
ParticleSystemRenderer:
  m_GameObject: {fileID: 400}
--- !u!1 &500
GameObject:
  m_Component:
  - component: {fileID: 501}
  m_Name: MainCamera
--- !u!4 &501
Transform:
  m_GameObject: {fileID: 500}
  m_Father: {fileID: 0}
"""


class RootScannerTests(unittest.TestCase):
    def scan(self, text=SAMPLE):
        with tempfile.TemporaryDirectory() as temp:
            scene = Path(temp) / "test.unity"
            scene.write_text(text, encoding="utf-8")
            dummy = GUI.StageConverterGUI.__new__(GUI.StageConverterGUI)
            return dummy._scan_scene_root_candidates(scene)

    def test_root_candidates_sorted_by_mesh_count(self):
        candidates = self.scan()
        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0]["name"], "StageRoot")
        self.assertEqual(candidates[0]["mesh_filters"], 1)
        self.assertEqual(candidates[0]["renderers"], 2)
        self.assertEqual(candidates[0]["particle_systems"], 1)

    def test_nested_effect_player_is_in_hierarchy_not_root_candidates(self):
        candidates = self.scan()
        root = candidates[0]["hierarchy"]
        self.assertEqual(root["name"], "StageRoot")
        child_names = [child["name"] for child in root["children"]]
        self.assertIn("EffectPlayer", child_names)
        self.assertNotIn("EffectPlayer", [item["name"] for item in candidates])

    def test_effect_subtree_is_preserved_and_counts_particles(self):
        root = self.scan()[0]["hierarchy"]
        effect_player = next(x for x in root["children"] if x["name"] == "EffectPlayer")
        effects = next(x for x in effect_player["children"] if x["name"] == "121_Effects")
        self.assertEqual(effects["particle_systems"], 1)
        self.assertEqual(effects["renderers"], 1)
        self.assertEqual(effects["mesh_filters"], 0)

    def test_candidate_totals_include_nested_effect_renderers(self):
        candidate = self.scan()[0]
        self.assertEqual(candidate["game_objects"], 4)
        self.assertEqual(candidate["mesh_filters"], 1)
        self.assertEqual(candidate["renderers"], 2)
        self.assertEqual(candidate["particle_systems"], 1)


if __name__ == "__main__":
    unittest.main()
