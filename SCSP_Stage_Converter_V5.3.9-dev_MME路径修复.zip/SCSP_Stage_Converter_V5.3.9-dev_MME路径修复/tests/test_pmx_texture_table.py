from __future__ import annotations

import struct
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "PMXExporter"))

from pmx_texture_table import read_texture_table_bytes, rewrite_texture_table
from texture_path_repair import repair_texture_references


def _pmx_string(value):
    raw = value.encode("utf-16-le")
    return struct.pack("<i", len(raw)) + raw


def _make_pmx_with_all_deform_types(path: Path, textures):
    # PMX 2.0; UTF-16LE; one additional UV; 4-byte vertex indices;
    # 1-byte texture/material/bone/morph/rigid indices.
    data = bytearray(b"PMX ")
    data += struct.pack("<f", 2.0)
    data += bytes([8, 0, 1, 4, 1, 1, 1, 1, 1])

    for _ in range(4):
        data += _pmx_string("")

    deform_payloads = {
        0: b"\x00",                                  # BDEF1: one bone index
        1: b"\x00\x00" + struct.pack("<f", 0.5),    # BDEF2
        2: b"\x00" * 4 + struct.pack("<4f", 1, 0, 0, 0),  # BDEF4
        3: b"\x00\x00" + struct.pack("<f", 0.5) + struct.pack("<9f", *([0.0] * 9)),  # SDEF
        4: b"\x00" * 4 + struct.pack("<4f", 1, 0, 0, 0),  # QDEF
    }
    data += struct.pack("<i", len(deform_payloads))
    for deform_type, payload in deform_payloads.items():
        data += struct.pack("<6f", *([0.0] * 6))   # pos + normal
        data += struct.pack("<2f", 0.0, 0.0)         # UV0
        data += struct.pack("<4f", 0.0, 0.0, 0.0, 0.0)  # additional UV
        data += bytes([deform_type])
        data += payload
        data += struct.pack("<f", 1.0)              # edge scale

    data += struct.pack("<i", 3)                    # surface index count
    data += struct.pack("<3I", 0, 1, 2)
    data += struct.pack("<i", len(textures))
    for texture in textures:
        data += _pmx_string(texture)
    data += b"TAIL_AFTER_TEXTURE_TABLE"

    path.write_bytes(data)


class PMXTextureTableTests(unittest.TestCase):
    def test_read_and_rewrite_texture_table_preserves_tail_and_all_deforms(self):
        with tempfile.TemporaryDirectory() as temp:
            pmx = Path(temp) / "stage.pmx"
            old = [
                r"G:\\output\\textures\\one_12345678.png",
                r"G:\\output\\textures\\two_abcdef01.png",
            ]
            new = ["textures/one_12345678.png", "textures/two_abcdef01.png"]
            _make_pmx_with_all_deform_types(pmx, old)

            before = read_texture_table_bytes(pmx.read_bytes())
            self.assertEqual(before["textures"], old)
            self.assertEqual(before["tail_bytes"], len(b"TAIL_AFTER_TEXTURE_TABLE"))

            result = rewrite_texture_table(pmx, old, new)
            after = read_texture_table_bytes(pmx.read_bytes())

            self.assertEqual(result["status"], "PASSED")
            self.assertEqual(after["textures"], new)
            self.assertEqual(after["tail_bytes"], before["tail_bytes"])
            self.assertTrue(pmx.read_bytes().endswith(b"TAIL_AFTER_TEXTURE_TABLE"))

    def test_rewrite_refuses_parser_table_mismatch(self):
        with tempfile.TemporaryDirectory() as temp:
            pmx = Path(temp) / "stage.pmx"
            _make_pmx_with_all_deform_types(pmx, ["textures/a.png"])
            with self.assertRaises(RuntimeError):
                rewrite_texture_table(pmx, ["wrong.png"], ["textures/a.png"])

    def test_absolute_paths_normalize_to_portable_relative_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            texture_dir = out / "textures"
            texture_dir.mkdir()
            pmx = out / "stage.pmx"
            image = texture_dir / "wall_1234abcd.png"
            image.write_bytes(b"test-image")
            _make_pmx_with_all_deform_types(pmx, [str(image.resolve())])

            result = repair_texture_references(pmx, [str(image.resolve())], texture_dir)
            self.assertEqual(result["status"], "PASSED")
            self.assertEqual(result["normalized_references"], ["textures/wall_1234abcd.png"])
            self.assertEqual(result["absolute_reference_count"], 1)
            self.assertEqual(result["normalized_absolute_count"], 1)


    def test_duplicate_texture_refs_keep_order(self):
        with tempfile.TemporaryDirectory() as temp:
            pmx = Path(temp) / "stage.pmx"
            refs = ["textures/shared.png", "textures/shared.png", "textures/other.png"]
            _make_pmx_with_all_deform_types(pmx, refs)
            parsed = read_texture_table_bytes(pmx.read_bytes())
            self.assertEqual(parsed["textures"], refs)
            new_refs = ["textures/shared.png", "textures/shared.png", "textures/other.png"]
            rewrite_texture_table(pmx, refs, new_refs)
            self.assertEqual(read_texture_table_bytes(pmx.read_bytes())["textures"], new_refs)


if __name__ == "__main__":
    unittest.main()
