from pathlib import Path
from struct import unpack_from
import unittest
from unittest.mock import patch

from StageEffects.pmx_binary import Model
from StageEffects.prepare_model import (FLOOR_LAYOUTS, floor_adjustment, floor_layout,
                                        material_vertices, prepare_model)
from test_stage_effects_v31 import pmx_fixture_multi_material


class SecondaryTextureTests(unittest.TestCase):
    def test_model_keeps_primary_uvs_textures_and_indices(self):
        base = Model(pmx_fixture_multi_material())
        ref = 'textures/AutoStageLight/test.png'
        path = Path('test.png')
        prepared, added = prepare_model(base,{0:(path,ref,{0,1,2},(2,3,.25,.5))},{0:.25})
        self.assertEqual(added,{ref:path})
        self.assertEqual(prepared.textures,[*base.textures,ref])
        self.assertEqual(prepared.uv_count,1)
        self.assertEqual(prepared.materials[0].texture_index,base.materials[0].texture_index)
        self.assertEqual((prepared.materials[0].sphere_mode,prepared.materials[0].sphere_index),(3,1))
        self.assertEqual((prepared.materials[1].sphere_mode,prepared.materials[1].sphere_index),(0,-1))
        self.assertEqual(unpack_from('<4f',prepared.data,prepared.vertex_offsets[0]+32),(.25,-2.5,0,0))
        self.assertEqual(unpack_from('<4f',prepared.data,prepared.vertex_offsets[3]+32),(0,0,0,0))
        self.assertEqual(unpack_from('<f',prepared.data,prepared.vertex_offsets[0]+4),(.25,))
        self.assertEqual(prepared.face_indices(0,6),base.face_indices(0,6))
        for source_at, prepared_at in zip(base.vertex_offsets,prepared.vertex_offsets):
            self.assertEqual(prepared.data[prepared_at+24:prepared_at+32],base.data[source_at+24:source_at+32])

    def test_floor_adjustment_is_local_and_requires_the_validated_geometry(self):
        base = Model(pmx_fixture_multi_material())
        slots = {'MatA':[0], 'MatB':[1]}
        scene = Path('fixture.unity')
        rule = ('test_decal',floor_layout(base,[0,1]),{'MatA':0.,'MatB':.2})
        with patch.dict(FLOOR_LAYOUTS,{('Fixture','fixture'):rule}):
            moves, result = floor_adjustment(base,scene,'Fixture',slots,material_vertices(base))
            self.assertEqual(moves,{3:.2,4:.2,5:.2})
            self.assertEqual(result['adjusted_materials'],{'MatB':.2})
            prepared, _ = prepare_model(base,{},moves)
            second, result = floor_adjustment(prepared,scene,'Fixture',slots,material_vertices(prepared))
            self.assertEqual(second,{})
            self.assertEqual(result['status'],'layout_not_matched')
