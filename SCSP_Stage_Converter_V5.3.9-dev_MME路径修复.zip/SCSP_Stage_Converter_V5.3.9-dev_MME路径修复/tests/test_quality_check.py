from __future__ import annotations

import importlib.util
import json
import struct
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "scsp_quality_check_test", ROOT / "Validator" / "quality_check.py"
)
QUALITY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(QUALITY)


def _pmx_bytes(texture_refs):
    data = bytearray(b"PMX " + struct.pack("<fB", 2.0, 8))
    data.extend(bytes([1, 0, 1, 1, 1, 1, 1, 1]))  # UTF-8, 0 extra UV, 1-byte indices
    for _ in range(4):
        data.extend(struct.pack("<i", 0))
    data.extend(struct.pack("<i", 3))  # three vertices
    for _ in range(3):
        data.extend(struct.pack("<8f", 0, 0, 0, 0, 1, 0, 0, 0))
        data.extend(bytes([0, 0]))  # BDEF1, bone index 0
        data.extend(struct.pack("<f", 1.0))
    data.extend(struct.pack("<i", 3))
    data.extend(bytes([0, 1, 2]))
    data.extend(struct.pack("<i", len(texture_refs)))
    for ref in texture_refs:
        raw = ref.encode("utf-8")
        data.extend(struct.pack("<i", len(raw)))
        data.extend(raw)
    return bytes(data)


def _mesh_asset_text(has_normals=True, has_uv=True):
    positions = [(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0)]
    normals = [(0.0, 0.0, 1.0)] * 3 if has_normals else None
    uvs = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0)] if has_uv else None
    if has_normals and has_uv:
        channels = [
            (0, 0, 3), (12, 0, 3), (24, 0, 0), (24, 0, 0), (24, 0, 2)
        ]
        vertex_data = b"".join(
            struct.pack("<8f", *(positions[i] + normals[i] + uvs[i]))
            for i in range(3)
        )
    elif has_normals:
        channels = [
            (0, 0, 3), (12, 0, 3), (24, 0, 0), (24, 0, 0), (24, 0, 0)
        ]
        vertex_data = b"".join(
            struct.pack("<6f", *(positions[i] + normals[i]))
            for i in range(3)
        )
    elif has_uv:
        channels = [
            (0, 0, 3), (12, 0, 0), (12, 0, 0), (12, 0, 0), (12, 0, 2)
        ]
        vertex_data = b"".join(
            struct.pack("<5f", *(positions[i] + uvs[i]))
            for i in range(3)
        )
    else:
        channels = [
            (0, 0, 3), (12, 0, 0), (12, 0, 0), (12, 0, 0), (12, 0, 0)
        ]
        vertex_data = b"".join(struct.pack("<3f", *row) for row in positions)

    channel_lines = []
    for offset, fmt, dimension in channels:
        channel_lines.extend([
            "    - stream: 0",
            f"      offset: {offset}",
            f"      format: {fmt}",
            f"      dimension: {dimension}",
        ])
    index_buffer = struct.pack("<3H", 0, 1, 2).hex()
    return (
        "Mesh:\n"
        "  m_Name: TestMesh\n"
        "  m_VertexCount: 3\n"
        "  m_IndexFormat: 0\n"
        f"  m_IndexBuffer: {index_buffer}\n"
        "  m_Channels:\n" + "\n".join(channel_lines) + "\n"
        f"  m_DataSize: {len(vertex_data)}\n"
        f"  _typelessdata: {vertex_data.hex()}\n"
        "  m_SubMeshes:\n"
        "  - serializedVersion: 2\n"
        "    firstByte: 0\n"
        "    indexCount: 3\n"
        "    topology: 0\n"
        "    baseVertex: 0\n"
        "  m_VertexData: {}\n"
    )


def _make_fixture(temp):
    root = Path(temp)
    project = root / "scene-project"
    assets = project / "Assets"
    assets.mkdir(parents=True)
    scene = assets / "Stage.unity"
    mesh_guid = "11111111111111111111111111111111"
    material_guid = "22222222222222222222222222222222"
    texture_guid = "33333333333333333333333333333333"
    scene.write_text(
        "%YAML 1.1\n"
        "--- !u!1 &1\nGameObject:\n"
        "  m_Component:\n  - component: {fileID: 2}\n"
        "  - component: {fileID: 3}\n"
        "  - component: {fileID: 4}\n"
        "  m_Name: StageRoot\n  m_IsActive: 1\n"
        "--- !u!4 &2\nTransform:\n"
        "  m_GameObject: {fileID: 1}\n  m_Children: []\n"
        "  m_Father: {fileID: 0}\n"
        "--- !u!33 &3\nMeshFilter:\n"
        "  m_GameObject: {fileID: 1}\n"
        "  m_Mesh: {fileID: 4300000, guid: " + mesh_guid + ", type: 3}\n"
        "--- !u!23 &4\nMeshRenderer:\n"
        "  m_GameObject: {fileID: 1}\n"
        "  m_Materials:\n  - {fileID: 2100000, guid: " + material_guid + ", type: 2}\n"
        "  m_StaticBatchInfo: {firstSubMesh: 0, subMeshCount: 0}\n"
        "  m_Enabled: 1\n",
        encoding="utf-8",
    )
    (assets / "mesh.asset").write_text(_mesh_asset_text(True, True), encoding="utf-8")
    (assets / "mesh.asset.meta").write_text("fileFormatVersion: 2\nguid: " + mesh_guid + "\n", encoding="utf-8")
    (assets / "material.mat").write_text(
        "Material:\n  m_Name: TestMaterial\n  _MainTex:\n    m_Texture: {fileID: 2800000, guid: " + texture_guid + ", type: 3}\n",
        encoding="utf-8",
    )
    (assets / "material.mat.meta").write_text("fileFormatVersion: 2\nguid: " + material_guid + "\n", encoding="utf-8")
    (assets / "texture.png").write_bytes(b"test-image")
    (assets / "texture.png.meta").write_text("fileFormatVersion: 2\nguid: " + texture_guid + "\n", encoding="utf-8")

    output = root / "output"
    texture_dir = output / "textures"
    texture_dir.mkdir(parents=True)
    texture_path = texture_dir / "texture.png"
    texture_path.write_bytes(b"test-image")
    pmx = output / "StageRoot.pmx"
    texture_ref = "textures/texture.png"
    pmx.write_bytes(_pmx_bytes([texture_ref]))

    source = {
        "scene": str(scene), "root": "StageRoot", "ok": True,
        "gameObjects": 1, "meshFilterComponents": 1, "rendererComponents": 1,
        "uniqueMeshReferences": 1, "decodedMeshes": 1,
        "nullMeshFilters": 0, "resolvedMeshFilterComponents": 1,
        "vertices": 3, "indices": 3, "submeshes": 1,
        "materialSlots": 1, "uniqueMaterials": 1,
        "mainTextureRefs": 1, "resolvedMainTextures": 1,
        "withNormals": 1, "withUV0": 1, "errors": [], "warnings": [],
    }
    rebuild = {
        "scene": str(scene), "root": "StageRoot", "inactivePolicy": "include",
        "stats": {
            "gameObjects": 1, "meshObjects": 1, "meshAssetsDecoded": 1,
            "meshFiltersEncountered": 1, "meshFilterAccounting": 1,
            "sourceRootMeshFilters": 1, "triangles": 1,
            "materials": 1, "texturedMaterials": 1,
            "missingMesh": [], "meshErrors": [], "skippedInactive": [],
            "materialWarnings": [], "particleSystemComponents": 0,
            "particleSystemRendererComponents": 0, "warnings": [],
        },
    }
    pmx_report = {
        "status": "completed", "output_pmx": str(pmx),
        "output_pmx_bytes": pmx.stat().st_size,
        "mmd_tools_parser_check": {
            "status": "PASSED", "vertices": 3, "faces": 1,
            "materials": 1, "textures": 1, "bones": 1,
            "morphs": 0, "rigid_bodies": 0, "joints": 0,
        },
        "texture_validation": {
            "status": "PASSED", "reference_count": 1, "resolved_count": 1,
            "unresolved_count": 0, "ambiguous_count": 0,
        },
        "texture_references": [texture_ref],
        "warnings": [],
    }
    return project, scene, output, pmx, source, rebuild, pmx_report


class QualityCheckTests(unittest.TestCase):
    def test_complete_stage_passes_all_quality_checks(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "PASS", report["checks"])
            self.assertEqual(report["summary"]["failures"], 0)
            self.assertTrue(any(item["id"] == "PMX-007" and item["status"] == "PASS" for item in report["checks"]))

    def test_mesh_inventory_records_identity_for_channel_complete_meshes(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            self.assertEqual(diagnostics["schema"], "scsp-mesh-channel-diagnostics-v6")
            self.assertEqual(len(diagnostics["meshInventory"]), 1)
            mesh = diagnostics["meshInventory"][0]
            self.assertEqual(mesh["meshGUID"], "11111111111111111111111111111111")
            self.assertEqual(mesh["meshFileID"], "4300000")
            self.assertEqual(mesh["meshName"], "TestMesh")
            self.assertEqual(mesh["decodeStatus"], "decoded")
            self.assertEqual(mesh["scope"], "included")
            material = mesh["gameObjects"][0]["materials"][0]
            self.assertEqual(material["name"], "TestMaterial")
            self.assertEqual(material["materialGUID"], "22222222222222222222222222222222")
            self.assertEqual(material["materialFileID"], "2100000")
            self.assertEqual(material["mainTextureGUID"], "33333333333333333333333333333333")
            self.assertEqual(material["mainTextureFileID"], 2800000)
            summary = diagnostics["meshInventorySummary"]
            self.assertTrue(summary["complete"])
            self.assertTrue(summary["identityComplete"])
            self.assertTrue(summary["scopeCountsMatch"])
            src009 = next(item for item in report["checks"] if item["id"] == "SRC-009")
            self.assertEqual(src009["status"], "PASS")
            self.assertTrue(src009["details"]["meshInventorySummary"]["identityComplete"])
            self.assertEqual(report["version"], "2.4.9-dev")
            text_path = Path(temp) / "quality_inventory.txt"
            QUALITY.write_text_report(report, text_path)
            text_report = text_path.read_text(encoding="utf-8-sig")
            self.assertIn("Mesh 完整资源身份清单", text_report)
            self.assertIn("记录 1 / 1", text_report)

    def test_mesh_inventory_retains_identity_when_asset_is_unresolved_or_decode_fails(self):
        for broken_mode in ("unresolved", "decode_error"):
            with self.subTest(broken_mode=broken_mode), tempfile.TemporaryDirectory() as temp:
                project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
                mesh_path = project / "Assets" / "mesh.asset"
                if broken_mode == "unresolved":
                    mesh_path.unlink()
                else:
                    mesh_path.write_text(
                        "Mesh:\n  m_Name: BrokenMesh\n  m_VertexCount: 3\n",
                        encoding="utf-8",
                    )
                diagnostics = QUALITY.inspect_scene_objects(
                    project, "Assets/Stage.unity", "StageRoot"
                )["meshChannelDiagnostics"]
                self.assertEqual(len(diagnostics["meshInventory"]), 1)
                row = diagnostics["meshInventory"][0]
                self.assertEqual(row["decodeStatus"], broken_mode)
                self.assertEqual(row["meshGUID"], "11111111111111111111111111111111")
                self.assertEqual(row["meshFileID"], "4300000")
                self.assertTrue(diagnostics["meshInventorySummary"]["complete"])
                self.assertTrue(diagnostics["meshInventorySummary"]["identityComplete"])
                self.assertTrue(diagnostics["meshInventorySummary"]["scopeCountsMatch"])

    def test_missing_mesh_channels_are_mapped_to_gameobject_and_material(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            source["withNormals"] = 0
            source["withUV0"] = 0
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            self.assertEqual(diagnostics["missingNormalsCount"], 1)
            self.assertEqual(diagnostics["missingUV0Count"], 1)
            self.assertEqual(diagnostics["missingEitherCount"], 1)
            self.assertEqual(diagnostics["missingNormals"][0]["meshName"], "TestMesh")
            occurrence = diagnostics["missingNormals"][0]["gameObjects"][0]
            self.assertEqual(occurrence["hierarchyPath"], "StageRoot")
            self.assertEqual(occurrence["gameObjectFileID"], 1)
            self.assertEqual(occurrence["meshFilterComponentFileIDs"], [3])
            self.assertTrue(occurrence["meshFilterComponentFileIDsComplete"])
            self.assertTrue(diagnostics["meshFilterComponentIdCoverage"]["complete"])
            self.assertTrue(diagnostics["missingUV0"][0]["gameObjects"][0]["hasTexturedMaterial"])
            self.assertEqual(diagnostics["missingUV0"][0]["uvRisk"], "TEXTURED_MATERIAL_ASSIGNED")
            checks = {item["id"]: item for item in report["checks"]}
            self.assertEqual(checks["SRC-005"]["status"], "WARNING")
            self.assertEqual(checks["SRC-005"]["details"]["missingMeshCount"], 1)
            self.assertEqual(checks["SRC-005"]["details"]["withNormals"], 0)
            self.assertEqual(checks["SRC-005"]["details"]["decodedMeshes"], 1)
            self.assertEqual(checks["SRC-006"]["status"], "WARNING")
            self.assertEqual(checks["SRC-006"]["details"]["withUV0"], 0)
            self.assertEqual(checks["SRC-006"]["details"]["warningMeshCount"], 1)
            self.assertEqual(checks["SRC-006"]["details"]["infoMeshCount"], 0)
            self.assertEqual(diagnostics["scopes"]["source"]["missingNormalsCount"], 1)
            self.assertEqual(diagnostics["scopes"]["included"]["missingNormalsCount"], 1)
            self.assertTrue(diagnostics["scopeAccounting"]["countsMatch"])
            self.assertEqual(checks["SRC-009"]["status"], "PASS")

            text_path = Path(temp) / "quality.txt"
            QUALITY.write_text_report(report, text_path)
            text_report = text_path.read_text(encoding="utf-8-sig")
            self.assertIn("TestMesh", text_report)
            self.assertIn("StageRoot", text_report)
            self.assertIn("TEXTURED_MATERIAL_ASSIGNED", text_report)
            self.assertIn("component fileID=3", text_report)

    def test_duplicate_meshfilter_occurrences_keep_each_component_fileid(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            scene_text = scene.read_text(encoding="utf-8")
            scene_text = scene_text.replace(
                "  - component: {fileID: 3}\n  - component: {fileID: 4}",
                "  - component: {fileID: 3}\n  - component: {fileID: 30}\n  - component: {fileID: 4}",
                1,
            )
            scene_text += (
                "--- !u!33 &30\nMeshFilter:\n"
                "  m_GameObject: {fileID: 1}\n"
                "  m_Mesh: {fileID: 4300000, guid: 11111111111111111111111111111111, type: 3}\n"
            )
            scene.write_text(scene_text, encoding="utf-8")
            diagnostics = QUALITY.inspect_scene_objects(
                project, "Assets/Stage.unity", "StageRoot"
            )["meshChannelDiagnostics"]
            occurrence = diagnostics["missingEither"][0]["gameObjects"][0]
            self.assertEqual(occurrence["meshFilterComponents"], 2)
            self.assertEqual(occurrence["meshFilterComponentFileIDs"], [3, 30])
            self.assertTrue(occurrence["meshFilterComponentFileIDsComplete"])
            self.assertEqual(diagnostics["meshFilterComponentIdCoverage"]["identifiedComponentFileIDs"], 2)

    def test_null_mesh_reference_reports_exact_meshfilter_component_id(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            scene.write_text(
                scene.read_text(encoding="utf-8").replace(
                    "m_Mesh: {fileID: 4300000, guid: 11111111111111111111111111111111, type: 3}",
                    "m_Mesh: {fileID: 0}",
                ),
                encoding="utf-8",
            )
            diagnostics = QUALITY.inspect_scene_objects(
                project, "Assets/Stage.unity", "StageRoot"
            )["meshChannelDiagnostics"]
            self.assertEqual(diagnostics["nullMeshFilterComponents"], 1)
            self.assertEqual(
                diagnostics["nullMeshFilterComponentDetails"][0]["meshFilterComponentFileID"], 3
            )
            self.assertTrue(diagnostics["meshFilterComponentIdCoverage"]["complete"])

    def test_shared_mesh_is_listed_once_with_all_gameobject_occurrences(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            # The included root has no MainTex; only the excluded shared occurrence does.
            (project / "Assets" / "material.mat").write_text(
                "Material:\n  m_Name: FlatMaterial\n", encoding="utf-8"
            )
            textured_guid = "44444444444444444444444444444444"
            (project / "Assets" / "textured.mat").write_text(
                "Material:\n  m_Name: TexturedMaterial\n  _MainTex:\n    m_Texture: {fileID: 2800000, guid: 33333333333333333333333333333333, type: 3}\n",
                encoding="utf-8",
            )
            (project / "Assets" / "textured.mat.meta").write_text(
                "fileFormatVersion: 2\nguid: " + textured_guid + "\n", encoding="utf-8"
            )
            scene_text = scene.read_text(encoding="utf-8")
            scene_text = scene_text.replace(
                "  m_GameObject: {fileID: 1}\n  m_Children: []\n  m_Father: {fileID: 0}",
                "  m_GameObject: {fileID: 1}\n  m_Children:\n  - {fileID: 12}\n  m_Father: {fileID: 0}",
                1,
            )
            scene_text += (
                "--- !u!1 &10\nGameObject:\n"
                "  m_Component:\n  - component: {fileID: 12}\n"
                "  - component: {fileID: 13}\n"
                "  - component: {fileID: 14}\n"
                "  m_Name: ChildMesh\n  m_IsActive: 1\n"
                "--- !u!4 &12\nTransform:\n"
                "  m_GameObject: {fileID: 10}\n  m_Children: []\n"
                "  m_Father: {fileID: 2}\n"
                "--- !u!33 &13\nMeshFilter:\n"
                "  m_GameObject: {fileID: 10}\n"
                "  m_Mesh: {fileID: 4300000, guid: 11111111111111111111111111111111, type: 3}\n"
                "--- !u!23 &14\nMeshRenderer:\n"
                "  m_GameObject: {fileID: 10}\n"
                "  m_Materials:\n  - {fileID: 2100000, guid: 22222222222222222222222222222222, type: 2}\n"
                "  m_StaticBatchInfo: {firstSubMesh: 0, subMeshCount: 0}\n"
                "  m_Enabled: 1\n"
            )
            scene.write_text(scene_text, encoding="utf-8")
            diagnostics = QUALITY.inspect_scene_objects(
                project, "Assets/Stage.unity", "StageRoot"
            )["meshChannelDiagnostics"]
            self.assertEqual(diagnostics["uniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["decodedMeshes"], 1)
            self.assertEqual(diagnostics["missingNormalsCount"], 1)
            self.assertEqual(diagnostics["missingUV0Count"], 1)
            self.assertEqual(diagnostics["missingEitherCount"], 1)
            record = diagnostics["missingEither"][0]
            self.assertEqual(record["occurrenceCount"], 2)
            self.assertEqual(record["uniqueGameObjectCount"], 2)
            self.assertEqual(
                [item["hierarchyPath"] for item in record["gameObjects"]],
                ["StageRoot", "StageRoot/ChildMesh"],
            )

    def test_parent_inactive_excludes_active_child_meshes_from_conversion_warnings(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            scene_text = scene.read_text(encoding="utf-8")
            scene_text = scene_text.replace("m_IsActive: 1", "m_IsActive: 0", 1)
            scene_text = scene_text.replace(
                "  m_GameObject: {fileID: 1}\n  m_Children: []\n  m_Father: {fileID: 0}",
                "  m_GameObject: {fileID: 1}\n  m_Children:\n  - {fileID: 12}\n  m_Father: {fileID: 0}",
                1,
            )
            scene_text += (
                "--- !u!1 &10\nGameObject:\n"
                "  m_Component:\n  - component: {fileID: 12}\n"
                "  - component: {fileID: 13}\n"
                "  - component: {fileID: 14}\n"
                "  m_Name: ActiveChild\n  m_IsActive: 1\n"
                "--- !u!4 &12\nTransform:\n"
                "  m_GameObject: {fileID: 10}\n  m_Children: []\n"
                "  m_Father: {fileID: 2}\n"
                "--- !u!33 &13\nMeshFilter:\n"
                "  m_GameObject: {fileID: 10}\n"
                "  m_Mesh: {fileID: 4300000, guid: 11111111111111111111111111111111, type: 3}\n"
                "--- !u!23 &14\nMeshRenderer:\n"
                "  m_GameObject: {fileID: 10}\n"
                "  m_Materials:\n  - {fileID: 2100000, guid: 22222222222222222222222222222222, type: 2}\n"
                "  m_StaticBatchInfo: {firstSubMesh: 0, subMeshCount: 0}\n"
                "  m_Enabled: 1\n"
            )
            scene.write_text(scene_text, encoding="utf-8")
            rebuild["inactivePolicy"] = "exclude"
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            inactive_child_row = next(
                item for item in report["objects"]["inactiveInHierarchyObjects"]
                if item["name"] == "ActiveChild"
            )
            self.assertIs(inactive_child_row["activeInHierarchy"], False)
            self.assertEqual(
                inactive_child_row["activeInHierarchySource"], "computed_by_unity_hierarchy_walk"
            )
            self.assertIs(inactive_child_row["activeInHierarchyInferred"], False)
            self.assertEqual(diagnostics["conversionPolicy"], "exclude")
            self.assertEqual(diagnostics["conversionUniqueMeshReferences"], 0)
            self.assertEqual(diagnostics["excludedOnlyUniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["meshInventorySummary"]["scopeUniqueMeshReferences"]["excludedOnly"], 1)
            self.assertEqual(diagnostics["meshInventory"][0]["scope"], "excludedOnly")
            self.assertEqual(diagnostics["meshInventory"][0]["meshGUID"], "11111111111111111111111111111111")
            text_path = Path(temp) / "quality_excluded_inventory.txt"
            QUALITY.write_text_report(report, text_path)
            text_report = text_path.read_text(encoding="utf-8-sig")
            self.assertIn("仅被排除对象引用的 Mesh 完整清单：1 个", text_report)
            self.assertIn("11111111111111111111111111111111", text_report)
            self.assertEqual(diagnostics["conversionMissingNormalsCount"], 0)
            self.assertEqual(diagnostics["conversionMissingUV0Count"], 0)
            checks = {item["id"]: item for item in report["checks"]}
            self.assertEqual(checks["SRC-005"]["status"], "PASS")
            self.assertEqual(checks["SRC-006"]["status"], "PASS")
            self.assertEqual(checks["SRC-005"]["details"]["decodedMeshes"], 0)
            self.assertEqual(checks["SRC-005"]["details"]["withNormals"], 0)
            self.assertEqual(checks["SRC-006"]["details"]["decodedMeshes"], 0)
            self.assertEqual(checks["SRC-006"]["details"]["withUV0"], 0)
            self.assertEqual(diagnostics["scopes"]["source"]["uniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["scopes"]["included"]["uniqueMeshReferences"], 0)
            self.assertEqual(diagnostics["scopes"]["excludedOnly"]["uniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["scopes"]["excludedOnly"]["missingNormalsCount"], 1)
            self.assertEqual(diagnostics["scopes"]["excludedOnly"]["missingUV0Count"], 1)
            self.assertTrue(diagnostics["scopeAccounting"]["countsMatch"])
            child = next(
                item for item in diagnostics["missingEither"][0]["gameObjects"]
                if item["gameObjectName"] == "ActiveChild"
            )
            self.assertTrue(child["activeSelf"])
            self.assertFalse(child["activeInHierarchy"])
            self.assertFalse(child["conversionIncluded"])
            self.assertEqual(child["conversionDecision"], "excluded_by_inactive_ancestor")
            self.assertEqual(
                child["conversionBlockingInactiveObject"]["gameObjectFileID"], 1
            )

    def test_inactive_external_ancestor_does_not_change_stage_root_conversion_scope(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            scene_text = scene.read_text(encoding="utf-8")
            scene_text = scene_text.replace(
                "  m_GameObject: {fileID: 1}\n  m_Children: []\n  m_Father: {fileID: 0}",
                "  m_GameObject: {fileID: 1}\n  m_Children: []\n  m_Father: {fileID: 21}",
                1,
            )
            scene_text += (
                "--- !u!1 &20\nGameObject:\n"
                "  m_Component:\n  - component: {fileID: 21}\n"
                "  m_Name: OuterDisabled\n  m_IsActive: 0\n"
                "--- !u!4 &21\nTransform:\n"
                "  m_GameObject: {fileID: 20}\n  m_Children:\n  - {fileID: 2}\n"
                "  m_Father: {fileID: 0}\n"
            )
            scene.write_text(scene_text, encoding="utf-8")
            rebuild["inactivePolicy"] = "exclude"
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            objects = report["objects"]
            self.assertFalse(objects["rootActiveInHierarchy"])
            self.assertTrue(objects["rootActiveWithinSelectedRoot"])
            self.assertFalse(objects["rootExternalAncestorChainActive"])
            self.assertEqual(objects["rootExternalAncestors"][0]["name"], "OuterDisabled")
            self.assertEqual(objects["conversionIncludedGameObjects"], 1)
            self.assertEqual(objects["conversionExcludedGameObjects"], 0)
            occurrence = report["meshDiagnostics"]["conversionMissingNormals"][0]["gameObjects"][0]
            self.assertFalse(occurrence["activeInHierarchy"])
            self.assertTrue(occurrence["activeWithinSelectedRoot"])
            self.assertTrue(occurrence["conversionIncluded"])
            self.assertEqual(
                occurrence["conversionDecision"], "included_active_within_selected_root"
            )
            self.assertEqual(
                occurrence["hierarchyInactiveCause"]["name"], "OuterDisabled"
            )

    def test_inactive_policy_include_keeps_inactive_mesh_in_conversion_scope(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            scene.write_text(
                scene.read_text(encoding="utf-8").replace("m_IsActive: 1", "m_IsActive: 0", 1),
                encoding="utf-8",
            )
            rebuild["inactivePolicy"] = "include"
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            self.assertEqual(diagnostics["conversionPolicy"], "include")
            self.assertEqual(diagnostics["conversionUniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["excludedOnlyUniqueMeshReferences"], 0)
            self.assertEqual(diagnostics["conversionMissingNormalsCount"], 1)
            self.assertEqual(diagnostics["conversionMissingUV0Count"], 1)
            self.assertEqual(diagnostics["scopes"]["included"]["decodedMeshes"], 1)
            self.assertEqual(diagnostics["scopes"]["included"]["missingNormalsCount"], 1)
            self.assertEqual(diagnostics["scopes"]["excludedOnly"]["uniqueMeshReferences"], 0)
            occurrence = diagnostics["conversionMissingEither"][0]["gameObjects"][0]
            self.assertEqual(occurrence["conversionDecision"], "included_by_inactive_policy_override")
            checks = {item["id"]: item for item in report["checks"]}
            self.assertEqual(checks["SRC-005"]["status"], "WARNING")
            self.assertEqual(checks["SRC-006"]["status"], "WARNING")

    def test_shared_mesh_across_included_and_excluded_objects_is_counted_once_as_converted(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, False), encoding="utf-8"
            )
            # The included root has no MainTex; only the excluded shared occurrence does.
            (project / "Assets" / "material.mat").write_text(
                "Material:\n  m_Name: FlatMaterial\n", encoding="utf-8"
            )
            textured_guid = "44444444444444444444444444444444"
            (project / "Assets" / "textured.mat").write_text(
                "Material:\n  m_Name: TexturedMaterial\n  _MainTex:\n    m_Texture: {fileID: 2800000, guid: 33333333333333333333333333333333, type: 3}\n",
                encoding="utf-8",
            )
            (project / "Assets" / "textured.mat.meta").write_text(
                "fileFormatVersion: 2\nguid: " + textured_guid + "\n", encoding="utf-8"
            )
            scene_text = scene.read_text(encoding="utf-8")
            scene_text = scene_text.replace(
                "  m_GameObject: {fileID: 1}\n  m_Children: []\n  m_Father: {fileID: 0}",
                "  m_GameObject: {fileID: 1}\n  m_Children:\n  - {fileID: 12}\n  m_Father: {fileID: 0}",
                1,
            )
            scene_text += (
                "--- !u!1 &10\nGameObject:\n"
                "  m_Component:\n  - component: {fileID: 12}\n"
                "  - component: {fileID: 13}\n"
                "  - component: {fileID: 14}\n"
                "  m_Name: InactiveChild\n  m_IsActive: 0\n"
                "--- !u!4 &12\nTransform:\n"
                "  m_GameObject: {fileID: 10}\n  m_Children: []\n"
                "  m_Father: {fileID: 2}\n"
                "--- !u!33 &13\nMeshFilter:\n"
                "  m_GameObject: {fileID: 10}\n"
                "  m_Mesh: {fileID: 4300000, guid: 11111111111111111111111111111111, type: 3}\n"
                "--- !u!23 &14\nMeshRenderer:\n"
                "  m_GameObject: {fileID: 10}\n"
                "  m_Materials:\n  - {fileID: 2100000, guid: " + textured_guid + ", type: 2}\n"
                "  m_StaticBatchInfo: {firstSubMesh: 0, subMeshCount: 0}\n"
                "  m_Enabled: 1\n"
            )
            scene.write_text(scene_text, encoding="utf-8")
            rebuild["inactivePolicy"] = "exclude"
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            self.assertEqual(diagnostics["conversionUniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["excludedOnlyUniqueMeshReferences"], 0)
            self.assertEqual(diagnostics["sharedMeshReferencesAcrossIncludedAndExcludedObjects"], 1)
            self.assertEqual(diagnostics["conversionMissingNormalsCount"], 1)
            self.assertEqual(diagnostics["conversionMissingUV0Count"], 1)
            record = diagnostics["conversionMissingEither"][0]
            self.assertTrue(record["hasIncludedAndExcludedOccurrences"])
            self.assertEqual(record["conversionOccurrenceCount"], 1)
            self.assertEqual(record["excludedOccurrenceCount"], 1)
            self.assertEqual(diagnostics["scopes"]["shared"]["uniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["scopes"]["included"]["uniqueMeshReferences"], 1)
            self.assertEqual(diagnostics["scopes"]["excludedOnly"]["uniqueMeshReferences"], 0)
            self.assertTrue(diagnostics["scopeAccounting"]["countsMatch"])
            self.assertTrue(diagnostics["meshInventorySummary"]["scopeCountsMatch"])
            self.assertEqual(diagnostics["meshInventorySummary"]["scopeUniqueMeshReferences"]["included"], 1)
            self.assertEqual(diagnostics["meshInventorySummary"]["scopeUniqueMeshReferences"]["shared"], 1)
            self.assertEqual(diagnostics["missingUV0"][0]["uvRisk"], "TEXTURED_MATERIAL_ASSIGNED")
            self.assertEqual(diagnostics["conversionMissingUV0"][0]["uvRisk"], "NO_MAIN_TEXTURE_DETECTED")
            self.assertEqual(diagnostics["conversionMissingUV0"][0]["sourceUvRisk"], "TEXTURED_MATERIAL_ASSIGNED")
            self.assertEqual({item["id"]: item for item in report["checks"]}["SRC-006"]["status"], "INFO")

    def test_missing_uv_without_detected_maintex_is_info_not_warning(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(True, False), encoding="utf-8"
            )
            (project / "Assets" / "material.mat").write_text(
                "Material:\n  m_Name: FlatMaterial\n", encoding="utf-8"
            )
            source["withUV0"] = 0
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            check = {item["id"]: item for item in report["checks"]}["SRC-006"]
            self.assertEqual(check["status"], "INFO")
            self.assertEqual(check["details"]["missingMeshCount"], 1)
            self.assertEqual(check["details"]["warningMeshCount"], 0)
            self.assertEqual(check["details"]["infoMeshCount"], 1)
            self.assertEqual(check["details"]["withUV0"], 0)
            self.assertEqual(
                diagnostics["scopes"]["included"]["uv0MissingRiskCounts"]["NO_MAIN_TEXTURE_DETECTED"], 1
            )
            text_path = Path(temp) / "quality.txt"
            QUALITY.write_text_report(report, text_path)
            text_report = text_path.read_text(encoding="utf-8-sig")
            self.assertIn("未检测到 MainTex（INFO）=1", text_report)
            self.assertIn("MainTex 检测不覆盖 Shader 的其他自定义纹理属性", text_report)

    def test_missing_pmx_texture_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (output / "textures" / "texture.png").unlink()
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "FAIL")
            self.assertTrue(any(item["id"] == "PMX-007" and item["status"] == "FAIL" for item in report["checks"]))

    def test_inactive_geometry_and_particles_are_warnings_not_failures(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            rebuild["stats"]["skippedInactive"] = [{"name": "Hidden", "meshFilters": 2}]
            rebuild["stats"]["particleSystemComponents"] = 8
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "WARNING")
            self.assertEqual(report["summary"]["failures"], 0)
            warning_ids = {item["id"] for item in report["checks"] if item["status"] == "WARNING"}
            self.assertIn("BLD-004", warning_ids)
            self.assertIn("BLD-006", warning_ids)

    def test_source_mesh_error_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            source["ok"] = False
            source["errors"] = [{"error": "Mesh GUID unresolved"}]
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "FAIL")
            self.assertTrue(any(item["id"] == "SRC-001" and item["status"] == "FAIL" for item in report["checks"]))

    def test_unsafe_relative_texture_path_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            outside = Path(temp) / "outside.png"
            outside.write_bytes(b"outside")
            pmx.write_bytes(_pmx_bytes(["../outside.png"]))
            pmx_report["output_pmx_bytes"] = pmx.stat().st_size
            pmx_report["texture_references"] = ["../outside.png"]
            pmx_report["texture_validation"] = {
                "status": "PASSED", "reference_count": 1, "resolved_count": 1,
                "unresolved_count": 0, "ambiguous_count": 0,
            }
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "FAIL")
            self.assertTrue(any(item["id"] == "PMX-007" and item["status"] == "FAIL" for item in report["checks"]))

    def test_zero_scale_transform_is_warning(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            text = scene.read_text(encoding="utf-8")
            text = text.replace("  m_Father: {fileID: 0}", "  m_LocalScale: {x: 0, y: 1, z: 1}\n  m_Father: {fileID: 0}")
            scene.write_text(text, encoding="utf-8")
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "WARNING")
            self.assertTrue(any(item["id"] == "OBJ-007" and item["status"] == "WARNING" for item in report["checks"]))

    def test_non_finite_transform_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            text = scene.read_text(encoding="utf-8")
            text = text.replace("  m_Father: {fileID: 0}", "  m_LocalPosition: {x: NaN, y: 0, z: 0}\n  m_Father: {fileID: 0}")
            scene.write_text(text, encoding="utf-8")
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            self.assertEqual(report["summary"]["status"], "FAIL")
            self.assertTrue(any(item["id"] == "OBJ-006" and item["status"] == "FAIL" for item in report["checks"]))

    def test_reports_are_written_as_json_and_text(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            paths = []
            for name, data in (("source.json", source), ("rebuild.json", rebuild), ("pmx.json", pmx_report)):
                path = Path(temp) / name
                path.write_text(json.dumps(data), encoding="utf-8")
                paths.append(path)
            json_out = Path(temp) / "quality.json"
            text_out = Path(temp) / "quality.txt"
            report = QUALITY.run_quality_check(
                paths[0], paths[1], paths[2], pmx, project,
                "Assets/Stage.unity", "StageRoot", json_out, text_out,
            )
            self.assertTrue(json_out.is_file())
            self.assertTrue(text_out.is_file())
            self.assertEqual(json.loads(json_out.read_text(encoding="utf-8"))["summary"]["status"], report["summary"]["status"])
            self.assertIn("总体结果：PASS", text_out.read_text(encoding="utf-8-sig"))


    def test_material_identity_keeps_fileid_distinct_within_same_guid(self):
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp)
            material_guid = "2" * 32
            material_path = project / "Material.mat"
            material_path.write_text("Material:\n  m_Name: SharedAssetMaterial\n", encoding="utf-8")
            renderer_by_go = {1: [{"materials": [
                {"guid": material_guid, "fileID": "2100000"},
                {"guid": material_guid, "fileID": "2100001"},
            ]}]}
            usage = QUALITY._material_usage_for_game_object(
                1, renderer_by_go, {material_guid: str(material_path)}, project, {}
            )
            self.assertEqual(len(usage), 2)
            self.assertEqual({item["materialFileID"] for item in usage}, {"2100000", "2100001"})
            self.assertTrue(all(item["materialGUID"] == material_guid for item in usage))

    def test_normal_evidence_classifies_textured_renderer(self):
        rows = [{"rendererCount": 1, "hasTexturedMaterial": True, "materialUsageKnown": True}]
        self.assertEqual(
            QUALITY._classify_normal_evidence(rows),
            "RENDERER_WITH_TEXTURED_MATERIAL",
        )

    def test_normal_evidence_classifies_known_flat_and_unknown_materials(self):
        flat = [{"rendererCount": 1, "hasTexturedMaterial": False, "materialUsageKnown": True}]
        unknown = [{"rendererCount": 1, "hasTexturedMaterial": False, "materialUsageKnown": False}]
        self.assertEqual(
            QUALITY._classify_normal_evidence(flat),
            "RENDERER_WITH_KNOWN_NON_TEXTURED_MATERIAL",
        )
        self.assertEqual(
            QUALITY._classify_normal_evidence(unknown),
            "RENDERER_MATERIAL_USAGE_UNKNOWN",
        )

    def test_normal_evidence_classifies_mesh_without_renderer(self):
        rows = [{"rendererCount": 0, "hasTexturedMaterial": False, "materialUsageKnown": False}]
        self.assertEqual(
            QUALITY._classify_normal_evidence(rows),
            "NO_RENDERER_DETECTED",
        )


    def test_missing_normal_evidence_is_scoped_and_written_to_json_and_txt(self):
        with tempfile.TemporaryDirectory() as temp:
            project, scene, output, pmx, source, rebuild, pmx_report = _make_fixture(temp)
            (project / "Assets" / "mesh.asset").write_text(
                _mesh_asset_text(False, True), encoding="utf-8"
            )
            source["withNormals"] = 0
            report = QUALITY.build_quality_report(
                source, rebuild, pmx_report, pmx, project, "Assets/Stage.unity", "StageRoot"
            )
            diagnostics = report["meshDiagnostics"]
            self.assertEqual(diagnostics["schema"], "scsp-mesh-channel-diagnostics-v6")
            record = diagnostics["conversionMissingNormals"][0]
            self.assertEqual(record["normalEvidence"], "RENDERER_WITH_TEXTURED_MATERIAL")
            self.assertEqual(
                diagnostics["scopes"]["included"]["normalMissingEvidenceCounts"]["RENDERER_WITH_TEXTURED_MATERIAL"],
                1,
            )
            self.assertTrue(diagnostics["scopeAccounting"]["includedNormalEvidenceCountsMatch"])
            check = next(item for item in report["checks"] if item["id"] == "SRC-005")
            self.assertEqual(
                check["details"]["normalEvidenceCounts"]["RENDERER_WITH_TEXTURED_MATERIAL"], 1
            )
            text_path = Path(temp) / "quality.txt"
            QUALITY.write_text_report(report, text_path)
            text = text_path.read_text(encoding="utf-8-sig")
            self.assertIn("法线证据分类", text)
            self.assertIn("RENDERER_WITH_TEXTURED_MATERIAL", text)
