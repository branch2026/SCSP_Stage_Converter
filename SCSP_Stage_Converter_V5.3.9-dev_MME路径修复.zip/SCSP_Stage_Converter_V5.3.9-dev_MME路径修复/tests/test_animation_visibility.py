from pathlib import Path
import tempfile
import unittest

from StageEffects.auto_restore import restore
from StageEffects.vmd_codec import parse_vmd
from test_stage_effects_v31 import pmx_fixture


class AnimationVisibilityTests(unittest.TestCase):
    def test_timeline_animator_binding_with_trim_and_speed(self):
        with tempfile.TemporaryDirectory() as workspace:
            project = Path(workspace)
            assets = project / 'Assets'
            assets.mkdir()
            material,timeline,animation = ('1'*32,'2'*32,'3'*32)
            for name,guid in [('MatA.mat',material),('timeline.playable',timeline),('toggle.anim',animation)]:
                (assets/(name+'.meta')).write_text(f'guid: {guid}\n','utf8')
            (assets/'MatA.mat').write_text('Material:\n  m_Name: MatA\n','utf8')
            (assets/'timeline.playable').write_text(f'''--- !u!114 &11400000
MonoBehaviour:
  m_Tracks:
  - {{fileID: 2}}
--- !u!114 &2
MonoBehaviour:
  m_Parent: {{fileID: 11400000}}
  m_Muted: 0
  m_Clips:
  - m_Version: 1
    m_Start: 1
    m_ClipIn: 1
    m_Duration: 2
    m_TimeScale: 2
    m_Asset: {{fileID: 3}}
    m_PostExtrapolationMode: 0
    m_PreExtrapolationMode: 1
--- !u!114 &3
MonoBehaviour:
  m_Name: AnimationPlayableAsset
  m_Loop: 2
  m_Clip: {{fileID: 7400000, guid: {animation}}}
''','utf8')
            (assets/'toggle.anim').write_text('''--- !u!74 &7400000
AnimationClip:
  m_FloatCurves:
  - serializedVersion: 2
    curve:
      m_Curve:
      - serializedVersion: 3
        time: 0
        value: 0
      - serializedVersion: 3
        time: 2
        value: 1
      - serializedVersion: 3
        time: 4
        value: 0
    attribute: m_IsActive
    path: Light
    classID: 1
  m_PPtrCurves: []
''','utf8')
            scene = assets/'test.unity'
            scene.write_text(f'''--- !u!1 &1
GameObject:
  m_Name: UnitStage
  m_IsActive: 1
--- !u!1 &2
GameObject:
  m_Name: Light
  m_IsActive: 1
--- !u!4 &3
Transform:
  m_GameObject: {{fileID: 1}}
  m_Father: {{fileID: 0}}
--- !u!4 &4
Transform:
  m_GameObject: {{fileID: 2}}
  m_Father: {{fileID: 3}}
--- !u!23 &5
MeshRenderer:
  m_GameObject: {{fileID: 2}}
  m_Enabled: 1
  m_Materials:
  - {{fileID: 2100000, guid: {material}, type: 2}}
--- !u!95 &6
Animator:
  m_GameObject: {{fileID: 1}}
--- !u!320 &7
PlayableDirector:
  m_Enabled: 1
  m_InitialTime: 0
  m_PlayableAsset: {{fileID: 11400000, guid: {timeline}}}
  m_SceneBindings:
  - key: {{fileID: 2, guid: {timeline}}}
    value: {{fileID: 6}}
''','utf8')
            pmx = project/'stage.pmx'
            pmx.write_bytes(pmx_fixture())
            texture = project/'textures/test.png'
            texture.parent.mkdir()
            texture.write_bytes(b'fixture')
            result = restore(project,scene,pmx,project/'AutoStage',120)
            self.assertEqual(result['visibility_controls'],1)
            item, = result['animation_clip_visibility']
            self.assertEqual(item['status'],'generated')
            motion = parse_vmd(next((project/'AutoStage').glob('*.vmd')).read_bytes())
            frames = {key['frame']:key['weight'] for key in motion['morph_frames']}
            self.assertEqual([frames[i] for i in (0,44,45,74,75,89,90,120)],[1,1,0,0,1,1,0,0])

            texture.unlink()
            result = restore(project,scene,pmx,project/'MissingTexture',120)
            self.assertEqual(result['effects'],0)
            self.assertEqual(result['planned_effects'],1)
            self.assertEqual(result['texture_audit']['missing_pmx_references'],['textures/test.png'])
            self.assertFalse(list((project/'MissingTexture').glob('*.vmd')))
