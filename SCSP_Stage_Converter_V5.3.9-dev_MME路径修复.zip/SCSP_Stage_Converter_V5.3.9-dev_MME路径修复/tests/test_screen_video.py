import unittest

from StageEffects.screen_video import video_canvas


class ScreenVideoCanvasTests(unittest.TestCase):
    def test_canvas_preserves_or_overrides_aspect(self):
        self.assertEqual(video_canvas((64,64)),(512,512))
        self.assertEqual(video_canvas((64,64),'9:16'),(288,512))
        with self.assertRaisesRegex(ValueError,'正整数'):
            video_canvas((64,64),'0:16')
