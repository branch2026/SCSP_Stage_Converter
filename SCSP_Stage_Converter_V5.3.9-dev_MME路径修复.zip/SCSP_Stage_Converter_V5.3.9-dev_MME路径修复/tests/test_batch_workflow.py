import json
import queue
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import Mock

import gui


class BatchWorkflowTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.folder = Path(temp.name)
        self.app = gui.StageConverterGUI.__new__(gui.StageConverterGUI)
        self.app.events = queue.Queue()
        self.app.stop_after_current = threading.Event()
        self.app._preflight_mmd_tools = Mock()
        self.tasks = [
            dict(id=str(i), root=str(i), scene=f"Assets/{i}.unity",
                 include_inactive=mode) for i, mode in enumerate([None, True, False])
        ]
        self.settings = dict(output=str(self.folder), include_inactive=False)

    def run_batch(self):
        self.app._worker_main(self.tasks, self.settings)
        reports = list(self.folder.glob("BatchReports/*/batch.json"))
        self.assertEqual(len(reports), 1)
        self.assertEqual(list(self.app.events.queue)[-1], ("worker_finished",))
        return json.loads(reports[0].read_text(encoding="utf-8"))

    def test_failure_before_output_retains_trace_and_processes_next(self):
        seen = []

        def convert(task, settings):
            seen.append(settings["include_inactive"])
            if task["id"] == "1":
                raise gui.StageConversionError("bad <scene>")
            output = self.folder / task["id"]
            output.mkdir()
            task["_output_dir"] = str(output)
            return output

        self.app._convert_one = convert
        rows = self.run_batch()["tasks"]
        self.assertEqual(seen, [False, True, False])
        self.assertEqual([row["status"] for row in rows], ["成功", "失败", "成功"])
        self.assertIn("bad <scene>", Path(rows[1]["failure_log"]).read_text(encoding="utf-8"))
        html = next(self.folder.rglob("index.html")).read_text(encoding="utf-8")
        self.assertIn("bad &lt;scene&gt;", html)
        self.assertNotIn("pmx", rows[1])

    def test_stop_leaves_remainder_unexecuted(self):
        self.app._convert_one = Mock(return_value=self.folder)
        self.app.stop_after_current.set()
        rows = self.run_batch()["tasks"]
        self.assertEqual([row["status"] for row in rows], ["成功", "未执行", "未执行"])
        self.app._convert_one.assert_called_once()

    def test_preflight_error_is_a_batch_error(self):
        self.app._preflight_mmd_tools.side_effect = RuntimeError("missing addon")
        self.app._convert_one = Mock()
        report = self.run_batch()
        self.assertIn("missing addon", report["status"])
        self.assertTrue(all(t["status"] == "未执行" for t in report["tasks"]))
        self.app._convert_one.assert_not_called()

    def test_root_suggestion_requires_unique_match(self):
        scene = Path("stage.unity")
        items = [{"name": "EffectPlayer"}, {"name": "Stage"}]
        self.assertEqual(gui.recommended_root(scene, items), "Stage")
        self.assertIsNone(gui.recommended_root(scene, items + [{"name": "STAGE"}]))
        self.assertIsNone(gui.recommended_root(Path("other.unity"), items))

    def test_renamed_scene_uses_renderable_geometry_and_excludes_effect_player(self):
        scene = Path("renamed.unity")
        stage = dict(name="Main",mesh_filters=30,mesh_renderers=28)
        effects = dict(name="EffectPlayer",mesh_filters=70,mesh_renderers=70)
        self.assertEqual(gui.recommended_root(scene,[effects,stage]),"Main")
        self.assertIsNone(gui.recommended_root(scene,[effects,stage,dict(stage,name="Other")]))
        self.assertEqual(gui.recommended_root(Path("main-stage.unity"),
                                             [dict(stage,name="Main_Stage"),effects]),"Main_Stage")

    def test_retry_uses_failed_ids_only(self):
        self.app.is_running = False
        self.app.tasks = self.tasks
        for task, status in zip(self.tasks, [gui.STATUS_DONE, gui.STATUS_FAILED, gui.STATUS_PENDING]):
            task["status"] = status
        self.app._start_worker = Mock()
        self.app._retry_failed()
        self.app._start_worker.assert_called_once_with(["1"])
