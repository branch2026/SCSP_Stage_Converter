from collections import defaultdict
import unittest

from StageEffects.screen_atlas import atlas_layout,atlas_motion
from StageEffects.vmd_codec import parse_vmd,write_vmd


class ScreenAtlasTests(unittest.TestCase):
    def test_switches_cells_and_keeps_original_visibility_track(self):
        original = [('Hide',0,0),('Hide',3,0),('Hide',4,1),('Hide',7,1),
                    ('Hide',8,0),('Hide',12,0)]
        source = write_vmd('Stage',original)
        result = parse_vmd(atlas_motion('Stage',source,['Atlas001','Atlas002'],2))
        by_frame = defaultdict(list)
        for k in result['morph_frames']:
            by_frame[k['frame']].append((k['name'],k['weight']))
        weights = {}
        for frame in range(13):
            weights.update(by_frame[frame])
            expected = frame//2%3
            self.assertEqual([i for i in (1,2) if weights[f'Atlas{i:03d}']],
                             [expected] if expected else [])
            self.assertEqual(weights['Hide'],int(4<=frame<8))

    def test_layout_rejects_texture_too_large(self):
        cols,rows,width,height = atlas_layout(288,512,18)
        self.assertGreaterEqual(cols*rows,18)
        self.assertEqual((width,height),(cols*292+4,rows*516+4))
        with self.assertRaises(ValueError):
            atlas_layout(512,512,120)
