from pathlib import Path
import hashlib
import ast
import re
import unittest
from gui import stage_output_name

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_manifest(path, pattern):
    text = path.read_text(encoding="utf-8")
    return dict(re.findall(pattern, text, re.M))


class ConversionCoreIntegrityTests(unittest.TestCase):
    def test_15_protected_conversion_files_match_v23_and_v2410_records(self):
        v2410 = parse_manifest(
            ROOT / "BASELINE_INTEGRITY_V2.4.10.txt",
            r"^PASS\s+(.+?)\s+SHA-256:\s*([0-9a-f]{64})\s*$",
        )
        v241 = parse_manifest(
            ROOT / "BASELINE_INTEGRITY_V2.4.1.txt",
            r"^- PASS\s+(.+?)\s+SHA-256:\s*([0-9a-f]{64})\s*$",
        )
        self.assertEqual(len(v2410), 15)
        for relative, expected in v2410.items():
            self.assertIn(relative, v241, relative)
            self.assertEqual(v241[relative], expected, relative)
            self.assertEqual(sha256(ROOT / relative), expected, relative)

    def test_single_stage_conversion_matches_v25(self):
        source = (ROOT / "gui.py").read_text(encoding="utf-8")
        method = next(n for n in ast.walk(ast.parse(source))
                      if isinstance(n, ast.FunctionDef) and n.name == "_convert_one")
        implementation = ast.get_source_segment(source, method)
        implementation = re.sub(
            r"(?ms)(^        source_label = [^\n]*\n).*?(^        out_dir = unique_dir\(output_root_path, stage_label\))",
            r"\1        # Output name varies with MME compatibility.\n\2", implementation,
        )
        digest = hashlib.sha256(implementation.encode()).hexdigest()
        self.assertEqual(digest, "e9fe56e5d7a10ff978b6d175fc2077ad0ff32b71dc6ea8b918b1c9690308c46e")

    def test_mme_preview_uses_ascii_stage_directory(self):
        japanese = ('過純性ブリーチ', '032_kjunbl', '032_KjunBL')
        self.assertEqual(stage_output_name(*japanese, mme_preview=True), '032_kjunbl__032_KjunBL')
        self.assertEqual(stage_output_name(*japanese, mme_preview=False), '__'.join(japanese))
        self.assertEqual(stage_output_name('SOS', '019_fuysos', '019_FuySOS', mme_preview=True),
                         'SOS__019_fuysos__019_FuySOS')

    def test_release_metadata_identifies_v42_dev_build(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        self.assertIn("SCSP Stage Converter V5.3.9-dev", version.splitlines()[0])
        self.assertIn("-dev", version.splitlines()[0])
        self.assertIn("SCSP Stage Converter V5.3.9-dev", readme.splitlines()[0])
        self.assertIn("-dev", readme.splitlines()[0])
        self.assertIn("V2.3.2-dev_FolderBatchRebuild.zip", version)


if __name__ == "__main__":
    unittest.main()
