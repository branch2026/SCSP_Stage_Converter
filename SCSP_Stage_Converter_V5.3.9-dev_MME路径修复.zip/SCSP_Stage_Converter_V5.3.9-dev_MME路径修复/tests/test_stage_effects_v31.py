# -*- coding: utf-8 -*-
"""V3.1 independent regression suite; no Blender, Unity or installed MMD required."""
import json
import struct
import tempfile
import unittest
from pathlib import Path

from StageEffects.pmx_binary import Model, PMXError
from StageEffects.stage_effects import (EffectError, build_effect_package, inspect,
    resolve_effects, make_vmd, safe_texture_path)
from StageEffects.dependency_audit import apng_info, vmd_info, audit_folder
from StageEffects.vmd_codec import parse_vmd, write_vmd, VMDError


def ss(v):
    b=v.encode('utf-8');return struct.pack('<i',len(b))+b


def pmx_fixture():
    f=lambda s:struct.pack('<'+str(len(s))+'f',*s)
    data=[b'PMX ',struct.pack('<fB',2.,8),bytes([1,0,1,1,1,1,1,1])]
    data += [ss('UnitStage'),ss('UnitStage'),ss(''),ss('')]
    data.append(struct.pack('<i',3))
    for pos,uv in [((0,0,0),(0,0)),((1,0,0),(1,0)),((0,1,0),(0,1))]:
        data += [f(pos),f([0,0,1]),f(uv),bytes([0,0]),f([1])]
    data += [struct.pack('<i',3),bytes([0,1,2])]
    data += [struct.pack('<i',1),ss('textures/test.png')]
    data.append(struct.pack('<i',1))
    data += [ss('MatA'),ss('MatA'),f([1,1,1,1]),f([0,0,0]),f([0]),
             f([0,0,0]),bytes([0]),f([0,0,0,0]),f([1]),bytes([0,255,0,1,0]),
             ss(''),struct.pack('<i',3)]
    data.append(struct.pack('<i',1))
    data += [ss('center'),ss('center'),f([0,0,0]),bytes([255]),struct.pack('<iH',0,0),f([0,0,0])]
    data += [struct.pack('<i',0),struct.pack('<i',1),ss('表情'),ss('Facial'),bytes([1]),
             struct.pack('<i',0),struct.pack('<ii',0,0)]
    return b''.join(data)


def pmx_fixture_multi_material():
    """Two-material PMX fixture for Phase-style material morph regression."""
    f=lambda s:struct.pack('<'+str(len(s))+'f',*s)
    data=[b'PMX ',struct.pack('<fB',2.,8),bytes([1,0,1,1,1,1,1,1])]
    data += [ss('PhaseStage'),ss('PhaseStage'),ss(''),ss('')]
    data.append(struct.pack('<i',6))
    points=[(0,0,0),(1,0,0),(0,1,0),(2,0,0),(3,0,0),(2,1,0)]
    for pos in points:
        data += [f(pos),f([0,0,1]),f([0,0]),bytes([0,0]),f([1])]
    data += [struct.pack('<i',6),bytes([0,1,2,3,4,5])]
    data += [struct.pack('<i',1),ss('textures/test.png')]
    data.append(struct.pack('<i',2))
    def material(name, diffuse, face_count):
        return [ss(name),ss(name),f(diffuse),f([0,0,0]),f([0]),f([0,0,0]),
                bytes([0]),f([0,0,0,0]),f([1]),bytes([0,255,0,1,0]),ss(''),
                struct.pack('<i',face_count)]
    data += material('MatA',[1,1,1,1],3)
    data += material('MatB',[1,1,1,1],3)
    data.append(struct.pack('<i',1))
    data += [ss('center'),ss('center'),f([0,0,0]),bytes([255]),struct.pack('<iH',0,0),f([0,0,0])]
    data += [struct.pack('<i',0),struct.pack('<i',1),ss('表情'),ss('Facial'),bytes([1]),
             struct.pack('<i',0),struct.pack('<ii',0,0)]
    return b''.join(data)


def read_material_morph_offsets(data):
    model=Model(data)
    c=__import__('StageEffects.pmx_binary',fromlist=['Cursor']).Cursor(data)
    c.p=model.morph_begin
    out={}
    for _ in range(c.count('morphs')):
        name=c.string(model.encoding);c.string(model.encoding);c.num('B');typ=c.num('B')
        offsets=[]
        for _ in range(c.count('morph offsets')):
            if typ==8:
                index=int.from_bytes(c.take(model.mat_width),'little',signed=True)
                operation=c.num('B');values=struct.unpack('<28f',c.take(112))
                offsets.append({'index':index,'operation':operation,'values':values})
            else:
                if typ in (0,9):width=model.morph_width+4
                elif typ==1:width=model.vertex_width+12
                elif typ==2:width=model.bone_width+28
                elif 3<=typ<=7:width=model.vertex_width+16
                elif typ==10:width=model.rigid_width+25
                else:raise AssertionError(typ)
                c.take(width)
        out[name]={'type':typ,'offsets':offsets}
    return out


class StageEffectsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder=Path(self.temp.name)
        self.src=self.folder/'UnitStage.pmx'
        self.src.write_bytes(pmx_fixture())
        (self.folder/'textures').mkdir()
        (self.folder/'textures/test.png').write_bytes(b'PNG_FAKE_BUT_NONEMPTY')
        self.spec={'schema_version':1,'model_name':'UnitStage',
                   'effects':[{'name':'灯面消去','type':'material_alpha','material_indices':[0],
                               'target_alpha':0,'keys':[[0,0],[40,1],[80,0]]}]}

    def save_profile(self):
        f=self.folder/'effect.json';f.write_text(json.dumps(self.spec,ensure_ascii=False),'utf-8');return f

    def test_fixture_roundtrip(self):
        m=Model(pmx_fixture())
        self.assertEqual((m.vertex_count,m.face_index_count,len(m.materials),len(m.bones)),(3,3,1,1))
        self.assertEqual(m.face_indices(0,3),(0,1,2))
        self.assertEqual(m.morph_count,0)

    def test_add_alpha_preserve_geometry_and_tail(self):
        before=Model(self.src.read_bytes()); spec=self.save_profile()
        report=build_effect_package(self.src,spec,self.folder/'out')
        out=next((self.folder/'out').glob('*.pmx'))
        after=Model(out.read_bytes())
        self.assertEqual(report['status'],'BUILT_NOT_MMD_VERIFIED')
        self.assertEqual(after.morph_names,['灯面消去'])
        self.assertEqual(after.morph_types,[8])
        self.assertEqual(before.data[:before.morph_begin],after.data[:after.morph_begin])
        self.assertEqual(before.original_tail,after.original_tail)
        self.assertEqual(after.vertex_count,3)
        self.assertEqual(after.materials,before.materials)
        self.assertIn((1,0),after.display[0][3])
        self.assertEqual((self.folder/'textures/test.png').read_bytes(),
                         (self.folder/'out/textures/test.png').read_bytes())
        self.assertTrue((self.folder/'out/UnitStage_效果测试.vmd').is_file())
        self.assertEqual(vmd_info(self.folder/'out/UnitStage_效果测试.vmd')['morph_tracks']['灯面消去'],3)

    def test_build_never_modifies_source(self):
        before=self.src.read_bytes()
        build_effect_package(self.src,self.save_profile(),self.folder/'out')
        self.assertEqual(before,self.src.read_bytes())

    def test_existing_output_refused(self):
        d=self.folder/'out';d.mkdir()
        with self.assertRaises(FileExistsError):build_effect_package(self.src,self.save_profile(),d)

    def test_duplicate_existing_morph_refused(self):
        a=Model(pmx_fixture()).add_morphs([{'name':'灯面消去','type':8,'targets':[(0,(0,0,0,-1))]}])
        self.src.write_bytes(a)
        with self.assertRaises(EffectError):build_effect_package(self.src,self.save_profile(),self.folder/'out')

    def test_uv0_morph_and_vmd(self):
        self.spec['effects']=[{'name':'UV横移','type':'uv_offset','materials':['MatA'],
            'uv_channel':0,'offset':[.5,0],'keys':[[0,0],[30,1]]}]
        build_effect_package(self.src,self.save_profile(),self.folder/'out')
        m=Model(next((self.folder/'out').glob('*.pmx')).read_bytes())
        self.assertEqual(m.morph_types,[3]);self.assertEqual(m.morph_names,['UV横移'])

    def test_missing_additional_uv_rejected(self):
        self.spec['effects']=[{'name':'UV1','type':'uv_offset','material_indices':[0],
            'uv_channel':1,'offset':[.5,0]}]
        with self.assertRaises(EffectError):build_effect_package(self.src,self.save_profile(),self.folder/'out')

    def test_material_tint(self):
        self.spec['effects']=[{'name':'色変化','type':'material_tint','material_indices':[0],
                              'target_rgba':[1,0,0,1]}]
        build_effect_package(self.src,self.save_profile(),self.folder/'out')
        self.assertEqual(Model(next((self.folder/'out').glob('*.pmx')).read_bytes()).morph_types,[8])

    def test_missing_texture_refused(self):
        (self.folder/'textures/test.png').unlink()
        with self.assertRaises(EffectError):build_effect_package(self.src,self.save_profile(),self.folder/'out')

    def test_unsafe_texture_refused(self):
        for ref in ('../other.png','C:\\temp\\x.png','/tmp/img.png','\\\\server\\share'):
            with self.subTest(ref=ref), self.assertRaises(EffectError):safe_texture_path(ref)

    def test_duplicate_material_indices_rejected(self):
        self.spec['effects'][0]['material_indices']=[0,0]
        with self.assertRaises(EffectError):resolve_effects(Model(pmx_fixture()),self.spec)

    def test_vmd_rejects_long_cp932_name(self):
        self.spec['effects'][0]['name']='测试动画形态键长度超出'
        with self.assertRaises(EffectError):resolve_effects(Model(pmx_fixture()),self.spec)

    def test_vmd_unity_source_requires_evidence(self):
        self.spec['effects'][0]['provenance']='unity-verified'
        with self.assertRaises(EffectError):resolve_effects(Model(pmx_fixture()),self.spec)

    def test_inspect(self):
        data=inspect(self.src)
        self.assertEqual(data['materials'][0]['name'],'MatA')
        self.assertEqual(data['missing_textures'],[])

    def test_audit_emd_missing_fx(self):
        (self.folder/'stage.emd').write_text('[Effect]\nObj[0] = MES40\\screen.fx\n','utf-8')
        report=audit_folder(self.folder)
        self.assertEqual(report['emd'][0]['missing_relative_fx'],['MES40\\screen.fx'])

    def test_apng_header(self):
        # Minimal chunk inventory: no decoder required to recognize animation header.
        p=self.folder/'animated.png'
        p.write_bytes(b'\x89PNG\r\n\x1a\n'+struct.pack('>I',13)+b'IHDR'+struct.pack('>II',10,20)+bytes(5)+bytes(4)
            +struct.pack('>I',8)+b'acTL'+struct.pack('>II',16,0)+bytes(4)
            +struct.pack('>I',0)+b'IEND'+bytes(4))
        self.assertEqual(apng_info(p)['apng_frames'],16)

    def test_vertex_indices_use_unsigned_pmx_encoding(self):
        m=Model(pmx_fixture())
        self.assertEqual(m.idx(40000,2,signed=False),struct.pack('<H',40000))
        with self.assertRaises(OverflowError):m.idx(40000,2,signed=True)

    def test_detect_truncated_pmx(self):
        with self.assertRaises(PMXError):Model(pmx_fixture()[:100])

    def test_vmd_writer_full_sections_and_neutral_anchor(self):
        payload=write_vmd('UnitStage', [('灯面消去',0,1.0),('灯面消去',30,0.0)],
                          [('center',0,(0,0,0),(0,0,0,1))])
        parsed=parse_vmd(payload)
        self.assertEqual(parsed['bone_keys'],1)
        self.assertEqual(parsed['bone_tracks'],{'center':1})
        self.assertEqual(parsed['morph_keys'],2)
        self.assertEqual(parsed['morph_tracks'],{'灯面消去':2})
        self.assertEqual(parsed['camera_keys'],0)
        self.assertEqual(parsed['trailing_bytes'],0)

    def test_phase_material_state_targets_multiple_slots(self):
        src=self.folder/'PhaseStage.pmx';src.write_bytes(pmx_fixture_multi_material())
        spec={
            'schema_version':1,'model_name':'PhaseStage',
            'vmd':{'neutral_anchor_bone':'center'},
            'effects':[{'name':'Phase1','type':'material_state','provenance':'manual-demo',
                'material_offsets':[
                    {'material':'MatA','operation':'multiply','diffuse':[0.5,0.5,0.5,1.0]},
                    {'material':'MatB','operation':'add','diffuse':[0,0,0,0.5],'ambient':[0.1,0.1,0.1]},
                ],
                'keys':[[0,0],[30,1],[60,0]]
            }]
        }
        profile=self.folder/'phase.json';profile.write_text(json.dumps(spec,ensure_ascii=False),'utf-8')
        out=self.folder/'phase_out'
        report=build_effect_package(src,profile,out)
        model=Model((out/'PhaseStage_V3.1_FX.pmx').read_bytes())
        self.assertEqual(model.morph_names,['Phase1'])
        self.assertEqual(model.morph_types,[8])
        offsets=read_material_morph_offsets((out/'PhaseStage_V3.1_FX.pmx').read_bytes())['Phase1']['offsets']
        self.assertEqual([(x['index'],x['operation']) for x in offsets],[(0,0),(1,1)])
        self.assertEqual(offsets[0]['values'][:4],(0.5,0.5,0.5,1.0))
        self.assertEqual(offsets[0]['values'][4:8],(1.0,1.0,1.0,1.0))
        self.assertEqual(offsets[1]['values'][:4],(0.0,0.0,0.0,0.5))
        for actual in offsets[1]['values'][8:11]:
            self.assertAlmostEqual(actual,0.1,places=6)
        self.assertTrue((out/'PhaseStage_效果测试.vmd').is_file())
        anchor=out/'PhaseStage_效果测试_中性骨骼锚点.vmd'
        self.assertTrue(anchor.is_file())
        parsed=vmd_info(anchor)
        self.assertEqual(parsed['bone_tracks'],{'center':1})
        self.assertEqual(parsed['morph_tracks'],{'Phase1':3})
        self.assertEqual(report['vmd_outputs'][1]['mode'],'neutral-bone-anchor')

    def test_phase_rejects_duplicate_material_target(self):
        model=Model(pmx_fixture_multi_material())
        fx={'material_offsets':[{'material':'MatA','operation':'add'},
                                {'material_index':0,'operation':'multiply'}]}
        from StageEffects.stage_effects import resolve_material_state
        with self.assertRaises(EffectError):resolve_material_state(model,fx)

    def test_phase_rejects_non_neutral_invalid_operation(self):
        model=Model(pmx_fixture_multi_material())
        fx={'material_offsets':[{'material':'MatA','operation':'invalid'}]}
        from StageEffects.stage_effects import resolve_material_state
        with self.assertRaises(EffectError):resolve_material_state(model,fx)


if __name__=='__main__':unittest.main()

class UnityEvidenceTests(unittest.TestCase):
    def setUp(self):
        from StageEffects.unity_effect_probe import guid_of
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.assets=self.root/'Assets';self.assets.mkdir()
        self.mat=self.assets/'Light.mat'
        self.mat.write_text('''%YAML 1.1
--- !u!21 &2100000
Material:
  m_Name: M_Light
  m_Shader: {fileID: 4800000, guid: abcdefabcdefabcdefabcdefabcdefab, type: 3}
  m_SavedProperties:
    m_TexEnvs:
    - _MainTex:
        m_Texture: {fileID: 2800000, guid: 1234567890abcdef1234567890abcdef, type: 3}
    m_Floats:
    - _SpeedL: 0.25
    - _Intensity: 1.6
    m_Colors:
    - _EmissionColor: {r: 1, g: 0.4, b: 0, a: 1}
''','utf-8')
        self.guid='a'*32
        Path(str(self.mat)+'.meta').write_text('guid: '+self.guid+'\n','utf-8')
        (self.assets/'Fake.unity').write_text('''--- !u!1 &100
GameObject:
  m_Name: LightObj
--- !u!23 &200
MeshRenderer:
  m_GameObject: {fileID: 100}
  m_Enabled: 1
  m_Materials:
  - {fileID: 2100000, guid: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa, type: 2}
''','utf-8')
        (self.assets/'Light.anim').write_text('''AnimationClip:
  m_Name: TestAnim
  attribute: m_IsActive
  path: Lights/LightObj
''','utf-8')

    def test_unity_source_probe(self):
        from StageEffects.unity_effect_probe import probe
        result=probe(self.root,Path('Assets/Fake.unity'))
        self.assertEqual(result['renderer_count'],1)
        self.assertEqual(result['referenced_materials'][0]['unity_material']['name'],'M_Light')
        self.assertEqual(result['referenced_materials'][0]['unity_material']['floats']['_SpeedL'],.25)
        self.assertEqual(result['referenced_materials'][0]['unity_material']['floats']['_Intensity'],1.6)
        self.assertEqual(result['referenced_materials'][0]['unity_material']['textures']['_MainTex'],'1234567890abcdef1234567890abcdef')
        self.assertEqual(result['animation_clips'][0]['tracks'][0]['attribute'],'m_IsActive')

    def test_unity_source_probe_rejects_path_outside_project(self):
        from StageEffects.unity_effect_probe import probe
        with self.assertRaises(ValueError):probe(self.root,Path('../outside.unity'))

    def test_apng_fx_sources_reported(self):
        from StageEffects.dependency_audit import audit_folder
        fx=self.assets/'LED.fx';fx.write_text('#define AnimatedTexture "anim.png"\n#include "missing.fxh"\n','utf-8')
        report=audit_folder(self.assets)
        self.assertEqual(report['fx'][0]['animated_textures'],['anim.png'])
        self.assertEqual(report['fx'][0]['dependencies'][0]['exists_relative_to_fx'],False)
