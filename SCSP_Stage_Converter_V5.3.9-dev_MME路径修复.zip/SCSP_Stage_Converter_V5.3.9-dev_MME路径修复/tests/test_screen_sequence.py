import unittest

from StageEffects.screen_sequence import sequence_motion
from StageEffects.vmd_codec import parse_vmd,write_vmd


class ScreenSequenceTimingTests(unittest.TestCase):
    def test_animation_preserves_screen_hide_and_other_controls(self):
        source = write_vmd('Stage',[('Hide',0,0),('Hide',5,0),('Hide',6,1),
                                    ('Hide',11,1),('Hide',12,0),('Hide',17,0),
                                    ('Floor',0,.5),('Floor',17,.25)])
        motion = parse_vmd(sequence_motion('Stage',source,'Hide',['Seq000','Seq001'],2))
        tracks = {}
        for key in motion['morph_frames']:
            tracks.setdefault(key['name'],{})[key['frame']] = key['weight']
        self.assertEqual(tracks.pop('Floor'),{0:.5,17:.25})
        self.assertNotIn('Hide',tracks)
        for frame in range(18):
            active = []
            for i,(name,track) in enumerate(sorted(tracks.items())):
                previous = max(key for key in track if key<=frame)
                if track[previous]==int(i>0):
                    active.append(i)
            self.assertEqual(active,[] if 6<=frame<12 else [(frame//2)%2])
