import tempfile
import unittest
from pathlib import Path

from StageEffects.vmd_codec import write_vmd, parse_vmd, VMDError
from StageEffects.vmd_compare import compare


class VMDCodecTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.a=self.root/'a.vmd'
        self.b=self.root/'b.vmd'

    def test_morph_only_and_anchor_variants_are_structurally_valid(self):
        morphs=[('Phase1',0,0.0),('Phase1',30,1.0)]
        self.a.write_bytes(write_vmd('UnitStage',morphs))
        self.b.write_bytes(write_vmd('UnitStage',morphs,[('center',0,(0,0,0),(0,0,0,1))]))
        a=parse_vmd(self.a);b=parse_vmd(self.b)
        self.assertEqual(a['bone_keys'],0)
        self.assertEqual(b['bone_keys'],1)
        self.assertEqual(a['morph_frames'],b['morph_frames'])
        self.assertEqual(b['bone_frames'][0]['position'],(0.0,0.0,0.0))
        self.assertEqual(b['bone_frames'][0]['rotation'],(0.0,0.0,0.0,1.0))

    def test_strict_parser_rejects_trailing_bytes(self):
        payload=write_vmd('UnitStage',[('Phase1',0,1.0)])+b'X'
        with self.assertRaises(VMDError):parse_vmd(payload)

    def test_vmd_name_limits_are_byte_based(self):
        with self.assertRaises(VMDError):write_vmd('A'*21,[('Phase1',0,1.0)])
        with self.assertRaises(VMDError):write_vmd('UnitStage',[('MorphNameTooLong123',0,1.0)])
        with self.assertRaises(VMDError):write_vmd('UnitStage',[('Phase\x001',0,1.0)])

    def test_vmd_rejects_long_bone_names_instead_of_truncating(self):
        with self.assertRaises(VMDError):
            write_vmd('UnitStage',[],[('stage_model_N_01',0,(0,0,0),(0,0,0,1))])

    def test_structural_compare_reports_anchor_difference(self):
        morphs=[('Phase1',0,0.0),('Phase1',30,1.0)]
        self.a.write_bytes(write_vmd('UnitStage',morphs))
        self.b.write_bytes(write_vmd('UnitStage',morphs,[('center',0,(0,0,0),(0,0,0,1))]))
        result=compare(self.a,self.b)
        self.assertTrue(result['model_name_equal'])
        self.assertTrue(result['morph_track_names_equal'])
        self.assertFalse(result['bone_track_names_equal'])
        self.assertEqual(result['left']['bone_keys'],0)
        self.assertEqual(result['right']['bone_keys'],1)


if __name__=='__main__':unittest.main()
