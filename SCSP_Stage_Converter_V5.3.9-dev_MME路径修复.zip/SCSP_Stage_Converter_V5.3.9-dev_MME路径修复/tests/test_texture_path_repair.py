from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "PMXExporter"))

from texture_path_repair import repair_texture_references, _is_absolute_reference


class TexturePathRepairTests(unittest.TestCase):
    def test_actual_182_superd_48_name_mappings(self):
        fixture = json.loads(
            (ROOT / "tests" / "fixtures" / "182_superd_texture_path_mapping.json")
            .read_text(encoding="utf-8")
        )
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            texture_dir = output / "textures"
            texture_dir.mkdir()
            pmx = output / "182_SuperD.pmx"
            pmx.write_bytes(b"PMX fixture")
            refs = [item["pmx_reference"] for item in fixture]
            expected = {}
            for item in fixture:
                source = texture_dir / item["source_file"]
                content = ("image:" + item["source_file"]).encode("utf-8")
                source.write_bytes(content)
                expected[item["pmx_reference"]] = content

            result = repair_texture_references(pmx, refs, texture_dir)
            self.assertEqual(result["status"], "PASSED")
            self.assertEqual(result["reference_count"], 48)
            self.assertEqual(result["resolved_count"], 48)
            self.assertEqual(result["alias_count"], 48)
            self.assertEqual(result["unresolved_count"], 0)
            for ref, content in expected.items():
                target = output / Path(ref)
                self.assertTrue(target.is_file(), ref)
                self.assertEqual(target.read_bytes(), content, ref)


    def test_windows_absolute_reference_detection(self):
        self.assertTrue(_is_absolute_reference(r"G:\STAGE\Output\textures\wall.png"))
        self.assertTrue(_is_absolute_reference("G:/STAGE/Output/textures/wall.png"))
        self.assertTrue(_is_absolute_reference(r"\\server\share\textures\wall.png"))
        self.assertFalse(_is_absolute_reference("textures/wall.png"))

    def test_missing_texture_is_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            (output / "textures").mkdir()
            pmx = output / "stage.pmx"
            pmx.write_bytes(b"PMX fixture")
            result = repair_texture_references(
                pmx, ["textures/missing.png"], output / "textures"
            )
            self.assertEqual(result["status"], "FAILED")
            self.assertEqual(result["unresolved_count"], 1)

    def test_ambiguous_hash_candidates_fail_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            texture_dir = output / "textures"
            texture_dir.mkdir()
            pmx = output / "stage.pmx"
            pmx.write_bytes(b"PMX fixture")
            (texture_dir / "same_11111111.png").write_bytes(b"A")
            (texture_dir / "same_22222222.png").write_bytes(b"B")
            result = repair_texture_references(
                pmx, ["textures/same.png"], texture_dir
            )
            self.assertEqual(result["status"], "FAILED")
            self.assertEqual(result["ambiguous_count"], 1)
            self.assertFalse((texture_dir / "same.png").exists())


if __name__ == "__main__":
    unittest.main()
