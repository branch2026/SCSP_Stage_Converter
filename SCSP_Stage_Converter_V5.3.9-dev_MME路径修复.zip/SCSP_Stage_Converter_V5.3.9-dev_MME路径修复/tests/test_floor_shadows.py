from pathlib import Path
from struct import pack_into
from tempfile import TemporaryDirectory
import unittest

from StageEffects.floor_shadows import disable_floor_shadows
from StageEffects.mme_preview import floor_glow_shader
from StageEffects.pmx_binary import Model
from test_stage_effects_v31 import pmx_fixture_multi_material, ss


def floor_fixture():
    base = Model(pmx_fixture_multi_material())
    data = bytearray(base.data)
    points = [(0,0,0),(2,0,0),(0,0,2),(.1,.05,.1),(1,.05,.1),(.1,.05,1)]
    for at, point in zip(base.vertex_offsets,points):
        pack_into('<6f',data,at,*point,0,1,0)
    for slot in base.materials:
        data[slot.diffuse_at+44]=0x1f
    return Model(data.replace(ss('MatA'),ss('floor')).replace(ss('MatB'),ss('shadow_decal')))


class FloorShadowTests(unittest.TestCase):
    def test_explicit_ground_shadow_faces_are_removed_with_stable_material_slots(self):
        model = floor_fixture()
        with TemporaryDirectory() as directory:
            path = Path(directory)
            shader = path/'shader.shader'
            shader.write_text('Shader "Custom/AllinOne(ParticleSystem)" {}','utf8')
            material = path/'shadow.mat'
            material.write_text('      _BlendSrc: 2\n      _BlendDst: 0\n','utf8')
            reference = [dict(name='shadow_decal',path=str(material),shader_guid='shader')]
            cleaned, report = disable_floor_shadows(model,reference,{'shader':shader},12.5)
            protected,_ = disable_floor_shadows(model,reference,{'shader':shader},12.5,{1})
        self.assertEqual(cleaned.textures,model.textures)
        self.assertEqual([slot.name for slot in cleaned.materials],['floor','shadow_decal'])
        self.assertEqual([slot.faces for slot in cleaned.materials],[3,0])
        self.assertEqual(protected.materials[1].faces,3)
        self.assertEqual(cleaned.data[cleaned.materials[0].diffuse_at+44],0x11)
        self.assertEqual(cleaned.data[cleaned.materials[1].diffuse_at+44],0x1d)
        self.assertEqual(report['shadow_faces'][0]['faces_removed'],1)

    def test_floor_glow_and_vertical_geometry_have_distinct_passes(self):
        code = floor_glow_shader(1.8)
        self.assertIn('clip(input.isFloor - 0.5);',code)
        self.assertIn('clip(0.5 - input.isFloor);',code)
        self.assertIn('SrcBlend = ONE; DestBlend = ONE;',code)
        self.assertIn('ZWriteEnable = false;',code)
