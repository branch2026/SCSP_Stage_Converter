import unittest

from StageEffects.mme_preview import shader_text
from StageEffects.point_mask_geometry import covered_polygons
from StageEffects.timeline_light_meshes import DOT_LIGHT_TEXTURES, SHADER, light_mesh_shader, uses_dot_light_mask


class DotLightTests(unittest.TestCase):
    def test_timeline_mesh_uses_point_alpha_only_for_verified_textures(self):
        main,light = DOT_LIGHT_TEXTURES
        self.assertTrue(uses_dot_light_mask(SHADER,{'_MainTex':main,'_LightTex':light}))
        self.assertFalse(uses_dot_light_mask(SHADER,{'_MainTex':main,'_LightTex':'different'}))
        layers = dict(main=((45,1,0,0),(0,0)),light=((3,2,-1,-1),(-1.5,0)),light_file='Light.png')
        masked = light_mesh_shader(0,layers,1,(1,1,1),'CCW',alpha_mask=True)
        self.assertIn('clip(base.a - 0.00392157)',masked)
        self.assertIn('(base.rgb * tint + light) * base.a',masked)
        self.assertIn('ZWriteEnable = false',masked)
        self.assertIn('SrcBlend = ONE; DestBlend = ONE',masked)
        opaque = light_mesh_shader(0,layers,1,(1,1,1),'CCW')
        self.assertIn('return float4(base + light, 1)',opaque)
        self.assertIn('ZWriteEnable = true',opaque)

    def test_existing_pmx_slot_masks_entire_lighting_result(self):
        code = shader_text(dict(mode='masked_scrolling_light',src='ONE',dst='ONE',
                                zwrite=False,cutoff=None,light=1,point_mask_uv=(45,1,0,0)))
        self.assertLess(code.index('clip(base.a'),code.index('base.rgb += tex2D'))
        self.assertLess(code.index('base.rgb += tex2D'),code.index('base = float4(base.rgb * base.a, 0.0)'))
        self.assertIn('ZWriteEnable = false',code)

    def test_triangle_mesh_covers_only_the_76_opaque_texels_per_tile(self):
        full_tile = [((0,0),(1,0),(1,1)), ((0,0),(1,1),(0,1))]
        area = 0
        for triangle in full_tile:
            for polygon in covered_polygons(triangle):
                area += abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(polygon,polygon[1:]+polygon[:1])))/2
        self.assertAlmostEqual(area, 76/1024)

