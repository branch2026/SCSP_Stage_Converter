import unittest

from StageEffects.camera_ripples import shader


class CameraRippleTests(unittest.TestCase):
    def test_ring_is_one_shot_and_uses_source_atlas_and_distortion(self):
        result = shader(23.733333587646484,.6,(1.625,0,8.875),[(0,0),(1,12.5)],
                        [(0,0),(.138,.447),(1,0)],(1,.97,0),.02,1)
        self.assertIn('Seconds - 23.73333359',result)
        self.assertIn('1.0 - step(0.60000000, age)', result)
        self.assertIn('min(5.0, floor(phase * 6.0))',result)
        self.assertIn('RippleDistortion.png',result)
        self.assertIn('ZEnable = false',result)
        self.assertEqual(result.count('compile vs_2_0'),result.count('compile ps_2_0'))
