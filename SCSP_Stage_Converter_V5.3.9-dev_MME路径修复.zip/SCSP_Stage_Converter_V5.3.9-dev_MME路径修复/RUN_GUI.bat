@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
py -3 "%~dp0gui.py"
set "SCSP_EXIT=%ERRORLEVEL%"
if not "%SCSP_EXIT%"=="0" (
    echo.
    echo SCSP Stage Converter GUI stopped with exit code %SCSP_EXIT%.
    pause
)
exit /b %SCSP_EXIT%
