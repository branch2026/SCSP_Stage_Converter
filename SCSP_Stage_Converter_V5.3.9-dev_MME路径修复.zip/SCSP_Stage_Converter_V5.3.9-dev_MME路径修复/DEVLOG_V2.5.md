# V2.5-dev 开发日志

## 目标

将 V2.4.10-dev 诊断能力收敛为稳定化候选版本，新增转换核心完整性保护，不改变已验证的转换行为。

## 开发基线

- Source ZIP: `SCSP_Stage_Converter_V2.4.10-dev_NormalInactiveAssociation.zip`
- SHA-256: `ec3cdfbcf0548ff1c09bca25edebb23a13c6a2d2c244f53214978eca3662a4d1`
- Rollback ZIP: `SCSP_Stage_Converter_V2.3.2-dev_FolderBatchRebuild.zip`
- Rollback SHA-256: `89ed0cce226e20bb5df36ac140aafabe1d8d4954e68f121ac389c5c056b3805e`

## 本次实现

1. 从 V2.4.10-dev 原始 ZIP 解压建立独立 V2.5-dev 工作目录。
2. 原样保留 15 个受保护转换文件。
3. 新增 `tests/test_conversion_core_integrity.py`，逐个核验 15 个受保护文件。
4. 15 个文件的哈希与 V2.4.10-dev 清单一致，也与 V2.4.1 中记录的 V2.3.2 原始比较哈希一致。
5. GUI 仅将 4 处 `V2.4.10` 版本文字替换为 `V2.5`；新增测试可反向还原并核对原始 GUI SHA-256。
6. 不触碰 SceneBuilder、PMXExporter、批量场景发现、源校验和启动脚本的受保护转换文件。

## 正式版收尾

2026-11-21 完成双舞台产物核对，并在 Windows 上重跑自动化测试。详细结果见 TEST_RESULTS_V2.5.txt。
