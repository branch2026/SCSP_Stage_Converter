@echo off
setlocal
cd /d "%~dp0"
title SCSP V2.4.10 WARNING / 法线关联诊断

set "PYEXE="
where py >nul 2>&1
if not errorlevel 1 (
    py -3 --version >nul 2>&1
    if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
    where python >nul 2>&1
    if not errorlevel 1 (
        python --version >nul 2>&1
        if not errorlevel 1 set "PYEXE=python"
    )
)
if not defined PYEXE (
    echo [ERROR] 未找到可用的 Python 3。
    echo 请先安装 Python 3，并确保 py -3 或 python 命令可用。
    pause
    exit /b 2
)

%PYEXE% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] 当前 Python 缺少 Tkinter，无法显示文件选择窗口。
    echo 请使用包含 Tkinter 的 python.org Windows 安装版 Python。
    pause
    exit /b 3
)

%PYEXE% "Validator\diagnose_warnings.py" --gui
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo.
    echo [ERROR] WARNING 诊断程序退出，代码：%RC%
    pause
)
exit /b %RC%
