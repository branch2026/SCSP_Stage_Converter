# V2.4.4-dev 开发记录

## 源码审计发现
V2.4.3 已经能够输出缺失法线 / UV0 Mesh 的 GUID、fileID、资源路径、GameObject fileID 与 Hierarchy 路径，因此 V2.4.4 不重复实现已有字段。

审计发现两个定位层面的不足：
1. V2.4.3 从所选舞台根对象开始以 `parent_active=True` 计算 `activeInHierarchy`。这在根对象位于 inactive 外部父级下时，不等于 Unity 全局 `activeInHierarchy`。同时，转换器本身也是直接从所选根对象开始遍历，因此全局状态与转换纳入决策必须分开。
2. MeshFilter 解析结果没有保留组件自身的序列化 fileID，报告只能写 `MeshFilter xN`，不能精确指向具体组件。空 Mesh 引用也只有数量，没有对应组件位置。

## V2.4.4 处理方式
- 只在 `Validator/quality_check.py` 中增加只读祖先链检查与 MeshFilter fileID 索引，不修改 SceneBuilder 的解析 / 重建代码。
- `activeInHierarchy` 包含所选根对象外部的祖先 active 状态。
- `activeWithinSelectedRoot` 单独反映从所选根对象开始的内部层级状态。
- `conversionIncluded` 仍严格遵循原转换器的 root-start 遍历策略：include 模式纳入全部选中子树；exclude 模式排除所选根对象子树内部被 inactive 自身或祖先阻断的对象。
- 输出 inactive 原因对象与转换决定，方便从 Mesh 缺失记录直接定位。
- 通过同一 YAML 文档解析器读取 class 33 MeshFilter 组件 ID，并按 GameObject + Mesh GUID + Mesh fileID 对应到每个 Mesh occurrence；同一对象重复引用相同 Mesh 时按组件文档顺序逐个配对。

## 回归保护
- V2.4.3 自动化基线：55 tests passed。
- V2.4.4 自动化：58 tests passed。
- 保护文件与 V2.4.3 的 SHA-256 对照记录在 `BASELINE_INTEGRITY_V2.4.4.txt`。
- 不把已有 185_SankaF 报告离线对照冒充成当前环境的 Windows 实机重新转换。
